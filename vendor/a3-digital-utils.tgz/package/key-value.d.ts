export declare class KeyValue<T> {
    [key: string]: T;
}
