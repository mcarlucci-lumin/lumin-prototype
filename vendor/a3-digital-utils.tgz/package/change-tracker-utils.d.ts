import { FieldChange } from './field-change.js';
export declare function formatFieldChanges(changes: FieldChange[], separator?: string, labels?: {
    fieldName: string;
    label: string;
}[], valueFormatter?: (fieldName: any, value: any) => string): string;
export declare function defaultValueFormatter(fieldName: any, value: any): string;
