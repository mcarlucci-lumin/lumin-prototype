import { NumberList } from './number-list.js';
export declare class NumberUtils {
    private static numberFormatter;
    private static numberFormatterNoDecimals;
    static currencyAmountsEqual(amount1: number, amount2: number): boolean;
    static formatNumber(value: number, noDecimals?: boolean): string;
    static formatCurrency(value: number, noCents?: boolean): string;
    static formatCurrency2(value: number, options?: {
        locale?: string;
        includeFractionalDigits?: boolean;
        alphaCode?: string;
    }): string;
    static formatCurrencyRoundIfNoCents(value: number): string;
    /**
     * Parses a formatted amount string into a signed number, or undefined when it holds no number.
     *
     * Accepts a currency symbol, thousands separators, a percent sign, a minus either before or after
     * the symbol, and accounting-style brackets for negatives. A percentage yields its bare number, so
     * the unit is only recoverable from the original string.
     */
    static parseCurrency(value: string): number | undefined;
    static sum(...values: number[]): number;
    static parseNumberListAndRanges(listAndRanges: string): NumberList;
    static getIntWithDefault(value: string, defaultValue: any): any;
}
