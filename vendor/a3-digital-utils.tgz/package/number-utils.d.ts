import { NumberList } from './number-list.js';
export declare class NumberUtils {
    private static numberFormatter;
    private static numberFormatterNoDecimals;
    static currencyAmountsEqual(amount1: number, amount2: number): boolean;
    static formatNumber(value: number, noDecimals?: boolean): string;
    static formatCurrency(value: number, noCents?: boolean): string;
    static formatCurrency2(value: number, options?: {
        locale?: string;
        includeFractionalDigits?: boolean;
        alphaCode?: string;
    }): string;
    static formatCurrencyRoundIfNoCents(value: number): string;
    static sum(...values: number[]): number;
    static parseNumberListAndRanges(listAndRanges: string): NumberList;
    static getIntWithDefault(value: string, defaultValue: any): any;
}
