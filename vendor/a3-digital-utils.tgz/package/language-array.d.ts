export interface Language {
    code: string;
    name: string;
    nativeName?: string;
}
export declare class LanguageArray extends Array<Language> {
    readonly English: Language;
    constructor(languages: Language[], englishLanguage: Language);
}
