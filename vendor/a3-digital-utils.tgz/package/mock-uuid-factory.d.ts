import { UuidFactory } from './uuid-factory.js';
export declare class MockUuidFactory extends UuidFactory {
    private testUuids;
    private testIndex;
    constructor();
    setTestUuids(testUuids: string[]): void;
    create(): string;
}
