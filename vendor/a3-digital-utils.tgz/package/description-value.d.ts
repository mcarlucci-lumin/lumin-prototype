export declare class DescriptionValue {
    description: string;
    value: string;
}
