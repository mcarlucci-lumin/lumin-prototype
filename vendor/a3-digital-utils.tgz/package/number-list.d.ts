export declare class NumberList {
    data: {};
    constructor(data?: any);
    includes(num: number): boolean;
    add(num: number): void;
    toArray(): number[];
}
