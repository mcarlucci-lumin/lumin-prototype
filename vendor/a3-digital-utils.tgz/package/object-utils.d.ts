export declare class ObjectUtils {
    static getPropertyValue(item: any, propertyExpression: string): any;
    static setPropertyValue(item: any, propertyExpression: string, value: any, initalizeParentPropertyIfMissing: boolean): void;
    static overlayProperties(dest: any, src: any, ignoreValues?: any[]): void;
}
