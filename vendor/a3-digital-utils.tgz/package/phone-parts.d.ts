import { Country } from './countries.js';
export declare class PhoneParts {
    dialCode: string;
    country: Country;
    number: string;
    fullNumber: string;
    raw: string;
    partialCountryMatches: Country[];
}
