export declare class CsvUtils {
    /**
     * Encodes one text cell for a CSV export. A cell starting with a spreadsheet formula trigger
     * (`=`, `+`, `-`, `@`, tab or CR) gets a leading single quote so it opens as text, not a formula.
     * Cells containing a comma, a double quote or whitespace other than a plain space are RFC 4180
     * quoted with embedded quotes doubled. Returns an empty string for a null or empty value.
     *
     * Not for numeric or currency cells: the guard would turn a negative amount into text.
     */
    static encodeField(value: string): string;
}
