import { Language } from './language.js';
export { Language };
export declare const LANGUAGE_CODES: {
    English: string;
    Spanish: string;
    Burmese: string;
};
export declare const LANGUAGE_WILDCARD = "*";
export declare class LanguageHelper {
    static get defaultLanguageCode(): string;
    /**
     * English as a Language. Unlike getLanguage, this never reads GlobalSettings, so it is safe
     * where configuration may not be initialized (e.g. date formatting).
     */
    static get defaultLanguage(): Language;
    /**
     * The FI's enabled languages, English first. Reads GlobalSettings.supportedLanguages, which
     * holds codes in addition to English. Any well-formed language code is accepted — there is no
     * catalog, so a new language needs no code change. Malformed codes are dropped; see
     * {@link invalidLanguageCodes}.
     */
    static get supportedLanguages(): Language[];
    /**
     * Codes in GlobalSettings.supportedLanguages that were dropped because they are not well-formed
     * language tags. This helper has no logger, so callers should log these.
     */
    static get invalidLanguageCodes(): string[];
    /**
     * Language codes a validator should accept: the configured languages plus the built-in
     * en/es/my, so content saved before a language was unconfigured stays valid and editable.
     */
    static get acceptedLanguageCodes(): string[];
    static displayName(code: string): string;
    static isLanguageCodeSupported(code: string): boolean;
    static getLanguage(languageCode: string): Language;
    private static get configuredCodes();
}
