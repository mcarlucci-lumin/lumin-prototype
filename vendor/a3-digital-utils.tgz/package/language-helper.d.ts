import { Language, LanguageArray } from './language-array.js';
export { Language };
export declare const LANGUAGE_CODES: {
    English: string;
    Spanish: string;
    Burmese: string;
};
export declare const LANGUAGES: LanguageArray;
export declare const LANGUAGE_WILDCARD = "*";
export declare class LanguageHelper {
    static get defaultLanguageCode(): string;
    /**
     * The FI's enabled languages, English first. Reads GlobalSettings.supportedLanguages, which
     * holds codes in addition to English. Codes with no LANGUAGES entry are dropped — this
     * catalog is the whitelist, so a new language needs an entry here and a publish.
     */
    static get supportedLanguages(): Language[];
    static displayName(code: string): string;
    static isLanguageCodeSupported(code: string): boolean;
    static getLanguage(languageCode: string): Language;
}
