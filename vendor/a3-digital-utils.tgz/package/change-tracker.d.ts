import { FieldChange } from './field-change.js';
import { CalculatedFieldTracker } from './calculated-field-tracker.js';
export declare class ChangeTracker<T> {
    private calculatedFieldTrackers?;
    private original;
    private calculatedFields;
    private current;
    constructor(item: T, calculatedFieldTrackers?: CalculatedFieldTracker<T>[]);
    private evaluateCalculatedFields;
    getChanges(): FieldChange[];
    isDate(input: any): boolean;
    isEmpty(input: any): boolean;
    fieldModified(originalValue: any, newValue: any): boolean;
}
