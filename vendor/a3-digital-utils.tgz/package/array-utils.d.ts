import { SortField } from './sort-field.js';
export declare class ArrayUtils {
    static getUniqueFieldValues<T>(array: any[], fieldName: string): Array<T>;
    static getUniqueExpressionValues<T>(array: any[], exp: (x: any) => T): Array<T>;
    static createKeyValuesMap<T>(array: T[], keyFieldName: string): {
        keys: string[];
    };
    static createExpressionKeyValuesMap<T>(array: T[], exp: (x: T) => string): {
        keys: string[];
    };
    static findMax<T>(array: T[], expression: (item: T) => any): T;
    static findMin<T>(array: T[], expression: (item: T) => any): T;
    static moveItem(array: any[], fromIndex: number, toIndex: number): any[];
    static compareValues(a: any, b: any): number;
    static sortByField<T>(array: Array<T>, fieldName: string, descending?: boolean): Array<T>;
    static sortByFields<T>(array: Array<T>, ...sortFields: Array<SortField>): Array<T>;
    static shuffleArray<T>(array: Array<T>): Array<T>;
    static sumFieldValue(items: Array<any>, fieldName: string): number;
}
