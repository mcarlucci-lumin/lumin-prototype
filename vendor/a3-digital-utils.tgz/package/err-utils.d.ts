export declare class ErrUtils {
    static isTiemoutError(err: any): boolean;
}
