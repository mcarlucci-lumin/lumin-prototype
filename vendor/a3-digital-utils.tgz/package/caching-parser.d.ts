export declare class CachingParser<T> {
    private parseFn;
    private parsedValues;
    constructor(parseFn: (text: string) => T);
    parse(text: string): T;
}
