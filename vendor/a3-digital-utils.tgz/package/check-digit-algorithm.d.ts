export declare enum CheckDigitAlgorithm {
    LUHN = "Luhn",
    MOD9 = "Mod9"
}
