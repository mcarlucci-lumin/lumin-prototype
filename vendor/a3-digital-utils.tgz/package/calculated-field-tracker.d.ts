export interface CalculatedFieldTracker<T> {
    fieldName: string;
    getValue: (T: any) => string;
}
