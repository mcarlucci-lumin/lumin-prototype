export interface State {
    abbr: string;
    name: string;
}
export declare const STATES: State[];
