export declare class KeyValuePair {
    [key: string]: string;
}
