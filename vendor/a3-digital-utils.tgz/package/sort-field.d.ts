export declare class SortField {
    fieldName: string;
    descending?: boolean;
}
