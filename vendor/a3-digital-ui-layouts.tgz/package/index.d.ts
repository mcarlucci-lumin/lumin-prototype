import * as i5 from '@a3-digital/ui-core';
import { BaseTextComponent, TextService, WindowService } from '@a3-digital/ui-core';
import * as i0 from '@angular/core';
import { TemplateRef, EventEmitter } from '@angular/core';
import * as i3 from '@angular/common';
import * as i4 from '@ng-bootstrap/ng-bootstrap';

declare enum PageLayoutMode {
    DASHBOARD = "dashboard",
    FULL_SCREEN = "full-screen",
    NONE = "none",
    SIDEBAR = "sidebar",
    UNAUTHENTICATED = "unauthenticated"
}

/**
 * An internal, UI-team-owned page shell. Do not use this component directly — it is not approved
 * for general use. Only Sidebar mode (side column, header, main content, and footer) and Full-screen
 * mode (the same without the side column) have been fully vetted so far. The other modes this
 * component supports exist to serve the UI team's own in-progress work and are not yet ready
 * to be built against.
 *
 * In web-client, most module components should simply extend ModuleBaseComponent (from a3/core) —
 * it wires up ModulePageLayoutComponent, and through it this component's sidebar mode, for free.
 * If a module has a use case ModuleBaseComponent genuinely can't handle, use
 * ModulePageLayoutComponent directly instead; it wires the header and side templates to the app's
 * standard header and side menu, and reads back-button, header detail, and footer state from
 * PageLayoutService, so individual pages don't have to. Reaching for this component itself should
 * not currently be necessary in application code.
 */
declare class PageLayoutComponent extends BaseTextComponent {
    private windowService;
    protected textService: TextService;
    /**
     * The mode of the page layout.
     * dashboard: only to be used on dashboard and related pages (like accounts)
     * full-screen: main content + header + footer, no side column
     * sidebar: side nav + main content + header + footer
     * unauthenticated: main content + footer
     */
    mode: PageLayoutMode;
    /**
     * Optional template to use as a header element.
     */
    headerTemplate: TemplateRef<any>;
    /**
     * Optional template to use as a side element
     */
    sideTemplate: TemplateRef<any>;
    /**
     * Optional template to use as a footer element.
     */
    footerTemplate: TemplateRef<any>;
    /**
     * Set to give the body (everything below the header, including the footer) the sunken
     * background instead of white. Suits pages made of cards.
     */
    sunkenBackground: boolean;
    /**
    * Set when the page shows a full-screen glass background.
    * On mobile, the empty space below the content stays transparent so the glass shows through
    * instead of being covered with white.
    **/
    fullScreenGlass: boolean;
    /**
    * Specifies whether the page is in a loading state.
    * If true, a loading spinner will be displayed instead of the page content.
    **/
    loading: boolean;
    /**
    * Optional message to display when the page is in a loading state.
    * If not provided, the default loading message will be shown.
    **/
    loadingMessage: string;
    isDesktop: boolean;
    isMobile: boolean;
    readonly PageLayoutMode: typeof PageLayoutMode;
    constructor(windowService: WindowService, textService: TextService);
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageLayoutComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PageLayoutComponent, "ui-layouts-page", never, { "mode": { "alias": "mode"; "required": false; }; "headerTemplate": { "alias": "headerTemplate"; "required": false; }; "sideTemplate": { "alias": "sideTemplate"; "required": false; }; "footerTemplate": { "alias": "footerTemplate"; "required": false; }; "sunkenBackground": { "alias": "sunkenBackground"; "required": false; }; "fullScreenGlass": { "alias": "fullScreenGlass"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; "loadingMessage": { "alias": "loadingMessage"; "required": false; }; }, {}, never, ["*"], false, never>;
}

/**
 * An internal, UI-team-owned page shell for multi-step flows: a centered card with a title, subtitle,
 * progress bar, the step content, and a Cancel / Back / Next action row. Not yet approved for
 * general use.
 *
 * The layout owns the action buttons and only emits events — the host decides what Next, Back and
 * Cancel do. On mobile, Cancel is never shown (the app's top nav owns closing a wizard) and Next is
 * stacked above Back.
 */
declare class WizardLayoutComponent extends BaseTextComponent {
    private windowService;
    protected textService: TextService;
    /**
     * The step's title, rendered as the page's h1.
     * The header (title and subtitle) is not rendered when this is empty.
     */
    headerTitle: string;
    /**
     * Optional text shown below the title.
     */
    subtitle: string;
    /**
     * The number of completed steps shown by the progress bar.
     * Start at 0 for a "get started" step with zero progress.
     */
    currentStep: number;
    /**
     * The total number of steps. The progress bar is not rendered when this is 0.
     */
    totalSteps: number;
    /**
     * Set to false to hide the progress bar.
     */
    showProgressBar: boolean;
    /**
     * Set to false to hide the whole Cancel / Back / Next row, for hosts that
     * render their own buttons inside the projected content.
     */
    showActions: boolean;
    /**
     * Set to false to hide the Back button, e.g. on the first step.
     */
    showBackButton: boolean;
    /**
     * Set to false to hide the Cancel button. Cancel is always hidden on mobile.
     */
    showCancelButton: boolean;
    /**
     * Next button label. Defaults to "Next".
     */
    nextButtonText: string;
    /**
     * Back button label. Defaults to "Back".
     */
    backButtonText: string;
    /**
     * Cancel button label. Defaults to "Cancel".
     */
    cancelButtonText: string;
    /**
     * Disables the Next button.
     */
    nextButtonDisabled: boolean;
    /**
     * Shows a spinner in the Next button, e.g. while the step is saving.
     */
    nextButtonLoading: boolean;
    /**
     * Set to give the step content the sunken background instead of white.
     */
    sunkenBackground: boolean;
    /**
     * Optional template for compliance content (NCUA / FDIC notice, copyright, etc.).
     * Rendered in its own card below the wizard on tablet and desktop, and inside the wizard,
     * centered under the action row, on mobile.
     */
    footerTemplate: TemplateRef<any>;
    /**
     * Emits when the Next button is clicked.
     */
    nextClicked: EventEmitter<void>;
    /**
     * Emits when the Back button is clicked.
     */
    backClicked: EventEmitter<void>;
    /**
     * Emits when the Cancel button is clicked.
     */
    cancelClicked: EventEmitter<void>;
    isDesktop: boolean;
    isMobile: boolean;
    constructor(windowService: WindowService, textService: TextService);
    get showProgress(): boolean;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<WizardLayoutComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WizardLayoutComponent, "ui-layouts-wizard", never, { "headerTitle": { "alias": "headerTitle"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "currentStep": { "alias": "currentStep"; "required": false; }; "totalSteps": { "alias": "totalSteps"; "required": false; }; "showProgressBar": { "alias": "showProgressBar"; "required": false; }; "showActions": { "alias": "showActions"; "required": false; }; "showBackButton": { "alias": "showBackButton"; "required": false; }; "showCancelButton": { "alias": "showCancelButton"; "required": false; }; "nextButtonText": { "alias": "nextButtonText"; "required": false; }; "backButtonText": { "alias": "backButtonText"; "required": false; }; "cancelButtonText": { "alias": "cancelButtonText"; "required": false; }; "nextButtonDisabled": { "alias": "nextButtonDisabled"; "required": false; }; "nextButtonLoading": { "alias": "nextButtonLoading"; "required": false; }; "sunkenBackground": { "alias": "sunkenBackground"; "required": false; }; "footerTemplate": { "alias": "footerTemplate"; "required": false; }; }, { "nextClicked": "nextClicked"; "backClicked": "backClicked"; "cancelClicked": "cancelClicked"; }, never, ["*"], false, never>;
}

declare class UiLayoutsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UiLayoutsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UiLayoutsModule, [typeof PageLayoutComponent, typeof WizardLayoutComponent], [typeof i3.CommonModule, typeof i4.NgbModule, typeof i5.UiCoreModule], [typeof PageLayoutComponent, typeof WizardLayoutComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UiLayoutsModule>;
}

export { PageLayoutComponent, PageLayoutMode, UiLayoutsModule, WizardLayoutComponent };
