import * as i4 from '@a3-digital/ui-core';
import { BaseTextComponent, TextService, WindowService } from '@a3-digital/ui-core';
import * as i0 from '@angular/core';
import { TemplateRef } from '@angular/core';
import * as i2 from '@angular/common';
import * as i3 from '@ng-bootstrap/ng-bootstrap';

declare enum PageLayoutMode {
    BASIC = "basic",
    DASHBOARD = "dashboard",
    NONE = "none",
    SIDEBAR = "sidebar",
    UNAUTHENTICATED = "unauthenticated",
    WIZARD = "wizard"
}

/**
 * An internal, UI-team-owned page shell. Do not use this component directly — it is not approved
 * for general use. Only the sidebar mode (side column, header, main content, and footer, with a
 * glass background behind the side column) has been fully vetted so far. The other modes this
 * component supports exist to serve the UI team's own in-progress work and are not yet ready to
 * be built against.
 *
 * In web-client, most module components should simply extend ModuleBaseComponent (from a3/core) —
 * it wires up ModulePageLayoutComponent, and through it this component's sidebar mode, for free.
 * If a module has a use case ModuleBaseComponent genuinely can't handle, use
 * ModulePageLayoutComponent directly instead; it wires the header and side templates to the app's
 * standard header and side menu, and reads back-button, header detail, and footer state from
 * PageLayoutService, so individual pages don't have to. Reaching for this component itself should
 * not currently be necessary in application code.
 */
declare class PageLayoutComponent extends BaseTextComponent {
    private windowService;
    protected textService: TextService;
    /**
     * The mode of the page layout.
     * basic: main content + header + footer
     * dashboard: only to be used on dashboard and related pages (like accounts)
     * sidebar: side + main content + header + footer, glass on side
     * unauthenticated: main content + footer
     * wizard: main content
     */
    mode: PageLayoutMode;
    /**
     * Optional template to use as a header element.
     */
    headerTemplate: TemplateRef<any>;
    /**
     * Optional template to use as a side element
     */
    sideTemplate: TemplateRef<any>;
    /**
    * Optional template to use as a footer element.
    **/
    footerTemplate: TemplateRef<any>;
    /**
    * Specifies whether the page is in a loading state.
    * If true, a loading spinner will be displayed instead of the page content.
    **/
    loading: boolean;
    /**
    * Optional message to display when the page is in a loading state.
    * If not provided, the default loading message will be shown.
    **/
    loadingMessage: string;
    isDesktop: boolean;
    isMobile: boolean;
    readonly PageLayoutMode: typeof PageLayoutMode;
    constructor(windowService: WindowService, textService: TextService);
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageLayoutComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PageLayoutComponent, "ui-layouts-page", never, { "mode": { "alias": "mode"; "required": false; }; "headerTemplate": { "alias": "headerTemplate"; "required": false; }; "sideTemplate": { "alias": "sideTemplate"; "required": false; }; "footerTemplate": { "alias": "footerTemplate"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; "loadingMessage": { "alias": "loadingMessage"; "required": false; }; }, {}, never, ["*"], false, never>;
}

declare class UiLayoutsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UiLayoutsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UiLayoutsModule, [typeof PageLayoutComponent], [typeof i2.CommonModule, typeof i3.NgbModule, typeof i4.UiCoreModule], [typeof PageLayoutComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UiLayoutsModule>;
}

export { PageLayoutComponent, PageLayoutMode, UiLayoutsModule };
