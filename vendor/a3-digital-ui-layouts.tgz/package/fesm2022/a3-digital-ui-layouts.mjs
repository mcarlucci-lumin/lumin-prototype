import * as i1 from '@a3-digital/ui-core';
import { BaseTextComponent, GlassBackgroundLayout, UiCoreModule } from '@a3-digital/ui-core';
import * as i0 from '@angular/core';
import { Input, Component, NgModule } from '@angular/core';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

var PageLayoutMode;
(function (PageLayoutMode) {
    PageLayoutMode["BASIC"] = "basic";
    PageLayoutMode["DASHBOARD"] = "dashboard";
    PageLayoutMode["NONE"] = "none";
    PageLayoutMode["SIDEBAR"] = "sidebar";
    PageLayoutMode["UNAUTHENTICATED"] = "unauthenticated";
    PageLayoutMode["WIZARD"] = "wizard";
})(PageLayoutMode || (PageLayoutMode = {}));

class PageLayoutComponent extends BaseTextComponent {
    constructor(windowService, textService) {
        super(textService, 'ui-layouts-page');
        this.windowService = windowService;
        this.textService = textService;
        /**
         * The mode of the page layout.
         * basic: main content + header + footer
         * dashboard: only to be used on dashboard and related pages (like accounts)
         * sidebar: side + main content + header + footer, glass on side
         * unauthenticated: main content + footer
         * wizard: main content
         */
        this.mode = PageLayoutMode.BASIC;
        /**
        * Specifies whether the page is in a loading state.
        * If true, a loading spinner will be displayed instead of the page content.
        **/
        this.loading = false;
        this.GlassBackgroundLayout = GlassBackgroundLayout;
        this.PageLayoutMode = PageLayoutMode;
        this.windowService.windowSize$.pipe(this.takeUntilDestroyed()).subscribe(windowSize => {
            this.isMobile = windowSize.isMobile;
            this.isDesktop = windowSize.isDesktop;
        });
    }
    getDefaultText() {
        return {
            loadingMessage: 'Loading...',
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: PageLayoutComponent, deps: [{ token: i1.WindowService }, { token: i1.TextService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.17", type: PageLayoutComponent, isStandalone: false, selector: "ui-layouts-page", inputs: { mode: "mode", headerTemplate: "headerTemplate", sideTemplate: "sideTemplate", footerTemplate: "footerTemplate", loading: "loading", loadingMessage: "loadingMessage" }, usesInheritance: true, ngImport: i0, template: "<div class=\"page-container\">\n    @if (mode !== PageLayoutMode.UNAUTHENTICATED && !isMobile) {\n        <ui-core-glass-background-v2 [layout]=\"GlassBackgroundLayout.FULL_SCREEN\">\n        </ui-core-glass-background-v2>\n    }\n    @if (mode === PageLayoutMode.DASHBOARD && isMobile) {\n        <ui-core-glass-background-v2 [layout]=\"GlassBackgroundLayout.DEFAULT\">\n        </ui-core-glass-background-v2>\n    }\n    <div class=\"content-grid\" [class]=\"mode\">\n        @if (mode === PageLayoutMode.SIDEBAR || mode === PageLayoutMode.DASHBOARD) {\n            <aside class=\"side-container\">\n                <ng-container [ngTemplateOutlet]=\"sideTemplate\"></ng-container>\n            </aside>\n        }\n        <section class=\"main-content\">\n            <div class=\"content-body\">\n                @if (headerTemplate && (mode !== PageLayoutMode.WIZARD && mode !== PageLayoutMode.UNAUTHENTICATED)) {\n                    <div class=\"content-header\">\n                        <ng-container [ngTemplateOutlet]=\"headerTemplate\"></ng-container>\n                    </div>\n                }\n                @if (loading) {\n                    <div class=\"d-flex justify-content-center\">\n                        @if (isMobile) {\n                            <h3 class=\"mt-5\">\n                                <ui-core-spinner size=\"h3\" [message]=\"loadingMessage ?? text.loadingMessage\"></ui-core-spinner>\n                            </h3>\n                        } @else {\n                            <h2 class=\"mt-3\">\n                                <ui-core-spinner size=\"h2\" [message]=\"loadingMessage ?? text.loadingMessage\"></ui-core-spinner>\n                            </h2>\n                        }\n                    </div>\n                } @else {\n                    <ng-content></ng-content>\n                }\n            </div>\n            @if (footerTemplate && isDesktop && mode !== PageLayoutMode.WIZARD) {\n                <div class=\"content-footer\">\n                    <div class=\"content-footer-container\">\n                        <ng-container [ngTemplateOutlet]=\"footerTemplate\"></ng-container>\n                    </div>\n                </div>\n            }\n        </section>\n    </div>\n</div>", styles: [":host{display:block;height:100%;width:100%}.page-container{display:flex;flex-direction:column;min-height:100%}@media (min-width: 768px){.page-container{padding:32px}}.content-grid{background-color:var(--color-default);flex-grow:1;width:100%;min-height:0}@media (min-width: 768px){.content-grid{border-radius:14px;box-shadow:var(--elevation-1)}}@media (max-width: 1079.98px){.content-grid{margin-bottom:var(--nav-footer-height)}}.content-grid.basic .main-content{justify-self:center;align-items:center}.content-grid.basic .main-content .content-footer .content-footer-container{justify-self:center}.content-grid.basic .main-content{background-color:var(--color-default)}.content-grid.basic .main-content>.content-body{max-width:75rem}.content-grid.wizard{box-shadow:none;margin:0 auto;max-width:54.5rem}.content-grid.wizard .main-content{justify-self:center;align-items:center}.content-grid.wizard .main-content .content-footer .content-footer-container{justify-self:center}.content-grid.wizard .main-content>.content-body{flex-grow:0;padding:0}.content-grid.unauthenticated{box-shadow:none}.content-grid.unauthenticated .main-content{justify-self:center;align-items:center}.content-grid.unauthenticated .main-content .content-footer .content-footer-container{justify-self:center}.content-grid.unauthenticated .main-content>.content-body{max-width:52.625rem}.content-grid.unauthenticated .main-content>.content-footer{background-color:var(--color-sunken);height:100%}.content-grid.sidebar{display:grid;grid-template-columns:18.75rem 1fr}@media (max-width: 1079.98px){.content-grid.sidebar{grid-template-columns:1fr}.content-grid.sidebar .side-container{display:none}}.content-grid.sidebar .main-content{background-color:var(--color-default)}.content-grid.sidebar .main-content>.content-body{max-width:65.875rem}.content-grid.dashboard{box-shadow:none;max-width:84.625rem;display:grid;grid-template-columns:var(--left-menu-width) 1fr}@media (max-width: 1079.98px){.content-grid.dashboard{grid-template-columns:1fr}.content-grid.dashboard .side-container{display:none}}.content-grid.dashboard .main-content{background-color:transparent}.content-grid.dashboard .side-container{background:none;padding:0 25px 0 0}.content-grid.dashboard .main-content>.content-body{padding:0 32px 26px}.side-container{background:var(--color-sunken);border-top-left-radius:14px;border-bottom-left-radius:14px;border-right:1px solid var(--color-stroke-1);scroll-margin-top:var(--navbar-desktop-height);z-index:1}.main-content{border-top-right-radius:14px;border-bottom-right-radius:14px;display:flex;flex-direction:column;position:relative;width:100%;z-index:1}@media (max-width: 1079.98px){.main-content{border-top-left-radius:14px;border-bottom-left-radius:14px}}.main-content .content-body{display:flex;flex-direction:column;flex-grow:1;flex-shrink:2;min-height:var(--desktop-min-height);padding:40px;width:100%}@media (max-width: 767.98px){.main-content .content-body{padding:0}}.main-content .content-body .content-header{width:100%}.main-content .content-footer{width:100%;padding:25px 40px}.main-content .content-footer .content-footer-container{width:100%}\n"], dependencies: [{ kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: i1.GlassBackgroundV2Component, selector: "ui-core-glass-background-v2", inputs: ["backgroundAccentColorClass", "layout", "animate"] }, { kind: "component", type: i1.SpinnerComponent, selector: "ui-core-spinner", inputs: ["message", "size", "buttonIcon", "hideSpinner", "centered", "delayMs", "buttonSpinner"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: PageLayoutComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-layouts-page', standalone: false, template: "<div class=\"page-container\">\n    @if (mode !== PageLayoutMode.UNAUTHENTICATED && !isMobile) {\n        <ui-core-glass-background-v2 [layout]=\"GlassBackgroundLayout.FULL_SCREEN\">\n        </ui-core-glass-background-v2>\n    }\n    @if (mode === PageLayoutMode.DASHBOARD && isMobile) {\n        <ui-core-glass-background-v2 [layout]=\"GlassBackgroundLayout.DEFAULT\">\n        </ui-core-glass-background-v2>\n    }\n    <div class=\"content-grid\" [class]=\"mode\">\n        @if (mode === PageLayoutMode.SIDEBAR || mode === PageLayoutMode.DASHBOARD) {\n            <aside class=\"side-container\">\n                <ng-container [ngTemplateOutlet]=\"sideTemplate\"></ng-container>\n            </aside>\n        }\n        <section class=\"main-content\">\n            <div class=\"content-body\">\n                @if (headerTemplate && (mode !== PageLayoutMode.WIZARD && mode !== PageLayoutMode.UNAUTHENTICATED)) {\n                    <div class=\"content-header\">\n                        <ng-container [ngTemplateOutlet]=\"headerTemplate\"></ng-container>\n                    </div>\n                }\n                @if (loading) {\n                    <div class=\"d-flex justify-content-center\">\n                        @if (isMobile) {\n                            <h3 class=\"mt-5\">\n                                <ui-core-spinner size=\"h3\" [message]=\"loadingMessage ?? text.loadingMessage\"></ui-core-spinner>\n                            </h3>\n                        } @else {\n                            <h2 class=\"mt-3\">\n                                <ui-core-spinner size=\"h2\" [message]=\"loadingMessage ?? text.loadingMessage\"></ui-core-spinner>\n                            </h2>\n                        }\n                    </div>\n                } @else {\n                    <ng-content></ng-content>\n                }\n            </div>\n            @if (footerTemplate && isDesktop && mode !== PageLayoutMode.WIZARD) {\n                <div class=\"content-footer\">\n                    <div class=\"content-footer-container\">\n                        <ng-container [ngTemplateOutlet]=\"footerTemplate\"></ng-container>\n                    </div>\n                </div>\n            }\n        </section>\n    </div>\n</div>", styles: [":host{display:block;height:100%;width:100%}.page-container{display:flex;flex-direction:column;min-height:100%}@media (min-width: 768px){.page-container{padding:32px}}.content-grid{background-color:var(--color-default);flex-grow:1;width:100%;min-height:0}@media (min-width: 768px){.content-grid{border-radius:14px;box-shadow:var(--elevation-1)}}@media (max-width: 1079.98px){.content-grid{margin-bottom:var(--nav-footer-height)}}.content-grid.basic .main-content{justify-self:center;align-items:center}.content-grid.basic .main-content .content-footer .content-footer-container{justify-self:center}.content-grid.basic .main-content{background-color:var(--color-default)}.content-grid.basic .main-content>.content-body{max-width:75rem}.content-grid.wizard{box-shadow:none;margin:0 auto;max-width:54.5rem}.content-grid.wizard .main-content{justify-self:center;align-items:center}.content-grid.wizard .main-content .content-footer .content-footer-container{justify-self:center}.content-grid.wizard .main-content>.content-body{flex-grow:0;padding:0}.content-grid.unauthenticated{box-shadow:none}.content-grid.unauthenticated .main-content{justify-self:center;align-items:center}.content-grid.unauthenticated .main-content .content-footer .content-footer-container{justify-self:center}.content-grid.unauthenticated .main-content>.content-body{max-width:52.625rem}.content-grid.unauthenticated .main-content>.content-footer{background-color:var(--color-sunken);height:100%}.content-grid.sidebar{display:grid;grid-template-columns:18.75rem 1fr}@media (max-width: 1079.98px){.content-grid.sidebar{grid-template-columns:1fr}.content-grid.sidebar .side-container{display:none}}.content-grid.sidebar .main-content{background-color:var(--color-default)}.content-grid.sidebar .main-content>.content-body{max-width:65.875rem}.content-grid.dashboard{box-shadow:none;max-width:84.625rem;display:grid;grid-template-columns:var(--left-menu-width) 1fr}@media (max-width: 1079.98px){.content-grid.dashboard{grid-template-columns:1fr}.content-grid.dashboard .side-container{display:none}}.content-grid.dashboard .main-content{background-color:transparent}.content-grid.dashboard .side-container{background:none;padding:0 25px 0 0}.content-grid.dashboard .main-content>.content-body{padding:0 32px 26px}.side-container{background:var(--color-sunken);border-top-left-radius:14px;border-bottom-left-radius:14px;border-right:1px solid var(--color-stroke-1);scroll-margin-top:var(--navbar-desktop-height);z-index:1}.main-content{border-top-right-radius:14px;border-bottom-right-radius:14px;display:flex;flex-direction:column;position:relative;width:100%;z-index:1}@media (max-width: 1079.98px){.main-content{border-top-left-radius:14px;border-bottom-left-radius:14px}}.main-content .content-body{display:flex;flex-direction:column;flex-grow:1;flex-shrink:2;min-height:var(--desktop-min-height);padding:40px;width:100%}@media (max-width: 767.98px){.main-content .content-body{padding:0}}.main-content .content-body .content-header{width:100%}.main-content .content-footer{width:100%;padding:25px 40px}.main-content .content-footer .content-footer-container{width:100%}\n"] }]
        }], ctorParameters: () => [{ type: i1.WindowService }, { type: i1.TextService }], propDecorators: { mode: [{
                type: Input
            }], headerTemplate: [{
                type: Input
            }], sideTemplate: [{
                type: Input
            }], footerTemplate: [{
                type: Input
            }], loading: [{
                type: Input
            }], loadingMessage: [{
                type: Input
            }] } });

class UiLayoutsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: UiLayoutsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.17", ngImport: i0, type: UiLayoutsModule, declarations: [PageLayoutComponent], imports: [CommonModule,
            NgbModule,
            UiCoreModule], exports: [PageLayoutComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: UiLayoutsModule, imports: [CommonModule,
            NgbModule,
            UiCoreModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: UiLayoutsModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        PageLayoutComponent
                    ],
                    imports: [
                        CommonModule,
                        NgbModule,
                        UiCoreModule,
                    ],
                    exports: [
                        PageLayoutComponent
                    ]
                }]
        }] });

/*
 * Public API Surface of ui-layouts
 */

/**
 * Generated bundle index. Do not edit.
 */

export { PageLayoutComponent, PageLayoutMode, UiLayoutsModule };
//# sourceMappingURL=a3-digital-ui-layouts.mjs.map
