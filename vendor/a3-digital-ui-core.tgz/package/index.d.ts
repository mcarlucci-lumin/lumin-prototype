import * as _angular_animations from '@angular/animations';
import { AnimationTransitionMetadata, AnimationTriggerMetadata, AnimationEvent } from '@angular/animations';
import * as i0 from '@angular/core';
import { PipeTransform, NgZone, OnChanges, ElementRef, AfterViewInit, OnDestroy, Renderer2, SimpleChanges, OnInit, EventEmitter, ChangeDetectorRef, TemplateRef, AfterViewChecked, QueryList, ViewContainerRef } from '@angular/core';
import { SafeUrl, DomSanitizer, SafeResourceUrl, SafeHtml } from '@angular/platform-browser';
import * as rxjs from 'rxjs';
import { Observable, Subject, MonoTypeOperatorFunction } from 'rxjs';
import * as i97 from '@angular/router';
import { Params, Router } from '@angular/router';
import * as i96 from '@ng-bootstrap/ng-bootstrap';
import { NgbModal, NgbModalRef, NgbModalOptions, NgbDropdown, NgbPopover } from '@ng-bootstrap/ng-bootstrap';
import { CalendarDate } from '@a3-digital/date-utils';
import { Country } from '@a3-digital/utils';
import { ColorVariable } from '@a3-digital/ui-styles';
import * as i95 from '@angular/common';
import * as i98 from '@angular/cdk/clipboard';
import * as i99 from '@angular/cdk/scrolling';

declare enum TransitionStateChange {
    WHEN_CREATED = "void => *",// AKA :enter
    WHEN_DESTROYED = "* => void",// AKA :leave
    WHEN_FALSE = "* => false",
    WHEN_TRUE = "* => true"
}

declare class TransitionEffect {
    initialStyle: object;
    finalStyle: object;
    constructor(initialStyle: object, finalStyle: object);
    getReverseEffect(): TransitionEffect;
}
declare const fadeInEffect: TransitionEffect;
declare const fadeOutEffect: TransitionEffect;
declare const collapseEffect: TransitionEffect;
declare const expandEffect: TransitionEffect;
declare const slideUpEffect: TransitionEffect;
declare const slideDownEffect: TransitionEffect;
declare const slideRightEffect: TransitionEffect;
declare const slideLeftEffect: TransitionEffect;

declare class AnimationUtils {
    static getTiming(durationMs: number, timingFunction?: string, delayMS?: number): string;
    static buildTransition(stateChange: string | TransitionStateChange, timing: string, effects: TransitionEffect[]): AnimationTransitionMetadata;
    static buildAnimation(triggerValue: string, transitions: AnimationTransitionMetadata[]): AnimationTriggerMetadata;
}

declare enum AnimationTimingFunction {
    DEFAULT = "ease",
    MOVING_OUT = "ease-in",
    MOVING_IN = "ease-out"
}

declare enum BadgeTheme {
    ERROR = "error",
    INFORMATION = "information",
    SUCCESS = "success",
    WARNING = "warning",
    NEUTRAL = "neutral",
    POSITIVE = "positive",
    NEGATIVE = "negative"
}

declare enum ContainerTheme {
    BORDERED = "bordered",
    BORDERED_INTERACTIVE = "bordered-interactive",
    DEFAULT = "default",
    ELEVATED = "elevated",
    ELEVATED_INTERACTIVE = "elevated-interactive",
    SUNKEN = "sunken",
    BRAND = "brand"
}

declare enum FeatureFlagClass {
    DISCLOSURE_PRINTING = "disclosure-printing",
    GLASS_V2 = "glass-v2",
    MICROAPP_BUTTON_UPDATES = "microapp-button-updates",
    NAVIGATION_UPDATE = "navigation-update",
    PAGE_LAYOUTS_UPDATE = "page-layouts-update"
}

declare enum HtmlAttributeState {
    TRUE = "true",
    FALSE = "false"
}

declare enum NativeMobileStatusBarTextColor {
    LIGHT = "LIGHT",
    DARK = "DARK"
}

declare enum NotificationTheme {
    NEUTRAL = "neutral",
    ERROR = "error",
    INFORMATION = "information",
    SUCCESS = "success",
    WARNING = "warning",
    GRADIENT = "gradient"
}

declare enum TextSize {
    H2 = "h2",
    H3 = "h3",
    H4 = "h4",
    H5 = "h5",
    H6 = "h6"
}

declare enum ThemeSize {
    SM = "sm",
    MD = "md",
    LG = "lg"
}

interface Action {
    action?: () => void;
    text: string;
    icon?: string;
    url?: string;
    externalUrlNewTab?: boolean;
    urlQueryParams?: Params;
    e2e?: string;
    id?: string;
}

declare class LinkParts {
    url: string;
    preLinkText: string;
    linkText: string;
    postLinkText: string;
    externalUrlNewTab: boolean;
}

declare class SpacingConfig {
    containerSelector?: string;
    labelSelector?: string;
    contentSelector?: string;
    spacingOffset?: boolean;
    spacingStyle?: string;
    centeredContent?: boolean;
}
declare class SpacingElement extends SpacingConfig {
    element: Element | HTMLElement;
}

declare class AccountMaskPipe implements PipeTransform {
    transform(value: string, length: number, showMask?: boolean): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountMaskPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<AccountMaskPipe, "accountMask", false>;
}

declare class DashedSsnPipe implements PipeTransform {
    transform(val: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DashedSsnPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<DashedSsnPipe, "dashedSsn", false>;
}

declare class FormatPipe implements PipeTransform {
    transform(template: string, data?: any): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormatPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<FormatPipe, "format", false>;
}

declare class Last4FormattedSsnPipe implements PipeTransform {
    transform(val: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<Last4FormattedSsnPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<Last4FormattedSsnPipe, "last4FormattedSsn", false>;
}

declare class Last4SsnPipe implements PipeTransform {
    transform(val: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<Last4SsnPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<Last4SsnPipe, "last4Ssn", false>;
}

declare class PhoneNumberPipe implements PipeTransform {
    transform(val: any): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<PhoneNumberPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<PhoneNumberPipe, "phoneNumber", false>;
}

declare class TimeZoneDatePipe implements PipeTransform {
    transform(value: Date | string | CalendarDate | number, pattern?: any, timezone?: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TimeZoneDatePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<TimeZoneDatePipe, "tzDate", false>;
}

declare const UI_ANALYTICS_PUBLISHER = "UI_ANALYTICS_PUBLISHER";
interface UiAnalyticsPublisher {
    pushCustomDimension(key: string, value?: string): Promise<void>;
    pushPageView(route: string, src?: string, type?: string): Promise<void>;
    pushSubroute(route: string, msg?: string): Promise<void>;
    pushNotification<TSeverity>(severity: TSeverity, msg?: string): Promise<void>;
    pushUserChangeDetails<TChangeDetails extends UserChangeDetails>(changeDetails: TChangeDetails): Promise<void>;
}
interface UserChangeDetails {
    userId?: string;
    isAuthenticated: boolean;
    analyticsTags: string[];
}

declare class AnalyticsService {
    protected pageViewPublisher: UiAnalyticsPublisher;
    constructor(pageViewPublisher: UiAnalyticsPublisher);
    pushSubroute(route: string, msg?: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AnalyticsService, [{ optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AnalyticsService>;
}

declare const UI_TEXT_PROVIDER = "UI_TEXT_PROVIDER";
interface UiTextProvider {
    getLanguage(): string;
    getText$(configKey: string): Observable<any>;
}

declare class TextService {
    protected textProvider: UiTextProvider;
    constructor(textProvider: UiTextProvider);
    getLanguage(): string;
    getText$(configKey: string, defaultText: any): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextService, [{ optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TextService>;
}

declare class WindowSize {
    readonly isDesktop: boolean;
    readonly isMobile: boolean;
    readonly isLowRes: boolean;
    readonly isTablet: boolean;
    constructor(isDesktop: boolean, isMobile: boolean, isLowRes: boolean);
}
declare class WindowService {
    private _ngZone;
    private windowSizeSubject;
    windowSize$: rxjs.Observable<WindowSize>;
    constructor(_ngZone: NgZone);
    private updateState;
    private snapshot;
    static ɵfac: i0.ɵɵFactoryDeclaration<WindowService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<WindowService>;
}

declare class AppInitializer {
    static initGlobalUI(): void;
    static setAppRemScale(size: string): void;
    private static initializeRemObserver;
}

declare enum FileType {
    ACH = ".ach",
    CSV = "text/csv",
    DOC = "application/doc",
    GIF = "image/gif",
    ICO = "image/x-icon",
    JPG = "image/jpg",
    JSON = "application/json",
    LOT = ".lot",// JSON Lottie format
    LOTTIE = ".lottie",// compressed dotLottie format
    OTF = "font/otf",
    PDF = "application/pdf",
    PNG = "image/png",
    SVG = "image/svg+xml",
    TFF = "image/tiff",
    TTF = "font/ttf",
    TXT = "text/plain",
    WOFF = "font/woff",
    XLS = "application/xls"
}
declare enum FileEncodingType {
    BASE64 = "base64",
    TEXT = "text"
}
declare const FILE_TYPE_VARIATIONS: {
    ".ach": string[];
    "text/csv": string[];
    "application/doc": string[];
    "image/x-icon": string[];
    "image/jpg": string[];
    ".lot": string[];
    ".lottie": string[];
    "font/otf": string[];
    "image/png": string[];
    "font/ttf": string[];
    "font/woff": string[];
    "application/xls": string[];
};
declare const IMAGE_FILE_TYPES: FileType[];
declare const BINARY_FILE_TYPES: FileType[];
declare class AttachmentFile {
    name: string;
    contents: string;
    encoding?: FileEncodingType;
    size?: number;
    type?: string;
}

declare class AttachmentUtils {
    static getFileType(file: File | AttachmentFile): FileType;
    static getImageTypeFromDataUrl(dataURL: string): string;
    static getAllFileVariations(types: FileType[]): FileType[];
    static isImageFile(file: File | AttachmentFile): boolean;
    static isBinaryFile(file: File | AttachmentFile): boolean;
    static isResizableImage(file: File | AttachmentFile): boolean;
    static getFileExtension(file: File | AttachmentFile): string;
    static checkForLottieAnimation(file: string, fileURL?: string, fileType?: FileType): 'v1' | 'v2' | false;
}

declare class EventUtils {
    static stopEvent(event: Event): void;
    static didEventTouchClass(event: Event, targetClass: string): boolean;
    static userIsTypingACharacter(event: KeyboardEvent): boolean;
    static isPrintableCharacter(char: string): boolean;
}

declare class FileUtils {
    static attachmentToBlob(attachment: {
        content: string;
        type?: string;
    }): Blob;
    static dataUrlToBlob(dataUrl: string): Blob;
    static base64ToBlob(base64: string, type: string): Blob;
    static base64ToArrayBuffer(base64: string): ArrayBuffer;
    static isDataUrl(urlString: string): boolean;
    static isEncodedUrl(urlString: string): boolean;
}

declare class FocusUtils {
    static getFocusableElements(parentElement: HTMLElement): (HTMLElement | HTMLInputElement)[];
    static attemptFocus(element: HTMLElement, preventScroll?: boolean): boolean;
    static forceFocus(element: HTMLElement, preventScroll?: boolean): void;
    static setInitialPageFocus(element?: HTMLElement): void;
    static checkFocusGuard(event: FocusEvent): void;
    static isFocusable(element: HTMLElement | HTMLInputElement): boolean;
}

declare class HtmlUtils {
    static parseLinkText(value: string): LinkParts | null;
    private static getLinkAttributeValue;
    static parseCSSUrl(cssUrl: string): string;
    static handleAction(action: Action, router: Router): void;
    static navigateToUrl(url: string, router: Router, externalUrlNewTab?: boolean, urlQueryParams?: Params): void;
    static isDeviceProtocolUrl(urlString: string): boolean;
    static isExternalUrl(urlString: string): boolean;
    static isRouterUrl(url: string): boolean;
    static generateRandomId(): string;
    static getVisibilityIcon(isMasked: boolean): string;
    static formatE2EPrefix(e2ePrefix: string): string;
    static formatE2EString(e2eString: string): string;
    static ariaHideAppRoot(hide: boolean): void;
    static isClassOnBody(targetClass: string): boolean;
    static removeClassFromBody(targetClass: string): void;
    static addClassToBody(targetClass: string): void;
    static isUsingKeyboard(): boolean;
    static isAnimationDisabled(): boolean;
}

interface A3MobileStatusBarConfig {
    backgroundHexColor: string;
    textColor: NativeMobileStatusBarTextColor;
}
interface A3MobileDocumentData {
    data: string | ArrayBuffer;
    contentType: string;
    fileName?: string;
}
interface A3MobileUtils {
    setStatusBarColor(config: A3MobileStatusBarConfig): void;
    revertStatusBarColor(): void;
    launchMobileDeviceBrowser(url: string, forceDefaultiOSBrowser?: boolean): void;
    downloadDocument(data: A3MobileDocumentData): void;
    viewDocument(data: A3MobileDocumentData): void;
}

declare class NativeMobileUtils {
    static isNativeApp(): boolean;
    static isAndroidBrowser(): boolean;
    static isAndroidNativeApp(): boolean;
    static isIosBrowser(): boolean;
    static isIosNativeApp(): boolean;
    static isIpad(): boolean;
    static isAppleBrowser(): boolean;
    static isTouchPrimaryDevice(): boolean;
    static snapShotIosBaseNumber(): number;
    static snapShotAndroidBaseNumber(): number;
    static browserUsesVirtualKeyboard(): boolean;
    static get a3MobileUtils(): A3MobileUtils;
    static setStatusBarColor(backgroundHexColor: string, textColor: NativeMobileStatusBarTextColor): void;
    static revertStatusBarColor(): void;
    static launchMobileDeviceBrowser(url: string, forceDefaultiOSBrowser?: boolean): void;
    private static nativeNavigator;
    private static userAgent;
    private static getSnapShotMobileBaseNumber;
}

declare class ObservableUtils {
    static getOneTimeTimer(timeMs: number, valueToEmit?: string): Observable<string>;
    static getIntervalTimer(componentDestroyed$: Subject<boolean>, timeMs: number, valueToEmit?: string): Observable<string>;
    static getCountdownTimer(time: number): Observable<number>;
}

declare class FormattedPhoneNumber {
    formattedValue: string;
    country: Country;
    constructor(formattedValue: string, country: Country);
}
declare class PhoneNumberUtils {
    static formatPhoneNumber(value: string): FormattedPhoneNumber;
    static formatInternationalPhoneNumber(country: Country, value: string): string;
    static isValidInternationalPhoneNumber(country: Country, value: string): boolean;
    static getInternationalPhoneNumberExample(country: Country): string;
    static formatDomesticPhoneNumber(value: string): string;
}

declare class ResizeObservable extends Observable<ResizeObserverEntry[]> {
    constructor(element: HTMLElement);
}

declare class SanitizationUtils {
    static removeInlineStyles(value: string): string;
    static allowRichTextOnly(value: string): string;
    static allowTextOnly(value: string): string;
    static allowTargetAttribute(value: string): string;
    static normalizeQuotes(value: string): string;
}

declare class ScrollUtils {
    static scrollToTop(animate?: boolean): void;
    static elementIsScrolledToTop(element: any): boolean;
    static elementIsScrolledToBottom(element: any): boolean;
    static get scrollY(): number;
}

declare class SpacingUtils {
    static setSpacingPerRow(spElements: SpacingElement[]): void;
    static setSpacingPerElement(spElements: SpacingElement[]): void;
    private static getLabelHeight;
    private static getMaxLabelHeight;
    private static getContentHeight;
    private static getMaxContentHeight;
    private static setSpacingOnContainer;
}

declare class UuidUtils {
    private static factory;
    static create(): string;
}

declare class WindowUtils {
    static nativeWindow(): Window;
    static isDesktopSize(): boolean;
    static isLowResSize(): boolean;
    static isMobileSize(): boolean;
    static openNewWindow(url: string, target?: string): Window;
}

declare const slideUp: _angular_animations.AnimationTriggerMetadata;
declare const slideInOutFromLeft: _angular_animations.AnimationTriggerMetadata;
declare const slideInOutFromRight: _angular_animations.AnimationTriggerMetadata;
declare const slideToTop: _angular_animations.AnimationTriggerMetadata;
declare const collapseOrSlideState: _angular_animations.AnimationTriggerMetadata;
declare const slideToTopState: _angular_animations.AnimationTriggerMetadata;
declare const collapse: _angular_animations.AnimationTriggerMetadata;
declare const collapseConditional: _angular_animations.AnimationTriggerMetadata;
declare const collapseState: _angular_animations.AnimationTriggerMetadata;
declare const fadeInOut: _angular_animations.AnimationTriggerMetadata;
declare const fadeInAnimation: _angular_animations.AnimationTriggerMetadata;

declare class DynamicAttribute {
    name: string;
    value: string;
    constructor(name: string, value?: string);
}
declare class AttributesDirective implements OnChanges {
    private readonly host;
    /**
     * An array of attributes to bind to the element.
     * Use a falsey value if it should be html attribute with no value: <input some-attribute />
     **/
    uiCoreAttributes: DynamicAttribute[];
    private element;
    private boundAttributeNames;
    constructor(host: ElementRef<HTMLElement>);
    ngOnChanges(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AttributesDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AttributesDirective, "[uiCoreAttributes]", never, { "uiCoreAttributes": { "alias": "uiCoreAttributes"; "required": false; }; }, {}, never, never, false, never>;
}

declare enum DesktopMenuAlignment {
    LEFT = "left",
    RIGHT = "right",
    NONE = ""
}
declare class DropdownMenuDirective implements AfterViewInit, OnChanges, OnDestroy {
    private readonly dropdownMenu;
    private readonly renderer;
    private _ngZone;
    isMobile: boolean;
    scrollToId: string;
    desktopMenuMaxHeight: number;
    desktopMenuWidth: number;
    desktopMenuAlignment: DesktopMenuAlignment;
    desktopMenuGap: boolean;
    itemCount: number;
    private parentContainer;
    private parentResizeSubscription;
    private determineDropUp;
    private isDropUp;
    private alignment;
    private touchStart;
    constructor(dropdownMenu: ElementRef, renderer: Renderer2, _ngZone: NgZone);
    onResize(): void;
    onWheelEvent(e: any): void;
    handleScrolling(e: WheelEvent | TouchEvent): void;
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    private reposition;
    private initializeParent;
    private findParentContainer;
    private getDesktopMenuWidth;
    private setAlignmentClass;
    private getDesktopMenuContentHeight;
    private determineIfDropUp;
    private positionDesktopMenu;
    private positionMobileMenu;
    private scrollOptionIntoView;
    private handleMobileScrollEvent;
    static ɵfac: i0.ɵɵFactoryDeclaration<DropdownMenuDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DropdownMenuDirective, "[uiCoreDropdownMenu]", never, { "isMobile": { "alias": "isMobile"; "required": false; }; "scrollToId": { "alias": "scrollToId"; "required": false; }; "desktopMenuMaxHeight": { "alias": "desktopMenuMaxHeight"; "required": false; }; "desktopMenuWidth": { "alias": "desktopMenuWidth"; "required": false; }; "desktopMenuAlignment": { "alias": "desktopMenuAlignment"; "required": false; }; "desktopMenuGap": { "alias": "desktopMenuGap"; "required": false; }; "itemCount": { "alias": "itemCount"; "required": false; }; }, {}, never, never, false, never>;
}

declare class FocusDirective implements OnInit, OnChanges {
    private readonly host;
    /**
     * Value to watch for changes & re-focus
     * <any> to allow for an Account, item, string, etc... as long as it changes when appropriate
     * pass boolean false, to disable focus behavior
     **/
    uiCoreFocus: any;
    private element;
    constructor(host: ElementRef);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    private setFocus;
    static ɵfac: i0.ɵɵFactoryDeclaration<FocusDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FocusDirective, "[uiCoreFocus]", never, { "uiCoreFocus": { "alias": "uiCoreFocus"; "required": false; }; }, {}, never, never, false, never>;
}

declare class HoverDirective {
    /**
     * Emits true when the host element is hovered and false when it loses hover.
     **/
    hovered: EventEmitter<boolean>;
    onMouseEnter(): void;
    onMouseLeave(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HoverDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HoverDirective, "[uiCoreHover]", never, {}, { "hovered": "hovered"; }, never, never, false, never>;
}

declare class ReplayMaskDirective {
    fullStoryMaskClass: boolean;
    maskClass: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReplayMaskDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ReplayMaskDirective, "[uiCoreReplayMask]", never, {}, {}, never, never, false, never>;
}

declare class ReplayUnmaskDirective {
    fullStoryUnmaskClass: boolean;
    unmaskClass: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReplayUnmaskDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ReplayUnmaskDirective, "[uiCoreReplayUnmask]", never, {}, {}, never, never, false, never>;
}

declare class ResizeEvent {
    height: number;
    width: number;
    constructor(height: number, width: number);
}
declare class ResizeDirective implements OnInit, OnDestroy {
    private readonly host;
    /**
     * Can be used to reduce event emission if only interested when one dimension changes.
     **/
    mode: 'height' | 'width' | 'all';
    /**
     * Time in ms to throttle events. Throttling is off by default.
     **/
    throttleTime: number;
    /**
     * Emitted when host element is resized.
     **/
    resized: EventEmitter<ResizeEvent>;
    private element;
    private height;
    private width;
    private resizeSubscription;
    constructor(host: ElementRef);
    ngOnInit(): void;
    ngOnDestroy(): void;
    private setDimensions;
    static ɵfac: i0.ɵɵFactoryDeclaration<ResizeDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ResizeDirective, "[uiCoreResize]", never, { "mode": { "alias": "mode"; "required": false; }; "throttleTime": { "alias": "throttleTime"; "required": false; }; }, { "resized": "resized"; }, never, never, false, never>;
}

declare abstract class BaseDestroyComponent implements OnDestroy {
    componentDestroyed$: Subject<boolean>;
    constructor();
    ngOnDestroy(): void;
    takeUntilDestroyed<T>(): MonoTypeOperatorFunction<T>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseDestroyComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BaseDestroyComponent, never, never, {}, {}, never, never, true, never>;
}

declare abstract class BaseMenuState {
    private isDrawerOnMobile;
    protected idPrefix: string;
    actions: Action[];
    protected hasFocusableIds: boolean;
    protected maxFocusableIndex: number;
    protected focusableIds: string[];
    focusedId: string;
    totalItemCount: number;
    open: () => void;
    close: () => void;
    readonly mobileCloseButtonId: string;
    constructor(isDrawerOnMobile: boolean, idPrefix: string, actions: Action[]);
    abstract onComboboxKeyDown(event: KeyboardEvent, isMobile: boolean, menuIsOpen: boolean): void;
    abstract onComboboxKeyUp(event: KeyboardEvent): void;
    protected abstract focusElementById(id: string, isMobile: boolean, isMenuInit: boolean): void;
    onMobileCloseKeyDown(event: KeyboardEvent): void;
    protected moveDown(isMobile: boolean): void;
    protected moveUp(isMobile: boolean): void;
    protected mobileTabUpOrDown(up: boolean): void;
    protected mobileSetFirstOrLast(first: boolean): void;
    protected pageDown(isMobile: boolean): void;
    protected pageUp(isMobile: boolean): void;
    protected setFocusNext(isMobile: boolean, mobileTabNav: boolean): void;
    protected setFocusPrev(isMobile: boolean, mobileTabNav: boolean): void;
    protected setFocusFirst(isMobile: boolean, isMenuInit?: boolean): void;
    protected setFocusLast(isMobile: boolean): void;
    protected focusMobileCloseButton(): void;
    protected initActions(): void;
    protected getFocusedIdIndex(): number;
    protected clickElementById(id: string): void;
    protected stopKeyboardEvent(event: KeyboardEvent): void;
}

declare abstract class BaseTextComponent extends BaseDestroyComponent {
    text: any;
    constructor(textService: TextService, textConfigKey: string);
    protected abstract getDefaultText(): any;
    protected onTextUpdate(): void;
}

declare const DESKTOP_MENU_MAX_HEIGHT = 330;
declare const DESKTOP_MENU_ON_MOBILE_MAX_HEIGHT = 198;
declare abstract class BaseMenuComponent extends BaseTextComponent {
    readonly isDrawerOnMobile: boolean;
    menuContainer: ElementRef;
    abstract menuState: BaseMenuState;
    desktopMenuGap: boolean;
    desktopMenuMaxHeight: number;
    desktopMenuWidth: number;
    desktopMenuAlignment: DesktopMenuAlignment;
    label: string;
    labelId: string;
    e2ePrefix: string;
    menuId: string;
    isMobile: boolean;
    constructor(textService: TextService, textConfigKey: string, isDrawerOnMobile: boolean);
    stopEvent(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseMenuComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BaseMenuComponent, never, never, { "menuState": { "alias": "menuState"; "required": false; }; "desktopMenuGap": { "alias": "desktopMenuGap"; "required": false; }; "desktopMenuMaxHeight": { "alias": "desktopMenuMaxHeight"; "required": false; }; "desktopMenuWidth": { "alias": "desktopMenuWidth"; "required": false; }; "desktopMenuAlignment": { "alias": "desktopMenuAlignment"; "required": false; }; "label": { "alias": "label"; "required": false; }; "labelId": { "alias": "labelId"; "required": false; }; "e2ePrefix": { "alias": "e2ePrefix"; "required": false; }; "menuId": { "alias": "menuId"; "required": false; }; "isMobile": { "alias": "isMobile"; "required": false; }; }, {}, never, never, true, never>;
}

declare const UI_ROUTE_VALIDATOR = "UI_ROUTE_VALIDATOR";
interface UiRouteValidator {
    isRouteValid(route: string): boolean;
}

declare class AttachmentComponent extends BaseTextComponent implements OnChanges {
    protected textService: TextService;
    private changeDetector;
    private domSanitizer;
    downloadLink: ElementRef;
    /**
    * AttachmentFile object that contains the file data
    * If the file has no contents available to download, component will emit the clicked event.
    **/
    file: AttachmentFile;
    /**
    * Boolean to indicate that file should not be removable
    **/
    isLocked: boolean;
    /**
    * Boolean to show the attachment file size
    **/
    showFileSize: boolean;
    /**
    * Boolean to show the remove/delete button
    **/
    showRemoveButton: boolean;
    /**
    * Boolean to center the file button within the container
    **/
    centered: boolean;
    /**
    * E2E testing - data-e2e attribute attached to buttons
    **/
    e2e: string;
    /**
    * Emits AttachmentFile object when remove button is clicked
    **/
    removed: EventEmitter<AttachmentFile>;
    /**
    * Emits when the attachment is clicked and there are no file contents
    **/
    clicked: EventEmitter<AttachmentFile>;
    downloadData: SafeUrl;
    downloadTitle: string;
    fileIcon: string;
    fileName: string;
    constructor(textService: TextService, changeDetector: ChangeDetectorRef, domSanitizer: DomSanitizer);
    ngOnChanges(): void;
    getFile(file: AttachmentFile): void;
    removeFile(file: AttachmentFile): void;
    private formatFileSize;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<AttachmentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AttachmentComponent, "ui-core-attachment", never, { "file": { "alias": "file"; "required": false; }; "isLocked": { "alias": "isLocked"; "required": false; }; "showFileSize": { "alias": "showFileSize"; "required": false; }; "showRemoveButton": { "alias": "showRemoveButton"; "required": false; }; "centered": { "alias": "centered"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; }, { "removed": "removed"; "clicked": "clicked"; }, never, never, false, never>;
}

declare class AvatarComponent extends BaseTextComponent implements OnChanges {
    private changeDetector;
    /**
    * String used to label avatar & progress circle for screen-readers, ex: 'Level 1', or 'Task 3'
    **/
    ariaLabel: string;
    /**
    * Background color class. Any class tied to a background-color can be used here.
    **/
    backgroundClass: string;
    /**
    * Icon color class. Any class tied to a font color can be used here.
    **/
    colorClass: string;
    /**
    * Boolean to indicate if avatar is in completed state (full bg, no chart, 'completed' aria text)
    **/
    completed: boolean;
    /**
    * Boolean to indicate if avatar should show as disabled/unavailable
    **/
    disabled: boolean;
    /**
    * A string corresponding to a Material Icon, a SVG icon, or a single char.
    **/
    icon: string;
    /**
    * An optional image rotation class. Possible options are 'rotate-90', 'rotate-180', or 'rotate-270'.
    **/
    imageRotationClass: '' | 'rotate-90' | 'rotate-180' | 'rotate-270';
    /**
    * If an image is desired, the URL of the image.
    **/
    imageUrl: string;
    /**
    * The shape of the avatar.
    **/
    shape: 'circle' | 'rounded' | 'square';
    /**
    * Avatar size. X-small/xs, Small/sm (default), Medium/md, Large/lg, X-Large/xl,
    *              Progress-chart-small/progress-sm, Progress-chart/progress
    **/
    size: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'progress-sm' | 'progress';
    /**
    * Number to indicate progress chart value
    *   also requires progressMax, shape: 'circle', and a progress size, for chart to display
    **/
    progressValue: number;
    /**
    * Number to indicate maximum/total progress chart value
    *   also requires progressValue, shape: 'circle', and a progress size, for chart to display
    **/
    progressMax: number;
    /**
    * Number to indicate where progress chart should start animation
    *   if defined, the chart will start from this value and animate to the "progressValue"
    **/
    progressAnimationStart: number;
    ariaText: string;
    disabledBackgroundClass: string;
    disabledColorClass: string;
    imageClass: string;
    isProgress: boolean;
    isCompleteAnimation: boolean;
    wrapperClass: string;
    showChart: boolean;
    constructor(textService: TextService, changeDetector: ChangeDetectorRef);
    ngOnChanges(): void;
    progressComplete(): void;
    private setImageClass;
    private shouldChartDisplay;
    private setAriaText;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<AvatarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AvatarComponent, "ui-core-avatar", never, { "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "backgroundClass": { "alias": "backgroundClass"; "required": false; }; "colorClass": { "alias": "colorClass"; "required": false; }; "completed": { "alias": "completed"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "imageRotationClass": { "alias": "imageRotationClass"; "required": false; }; "imageUrl": { "alias": "imageUrl"; "required": false; }; "shape": { "alias": "shape"; "required": false; }; "size": { "alias": "size"; "required": false; }; "progressValue": { "alias": "progressValue"; "required": false; }; "progressMax": { "alias": "progressMax"; "required": false; }; "progressAnimationStart": { "alias": "progressAnimationStart"; "required": false; }; }, {}, never, never, false, never>;
}

declare class AvatarModel {
    progressValue: number;
    progressMax: number;
    progressAnimationStart: number;
    ariaLabel: string;
    icon: string;
    imageUrl: string;
    shape: 'circle' | 'rounded' | 'square';
    size: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'progress-sm' | 'progress';
    backgroundClass: string;
    static fromObject(data: any): AvatarModel;
}

declare class BreadcrumbItem {
    label: string;
    url: string;
    constructor(label: string, url: string);
}

declare class BreadcrumbsComponent extends BaseDestroyComponent {
    /**
    * Each item is a clickable link, except for the last one which is just text.
    **/
    breadcrumbs: BreadcrumbItem[];
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BreadcrumbsComponent, "ui-core-breadcrumbs", never, { "breadcrumbs": { "alias": "breadcrumbs"; "required": false; }; }, {}, never, never, false, never>;
}

declare class BackButtonComponent {
    /**
    * The text to display in the back button.
    **/
    message: string;
    /**
    * URL to navigate to when clicked. If this is not set, a "clicked" event will be emitted.
    **/
    url: string;
    /**
    * E2E testing - data-e2e attribute attached to back button
    **/
    e2e: string;
    /**
    * Emitted when the back button is clicked. Will only emit if no "url" is provided.
    **/
    clicked: EventEmitter<void>;
    e2eAttr: string;
    ngOnChanges(changes: SimpleChanges): void;
    onButtonClicked(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BackButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BackButtonComponent, "ui-core-back-button", never, { "message": { "alias": "message"; "required": false; }; "url": { "alias": "url"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; }, { "clicked": "clicked"; }, never, never, false, never>;
}

type ButtonTheme = 'primary' | 'secondary' | 'tertiary' | 'link';
type ButtonThemeGroup = 'branded' | 'neutral';

declare class ButtonComponent implements OnChanges {
    /**
    * Theme group for the button.
    * Determines which set of themes are available:
    * - 'branded': Uses brand-specific themes (primary, secondary, tertiary, link)
    * - 'neutral': Uses neutral themes (primary, secondary, tertiary)
    **/
    themeGroup: ButtonThemeGroup;
    /**
    * Button theme.
    * Applies primary, secondary, tertiary, or link styling to button to indicate hierarchy. Defaults to 'tertiary'.
    * The 'link' theme is only available when themeGroup is 'branded'. If themeGroup is 'neutral', 'tertiary' will be used instead.
    **/
    theme: ButtonTheme;
    /**
    * Button text to display.
    **/
    message: string;
    /**
    * Material Icon string of icon to display.
    **/
    icon: string;
    /**
    * Icon position. Left or Right side of text, defaults to left
    **/
    iconPosition: 'left' | 'right';
    /**
    * Boolean to toggle disabled state.
    * Applies "disabled" classes and properties to prevent clicks, navigation, or focus.
    * This will apply to both the host element & button element. If "disabled", no interactions should be possible.
    **/
    disabled: boolean;
    /**
    * Message to show when disabled, typically displays next to a spinner
    * If not set, button message will be shown
    **/
    disabledMessage: string;
    /**
    * Boolean to show spinner in disabled button
    *  (indicate busy/submitting/loading status)
    **/
    showSpinner: boolean;
    /**
    * Class(es) to apply directly to button element
    * (default "class" property of ButtonComponent is applied to the host element, this will apply directly to the button)
    **/
    buttonClass: string;
    /**
    * Button width (minimum width)
    * By default button will be a minimum of 4rem wide & expand to contain its message, these options will size it further
    * 'wide' = min-width 10rem
    * 'wider' = min-width 13.75rem
    * 'full' = same as .btn-block - button will be as wide as possible
    **/
    width: '' | 'wide' | 'wider' | 'full';
    /**
    * ARIA Expanded attribute (aria-expanded)
    * Needs to be set on button element to be handled correctly by screen-readers
    * Used to indicate state of collapsable/hideable areas controlled by this button
    **/
    ariaExpanded: HtmlAttributeState | null;
    /**
    * ARIA Controls attribute (aria-controls)
    * Needs to be set on button element to be handled correctly by screen-readers
    * Used to indicate relationship to areas controlled by this button (expects id attribute of controlled area, the area being collapsed/hidden)
    **/
    ariaControls: string;
    /**
    * ARIA "Has Popup" attribute (aria-has-popup)
    * Needs to be set on button elements with popups to be handled correctly by screen-readers
    * Used to indicate the availability of interactive popup element, such as menu, that can be triggered by an element.
    **/
    ariaHasPopup: HtmlAttributeState | null;
    /**
    * ARIA "Active Descendant" attribute (aria-has-popup)
    * Needs to be set on button elements with menus to be handled correctly by screen-readers
    * Used to indicate the availability of interactive popup element, such as menu, that can be triggered by an element.
    **/
    ariaActiveDescendantId: string;
    /**
    * ARIA Label attribute (aria-label)
    * Used to replace the button message with more descriptive text, screen-readers will read the ariaLabel, instead of message
    **/
    ariaLabel: string;
    /**
    * Boolean to support dynamic form styling
    **/
    isFormValid: boolean;
    /**
    * E2E testing - data-e2e attribute attached to button
    **/
    e2e: string;
    /**
    * Customizable id
    **/
    buttonId: string;
    showIcon: boolean;
    activeTheme: string;
    buttonClasses: string[];
    ngOnChanges(): void;
    private computeButtonClasses;
    static ɵfac: i0.ɵɵFactoryDeclaration<ButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ButtonComponent, "ui-core-button", never, { "themeGroup": { "alias": "themeGroup"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "message": { "alias": "message"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "iconPosition": { "alias": "iconPosition"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "disabledMessage": { "alias": "disabledMessage"; "required": false; }; "showSpinner": { "alias": "showSpinner"; "required": false; }; "buttonClass": { "alias": "buttonClass"; "required": false; }; "width": { "alias": "width"; "required": false; }; "ariaExpanded": { "alias": "ariaExpanded"; "required": false; }; "ariaControls": { "alias": "ariaControls"; "required": false; }; "ariaHasPopup": { "alias": "ariaHasPopup"; "required": false; }; "ariaActiveDescendantId": { "alias": "ariaActiveDescendantId"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "isFormValid": { "alias": "isFormValid"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; "buttonId": { "alias": "buttonId"; "required": false; }; }, {}, never, never, false, never>;
}

type ButtonCardTextWeight = 'semibold' | 'regular';
type ButtonCardTextColor = 'primary' | 'secondary' | 'negative' | 'positive';
type ButtonCardTextSize = 'caption' | 'body';
type ButtonCardIconSize = 'sm' | 'md' | 'lg';
declare class ButtonCardItem {
    leftTitle: string;
    value: string;
    isUrl: boolean;
    externalUrlNewTab: boolean;
    urlQueryParams: Params;
    constructor(leftTitle: string, value: string, // The value to emit when clicked, or else the url to navigate to
    isUrl?: boolean, // If true, will navigate to the value when clicked,
    externalUrlNewTab?: boolean, // If it's an external url, open in new browser tab
    urlQueryParams?: Params);
    disabled?: boolean;
    markComplete?: boolean;
    rightTitle?: string;
    leftBodyLine1?: string;
    leftBodyLine2?: string;
    rightBodyLine1?: string;
    rightBodyLine2?: string;
    leftTitleWeight?: ButtonCardTextWeight;
    leftTitleColor?: ButtonCardTextColor;
    leftTitleSize?: ButtonCardTextSize;
    rightTitleWeight?: ButtonCardTextWeight;
    rightTitleColor?: ButtonCardTextColor;
    rightTitleSize?: ButtonCardTextSize;
    leftBodyLine1Weight?: ButtonCardTextWeight;
    leftBodyLine1Color?: ButtonCardTextColor;
    leftBodyLine1Size?: ButtonCardTextSize;
    leftBodyLine2Weight?: ButtonCardTextWeight;
    leftBodyLine2Color?: ButtonCardTextColor;
    leftBodyLine2Size?: ButtonCardTextSize;
    rightBodyLine1Weight?: ButtonCardTextWeight;
    rightBodyLine1Color?: ButtonCardTextColor;
    rightBodyLine1Size?: ButtonCardTextSize;
    rightBodyLine2Weight?: ButtonCardTextWeight;
    rightBodyLine2Color?: ButtonCardTextColor;
    rightBodyLine2Size?: ButtonCardTextSize;
    icon?: string;
    iconBackgroundClass?: string;
    badgeMessage?: string;
    badgeTheme: BadgeTheme;
    static fromObject(data: any): ButtonCardItem;
}

declare class ButtonCardsComponent extends BaseDestroyComponent implements OnChanges {
    private windowService;
    private router;
    /**
    * Optional header text.
    **/
    header: string;
    /**
    * Optional subheader text.
    **/
    subheader: string;
    /**
    * Each item represents a button card and has a message, value and icon.
    * Each item can also have isUrl set to true, which will route to the value on click (can be an internal or external url).
    **/
    items: ButtonCardItem[];
    /**
    * The number of columns to show on mobile. Max is 3. Default is 1.
    **/
    mobileColumns: number;
    /**
    * The number of columns to show on tablet. Max is 3. Default is 2.
    **/
    tabletColumns: number;
    /**
    * The number of columns to show on desktop. Max is 3. Default is 3.
    **/
    desktopColumns: number;
    /**
    * When true, applies tighter card spacing: 12px card padding, 8px gap between cards, 8px gap
    * between the icon and left text, and 12px gap between the left/right text (all default to 16px).
    * Default is false.
    **/
    compactSpacing: boolean;
    /**
    * When true, lays the cards out as a single horizontally scrolling row instead of a grid,
    * ignoring mobileColumns/tabletColumns/desktopColumns. Applies at any breakpoint. Default is false.
    **/
    horizontalScroll: boolean;
    /**
    * When false, removes each card's resting shadow so it's flat until hovered. Default is true.
    **/
    cardShadow: boolean;
    /**
    * When true, vertically centers the icon next to the text instead of top-aligning it. Default is false.
    **/
    centerIcon: boolean;
    /**
    * The size of every card's icon in this list. This is set once for the whole list, not per item -
    * icon size is a consistent, implementation-level choice rather than something that varies card to
    * card. Default is 'md'.
    **/
    iconSize: ButtonCardIconSize;
    /**
    * Optional accessible name for the group of button cards, announced to screen readers.
    * Only needed when no header is provided. If a header exists, the group is labelled by that.
    **/
    ariaLabel: string;
    /**
    * Emits the value of the item clicked.
    **/
    itemClicked: EventEmitter<string>;
    isMobile: boolean;
    private isDesktop;
    columnCssClass: string;
    readonly headerId: string;
    constructor(windowService: WindowService, router: Router);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    getTextClasses(weight: ButtonCardTextWeight, color: ButtonCardTextColor, size: ButtonCardTextSize): string[];
    buttonClicked(item: ButtonCardItem): void;
    private setColumnClass;
    private gridColumnClass;
    static ɵfac: i0.ɵɵFactoryDeclaration<ButtonCardsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ButtonCardsComponent, "ui-core-button-cards", never, { "header": { "alias": "header"; "required": false; }; "subheader": { "alias": "subheader"; "required": false; }; "items": { "alias": "items"; "required": false; }; "mobileColumns": { "alias": "mobileColumns"; "required": false; }; "tabletColumns": { "alias": "tabletColumns"; "required": false; }; "desktopColumns": { "alias": "desktopColumns"; "required": false; }; "compactSpacing": { "alias": "compactSpacing"; "required": false; }; "horizontalScroll": { "alias": "horizontalScroll"; "required": false; }; "cardShadow": { "alias": "cardShadow"; "required": false; }; "centerIcon": { "alias": "centerIcon"; "required": false; }; "iconSize": { "alias": "iconSize"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; }, { "itemClicked": "itemClicked"; }, never, never, false, never>;
}

declare class ButtonMenuOption implements Action {
    action?: (item?: any) => void;
    icon?: string;
    text: string;
    url?: string;
    urlQueryParams?: Params;
    externalUrlNewTab?: boolean;
    e2e?: string;
}

declare class ButtonGridItem implements Action {
    value: string;
    text: string;
    icon: string;
    e2e: string;
    url?: string;
    constructor(value: string, // When used for microapps, the value should correspond to the microapp's ID
    text: string, icon: string, e2e: string, url?: string);
    menuOptions: ButtonMenuOption[];
    badgeMessage: string;
    badgeTheme: BadgeTheme;
    iconShape: 'circle' | 'rounded' | 'square' | '';
    stackButtonClass: string;
    action: (item?: any) => void;
    urlQueryParams: Params;
    externalUrlNewTab: boolean;
}

declare class ButtonGridComponent extends BaseTextComponent implements OnChanges {
    private router;
    protected textService: TextService;
    private windowService;
    /**
    * Each item represents a button in the grid and has text, value, icon and e2e attribute.
    * Each item can also have isUrl set to true, which on "click" will route to the value (can be an internal or external url).
    **/
    items: ButtonGridItem[];
    /**
    * Whether the icon should appear above the provided message.
    **/
    iconAboveMessage: boolean;
    /**
    * Visual presentation of input. Defaults to "grid".
    **/
    display: 'column' | 'grid' | 'row';
    /**
    * Label text to display at beginning of grid row (row display only)
    **/
    rowLabel: string;
    /**
    * Notification text to display when grid is empty (no actions available)
    * An empty grid typically will not display anything, unless this is set.
    **/
    emptyLabel: string;
    /**
    * Emits the ButtonGridItem that was clicked.
    **/
    itemClicked: EventEmitter<ButtonGridItem>;
    visibleItems: ButtonGridItem[];
    moreMenuOptions: ButtonMenuOption[];
    isRow: boolean;
    isTwoColumnGrid: boolean;
    readonly moreMenuAlignment = DesktopMenuAlignment.RIGHT;
    private isMobile;
    constructor(router: Router, textService: TextService, windowService: WindowService);
    ngOnChanges(changes: SimpleChanges): void;
    private buildVisibleItems;
    buttonClicked(item: ButtonGridItem): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<ButtonGridComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ButtonGridComponent, "ui-core-button-grid", never, { "items": { "alias": "items"; "required": false; }; "iconAboveMessage": { "alias": "iconAboveMessage"; "required": false; }; "display": { "alias": "display"; "required": false; }; "rowLabel": { "alias": "rowLabel"; "required": false; }; "emptyLabel": { "alias": "emptyLabel"; "required": false; }; }, { "itemClicked": "itemClicked"; }, never, never, false, never>;
}

declare class ButtonGroupComponent implements OnChanges {
    /**
    * Set to true to disable all buttons.
    **/
    disableButtons: boolean;
    /**
    * The text of the primary button.
    **/
    primaryButtonText: string;
    /**
    * The text of the primary button in its disabled state.
    **/
    primaryButtonDisabledText: string;
    /**
    * The icon of the primary button.
    **/
    primaryButtonIcon: string;
    /**
    * Position of the icon of the primary button.
    **/
    primaryButtonIconPosition: 'left' | 'right';
    /**
    * Controls the primary button spinner when in a disabled state.
    **/
    showPrimarySpinner: boolean;
    /**
    * An optional URL to navigate to on primary button click.
    **/
    primaryButtonUrl: string;
    /**
    * Optional query parameters for the primaryButtonUrl.
    **/
    primaryButtonUrlParams: Params;
    /**
    * If true, the primary button's external link will open in a new tab.
    **/
    primaryButtonUsesExternalUrlNewTab: boolean;
    /**
    * The text of the secondary button.
    **/
    secondaryButtonText: string;
    /**
    * The icon of the secondary button.
    **/
    secondaryButtonIcon: string;
    /**
    * Position of the icon of the secondary button.
    **/
    secondaryButtonIconPosition: 'left' | 'right';
    /**
    * Controls the secondary button spinner when in a disabled state.
    **/
    showSecondarySpinner: boolean;
    /**
    * Optional theme over-ride of the secondary button.
    * (not typical, but in some cases, we need to over-ride the standard group themes)
    **/
    secondaryButtonTheme: 'secondary' | 'tertiary' | 'link';
    /**
    * An optional URL to navigate to on secondary button click.
    **/
    secondaryButtonUrl: string;
    /**
    * Optional query parameters for the secondaryButtonUrl.
    **/
    secondaryButtonUrlParams: Params;
    /**
    * If true, the secondary button's external link will open in a new tab.
    **/
    secondaryButtonUsesExternalUrlNewTab: boolean;
    /**
    * The text of the tertiary button.
    **/
    tertiaryButtonText: string;
    /**
    * The icon of the tertiary button.
    **/
    tertiaryButtonIcon: string;
    /**
    * Position of the icon of the tertiary button.
    **/
    tertiaryButtonIconPosition: 'left' | 'right';
    /**
    * Controls the tertiary button spinner when in a disabled state.
    **/
    showTertiarySpinner: boolean;
    /**
    * Optional theme over-ride of the tertiary button.
    * (not typical, but in some cases, we need to over-ride the standard group themes)
    **/
    tertiaryButtonTheme: 'secondary' | 'tertiary' | 'link';
    /**
    * An optional URL to navigate to on tertiary button click.
    **/
    tertiaryButtonUrl: string;
    /**
    * Optional query parameters for the tertiaryButtonUrl.
    **/
    tertiaryButtonUrlParams: Params;
    /**
    * If true, the tertiary button's external link will open in a new tab.
    **/
    tertiaryButtonUsesExternalUrlNewTab: boolean;
    /**
    * Set this flag when the parent form is valid.
    **/
    isFormValid: boolean;
    /**
    * Set this flag when this component is nested within Form Renderer.
    **/
    withinFormRenderer: boolean;
    /**
    * Error messages to display. Typically used for server-side validation.
    **/
    errorMessages: string[];
    /**
    * E2E testing - this value is used to generate e2e hooks across this component.
    **/
    e2e: string;
    /**
    * Controls margin below the buttons.
    **/
    marginBottom: boolean;
    /**
    * Controls margin above the buttons.
    **/
    marginTop: boolean;
    /**
    * If true, will force the buttons to stack & be full-width, like mobile behavior
    **/
    stacked: boolean;
    /**
    * Emits when primary button is clicked.
    **/
    primaryButtonClicked: EventEmitter<Event>;
    /**
    * Emits when secondary button is clicked.
    **/
    secondaryButtonClicked: EventEmitter<Event>;
    /**
    * Emits when tertiary button is clicked.
    **/
    tertiaryButtonClicked: EventEmitter<Event>;
    e2ePrefix: string;
    ngOnChanges(changes: SimpleChanges): void;
    primaryButtonClick(event: Event): void;
    secondaryButtonClick(event: Event): void;
    tertiaryButtonClick(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ButtonGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ButtonGroupComponent, "ui-core-button-group", never, { "disableButtons": { "alias": "disableButtons"; "required": false; }; "primaryButtonText": { "alias": "primaryButtonText"; "required": false; }; "primaryButtonDisabledText": { "alias": "primaryButtonDisabledText"; "required": false; }; "primaryButtonIcon": { "alias": "primaryButtonIcon"; "required": false; }; "primaryButtonIconPosition": { "alias": "primaryButtonIconPosition"; "required": false; }; "showPrimarySpinner": { "alias": "showPrimarySpinner"; "required": false; }; "primaryButtonUrl": { "alias": "primaryButtonUrl"; "required": false; }; "primaryButtonUrlParams": { "alias": "primaryButtonUrlParams"; "required": false; }; "primaryButtonUsesExternalUrlNewTab": { "alias": "primaryButtonUsesExternalUrlNewTab"; "required": false; }; "secondaryButtonText": { "alias": "secondaryButtonText"; "required": false; }; "secondaryButtonIcon": { "alias": "secondaryButtonIcon"; "required": false; }; "secondaryButtonIconPosition": { "alias": "secondaryButtonIconPosition"; "required": false; }; "showSecondarySpinner": { "alias": "showSecondarySpinner"; "required": false; }; "secondaryButtonTheme": { "alias": "secondaryButtonTheme"; "required": false; }; "secondaryButtonUrl": { "alias": "secondaryButtonUrl"; "required": false; }; "secondaryButtonUrlParams": { "alias": "secondaryButtonUrlParams"; "required": false; }; "secondaryButtonUsesExternalUrlNewTab": { "alias": "secondaryButtonUsesExternalUrlNewTab"; "required": false; }; "tertiaryButtonText": { "alias": "tertiaryButtonText"; "required": false; }; "tertiaryButtonIcon": { "alias": "tertiaryButtonIcon"; "required": false; }; "tertiaryButtonIconPosition": { "alias": "tertiaryButtonIconPosition"; "required": false; }; "showTertiarySpinner": { "alias": "showTertiarySpinner"; "required": false; }; "tertiaryButtonTheme": { "alias": "tertiaryButtonTheme"; "required": false; }; "tertiaryButtonUrl": { "alias": "tertiaryButtonUrl"; "required": false; }; "tertiaryButtonUrlParams": { "alias": "tertiaryButtonUrlParams"; "required": false; }; "tertiaryButtonUsesExternalUrlNewTab": { "alias": "tertiaryButtonUsesExternalUrlNewTab"; "required": false; }; "isFormValid": { "alias": "isFormValid"; "required": false; }; "withinFormRenderer": { "alias": "withinFormRenderer"; "required": false; }; "errorMessages": { "alias": "errorMessages"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; "marginBottom": { "alias": "marginBottom"; "required": false; }; "marginTop": { "alias": "marginTop"; "required": false; }; "stacked": { "alias": "stacked"; "required": false; }; }, { "primaryButtonClicked": "primaryButtonClicked"; "secondaryButtonClicked": "secondaryButtonClicked"; "tertiaryButtonClicked": "tertiaryButtonClicked"; }, never, never, false, never>;
}

/**
 * Service to bridge communication between the ModalService and native app code that needs to trigger modal actions.
 * This is necessary because our ModalService does not act like a true singleton and could be running multiple instances.
 * See DEV-49798, we should be able to delete this bridge & use ModalService directly once that's fixed.
 **/
declare class ModalBridgeService {
    private closeRequest$;
    private ngbModal;
    hasOpenModals(): boolean;
    requestClose(): void;
    onCloseMostRecentRequest(): Observable<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ModalBridgeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ModalBridgeService>;
}

declare enum ModalButtonType {
    BACK = "BACK",
    PRIMARY = "PRIMARY",
    SECONDARY = "SECONDARY",
    ACTION = "ACTION"
}

declare class ModalService {
    private ngbModal;
    private ngZone;
    private modalBridgeService;
    private openModals;
    private closingPreviousModal;
    private dismissingAllModals;
    private dismissInProgress;
    private intentionalClose;
    private buttonClose;
    private dismissReason;
    private readonly dismissTimeout;
    private readonly modalAnimationTimeMs;
    private readonly mobileSearchBarClass;
    private readonly enhancedClass;
    private readonly partialClass;
    private buttonClickedSubject;
    constructor(ngbModal: NgbModal, ngZone: NgZone, modalBridgeService: ModalBridgeService);
    openEnhancedModal(modal: TemplateRef<any>): NgbModalRef;
    openInterstitialModal(component: any): NgbModalRef;
    openMobileOnlyModal(modal: TemplateRef<any>, modalClass?: string, showPrimaryAnimations?: boolean): NgbModalRef;
    openMobileSearchModal(component: any): NgbModalRef;
    openNormalModal(modal: TemplateRef<any>): NgbModalRef;
    openPartialModal(modal: TemplateRef<any>): NgbModalRef;
    swapToNormalModal(newModal: TemplateRef<any>): NgbModalRef;
    swapToEnhancedModal(newModal: TemplateRef<any>): NgbModalRef;
    openCustomOptionsModal(modal: TemplateRef<any>, options: NgbModalOptions): NgbModalRef;
    getNumberOfOpenModals(): number;
    private swapToModal;
    private openModal;
    private transitionModalOut;
    private onDismiss;
    private completeDismiss;
    closeMostRecentModal(optionalReason?: string): void;
    closeMostRecentMobileOnlyModal(optionalReason?: string): void;
    dismissAll(): void;
    private getCurrentModal;
    lockCurrentModalScrim(): void;
    registerBeforeClose(fn: () => boolean | Promise<boolean>): void;
    requestMostRecentModalClose(): void;
    private closeModal;
    private closePreviousModal;
    hasOpenModals(): boolean;
    hasMultipleOpenModals(): boolean;
    hasEnhancedModalOnTop(): boolean;
    private setModalFocus;
    handleButtonClicked(id: string, buttonType: ModalButtonType): void;
    getButtonClickedObservable(id: string, buttonType: ModalButtonType): Observable<void>;
    getModalId(): string;
    private setNativeAppStatusBarToMatchModalBackground;
    private revertNativeAppStatusBarColor;
    scrollMostRecentModalToTop(delay?: number): void;
    scrollMostRecentEnhancedModalToTop(delay?: number): void;
    private scrollModalToTop;
    static ɵfac: i0.ɵɵFactoryDeclaration<ModalService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ModalService>;
}

/**
 * @deprecated Use ui-core-button-menu instead.
 */
declare class ButtonMenuLegacyComponent extends BaseTextComponent implements OnChanges {
    private modalService;
    private windowService;
    dropdown: NgbDropdown;
    mobileModal: TemplateRef<any>;
    /**
    * Optional. Material Icon string of icon to display.
    **/
    icon: string;
    /**
    * Required. The title of the button menu.
    **/
    title: string;
    /**
    * Required. The options within the button menu.
    * Each option must have a value for the "text" field and
    * specify either an "action" (function) or "url" (string).
    * There is also an optional "icon" (string) field.
    **/
    options: ButtonMenuOption[];
    /**
    * Optional. Whether this component is nested within the Button Grid Component.
    **/
    withinButtonGrid: boolean;
    /**
    * Optional. E2E testing - this value is used to generate e2e hooks across this component.
    **/
    e2e: string;
    /**
    * Emits when the mobile only modal is opened.
    **/
    modalOpened: EventEmitter<ButtonMenuOption>;
    HtmlAttributeStateEnum: typeof HtmlAttributeState;
    uid: string;
    e2ePrefix: string;
    isMobile: boolean;
    constructor(modalService: ModalService, textService: TextService, windowService: WindowService);
    ngOnChanges(changes: SimpleChanges): void;
    openMobileModalMenu(): void;
    hasOpenModals(): boolean;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<ButtonMenuLegacyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ButtonMenuLegacyComponent, "ui-core-button-menu-legacy", never, { "icon": { "alias": "icon"; "required": false; }; "title": { "alias": "title"; "required": false; }; "options": { "alias": "options"; "required": false; }; "withinButtonGrid": { "alias": "withinButtonGrid"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; }, { "modalOpened": "modalOpened"; }, never, never, false, never>;
}

declare class ActionMenuState extends BaseMenuState {
    private changeDetector;
    private ngZone;
    constructor(changeDetector: ChangeDetectorRef, ngZone: NgZone, idPrefix: string, actions: Action[]);
    private setFocusableIds;
    onComboboxKeyDown(event: KeyboardEvent, isMobile: boolean, menuIsOpen: boolean): void;
    onComboboxKeyUp(event: KeyboardEvent): void;
    onMenuItemKeyDown(itemId: string, event: KeyboardEvent, isMobile: boolean): void;
    onMenuInit(isMobile: boolean): void;
    protected focusElementById(id: string, isMobile: boolean, isMenuInit?: boolean): void;
    static getEmptyState(): ActionMenuState;
}

declare class ActionMenuComponent extends BaseMenuComponent implements OnInit {
    menuState: ActionMenuState;
    hoverShadow: boolean;
    transparentBackground: boolean;
    closed: EventEmitter<void>;
    action: EventEmitter<Action>;
    constructor(textService: TextService);
    ngOnInit(): void;
    close(): void;
    onActionClick(actionItem: Action): void;
    onActionKeyDown(action: Action, event: KeyboardEvent): void;
    closeKeyDown(event: KeyboardEvent): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<ActionMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ActionMenuComponent, "ui-core-action-menu", never, { "menuState": { "alias": "menuState"; "required": false; }; "hoverShadow": { "alias": "hoverShadow"; "required": false; }; "transparentBackground": { "alias": "transparentBackground"; "required": false; }; }, { "closed": "closed"; "action": "action"; }, never, never, false, never>;
}

declare abstract class BaseActionDropdownComponent extends BaseTextComponent {
    protected router: Router;
    protected windowService: WindowService;
    toggleContainer: ElementRef;
    menuComponent: ActionMenuComponent;
    /**
    * The width of the menu in desktop.
    **/
    desktopMenuWidth: number;
    abstract menuState: ActionMenuState;
    menuIsOpen: boolean;
    readonly uid: string;
    readonly menuId: string;
    isMobile: boolean;
    get activeDescendantId(): string;
    constructor(router: Router, windowService: WindowService, textService: TextService, textConfigKey: string);
    protected get menuElement(): ElementRef;
    protected get toggleElement(): ElementRef;
    onDocumentClick(event: MouseEvent, targetElement: HTMLElement): void;
    handleScrolling(e: WheelEvent | TouchEvent): void;
    close(): void;
    open(): void;
    toggleMenu(): void;
    onActionClick(action: Action): void;
    onComboboxKeyDown(event: KeyboardEvent): void;
    onComboboxKeyUp(event: KeyboardEvent): void;
    onComboboxClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseActionDropdownComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BaseActionDropdownComponent, never, never, { "desktopMenuWidth": { "alias": "desktopMenuWidth"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ButtonMenuComponent extends BaseActionDropdownComponent implements OnChanges {
    private changeDetector;
    protected ngZone: NgZone;
    /**
    * Optional. The icon to display.
    **/
    icon: string;
    /**
    * Required. The title of the button menu.
    **/
    title: string;
    /**
    * Required. The options within the button menu.
    * Each option must have a value for the "text" field and
    * specify either an "action" (function) or "url" (string).
    * There is also an optional "icon" (string) field.
    **/
    options: ButtonMenuOption[];
    /**
    * Optional. E2E testing - this value is used to generate e2e hooks across this component.
    **/
    e2e: string;
    /**
    * Optional. Control the type of button used for the menu toggle.
    * tertiary - button component with tertiary theme
    * icon - icon button component
    * grid - for use within button-grid
    **/
    display: 'tertiary' | 'icon' | 'grid';
    /**
    * Optional. Only for use with display 'grid'. Maintains iconAboveMessage support for button-grid.
    **/
    gridIconAboveMessage: boolean;
    /**
    * Optional. Only for use with display 'grid'. Maintains iconShape support for button-grid.
    **/
    gridIconShape: 'circle' | 'rounded' | 'square' | '';
    /**
    * Optional. Only for use with display 'grid'. Maintains row support for button-grid.
    **/
    gridRowPosition: 'row' | 'more' | '';
    /**
    * Optional. Only for use with display 'icon'. Maintains theme support for icon button.
    **/
    iconTheme: 'light' | 'glass' | '';
    /**
    * Emits when the button toggle is clicked.
    **/
    buttonClicked: EventEmitter<void>;
    HtmlAttributeStateEnum: typeof HtmlAttributeState;
    e2ePrefix: string;
    menuState: ActionMenuState;
    isTertiaryButton: boolean;
    isIconButton: boolean;
    isButtonGrid: boolean;
    isButtonGridMoreMenu: boolean;
    desktopMenuAlignment: DesktopMenuAlignment;
    constructor(textService: TextService, windowService: WindowService, router: Router, changeDetector: ChangeDetectorRef, ngZone: NgZone);
    ngOnChanges(changes: SimpleChanges): void;
    onToggleClick(): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<ButtonMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ButtonMenuComponent, "ui-core-button-menu", never, { "icon": { "alias": "icon"; "required": false; }; "title": { "alias": "title"; "required": false; }; "options": { "alias": "options"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; "display": { "alias": "display"; "required": false; }; "gridIconAboveMessage": { "alias": "gridIconAboveMessage"; "required": false; }; "gridIconShape": { "alias": "gridIconShape"; "required": false; }; "gridRowPosition": { "alias": "gridRowPosition"; "required": false; }; "iconTheme": { "alias": "iconTheme"; "required": false; }; }, { "buttonClicked": "buttonClicked"; }, never, never, false, never>;
}

declare class ChinButtonsComponent {
    private router;
    /**
    * Text of optional primary button.
    **/
    primaryButtonText: string;
    /**
    * Screen-reader label to apply to primary button for accessibility.
    *   Read instead of, or in addition to, to the primaryButtonText (depending on device).
    **/
    primaryButtonAriaLabel: string;
    /**
    * The url to navigate to on primary button click.
    **/
    primaryButtonUrl: string;
    /**
    * Query parameters for the primaryButtonUrl.
    **/
    primaryButtonUrlParams: Params;
    /**
    * E2E testing - data-e2e attribute attached to primary button
    **/
    primaryButtonE2E: string;
    /**
    * Text of optional additional button.
    **/
    additionalButtonText: string;
    /**
    * Screen-reader label to apply to additional button for accessibility.
    *   Read instead of, or in addition to, to the additionalButtonText (depending on device).
    **/
    additionalButtonAriaLabel: string;
    /**
    * The url to navigate to on additional button click.
    **/
    additionalButtonUrl: string;
    /**
    * Query parameters for the additionalButtonUrl.
    **/
    additionalButtonUrlParams: Params;
    /**
    * E2E testing - data-e2e attribute attached to additional button
    **/
    additionalButtonE2E: string;
    /**
    * If there isn't a "primaryButtonUrl" supplied, this emits when the primary button is clicked.
    **/
    primaryButtonClicked: EventEmitter<void>;
    /**
    * If there isn't a "additionalButtonUrl" supplied, this emits when the additional button is clicked.
    **/
    additionalButtonClicked: EventEmitter<void>;
    constructor(router: Router);
    onPrimaryButtonClick(): void;
    onAdditionalButtonClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChinButtonsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChinButtonsComponent, "ui-core-chin-buttons", never, { "primaryButtonText": { "alias": "primaryButtonText"; "required": false; }; "primaryButtonAriaLabel": { "alias": "primaryButtonAriaLabel"; "required": false; }; "primaryButtonUrl": { "alias": "primaryButtonUrl"; "required": false; }; "primaryButtonUrlParams": { "alias": "primaryButtonUrlParams"; "required": false; }; "primaryButtonE2E": { "alias": "primaryButtonE2E"; "required": false; }; "additionalButtonText": { "alias": "additionalButtonText"; "required": false; }; "additionalButtonAriaLabel": { "alias": "additionalButtonAriaLabel"; "required": false; }; "additionalButtonUrl": { "alias": "additionalButtonUrl"; "required": false; }; "additionalButtonUrlParams": { "alias": "additionalButtonUrlParams"; "required": false; }; "additionalButtonE2E": { "alias": "additionalButtonE2E"; "required": false; }; }, { "primaryButtonClicked": "primaryButtonClicked"; "additionalButtonClicked": "additionalButtonClicked"; }, never, never, false, never>;
}

declare class ClickableComponent {
    /**
    * Boolean to toggle disabled state.
    * Applies "disabled" classes and properties to prevent clicks, navigation, or focus.
    * This will apply to both the host element & button element. If "disabled", no interactions should be possible.
    **/
    disabled: boolean;
    /**
    * Class(es) to apply directly to button element
    * (default "class" property of ClickableComponent is applied to the host element, this will apply directly to the button)
    **/
    buttonClass: string;
    /**
    * ARIA Label attribute (aria-label)
    * Used to replace the button message with more descriptive text, screen-readers will read the ariaLabel, instead of message
    **/
    ariaLabel: string;
    /**
    * E2E testing - data-e2e attribute attached to button
    **/
    e2e: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClickableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClickableComponent, "ui-core-clickable", never, { "disabled": { "alias": "disabled"; "required": false; }; "buttonClass": { "alias": "buttonClass"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; }, {}, never, ["*"], false, never>;
}

declare class CloseButtonComponent extends BaseTextComponent {
    /**
    * The absolute "top" position of the button.
    **/
    top: number;
    /**
    * The absolute "right" position of the button.
    **/
    right: number;
    /**
    * Size of the close button. Small/sm or Medium/md (default)
    **/
    size: 'sm' | 'md';
    /**
    * E2E testing - data-e2e attribute attached to button
    **/
    e2e: string;
    /**
    * Determines if the button has a filled style (default) or not.
    **/
    filled: boolean;
    /**
    * Emits the DOM Event when the close button is clicked.
    **/
    closed: EventEmitter<Event>;
    constructor(textService: TextService);
    close(event: Event): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<CloseButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CloseButtonComponent, "ui-core-close-button", never, { "top": { "alias": "top"; "required": false; }; "right": { "alias": "right"; "required": false; }; "size": { "alias": "size"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; "filled": { "alias": "filled"; "required": false; }; }, { "closed": "closed"; }, never, never, false, never>;
}

declare class CopyToClipboardButtonComponent extends BaseTextComponent implements OnInit, OnDestroy {
    /**
    * Class(es) to pass through to icon button for more custom styling as needed.
    **/
    buttonClass: string;
    /**
    * The label of the value being copied. Used for accessibility (appended to the
    * aria-label) and as the field-name identifier consumers can include in audit
    * log descriptions emitted via (copied). Should describe the field, not contain
    * the sensitive value itself.
    **/
    label: string;
    /**
    * Icon size to pass through to icon button.
    **/
    size: 'sm' | 'md' | 'lg' | 'xl';
    /**
    * The text to copy when clicked. When empty/null/undefined, the button still
    * renders but is shown in a disabled state — useful for inputs that may be
    * empty initially and become populated later.
    **/
    value: string;
    /**
    * E2E testing - data-e2e attribute attached to interactive elements of the component
    **/
    e2e: string;
    /**
    * Direction to place the success or error message popover.
    * If room isn't available for chosen placement, "auto" will attempt to place the popover where it can be seen (based on container/window bounds)
    * See ng-bootstrap documentation for details.
    **/
    statusMessagePlacement: 'auto' | 'top' | 'top-left' | 'top-right' | 'bottom' | 'bottom-left' | 'bottom-right' | 'left' | 'left-top' | 'left-bottom' | 'right' | 'right-top' | 'right-bottom';
    /**
    * Emits after a copy attempt completes. Payload is the success boolean from
    * cdkCopyToClipboardCopied — true when the value reached the clipboard, false
    * on failure. Use this to log audit events at the call site.
    **/
    copied: EventEmitter<boolean>;
    popover: NgbPopover;
    ariaLabel: string;
    success: boolean | null;
    private readonly emptyMessage;
    statusMessage: string;
    readonly checkmarkJson: string;
    _placement: string;
    private messageTimer;
    constructor(textService: TextService);
    ngOnInit(): void;
    onCopy(success: boolean): void;
    onHidden(): void;
    ngOnDestroy(): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<CopyToClipboardButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CopyToClipboardButtonComponent, "ui-core-copy-to-clipboard-button", never, { "buttonClass": { "alias": "buttonClass"; "required": false; }; "label": { "alias": "label"; "required": false; }; "size": { "alias": "size"; "required": false; }; "value": { "alias": "value"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; "statusMessagePlacement": { "alias": "statusMessagePlacement"; "required": false; }; }, { "copied": "copied"; }, never, never, false, never>;
}

declare class IconButtonComponent {
    /**
    * REQUIRED
    * Text for screen-readers, explains purpose of button and is the only way for accessible users to be able to identify it
    * Identical to "message" in ui-core-button, but isn't visible.
    **/
    message: string;
    /**
    * Material Icon string of icon to display.
    **/
    icon: string;
    /**
    * Icon size. Small/sm, Medium/md (default), Large/lg, or X-Large/xl
    **/
    size: 'sm' | 'md' | 'lg' | 'xl';
    /**
    * Boolean to toggle disabled state.
    * Applies "disabled" classes and properties to prevent clicks, navigation, or focus.
    * This will apply to both the host element & button element. If "disabled", no interactions should be possible.
    **/
    disabled: boolean;
    /**
    * Class(es) to apply directly to button element
    * (default "class" property of ButtonComponent is applied to the host element, this will apply directly to the button)
    **/
    buttonClass: string;
    /**
    * ARIA Pressed attribute (aria-pressed)
    * Needs to be set on button element to be handled correctly by screen-readers
    * Used to indicate toggle state (true/false or null/unused) - example: a show/hide button would read this in addition to the message/label ("Hide Account: selected")
    **/
    ariaPressed: boolean;
    /**
    * ARIA Expanded attribute (aria-expanded)
    * Needs to be set on button element to be handled correctly by screen-readers
    * Used to indicate state of collapsable/hideable areas controlled by this button
    **/
    ariaExpanded: HtmlAttributeState | null;
    /**
    * ARIA Controls attribute (aria-controls)
    * Needs to be set on button element to be handled correctly by screen-readers
    * Used to indicate relationship to areas controlled by this button (expects id attribute of controlled area, the area being collapsed/hidden)
    **/
    ariaControls: string;
    /**
    * ARIA "Has Popup" attribute (aria-has-popup)
    * Needs to be set on button elements with popups to be handled correctly by screen-readers
    * Used to indicate the availability of interactive popup element, such as menu, that can be triggered by an element.
    **/
    ariaHasPopup: HtmlAttributeState | null;
    /**
    * ARIA "Active Descendant" attribute (aria-has-popup)
    * Needs to be set on button elements with menus to be handled correctly by screen-readers
    * Used to indicate the availability of interactive popup element, such as menu, that can be triggered by an element.
    **/
    ariaActiveDescendantId: string;
    /**
    * E2E testing - data-e2e attribute attached to button
    **/
    e2e: string;
    /**
    * Icon theme - default icon color is gray
    * "light" shows white icon color for headers/nav
    * "glass" show gray icon color with glass UI background and circle
    **/
    theme: 'glass' | 'light' | 'filled' | 'neutral' | '';
    /**
    * Applies glass UI style on hover
    **/
    usesGlassHoverState: boolean;
    /**
    * Customizable id
    **/
    buttonId: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<IconButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IconButtonComponent, "ui-core-icon-button", never, { "message": { "alias": "message"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "size": { "alias": "size"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "buttonClass": { "alias": "buttonClass"; "required": false; }; "ariaPressed": { "alias": "ariaPressed"; "required": false; }; "ariaExpanded": { "alias": "ariaExpanded"; "required": false; }; "ariaControls": { "alias": "ariaControls"; "required": false; }; "ariaHasPopup": { "alias": "ariaHasPopup"; "required": false; }; "ariaActiveDescendantId": { "alias": "ariaActiveDescendantId"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "usesGlassHoverState": { "alias": "usesGlassHoverState"; "required": false; }; "buttonId": { "alias": "buttonId"; "required": false; }; }, {}, never, never, false, never>;
}

declare enum CardOrientation {
    VERTICAL = "VERTICAL",
    HORIZONTAL = "HORIZONTAL",
    UNKNOWN = "UNKNOWN"
}

declare class CardImageComponent {
    /**
    * The path of the card image.
    **/
    path: string;
    /**
    * The orientation of the card image.
    * Orientation determines the width of the large card image
    * If orientation is unknown, width is set to auto
    * (does not affect small card image)
    **/
    orientation: CardOrientation;
    /**
    * The size the card image.
    * Small card images are used in dropdowns
    **/
    size: 'sm' | 'lg';
    /**
    * Alternate text to describe image for screen-readers (optional)
    **/
    altText: string;
    lgHeight: number;
    lgHorizontalWidth: number;
    lgVerticalWidth: number;
    smHeight: number;
    smWidth: number;
    CardOrientation: typeof CardOrientation;
    static ɵfac: i0.ɵɵFactoryDeclaration<CardImageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardImageComponent, "ui-core-card-image", never, { "path": { "alias": "path"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "size": { "alias": "size"; "required": false; }; "altText": { "alias": "altText"; "required": false; }; }, {}, never, never, false, never>;
}

declare enum GlassBackgroundLayout {
    CARD = "CARD",
    DEFAULT = "DEFAULT",
    FULL_SCREEN = "FULL_SCREEN",
    HEADER = "HEADER",
    MOBILE_HEADER_DEFAULT = "MOBILE_HEADER_DEFAULT",
    MOBILE_HEADER_TALL = "MOBILE_HEADER_TALL",
    MODAL = "MODAL",// same as VERTICAL, but doesn't use fixed position on mobile
    VERTICAL = "VERTICAL"
}

declare class LabelValueListItem {
    id?: string;
    label: string;
    labelIcon?: string;
    value?: string;
    values?: string[];
    e2e?: string;
    iconLeft?: string;
    iconRight?: string;
    iconRightAriaLabel?: string;
    iconLeftColorClass?: string;
    iconLeftAllowEmojis?: boolean;
    tooltipContent?: string;
    masked?: boolean;
    showCopyToClipboard?: boolean;
    valueIsLink?: boolean;
    externalUrlNewTab?: boolean;
    url?: string;
    notificationMessage?: string;
    notificationTheme?: 'error' | 'information' | 'success' | 'warning' | '';
    notificationIcon?: string;
}

declare class AccountCardComponent extends BaseDestroyComponent {
    private windowService;
    /**
    * Controls the background color of the card and account icon. Accepts any class that defines a background color.
    * Examples include: "bg-brand-primary", "bg-brand-secondary", "bg-accent-color-1", "bg-accent-color-2", etc.
    **/
    backgroundAccentColorClass: string;
    /**
    * The account icon to display at the top right of the card.
    **/
    accountIcon: string;
    /**
    * The account name to display at the top of the card.
    **/
    accountName: string;
    /**
    * The masked account number to the right of the account name.
    **/
    maskedAccountNumber: string;
    /**
    * The label to display directly beneath the primary amount.
    **/
    primaryAmountLabel: string;
    /**
    * The primary amount value that displays beneath the account name.
    **/
    primaryAmountValue: string;
    /**
    * Array of fields to display as LabelValueListItems. Only up to two fields will be shown.
    **/
    fields: LabelValueListItem[];
    /**
    * Emits after a copy-to-clipboard attempt completes on one of the fields.
    * Payload identifies which field's label was copied and whether the copy
    * succeeded. Use this to log audit events at the call site.
    **/
    copied: EventEmitter<{
        label: string;
        success: boolean;
    }>;
    glassV2Enabled: boolean;
    isLowRes: boolean;
    isMobile: boolean;
    GlassBackgroundLayout: typeof GlassBackgroundLayout;
    constructor(windowService: WindowService);
    onFieldCopied(field: LabelValueListItem, success: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AccountCardComponent, "ui-core-account-card", never, { "backgroundAccentColorClass": { "alias": "backgroundAccentColorClass"; "required": false; }; "accountIcon": { "alias": "accountIcon"; "required": false; }; "accountName": { "alias": "accountName"; "required": false; }; "maskedAccountNumber": { "alias": "maskedAccountNumber"; "required": false; }; "primaryAmountLabel": { "alias": "primaryAmountLabel"; "required": false; }; "primaryAmountValue": { "alias": "primaryAmountValue"; "required": false; }; "fields": { "alias": "fields"; "required": false; }; }, { "copied": "copied"; }, never, never, false, never>;
}

declare class ActionCardItem implements Action {
    text: string;
    icon: string;
    e2e?: string;
    action: (item?: any) => void;
    url?: string;
    urlQueryParams: Params;
    externalUrlNewTab: boolean;
    constructor(text: string, icon: string);
    static fromObject(data: any): ActionCardItem;
}

declare class GridItem {
    data: any;
    order?: number;
    height?: number;
    constructor(data: any, order?: number, height?: number);
    static fromObject(data: any): GridItem;
}

declare class GridLayoutComponent extends BaseDestroyComponent implements OnInit, OnChanges, AfterViewInit, AfterViewChecked {
    private windowService;
    gridItems: QueryList<ElementRef>;
    /**
    * Each item represents a grid item. "data" property is required.
    **/
    items: GridItem[];
    /**
    * Required. The generic template to render for each grid cell. Use the "data" property on each GridLayoutItem to pass data.
    **/
    itemTemplate: TemplateRef<any>;
    /**
    * The number of columns to show on tablet. Max is 4.
    * For example, if this is used inside an enhanced modal, recommended number of columns for tablet is 2.
    **/
    tabletColumns: 1 | 2 | 3 | 4;
    /**
    * The number of columns to show on desktop. Max is 4.
    **/
    desktopColumns: 1 | 2 | 3 | 4;
    /**
     * When enabled, the layout will switch from a standard grid to a masonry layout, where items are placed in the next available space in the grid, rather than strictly by row.
     * This allows for items of varying heights to be displayed without leaving large gaps in the layout.
    **/
    layout: 'default' | 'masonry';
    /**
    * When enabled, all rows in the grid will have the same height, determined by the tallest item in the grid.
    **/
    equalHeightRows: boolean;
    /**
    * When enabled, a border appears between rows.
    **/
    borderedRows: boolean;
    /**
    * When enabled, the gap between rows is removed. Useful for templates that have their own vertical whitespace.
    * Will not be applied if borderedRows is enabled.
    **/
    noRowGap: boolean;
    /**
    * When enabled, the gap between columns is reduced.
    **/
    smallColumnGap: boolean;
    /**
     * Only applies if layout is set to masonry. Determines how items are distributed across columns.
     * "default" will place each item in the next available space in the grid, which may result in a more balanced layout but less control over item placement.
     * "leftToRightPreferred" will attempt to place items in their natural left-to-right order, but will deviate from this order if placing an item in its natural column would result in significantly taller columns compared to placing it in the shortest column.
     */
    masonryColumnDistribution: 'default' | 'leftToRightPreferred';
    private isDesktop;
    private isTablet;
    isMobile: boolean;
    gridClasses: string;
    columnGroups: GridItem[][];
    masonryGridItems: GridItem[];
    gridItemHeights: number[];
    constructor(windowService: WindowService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    ngAfterViewChecked(): void;
    private measureAndRebuildMasonry;
    private clearMasonryState;
    private setGridClasses;
    private getGridItemsHeights;
    private buildDefaultMasonryColumnGroups;
    private buildLeftToRightPreferredMasonryColumnGroups;
    static ɵfac: i0.ɵɵFactoryDeclaration<GridLayoutComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GridLayoutComponent, "ui-core-grid-layout", never, { "items": { "alias": "items"; "required": false; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; }; "tabletColumns": { "alias": "tabletColumns"; "required": false; }; "desktopColumns": { "alias": "desktopColumns"; "required": false; }; "layout": { "alias": "layout"; "required": false; }; "equalHeightRows": { "alias": "equalHeightRows"; "required": false; }; "borderedRows": { "alias": "borderedRows"; "required": false; }; "noRowGap": { "alias": "noRowGap"; "required": false; }; "smallColumnGap": { "alias": "smallColumnGap"; "required": false; }; "masonryColumnDistribution": { "alias": "masonryColumnDistribution"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ActionCardComponent implements OnChanges {
    /**
    * Items to be rendered.
    **/
    items: ActionCardItem[];
    /**
    * Optional header text.
    **/
    header: string;
    /**
    * The theme of the card, which directly corresponds to our standard container classes.
    **/
    theme: 'bordered' | 'bordered-interactive' | 'default' | 'elevated' | 'elevated-interactive' | 'sunken' | 'brand';
    /**
    * The number of columns to show on tablet. Max is 4.
    * For example, if this is used inside an enhanced modal, recommended number of columns for tablet is 2.
    **/
    tabletColumns: 1 | 2 | 3 | 4;
    /**
    * The number of columns to show on desktop. Max is 4.
    **/
    desktopColumns: 1 | 2 | 3 | 4;
    /**
    * Optional. E2E customization.
    **/
    e2e: string;
    e2ePrefix: string;
    containerClasses: string;
    gridItems: GridItem[];
    ngOnChanges(changes: SimpleChanges): void;
    onButtonClick(item: ActionCardItem): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ActionCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ActionCardComponent, "ui-core-action-card", never, { "items": { "alias": "items"; "required": false; }; "header": { "alias": "header"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "tabletColumns": { "alias": "tabletColumns"; "required": false; }; "desktopColumns": { "alias": "desktopColumns"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; }, {}, never, never, false, never>;
}

declare class CardComponent implements OnChanges {
    /**
    * The theme of the card, which directly corresponds to our standard container classes.
    **/
    theme: 'bordered' | 'bordered-interactive' | 'default' | 'elevated' | 'elevated-interactive' | 'sunken' | 'brand';
    /**
    * Specifies whether the card's content should be centered within the container. Defaults to false.
    **/
    centered: boolean;
    /**
    * Optional input to set the height of the card. For example: "157px", "100%", "auto", etc.
    **/
    height: string;
    /**
    * Specifies whether the card's container should have equal padding all the way around. Defaults to false.
    **/
    equalPadding: boolean;
    containerClasses: string;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardComponent, "ui-core-card", never, { "theme": { "alias": "theme"; "required": false; }; "centered": { "alias": "centered"; "required": false; }; "height": { "alias": "height"; "required": false; }; "equalPadding": { "alias": "equalPadding"; "required": false; }; }, {}, never, ["*"], false, never>;
}

declare class CardGridItem {
    theme: string;
    value?: string;
    isUrl: boolean;
    constructor(theme?: string, value?: string, // The value to emit when clicked, or else the url to navigate to
    isUrl?: boolean);
    data: any;
    e2e?: string;
}

declare class CardGridComponent extends BaseDestroyComponent implements OnChanges {
    private windowService;
    private router;
    /**
    * Each item represents a card with a theme. Optional properties include "value" and "data".
    * Each item can also have isUrl set to true, which will route to the value on click (can be an internal or external url).
    **/
    items: CardGridItem[];
    /**
    * Required. The generic template to render for each card. Use the "data" property on each CardGridItem to pass data.
    **/
    cardTemplate: TemplateRef<any>;
    /**
    * The number of columns to show on tablet. Max is 3.
    * For example, if this is used inside an enhanced modal, recommended number of columns for tablet is 2.
    **/
    tabletColumns: number;
    /**
    * The number of columns to show on desktop. Max is 3.
    **/
    desktopColumns: number;
    /**
    * Emits the value of the CardGridItem clicked.
    **/
    cardClicked: EventEmitter<string>;
    private isDesktop;
    private isMobile;
    columnCssClass: string;
    constructor(windowService: WindowService, router: Router);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    cardButtonClicked(item: CardGridItem): void;
    private setColumnClass;
    static ɵfac: i0.ɵɵFactoryDeclaration<CardGridComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardGridComponent, "ui-core-card-grid", never, { "items": { "alias": "items"; "required": false; }; "cardTemplate": { "alias": "cardTemplate"; "required": false; }; "tabletColumns": { "alias": "tabletColumns"; "required": false; }; "desktopColumns": { "alias": "desktopColumns"; "required": false; }; }, { "cardClicked": "cardClicked"; }, never, never, false, never>;
}

/**
 * Model for badge component configuration
 */
declare class BadgeModel {
    message: string;
    theme: BadgeTheme;
    icon?: string;
    /** Whether the badge has a framed background */
    framed: boolean;
    /** Position of the icon relative to the message text */
    iconPosition: 'left' | 'right';
    constructor(message: string, theme?: BadgeTheme, icon?: string);
    /**
     * Creates a BadgeModel instance from a plain object
     */
    static fromObject(data: any): BadgeModel;
}

type ImageDisplayMode = 'fit' | 'fill';

declare enum ObjectPosition {
    TOP = "top",
    RIGHT = "right",
    BOTTOM = "bottom",
    LEFT = "left",
    CENTER = "center"
}

declare class ImageDisplayModel {
    path: string;
    altText: string;
    height: number;
    displayMode: ImageDisplayMode;
    constructor(path: string, altText: string, height: number, displayMode: ImageDisplayMode);
    width: number;
    objectPosition: ObjectPosition;
    badges: BadgeModel[];
    borderRadius: boolean;
    static fromObject(data: any): ImageDisplayModel;
}

declare class ActionListItem implements Action {
    action?: () => void;
    text: string;
    url?: string;
    externalUrlNewTab?: boolean;
    urlQueryParams?: Params;
    ariaLabel?: string;
    e2e?: string;
    id?: string;
    showBadge?: boolean;
    iconLeft?: string;
    iconRight?: string;
    fontWeight?: 'bold' | 'semibold';
}

declare class ActionListComponent implements OnChanges {
    private router;
    /**
    * Required. Array of ActionListItems to display
    **/
    items: ActionListItem[];
    /**
     * Optional. Controls the visual style of the action list.
     **/
    variant: 'default' | 'horizontal-mega-menu';
    /**
    * Optional. Heading to display above list.
    **/
    heading?: string;
    /**
    * Optional. Allows a parent component to control the selected item externally.
    * When provided, overrides the internal selected state. Set to undefined to clear selection.
    * Useful when the parent needs to reset selection (e.g. when a nav menu closes).
    **/
    selectedItemId?: string;
    /**
     * Emits the clicked ActionListItem. Use this to react to item clicks at the parent level,
     * e.g. opening a submenu or tracking active state across components.
     **/
    itemSelected: EventEmitter<ActionListItem>;
    showAnimation: boolean;
    actionItems: ActionListItem[];
    selectedItem: string | undefined;
    constructor(router: Router);
    ngOnChanges(changes: SimpleChanges): void;
    onActionClick(actionItem: ActionListItem): void;
    private getAction;
    static ɵfac: i0.ɵɵFactoryDeclaration<ActionListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ActionListComponent, "ui-core-action-list", never, { "items": { "alias": "items"; "required": false; }; "variant": { "alias": "variant"; "required": false; }; "heading": { "alias": "heading"; "required": false; }; "selectedItemId": { "alias": "selectedItemId"; "required": false; }; }, { "itemSelected": "itemSelected"; }, never, never, false, never>;
}

declare class BadgeListComponent implements OnChanges {
    /**
    * Badges to render
    **/
    items: BadgeModel[];
    /**
    * Controls margin above the badges
    **/
    marginTop: boolean;
    /**
    * Optional. Can be used to cap the number of badges.
    * If zero, there is no max.
    **/
    max: number;
    /**
    * Optional. Can be used to right-align badges.
    **/
    rightAlign: boolean;
    visibleBadges: BadgeModel[];
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BadgeListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BadgeListComponent, "ui-core-badge-list", never, { "items": { "alias": "items"; "required": false; }; "marginTop": { "alias": "marginTop"; "required": false; }; "max": { "alias": "max"; "required": false; }; "rightAlign": { "alias": "rightAlign"; "required": false; }; }, {}, never, never, false, never>;
}

declare class BulletListComponent implements OnChanges {
    /**
    * Required. Array of strings to display
    **/
    items: string[];
    /**
    * Optional. Label displayed above the list.
    **/
    label: string;
    /**
    * Optional. CSS classes to apply to the label text.
    * Use typography classes to control size (e.g. 'text-caption', 'text-second', 'text-subheading'),
    * weight (e.g. 'font-weight-normal', 'font-weight-bold'), and
    * color (e.g. 'text-color-primary', 'text-color-tertiary').
    **/
    labelClasses: string;
    /**
    * Optional. The marker style for list items.
    * 'disc' = filled circle (default), 'circle' = outline circle,
    * 'square' = filled square, 'none' = no marker
    **/
    markerStyle: 'disc' | 'circle' | 'square' | 'none';
    /**
    * Optional. If enabled, items are not indented but appear flush to the edge of the container.
    * Defaults to false, which applies standard indentation for list items.
    **/
    leftAligned: boolean;
    /**
    * Optional. Controls margin below the list. Default is true, which applies a margin below the list.
    **/
    marginBottom: boolean;
    readonly labelId: string;
    validItems: string[];
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BulletListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BulletListComponent, "ui-core-bullet-list", never, { "items": { "alias": "items"; "required": false; }; "label": { "alias": "label"; "required": false; }; "labelClasses": { "alias": "labelClasses"; "required": false; }; "markerStyle": { "alias": "markerStyle"; "required": false; }; "leftAligned": { "alias": "leftAligned"; "required": false; }; "marginBottom": { "alias": "marginBottom"; "required": false; }; }, {}, never, never, false, never>;
}

interface OrderedListItem {
    label: string;
    children?: OrderedListInput[];
}
type OrderedListInput = string | OrderedListItem;
type OrderedListType = '1' | 'a' | 'A' | 'i' | 'I';
declare class OrderedListComponent implements OnChanges {
    /**
    * Required. An array of strings to display. For nested lists, this will be an array of strings
    * and item objects to display and recurse through.
    **/
    items: OrderedListInput[];
    /**
    * Optional. Label displayed above the list.
    **/
    label: string;
    /**
    * Optional. The number to start counting from. Defaults to 1.
    **/
    start: number;
    /**
    * Optional. The marker type for list items.
    * '1' = numeric (default), 'a' = lowercase alpha, 'A' = uppercase alpha,
    * 'i' = lowercase roman, 'I' = uppercase roman. For nested lists, the marker type will be
    * determined automatically.
    **/
    type: OrderedListType;
    /**
    * Optional. If enabled, items are not indented but appear flush to the edge of the container.
    * Defaults to false, which applies standard indentation for list items.
    **/
    leftAligned: boolean;
    /**
    * Optional. Controls margin below the list. Default is true, which applies a margin below the list.
    **/
    marginBottom: boolean;
    /**
    * Optional. CSS classes to apply to the label text.
    * Use typography classes to control size (e.g. 'text-caption', 'text-second', 'text-subheading'),
    * weight (e.g. 'font-weight-normal', 'font-weight-bold'), and
    * color (e.g. 'text-color-primary', 'text-color-tertiary').
    **/
    labelClasses: string;
    /**
     * @internal — Set automatically by the component during recursion.
     * Used to determine marker type for nested lists based on the current depth and parent list's type.
     **/
    _rootType: OrderedListType | null;
    /**
     * @internal — Set automatically by the component during recursion.
     * Used to track the current depth of the list for nested lists.
     **/
    _depth: number;
    readonly labelId: string;
    validItems: OrderedListItem[];
    activeType: OrderedListType;
    childDepth: number;
    ngOnChanges(changes: SimpleChanges): void;
    private normalizeItems;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderedListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrderedListComponent, "ui-core-ordered-list", never, { "items": { "alias": "items"; "required": false; }; "label": { "alias": "label"; "required": false; }; "start": { "alias": "start"; "required": false; }; "type": { "alias": "type"; "required": false; }; "leftAligned": { "alias": "leftAligned"; "required": false; }; "marginBottom": { "alias": "marginBottom"; "required": false; }; "labelClasses": { "alias": "labelClasses"; "required": false; }; "_rootType": { "alias": "_rootType"; "required": false; }; "_depth": { "alias": "_depth"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ChipListItem {
    message: string;
    e2e: string;
    id: string;
    icon: string;
    constructor(message: string);
}

declare class ChipListComponent extends BaseTextComponent implements OnChanges {
    /**
    * Required. The label for the chip list
    **/
    label: string;
    /**
    * Can be used to visually hide the label. Label should always be provided, and hidden if undesired
    **/
    hideLabel: boolean;
    /**
    * All chips to display
    **/
    items: ChipListItem[];
    /**
    * When enabled, the remove button is displayed per chip.
    * This is required to trigger the itemRemoved event.
    * Chip list must not be disabled to show the remove button.
    **/
    showRemoveButton: boolean;
    /**
    * Boolean to indicate if chips should show as disabled/uninteractive.
    * When disabled, the itemClicked will not be emitted.
    **/
    disabled: boolean;
    /**
    * Emits the item when a chip is clicked.
    **/
    itemClicked: EventEmitter<ChipListItem>;
    /**
    * Emits the item when the remove button is clicked.
    **/
    itemRemoved: EventEmitter<ChipListItem>;
    readonly labelId: string;
    constructor(textService: TextService);
    ngOnChanges(changes: SimpleChanges): void;
    onItemClick(item: ChipListItem): void;
    itemKeyDown(event: KeyboardEvent, item: ChipListItem): void;
    removeClicked(event: Event, item: ChipListItem): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChipListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChipListComponent, "ui-core-chip-list", never, { "label": { "alias": "label"; "required": false; }; "hideLabel": { "alias": "hideLabel"; "required": false; }; "items": { "alias": "items"; "required": false; }; "showRemoveButton": { "alias": "showRemoveButton"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, { "itemClicked": "itemClicked"; "itemRemoved": "itemRemoved"; }, never, never, false, never>;
}

declare class DescriptionListItem {
    label: string;
    value?: string;
    values?: string[];
    e2e?: string;
    static fromObject(data: any): DescriptionListItem;
}

declare class DescriptionListComponent implements OnChanges {
    get hostClass(): string;
    /**
    * Required. Array of DescriptionListItems to display
    **/
    items: DescriptionListItem[];
    /**
    * Boolean to show a shaded/grey background behind the list
    **/
    framed: boolean;
    /**
    * Boolean to display label as bold
    **/
    labelIsBold: boolean;
    /**
    * Boolean to align values to the right
    **/
    rightAlignValue: boolean;
    /**
    * Controls margin below the list.
    **/
    marginBottom: boolean;
    displayItems: DescriptionListItem[];
    constructor();
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DescriptionListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DescriptionListComponent, "ui-core-description-list", never, { "items": { "alias": "items"; "required": false; }; "framed": { "alias": "framed"; "required": false; }; "labelIsBold": { "alias": "labelIsBold"; "required": false; }; "rightAlignValue": { "alias": "rightAlignValue"; "required": false; }; "marginBottom": { "alias": "marginBottom"; "required": false; }; }, {}, never, never, false, never>;
}

declare class IconBulletItem {
    message: string;
    icon: string;
    header: string;
    backgroundClass: string;
    colorClass: string;
    constructor(message: string, icon: string);
    static fromObject(data: any): IconBulletItem;
    static getProgressItem(complete: boolean, message: string, header?: string): IconBulletItem;
}

declare class IconBulletsComponent implements OnChanges {
    /**
    * An array of items to display in the unordered list.
    * Each item must have a message (supports HTML) and a material icon specified. If either is missing, the item will not display.
    * The backgroundClass is optional. If any item is missing the backgroundClass, the component will assign accent colors.
    * The colorClass and header are also optional.
    **/
    items: IconBulletItem[];
    /**
    * By default, the icons are presented within a circle. If iconOnly is enabled, the icon will render without a shape.
    * backgroundClass per item will have no effect.
    **/
    iconOnly: boolean;
    /**
    * The default style of the item headers. Can be customized with standard typography classes.
    **/
    headerClass: string;
    validItems: IconBulletItem[];
    ngOnChanges(): void;
    private assignBackgroundColors;
    static ɵfac: i0.ɵɵFactoryDeclaration<IconBulletsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IconBulletsComponent, "ui-core-icon-bullets", never, { "items": { "alias": "items"; "required": false; }; "iconOnly": { "alias": "iconOnly"; "required": false; }; "headerClass": { "alias": "headerClass"; "required": false; }; }, {}, never, never, false, never>;
}

declare class LabelValueListComponent extends BaseDestroyComponent implements OnChanges, AfterViewChecked {
    private windowService;
    private elementRef;
    mobileGrid: boolean;
    vertical: boolean;
    /**
    * Required. Array of LabelValueListItems to display
    **/
    items: LabelValueListItem[];
    /**
    * On mobile, show items in a single vertical column instead of 2 columns.
    **/
    mobileSingleColumn: boolean;
    /**
    * Class(es) to apply to label-value containers for spacing.
    **/
    elementsClass: string;
    /**
    * Displays list as a vertical list
    **/
    isVerticalList: boolean;
    /**
    * Emits the item when the icon right is clicked.
    **/
    iconRightClicked: EventEmitter<LabelValueListItem>;
    /**
    * Emits the item when the link is clicked.
    **/
    linkClicked: EventEmitter<LabelValueListItem>;
    /**
    * Emits after a copy-to-clipboard attempt completes on one of the items.
    * Payload identifies which item's label was copied and whether the copy
    * succeeded. Use this to log audit events at the call site.
    **/
    copied: EventEmitter<{
        label: string;
        success: boolean;
    }>;
    /**
    * Emits when a user toggles the mask on a masked item. Payload identifies
    * the item and whether the mask is now on (true) or off/revealed (false).
    * Use this to log audit events at the call site.
    **/
    maskToggleClicked: EventEmitter<{
        item: LabelValueListItem;
        maskIsOn: boolean;
    }>;
    displayItems: LabelValueListItem[];
    isLowRes: boolean;
    isMobile: boolean;
    constructor(windowService: WindowService, elementRef: ElementRef);
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewChecked(): void;
    private setLayoutFlags;
    private getSpacingElements;
    private getMobileRows;
    onIconRightClick(item: LabelValueListItem): void;
    onLinkClick(item: LabelValueListItem): void;
    onItemCopied(item: LabelValueListItem, success: boolean): void;
    onItemMaskToggled(item: LabelValueListItem, maskIsOn: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LabelValueListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LabelValueListComponent, "ui-core-label-value-list", never, { "items": { "alias": "items"; "required": false; }; "mobileSingleColumn": { "alias": "mobileSingleColumn"; "required": false; }; "elementsClass": { "alias": "elementsClass"; "required": false; }; "isVerticalList": { "alias": "isVerticalList"; "required": false; }; }, { "iconRightClicked": "iconRightClicked"; "linkClicked": "linkClicked"; "copied": "copied"; "maskToggleClicked": "maskToggleClicked"; }, never, never, false, never>;
}

declare class PipedDetail {
    message: string;
    e2e?: string;
    constructor(message: string, e2e?: string);
    cssClass?: string;
    icon?: string;
    italic: boolean;
    notificationTheme?: NotificationTheme;
}

declare class PipedDetailsComponent extends BaseDestroyComponent {
    private windowService;
    /**
    * These details display in a horizontal list and are separated by pipes.
    **/
    details: PipedDetail[];
    /**
    * Enable emoji support for icons. Checking for emojis is expensive, so only enable if needed.
    **/
    allowEmojis: boolean;
    /**
    * Sets the alignment within the container.
    * Default is 'left'. Use 'right' for right-aligned details.
    **/
    alignment: 'left' | 'right';
    isLowRes: boolean;
    isMobile: boolean;
    constructor(windowService: WindowService);
    static ɵfac: i0.ɵɵFactoryDeclaration<PipedDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PipedDetailsComponent, "ui-core-piped-details", never, { "details": { "alias": "details"; "required": false; }; "allowEmojis": { "alias": "allowEmojis"; "required": false; }; "alignment": { "alias": "alignment"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ContentCardComponent implements OnChanges {
    /**
    * Optional image to display on the card.
    * If no height is provided on the ImageDisplayModel, it defaults to 144px.
    **/
    image: ImageDisplayModel | null;
    /**
    * Optional header text.
    **/
    header: string;
    /**
    * Optional subheader text.
    **/
    subheader: string;
    /**
    * Optional label-value pairs that render under the badges.
    **/
    labelValueItems: LabelValueListItem[];
    /**
    * Optional badges that render under the subheader.
    * Up to 5 are allowed.
    **/
    badges: BadgeModel[];
    /**
    * Optional: The text of the primary button.
    **/
    primaryButtonText: string;
    /**
    * Optional: The text of the secondary button.
    **/
    secondaryButtonText: string;
    /**
    * Optional: The text of the tertiary button.
    **/
    tertiaryButtonText: string;
    /**
    * Whether or not the entire card area should be clickable. If true, the entire card will have a visible hover state
    * and allow emitting "cardClicked" events.
    **/
    clickable: boolean;
    /**
    * Display card in auto, stretch, or fixed mode.
    * - 'auto': Default mode, adjusts height based on content
    * - 'stretch': Stretches the card to fill the height of its parent container (Useful in grid)
    * - 'fixed': Displays card in a fixed height with no scroll
    **/
    mode: 'auto' | 'stretch' | 'fixed';
    /**
    * Emits when primary button is clicked.
    **/
    primaryButtonClicked: EventEmitter<void>;
    /**
    * Emits when secondary button is clicked.
    **/
    secondaryButtonClicked: EventEmitter<void>;
    /**
    * Emits when tertiary button is clicked.
    **/
    tertiaryButtonClicked: EventEmitter<void>;
    /**
    * Emits the value of the item clicked.
    **/
    cardClicked: EventEmitter<void>;
    resolvedImage: ImageDisplayModel | null;
    hasImage: boolean;
    hasHeaderText: boolean;
    hasBadges: boolean;
    hasLabelValueItems: boolean;
    hasButtons: boolean;
    clickableButtonClasses: string;
    ngOnChanges(changes: SimpleChanges): void;
    onCardClick(): void;
    onPrimaryButtonClick(): void;
    onSecondaryButtonClick(): void;
    onTertiaryButtonClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContentCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ContentCardComponent, "ui-core-content-card", never, { "image": { "alias": "image"; "required": false; }; "header": { "alias": "header"; "required": false; }; "subheader": { "alias": "subheader"; "required": false; }; "labelValueItems": { "alias": "labelValueItems"; "required": false; }; "badges": { "alias": "badges"; "required": false; }; "primaryButtonText": { "alias": "primaryButtonText"; "required": false; }; "secondaryButtonText": { "alias": "secondaryButtonText"; "required": false; }; "tertiaryButtonText": { "alias": "tertiaryButtonText"; "required": false; }; "clickable": { "alias": "clickable"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; }, { "primaryButtonClicked": "primaryButtonClicked"; "secondaryButtonClicked": "secondaryButtonClicked"; "tertiaryButtonClicked": "tertiaryButtonClicked"; "cardClicked": "cardClicked"; }, never, ["*"], false, never>;
}

declare class SwiperContainerComponent<T> implements AfterViewInit, OnChanges {
    swiperRef: ElementRef;
    /**
    * Items to render as "slides"
    **/
    slides: T[];
    /**
    * Template for rendering each slide.
    * Use "slide" property for template binding.
    **/
    slideTemplate: TemplateRef<any>;
    /**
    * Swiper options to control behavior.
    **/
    options: object;
    /**
    * If enabled, full-height is added to the swiper.
    **/
    fullHeight: boolean;
    /**
    * Emits the new slide index when the visible slide has changed.
    **/
    slideChanged: EventEmitter<number>;
    private swiper;
    private initialized;
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    private initializeSwiper;
    removeSlide(index: number): void;
    removeCurrentSlide(): void;
    setAriaActive(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SwiperContainerComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SwiperContainerComponent<any>, "ui-core-swiper-container", never, { "slides": { "alias": "slides"; "required": false; }; "slideTemplate": { "alias": "slideTemplate"; "required": false; }; "options": { "alias": "options"; "required": false; }; "fullHeight": { "alias": "fullHeight"; "required": false; }; }, { "slideChanged": "slideChanged"; }, never, never, true, never>;
}

declare class CarouselComponent<T> extends BaseTextComponent implements OnChanges {
    private windowService;
    swiperContainer: SwiperContainerComponent<T>;
    /**
    * Items to render as "slides"
    **/
    slides: T[];
    /**
    * Template for rendering each slide.
    * Use "slide" property for template binding.
    **/
    slideTemplate: TemplateRef<any>;
    /**
    * Optional input to use a layout without pagination circles.
    * If only one slide is visible, pagination is hidden.
    **/
    showPagination: boolean;
    /**
    * Optional input to hide next/previous buttons.
    * If only one slide is visible, scroll buttons are hidden.
    **/
    showScrollButtons: boolean;
    /**
    * Optional input for showing shadow styling on the swiper container.
    **/
    showSwiperContainerShadow: boolean;
    /**
    * Optional input to determine which slide is shown first.
    **/
    initialSlideIndex: number;
    /**
    * Hidden label to apply to carousel.
    **/
    ariaLabel: string;
    /**
    * If true, the carousel will focus on the first slide when it loads
    * screen-reader support for pages with carousel as the header
    **/
    focusOnLoad: boolean;
    /**
    * Optional input to specify whether the carousel should "rewind" instead of "loop" at the beginning/end.
    * Recommended when slides need to be added after the first render, since looping can cause issues with slide indexing.
    * Defaults to false.
    **/
    rewind: boolean;
    /**
    * Emits the new slide index when the visible slide has changed.
    **/
    slideChanged: EventEmitter<number>;
    private currentIndex;
    currentItemMessage: string;
    isAriaActive: boolean;
    readonly labelId: string;
    readonly paginationId: string;
    readonly prevButtonId: string;
    readonly nextButtonId: string;
    isFullNav: boolean;
    private isMobile;
    swiperOptions: object;
    constructor(textService: TextService, windowService: WindowService);
    private getSwiperOptions;
    ngOnChanges(changes: SimpleChanges): void;
    handleSlideChange(index: number): void;
    removeSlide(index: number): void;
    removeCurrentSlide(): void;
    get currentSlideIndex(): number;
    private setCurrentItemMessage;
    private setAriaActive;
    private setSlideAccessibility;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<CarouselComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CarouselComponent<any>, "ui-core-carousel", never, { "slides": { "alias": "slides"; "required": false; }; "slideTemplate": { "alias": "slideTemplate"; "required": false; }; "showPagination": { "alias": "showPagination"; "required": false; }; "showScrollButtons": { "alias": "showScrollButtons"; "required": false; }; "showSwiperContainerShadow": { "alias": "showSwiperContainerShadow"; "required": false; }; "initialSlideIndex": { "alias": "initialSlideIndex"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "focusOnLoad": { "alias": "focusOnLoad"; "required": false; }; "rewind": { "alias": "rewind"; "required": false; }; }, { "slideChanged": "slideChanged"; }, never, never, false, never>;
}

declare class CollapsableComponent extends BaseTextComponent implements OnChanges {
    /**
    * Text to display on collapsable button.
    **/
    message: string;
    /**
    * Class(es) to apply directly to collapsable button element.
    **/
    messageClass: string;
    /**
    * Size of collapsable button - 'xs' = caption/label, 'sm' = button, 'md' = body/base, 'lg' = heading4.
    * 'lg' renders in primary text color and is intended for use as a group/section header.
    * All other sizes render in tertiary text color.
    **/
    size: 'xs' | 'sm' | 'md' | 'lg';
    /**
    * Position of arrow icon. Left or Right side of button text.
    **/
    arrowPosition: 'left' | 'right';
    /**
    * Initial state of collapsable container.
    **/
    collapsed: boolean;
    /**
    * Collapsable button will fill container if true.
    * If tertiary button is defined, collapsable button will be standard width while tertiary button aligns right.
    **/
    fullWidth: boolean;
    /**
    * Text content to display in an optional tooltip popover.
    * Required field to show tooltip icon.
    **/
    tooltip: string;
    /**
    * Direction to place the tooltip popover.
    * Passed directly to ui-core-tooltip.
    **/
    tooltipPlacement: 'auto' | 'top' | 'top-left' | 'top-right' | 'bottom' | 'bottom-left' | 'bottom-right' | 'left' | 'left-top' | 'left-bottom' | 'right' | 'right-top' | 'right-bottom';
    /**
    * Text to display on optional tertiary button.
    **/
    tertiaryButtonMessage: string;
    /**
    * Icon shown in tertiary button.
    **/
    tertiaryButtonIcon: string;
    /**
    * Displays a standard (themed) top border if true
    **/
    borderTop: boolean;
    /**
    * Displays a standard (themed) bottom border if true
    **/
    borderBottom: boolean;
    /**
    * E2E testing - data-e2e attribute attached to collapsable button
    **/
    e2e: string;
    /**
    * When this component wraps another (like Text Area), this labelId links the other component to the Collapsable label
    **/
    labelId: string;
    /**
    * Boolean to set locked/disabled state. Used with textarea inputs.
    **/
    locked: boolean;
    /**
    * String to display in tooltip when collapsed input is locked.
    **/
    lockedMessage: string;
    /**
    * ARIA Described-by content to add to collapsable button message
    * Used to give more context to the collapsable for screen-readers
    * for example: an ariaDescription of "Call Center" would give meaningful context to a message of just "Hours" (as used in Support Hub)
    **/
    ariaDescription: string;
    /**
    * Emits true if collapsed. False if expanded.
    **/
    collapsedChange: EventEmitter<boolean>;
    /**
    * Emits when tertiary button is clicked.
    **/
    tertiaryButtonClicked: EventEmitter<any>;
    HtmlAttributeStateEnum: typeof HtmlAttributeState;
    largeArrow: boolean;
    sizeClass: string;
    uid: string;
    constructor(textService: TextService);
    ngOnChanges(): void;
    toggleCollapsed(): void;
    triggerButtonClick(): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<CollapsableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CollapsableComponent, "ui-core-collapsable", never, { "message": { "alias": "message"; "required": false; }; "messageClass": { "alias": "messageClass"; "required": false; }; "size": { "alias": "size"; "required": false; }; "arrowPosition": { "alias": "arrowPosition"; "required": false; }; "collapsed": { "alias": "collapsed"; "required": false; }; "fullWidth": { "alias": "fullWidth"; "required": false; }; "tooltip": { "alias": "tooltip"; "required": false; }; "tooltipPlacement": { "alias": "tooltipPlacement"; "required": false; }; "tertiaryButtonMessage": { "alias": "tertiaryButtonMessage"; "required": false; }; "tertiaryButtonIcon": { "alias": "tertiaryButtonIcon"; "required": false; }; "borderTop": { "alias": "borderTop"; "required": false; }; "borderBottom": { "alias": "borderBottom"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; "labelId": { "alias": "labelId"; "required": false; }; "locked": { "alias": "locked"; "required": false; }; "lockedMessage": { "alias": "lockedMessage"; "required": false; }; "ariaDescription": { "alias": "ariaDescription"; "required": false; }; }, { "collapsedChange": "collapsedChange"; "tertiaryButtonClicked": "tertiaryButtonClicked"; }, never, ["*"], false, never>;
}

declare class AnimationComponent implements OnChanges {
    /**
    * JSON string or base64-encoded string of animation data
    *  (animationData and path are mutually exclusive)
    **/
    animationData: string;
    /**
    * Alternate text to describe animation for screen-readers
    **/
    altText: string;
    /**
    * Boolean to indicate that the animation should not animate, but display a single still frame
    **/
    freeze: boolean;
    /**
    * Animation frame to display when freeze is true - animation becomes a "still image" of this frame
    **/
    freezeFrame: number;
    /**
    * Boolean to indicate that the animation should loop & play continuously. If false, it will play once & stop.
    **/
    loop: boolean;
    /**
    * Number to indicate the total number of times the animation should loop. Only used when loop is true.
    * 0 enables infinite looping of animation (default).
    **/
    loopTotal: number;
    /**
    * URL path of animation file
    **/
    path: string;
    /**
     * Event emitted when the animation completes.
     */
    animationCompleted: EventEmitter<void>;
    isLottieV2: boolean;
    ngOnChanges(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AnimationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AnimationComponent, "ui-core-animation", never, { "animationData": { "alias": "animationData"; "required": false; }; "altText": { "alias": "altText"; "required": false; }; "freeze": { "alias": "freeze"; "required": false; }; "freezeFrame": { "alias": "freezeFrame"; "required": false; }; "loop": { "alias": "loop"; "required": false; }; "loopTotal": { "alias": "loopTotal"; "required": false; }; "path": { "alias": "path"; "required": false; }; }, { "animationCompleted": "animationCompleted"; }, never, never, false, never>;
}

declare class LottieV1Component implements OnChanges, OnDestroy {
    element: ElementRef;
    /**
    * URL path of animation .json file
    **/
    path: string;
    /**
    * JSON string of animation data
    *  (animationData and path are mutually exclusive)
    **/
    animationData: string;
    /**
    * Alternate text to describe animation for screen-readers
    **/
    altText: string;
    /**
    * Boolean to indicate that the animation should not animate, but display a single still frame
    **/
    freeze: boolean;
    /**
    * Animation frame to display when freeze is true - animation becomes a "still image" of this frame
    **/
    freezeFrame: number;
    /**
    * Boolean to indicate that the animation should loop & play continuously. If false, it will play once & stop.
    **/
    loop: boolean;
    /**
    * Number to indicate the total number of times the animation should loop. Only used when loop is true.
    * 0 enables infinite looping of animation (default).
    **/
    loopTotal: number;
    /**
     * Event emitted when the animation completes.
     */
    animationCompleted: EventEmitter<void>;
    private animation;
    showAnimation: boolean;
    ngOnChanges(): void;
    ngOnDestroy(): void;
    fadeComplete(event: AnimationEvent): void;
    private destroyAnimation;
    private isReducedMotion;
    private animationComplete;
    static ɵfac: i0.ɵɵFactoryDeclaration<LottieV1Component, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LottieV1Component, "ui-core-lottie-v1", never, { "path": { "alias": "path"; "required": false; }; "animationData": { "alias": "animationData"; "required": false; }; "altText": { "alias": "altText"; "required": false; }; "freeze": { "alias": "freeze"; "required": false; }; "freezeFrame": { "alias": "freezeFrame"; "required": false; }; "loop": { "alias": "loop"; "required": false; }; "loopTotal": { "alias": "loopTotal"; "required": false; }; }, { "animationCompleted": "animationCompleted"; }, never, never, false, never>;
}

declare class LottieV2Component implements OnChanges, OnDestroy {
    canvas: ElementRef;
    /**
    * URL path of animation .json file
    **/
    path: string;
    /**
    * JSON string or base64-encoded string of animation data
    *  (animationData and path are mutually exclusive)
    **/
    animationData: string;
    /**
    * Alternate text to describe animation for screen-readers
    **/
    altText: string;
    /**
    * Boolean to indicate that the animation should not animate, but display a single still frame
    **/
    freeze: boolean;
    /**
    * Animation frame to display when freeze is true - animation becomes a "still image" of this frame
    **/
    freezeFrame: number;
    /**
    * Boolean to indicate that the animation should loop & play continuously. If false, it will play once & stop.
    **/
    loop: boolean;
    /**
    * Number to indicate the total number of times the animation should loop. Only used when loop is true.
    * 0 enables infinite looping of animation (default).
    **/
    loopTotal: number;
    /**
     * Event emitted when the animation completes.
     */
    animationCompleted: EventEmitter<void>;
    showAnimation: boolean;
    private animation?;
    private resizeSubscription;
    ngOnChanges(): void;
    ngOnDestroy(): void;
    fadeComplete(): void;
    private initializeAnimation;
    private destroyAnimation;
    private freezeAnimation;
    private animationLoad;
    private animationComplete;
    private restoreAspectRatio;
    private startResizeObserver;
    static ɵfac: i0.ɵɵFactoryDeclaration<LottieV2Component, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LottieV2Component, "ui-core-lottie-v2", never, { "path": { "alias": "path"; "required": false; }; "animationData": { "alias": "animationData"; "required": false; }; "altText": { "alias": "altText"; "required": false; }; "freeze": { "alias": "freeze"; "required": false; }; "freezeFrame": { "alias": "freezeFrame"; "required": false; }; "loop": { "alias": "loop"; "required": false; }; "loopTotal": { "alias": "loopTotal"; "required": false; }; }, { "animationCompleted": "animationCompleted"; }, never, never, false, never>;
}

declare class ContentComponent implements OnChanges {
    img: string;
    animationData: string;
    animationUrl: string;
    embedVideoUrl: string;
    /**
    * Alternate text to describe animation for screen-readers (optional)
    **/
    altText: string;
    /**
    * JSON string of animation data
    * OR
    * Base64-encoded image data (jpg/png/gif)
    **/
    file: string;
    /**
    * URL of image or animation file
    **/
    fileURL: string;
    /**
    * FileType of image or animation provided in file Input
    **/
    fileType: FileType.LOT | FileType.LOTTIE | FileType.GIF | FileType.JPG | FileType.PNG | FileType.SVG;
    /**
    * Animation Only. Boolean to indicate that the animation should not animate, but display a single still frame
    **/
    freeze: boolean;
    /**
    * Animation Only. Animation frame to display when freeze is true - animation becomes a "still image" of this frame
    **/
    freezeFrame: number;
    /**
    * Animation Only. Boolean to indicate that the animation should loop & play continuously. If false, it will play once & stop.
    **/
    loop: boolean;
    /**
    * String url pointing to supported video file (currently supports YouTube urls, Vimeo urls, or any url that returns a video player supporting embed/iframe)
    **/
    videoUrl: string;
    ngOnChanges(): void;
    private setImage;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ContentComponent, "ui-core-content", never, { "altText": { "alias": "altText"; "required": false; }; "file": { "alias": "file"; "required": false; }; "fileURL": { "alias": "fileURL"; "required": false; }; "fileType": { "alias": "fileType"; "required": false; }; "freeze": { "alias": "freeze"; "required": false; }; "freezeFrame": { "alias": "freezeFrame"; "required": false; }; "loop": { "alias": "loop"; "required": false; }; "videoUrl": { "alias": "videoUrl"; "required": false; }; }, {}, never, never, false, never>;
}

declare class VideoComponent implements OnChanges {
    private sanitizer;
    embedUrl: SafeResourceUrl;
    /**
    * Alternate text to describe video frame for screen-readers (optional)
    **/
    altText: string;
    /**
    * String url pointing to supported video file (currently supports YouTube urls, Vimeo urls, or any url that returns a video player supporting embed/iframe)
    **/
    url: string;
    constructor(sanitizer: DomSanitizer);
    ngOnChanges(): void;
    private createVideoEmbedUrl;
    static ɵfac: i0.ɵɵFactoryDeclaration<VideoComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VideoComponent, "ui-core-video", never, { "altText": { "alias": "altText"; "required": false; }; "url": { "alias": "url"; "required": false; }; }, {}, never, never, false, never>;
}

declare class CountdownComponent implements OnChanges, OnDestroy {
    /**
    * Icon to the left of timer
    **/
    icon: string;
    /**
    * The countdown time in seconds.
    **/
    time: number;
    /**
    * Emits true when the timer is done
    **/
    isTimeOut: EventEmitter<boolean>;
    countdown: number;
    private timerSubscription;
    constructor();
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CountdownComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CountdownComponent, "ui-core-countdown", never, { "icon": { "alias": "icon"; "required": false; }; "time": { "alias": "time"; "required": false; }; }, { "isTimeOut": "isTimeOut"; }, never, never, false, never>;
}

declare class DocumentView {
    date: string;
    title: string;
    url: string;
    viewed: boolean;
}
declare enum DocumentAction {
    PRINT = "print",
    DOWNLOAD = "download"
}

declare class PageActionItem implements Action {
    text: string;
    url?: string;
    urlQueryParams?: Params;
    externalUrlNewTab?: boolean;
    icon?: string;
    id?: string;
    e2e?: string;
    disabled?: boolean;
    disabledMessage?: string;
    showSpinner?: boolean;
    action?: () => void;
    badgeMessage?: string;
    badgeTheme?: BadgeTheme;
}

declare enum DOCUMENT_VIEWER_ACTION {
    PRINT = "PRINT",
    VIEW = "VIEW",
    DOWNLOAD = "DOWNLOAD",
    LOADING_PRINT = "LOADING_PRINT"
}
declare class DocumentViewerComponent extends BaseTextComponent implements OnChanges {
    private modalService;
    private sanitizer;
    private textService;
    private windowService;
    private changeDetector;
    private ngZone;
    documentFrame: ElementRef<any>;
    documentModal: TemplateRef<any>;
    /**
    * Actions to show in the document viewer header, or mobile view
    * can include custom PageActionItems or DocumentAction enum values (for standard actions)
    * Note: the DocumentAction.PRINT action may be removed for external documents or mobile devices
    *       and the DocumentAction.DOWNLOAD action will be re-included, if needed, to support mobile.
    * Set to null or empty array to hide all non-view actions.
    **/
    actions: (PageActionItem | DocumentAction)[];
    /**
    * Optional. Sets the page actions more menu button icon. Defaults to three vertical dots.
    **/
    pageActionsMenuIcon: string;
    /**
    * Optional. Sets the page actions more menu button text. Defaults to 'More'.
    **/
    pageActionsMenuText: string;
    /**
    * String date to be displayed in modal header
    **/
    date: string;
    /**
    * Boolean to indicate if document should launch in a modal
    **/
    modal: boolean;
    /**
    * Optional. Locks the modal scrim, preventing the user from closing the modal by clicking outside of it.
    * Defaults to false. Content modals should generally have unlocked scrims for ADA reasons —
    * users, especially keyboard users, rely on scrim dismissal as a standard affordance.
    **/
    lockModalScrim: boolean;
    /**
    * String title displayed in modal header, download filename, or accessibility labels
    **/
    documentTitle: string;
    /**
    * URL of document to display - this can be remote (https://...), local (/assets/...), or encoded (data:...)
    **/
    url: string;
    /**
    * Boolean to indicate if document should display "viewed" indicator (based on document viewed prop)
    **/
    showViewed: boolean;
    /**
    * Boolean to indicate that Mobile documents should be viewed as HTML, but downloaded as PDF
    **/
    viewHtmlDownloadPdf: boolean;
    /**
    * Emits an error message when something unexpected happens.
    **/
    error: EventEmitter<string>;
    /**
    * Emits true when the document has been viewed.
    **/
    viewed: EventEmitter<boolean>;
    documentLoading: boolean;
    isExternalDoc: boolean;
    isMobile: boolean;
    isMobileView: boolean;
    pageActions: PageActionItem[];
    safeIframeUrl: SafeResourceUrl;
    selectedDocument: DocumentView;
    showControls: boolean;
    showIframe: boolean;
    showInfo: boolean;
    private httpClient;
    private isIosApp;
    private isMobileDevice;
    private isAndroidApp;
    private isMobileAppAndViewAndDownloadSupported;
    actionInProgress: DOCUMENT_VIEWER_ACTION | null;
    DOCUMENT_VIEWER_ACTION: typeof DOCUMENT_VIEWER_ACTION;
    constructor(modalService: ModalService, sanitizer: DomSanitizer, textService: TextService, windowService: WindowService, changeDetector: ChangeDetectorRef, ngZone: NgZone);
    ngOnChanges(): void;
    openModal(doc?: DocumentView): void;
    view(): void;
    download(action?: DOCUMENT_VIEWER_ACTION): void;
    closeDocumentModal(): void;
    print(): void;
    private printFrame;
    onDocumentLoaded(): void;
    private initialize;
    private loadDocumentView;
    private loadFrame;
    private printAfterLoad;
    private prepControls;
    private getDownloadAction;
    private updateActionsState;
    private downloadDocument;
    private downloadForAndroid;
    private viewFromApp;
    private viewForAndroid;
    private viewForIOS;
    private docViewed;
    private clearViewed;
    private isExternalDocUrl;
    private resizeImgDocs;
    private getDocument;
    private handleMobileBlobDocument;
    private getFileExtension;
    private getHyperLinkHtml;
    private setActionInProgress;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentViewerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DocumentViewerComponent, "ui-core-document-viewer", never, { "actions": { "alias": "actions"; "required": false; }; "pageActionsMenuIcon": { "alias": "pageActionsMenuIcon"; "required": false; }; "pageActionsMenuText": { "alias": "pageActionsMenuText"; "required": false; }; "date": { "alias": "date"; "required": false; }; "modal": { "alias": "modal"; "required": false; }; "lockModalScrim": { "alias": "lockModalScrim"; "required": false; }; "documentTitle": { "alias": "documentTitle"; "required": false; }; "url": { "alias": "url"; "required": false; }; "showViewed": { "alias": "showViewed"; "required": false; }; "viewHtmlDownloadPdf": { "alias": "viewHtmlDownloadPdf"; "required": false; }; }, { "error": "error"; "viewed": "viewed"; }, never, never, false, never>;
}

declare class GlassBackgroundComponent extends BaseDestroyComponent implements OnChanges {
    private windowService;
    backgroundAccentColorClass: string;
    layout: GlassBackgroundLayout;
    accentColorClass: string;
    isFullNav: boolean;
    isMobile: boolean;
    GlassBackgroundLayout: typeof GlassBackgroundLayout;
    constructor(windowService: WindowService);
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GlassBackgroundComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GlassBackgroundComponent, "ui-core-glass-background", never, { "backgroundAccentColorClass": { "alias": "backgroundAccentColorClass"; "required": false; }; "layout": { "alias": "layout"; "required": false; }; }, {}, never, never, false, never>;
}

declare class GlassBackgroundV2Component extends BaseDestroyComponent implements OnChanges {
    private windowService;
    private elementRef;
    get isLayoutFixed(): boolean;
    get isSolid(): boolean;
    backgroundAccentColorClass: string;
    layout: GlassBackgroundLayout;
    animate: boolean;
    accentColorClass: string;
    isFullNav: boolean;
    isMobile: boolean;
    readonly GlassBackgroundLayout: typeof GlassBackgroundLayout;
    constructor(windowService: WindowService, elementRef: ElementRef);
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GlassBackgroundV2Component, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GlassBackgroundV2Component, "ui-core-glass-background-v2", never, { "backgroundAccentColorClass": { "alias": "backgroundAccentColorClass"; "required": false; }; "layout": { "alias": "layout"; "required": false; }; "animate": { "alias": "animate"; "required": false; }; }, {}, never, never, false, never>;
}

declare class GlassHeaderComponent extends BaseTextComponent implements OnChanges {
    private router;
    private windowService;
    /**
    * The header text to display.
    **/
    header: string;
    /**
    * Optional "primary" subtitle text.
    **/
    subtitlePrimary: string;
    /**
    * Optional "secondary" subtitle text to display in light gray after the "primary" subtitle text.
    **/
    subtitleSecondary: string;
    /**
    * If a string URL is given, a back arrow using this URL will be displayed.
    **/
    backUrl: string;
    /**
    * If true, a close button will show in the top right corner of the component on tablet/desktop views. Defaults to false.
    **/
    showCloseButton: boolean;
    /**
    * If true, the header will be styled for being nested within the Wizard Component. Defaults to false.
    **/
    withinWizard: boolean;
    /**
    * Optional CSS class for background accent color, e.g. "bg-accent-color-2" or "bg-brand-primary".
    * Only applies to mobile and tablet views.
    **/
    backgroundAccentColorClass: string;
    /**
    * Customizable e2e hook for interactive elements.
    **/
    e2e: string;
    /**
    * Emits when back button is clicked if the backUrl provided is not an internal url.
    **/
    backButtonClicked: EventEmitter<void>;
    /**
    * Emits when the close button is clicked.
    **/
    closed: EventEmitter<void>;
    isFullNav: boolean;
    accentColorClass: string;
    e2ePrefix: string;
    glassV2Enabled: boolean;
    isMobile: boolean;
    readonly GlassBackgroundLayout: typeof GlassBackgroundLayout;
    constructor(router: Router, textService: TextService, windowService: WindowService);
    ngOnChanges(changes: SimpleChanges): void;
    onBackButtonClick(): void;
    close(): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<GlassHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GlassHeaderComponent, "ui-core-glass-header", never, { "header": { "alias": "header"; "required": false; }; "subtitlePrimary": { "alias": "subtitlePrimary"; "required": false; }; "subtitleSecondary": { "alias": "subtitleSecondary"; "required": false; }; "backUrl": { "alias": "backUrl"; "required": false; }; "showCloseButton": { "alias": "showCloseButton"; "required": false; }; "withinWizard": { "alias": "withinWizard"; "required": false; }; "backgroundAccentColorClass": { "alias": "backgroundAccentColorClass"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; }, { "backButtonClicked": "backButtonClicked"; "closed": "closed"; }, never, never, false, never>;
}

declare class HtmlEditorContentComponent {
    private domSanitizer;
    readonly hostClass = true;
    /**
    * Content to display. Must be generated from the html-editor component.
    **/
    content: string;
    /**
    * By default, run the DOM sanitizer on html content. If you trust the content, you can disable this.
    **/
    sanitize: boolean;
    /**
    * Classes applied to the div containing the custom content.
    * Not applied when using a scrollbox.
    **/
    containerClass: string;
    /**
    * If true, will wrap content in a scrollbox.
    **/
    showScrollbox: boolean;
    /**
    * If enabled, will emit when the user has scrolled through all content.
    **/
    emitScroll: boolean;
    /**
    * Optional micronotification to appear below the scrollbox.
    **/
    scrollMessage: string;
    /**
    * Label to apply to scrollable content.
    **/
    scrollAriaLabel: string;
    /**
    * E2E testing - data-e2e attribute attached to various parts of the scrollbox component.
    * Default is "html-content".
    **/
    e2e: string;
    /**
    *  Emitted when user scrolls to bottom of content if emitScroll is enabled.
    **/
    scrolled: EventEmitter<boolean>;
    sanitizedContent: SafeHtml;
    constructor(domSanitizer: DomSanitizer);
    ngOnChanges(): void;
    private sanitizeContent;
    onScrollboxScroll(event: boolean): void;
    private modifyVideoIFrames;
    private fixQuillIndentedLists;
    private hasVisibleContent;
    static ɵfac: i0.ɵɵFactoryDeclaration<HtmlEditorContentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HtmlEditorContentComponent, "ui-core-html-editor-content", never, { "content": { "alias": "content"; "required": false; }; "sanitize": { "alias": "sanitize"; "required": false; }; "containerClass": { "alias": "containerClass"; "required": false; }; "showScrollbox": { "alias": "showScrollbox"; "required": false; }; "emitScroll": { "alias": "emitScroll"; "required": false; }; "scrollMessage": { "alias": "scrollMessage"; "required": false; }; "scrollAriaLabel": { "alias": "scrollAriaLabel"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; }, { "scrolled": "scrolled"; }, never, never, false, never>;
}

declare class SafeHtmlComponent {
    private domSanitizer;
    /**
    * Html content to sanitize and display.
    **/
    content: string;
    /**
    * Control the level of sanitization.
    * Rich text mode allows non-interactive html elements, such as bold or italic text.
    * Text mode removes all html and styling.
    **/
    mode: 'rich-text' | 'text';
    /**
    * Classes applied to the div containing the html.
    **/
    containerClass: string;
    sanitizedContent: SafeHtml;
    constructor(domSanitizer: DomSanitizer);
    ngOnChanges(changes: SimpleChanges): void;
    private sanitizeContent;
    static ɵfac: i0.ɵɵFactoryDeclaration<SafeHtmlComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SafeHtmlComponent, "ui-core-safe-html", never, { "content": { "alias": "content"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "containerClass": { "alias": "containerClass"; "required": false; }; }, {}, never, never, false, never>;
}

declare class IconRendererDirective {
    private el;
    icon: string;
    allowEmojis: boolean;
    isCharIcon: boolean;
    isMaterialIcon: boolean;
    isSvgIcon: boolean;
    isEmojiIcon: boolean;
    constructor(el: ElementRef);
    ngOnChanges(): void;
    private iconChanged;
    private removeSvgIconClasses;
    static ɵfac: i0.ɵɵFactoryDeclaration<IconRendererDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<IconRendererDirective, "[ui-core-icon-renderer]", never, { "icon": { "alias": "icon"; "required": false; }; "allowEmojis": { "alias": "allowEmojis"; "required": false; }; }, {}, never, never, false, never>;
}

declare class IconComponent implements OnChanges {
    /**
    * Required. The icon to show.
    **/
    icon: string;
    /**
    * The size of the icon.
    **/
    size: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'xxl' | 'xxxl' | 'navbar';
    /**
    * The color class used to change the color of the icon.
    **/
    colorClass: string;
    /**
    * Enable emoji support for icons. Checking for emojis is expensive, so only enable if needed.
    **/
    allowEmojis: boolean;
    /**
    * ARIA Label attribute (aria-label)
    * Descriptive text for screen-readers. When animationPath or animationData is provided, this value
    * will be applied to the altText input of the animation component.
    **/
    ariaLabel: string;
    /**
    * When enabled, uses vertical-align bottom to better fit text.
    **/
    alignWithText: boolean;
    /**
    * When enabled, collapses component height to actual icon/animation height by removing vertical white-space.
    **/
    collapseHeight: boolean;
    /**
    * When enabled, the icon size will scale with device/browser font size. See _icon-size.scss for details.
    **/
    scaleWithFonts: boolean;
    animationPath: string;
    /**
    * JSON string of animation data. When set, renders a Lottie animation instead of an icon.
    * (Mutually exclusive with animationPath.)
    **/
    animationData: string;
    /**
    * Boolean to indicate that the animation should not animate, but display a single still frame.
    **/
    animationFreeze: boolean;
    /**
    * Animation frame to display when freeze is true - animation becomes a "still image" of this frame.
    **/
    animationFreezeFrame: number;
    /**
    * Boolean to indicate that the animation should loop & play continuously. If false, it will play once & stop.
    **/
    animationLoop: boolean;
    /**
    * Number to indicate the total number of times the animation should loop. Only used when loop is true.
    * 0 enables infinite looping of animation (default).
    **/
    animationLoopTotal: number;
    /**
    * Emitted when the animation completes (non-looped).
    **/
    animationCompleted: EventEmitter<void>;
    cssClass: string;
    get isAnimated(): boolean;
    constructor();
    ngOnChanges(changes: SimpleChanges): void;
    private setClass;
    static ɵfac: i0.ɵɵFactoryDeclaration<IconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IconComponent, "ui-core-icon", never, { "icon": { "alias": "icon"; "required": false; }; "size": { "alias": "size"; "required": false; }; "colorClass": { "alias": "colorClass"; "required": false; }; "allowEmojis": { "alias": "allowEmojis"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "alignWithText": { "alias": "alignWithText"; "required": false; }; "collapseHeight": { "alias": "collapseHeight"; "required": false; }; "scaleWithFonts": { "alias": "scaleWithFonts"; "required": false; }; "animationPath": { "alias": "animationPath"; "required": false; }; "animationData": { "alias": "animationData"; "required": false; }; "animationFreeze": { "alias": "animationFreeze"; "required": false; }; "animationFreezeFrame": { "alias": "animationFreezeFrame"; "required": false; }; "animationLoop": { "alias": "animationLoop"; "required": false; }; "animationLoopTotal": { "alias": "animationLoopTotal"; "required": false; }; }, { "animationCompleted": "animationCompleted"; }, never, never, false, never>;
}

declare class IconShapeComponent implements OnChanges {
    /**
    * Required. A string corresponding to a Material Icon, a SVG icon, or a single char.
    **/
    icon: string;
    /**
    * The background class used to control the color of the shape.
    **/
    backgroundClass: string;
    /**
    * String to define a border around the shape.
    **/
    borderColor: string;
    /**
    * The class used to control the color of the icon.
    **/
    colorClass: string;
    /**
    * The size of the icon.
    **/
    size: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'responsive';
    /**
    * The shape of the icon.
    **/
    shape: 'circle' | 'rounded' | 'square';
    /**
    * Label used to describe icon for screen-readers. If not provided, nothing will be announced.
    **/
    ariaLabel: string;
    cssClass: string;
    constructor();
    ngOnChanges(changes: SimpleChanges): void;
    private setClass;
    static ɵfac: i0.ɵɵFactoryDeclaration<IconShapeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IconShapeComponent, "ui-core-icon-shape[icon]", never, { "icon": { "alias": "icon"; "required": false; }; "backgroundClass": { "alias": "backgroundClass"; "required": false; }; "borderColor": { "alias": "borderColor"; "required": false; }; "colorClass": { "alias": "colorClass"; "required": false; }; "size": { "alias": "size"; "required": false; }; "shape": { "alias": "shape"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; }, {}, never, never, false, never>;
}

declare class NavIconComponent implements OnChanges {
    /**
    * Required. A string corresponding to a Material Icon, a SVG icon, or a single char.
    **/
    icon: string;
    /**
    * The background class used to control the color of the shape.
    **/
    backgroundClass: string;
    /**
    * The size of the icon.
    **/
    size: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'responsive';
    /**
    * The shape of the icon.
    **/
    shape: 'circle' | 'rounded' | 'square';
    actualShape: string;
    constructor();
    ngOnChanges(changes: SimpleChanges): void;
    private setClasses;
    static ɵfac: i0.ɵɵFactoryDeclaration<NavIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NavIconComponent, "ui-core-nav-icon[icon]", never, { "icon": { "alias": "icon"; "required": false; }; "backgroundClass": { "alias": "backgroundClass"; "required": false; }; "size": { "alias": "size"; "required": false; }; "shape": { "alias": "shape"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ImageDisplayComponent extends BaseTextComponent {
    protected textService: TextService;
    /**
     * Required. The path of the image.
     **/
    path: string;
    /**
     * Required. Alternate text to describe image for screen-readers.
     **/
    altText: string;
    /**
     * Required. The height of the image container in pixels.
     **/
    height: number;
    /**
     * Optional. The width of the image container in pixels.
     * If no value is provided, the container will take up the full width of the parent container.
     **/
    width: number;
    /**
     * Optional. Controls how the image is displayed within its container.
     * - 'fill': Image fills the full container, cropping any overflow. No blur background.
     * - 'fit': Image fits inside the container without cropping. A blurred version of the image
     *   fills any remaining space in the background.
     * Defaults to 'fill'.
     **/
    displayMode: ImageDisplayMode;
    /**
     * Optional. Controls which part of the image remains visible when the image is cropped.
     * Only has a visual effect when displayMode: 'fill' since that's the only mode where cropping occurs.
     * If no value is provided, the image is centered.
     **/
    objectPosition: ObjectPosition;
    /**
     * Optional. Array of badges (max of 5) to be displayed on the top right corner of the image.
     * Badges are rendered as an overlay on the full container, so can appear over both the image and the blur background.
     * All of the themes provided by the badge component are supported here.
     **/
    badges: BadgeModel[];
    /**
     * Optional. Applies border radius (rounded corners) to the container.
     * The overflow: hidden on the container naturally clips the image corners.
     **/
    borderRadius: boolean;
    blurBackgroundStyle: string;
    constructor(textService: TextService);
    protected getDefaultText(): any;
    ngOnChanges(changes: SimpleChanges): void;
    private updateBlurBackgroundStyle;
    static ɵfac: i0.ɵɵFactoryDeclaration<ImageDisplayComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ImageDisplayComponent, "ui-core-image-display", never, { "path": { "alias": "path"; "required": false; }; "altText": { "alias": "altText"; "required": false; }; "height": { "alias": "height"; "required": false; }; "width": { "alias": "width"; "required": false; }; "displayMode": { "alias": "displayMode"; "required": false; }; "objectPosition": { "alias": "objectPosition"; "required": false; }; "badges": { "alias": "badges"; "required": false; }; "borderRadius": { "alias": "borderRadius"; "required": false; }; }, {}, never, never, false, never>;
}

declare class InlineAction implements Action {
    text: string;
    icon: string;
    isSelectable: boolean;
    e2e?: string;
    action?: () => void;
    url?: string;
    urlQueryParams: Params;
    externalUrlNewTab: boolean;
    constructor(text: string, icon: string, isSelectable: boolean);
}

declare class InlineActionsBarComponent {
    private router;
    /**
     * Message to show before the actions
     */
    message: string;
    /**
     * Actions to display.
     */
    inlineActions: InlineAction[];
    /**
     * Max number of actions to display
     */
    maxActions: number;
    /**
     * Emits the action that was clicked.
     */
    actionClicked: EventEmitter<InlineAction>;
    selectedIcon: string;
    constructor(router: Router);
    get actions(): InlineAction[];
    selectAction(action: InlineAction): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<InlineActionsBarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InlineActionsBarComponent, "ui-core-inline-actions-bar", never, { "message": { "alias": "message"; "required": false; }; "inlineActions": { "alias": "inlineActions"; "required": false; }; "maxActions": { "alias": "maxActions"; "required": false; }; }, { "actionClicked": "actionClicked"; }, never, never, false, never>;
}

declare class LabelValueComponent extends BaseTextComponent implements OnChanges {
    private router;
    /**
    * Required. The label to show above the value.
    **/
    label: string;
    /**
    * A single value to display.
    **/
    value: string;
    /**
    * Use this input when multiple values should be displayed.
    **/
    values: string[];
    /** *******************************/
    /** Optional label inputs below **/
    /** *******************************/
    /**
    * An optional icon to display to the right of the label. This is not clickable.
    * Note: if an interactive icon (mask toggle, tooltip) is enabled, this icon will not display.
    **/
    labelIcon: string;
    /**
    * Optional text content to display within a tooltip popover.
    * Note: if the masked feature is enabled, the tooltip will not display unless rightAlignIconButtons is also enabled.
    **/
    tooltipContent: string;
    /**
    * Direction to place the tooltip popover.
    * "auto" (default) will attempt to place the popover where it can be seen (based on container/window bounds)
    * See ng-bootstrap documentation for details - type: Placement
    **/
    tooltipPlacement: 'auto' | 'top' | 'top-left' | 'top-right' | 'bottom' | 'bottom-left' | 'bottom-right' | 'left' | 'left-top' | 'left-bottom' | 'right' | 'right-top' | 'right-bottom';
    /** *******************************/
    /** Optional value inputs below **/
    /** *******************************/
    /**
    * An optional icon to display to the left of the value/s. This is not clickable.
    **/
    iconLeft: string;
    /**
    * An optional icon to display to the right of the value/s as a clickable button.
    **/
    iconRight: string;
    /**
    * The aria-label attribute for the optional right icon. *Required* when using "iconRight".
    **/
    iconRightAriaLabel: string;
    /**
    * An optional icon color class string. Only applies to iconLeft.
    **/
    iconLeftColorClass: string;
    /**
    * Enable emoji support for icons in the iconLeft position.
    **/
    iconLeftAllowEmojis: boolean;
    /**
    * If enabled, the value is replaced with asterisks and a mask toggle is used to swap between asterisks and clear text.
    **/
    masked: boolean;
    /**
    * Optional text to display instead of asterisks when the masked input is set to true.
    **/
    maskedValues: string[];
    /**
    * If enabled, the copy to clipboard button is displayed.
    **/
    showCopyToClipboard: boolean;
    /**
    * If enabled, icon buttons (iconRight, mask toggle, copy to clipboard) are right aligned.
    **/
    rightAlignIconButtons: boolean;
    /**
    * Class(es) to apply to outer container for spacing.
    **/
    elementClass: string;
    /**
    * If enabled, shows a border at the bottom.
    **/
    borderBottom: boolean;
    /**
    * Class(es) to apply directly to value/s.
    **/
    valueClass: string;
    /**
    * If enabled, the value will be shown with link styling. Should be used with the "linkClicked" output.
    **/
    valueIsLink: boolean;
    /**
    *  Optional link text to display beneath the value. Should be used with the "linkClicked" output. Cannot be used when the valueIsLink Input is set to true!
    **/
    valueSubLinkText: string;
    /**
    * If "valueIsLink" is true, the link will navigate to this optional url.
    **/
    url: string;
    /**
    * If true, any external link will open in a new tab.
    **/
    externalUrlNewTab: boolean;
    /**
    * Optional spinner to display to the right of the value/s. If enabled, it hides "iconRight".
    **/
    showSpinner: boolean;
    /**
    * E2E testing - data-e2e attribute attached to interactive elements of the component
    **/
    e2e: string;
    /**
    * Optional, makes the value unable to be copied
    **/
    valueIsUnselectable: boolean;
    /**
    * Optional, micro-notification message text.
    **/
    notificationMessage: string;
    /**
    * Optional, Sets styling & icon of micro-notification to display.
    **/
    notificationTheme: 'neutral' | 'information' | 'error' | 'success' | 'warning';
    /**
    * Optional, Specific micro-notification icon to display, overrides icon set by notificationTheme.
    **/
    notificationIcon: string;
    /**
    * Emits the value when the icon right is clicked.
    **/
    iconRightClicked: EventEmitter<string>;
    /**
    * Emits when the link is clicked.
    **/
    linkClicked: EventEmitter<void>;
    /**
    * Emits when the user interacts with the mask toggle. True indicates that the mask is on.
    * Useful for parent components to fetch sensitive data on request.
    **/
    maskToggleClicked: EventEmitter<boolean>;
    /**
    * Emits after a copy-to-clipboard attempt completes. Payload is the success
    * boolean — true when the value reached the clipboard, false on failure.
    * Use this to log audit events at the call site.
    **/
    copied: EventEmitter<boolean>;
    maskIsOn: boolean;
    maskIcon: string;
    maskToggleAriaLabel: string;
    labelIconMode: 'mask' | 'tooltip' | 'icon' | 'none';
    ariaLabel: string;
    copyValue: string;
    displayValues: string[];
    private valueLinkIsExternal;
    showExternalLinkIcon: boolean;
    usesAriaLabel: boolean;
    constructor(router: Router, textService: TextService);
    ngOnChanges(changes: SimpleChanges): void;
    private setInternalValues;
    private getMaskedDisplayValues;
    toggleMask(): void;
    private setLabelIconMode;
    protected getDefaultText(): any;
    iconClicked(value: string): void;
    onLinkClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LabelValueComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LabelValueComponent, "ui-core-label-value", never, { "label": { "alias": "label"; "required": false; }; "value": { "alias": "value"; "required": false; }; "values": { "alias": "values"; "required": false; }; "labelIcon": { "alias": "labelIcon"; "required": false; }; "tooltipContent": { "alias": "tooltipContent"; "required": false; }; "tooltipPlacement": { "alias": "tooltipPlacement"; "required": false; }; "iconLeft": { "alias": "iconLeft"; "required": false; }; "iconRight": { "alias": "iconRight"; "required": false; }; "iconRightAriaLabel": { "alias": "iconRightAriaLabel"; "required": false; }; "iconLeftColorClass": { "alias": "iconLeftColorClass"; "required": false; }; "iconLeftAllowEmojis": { "alias": "iconLeftAllowEmojis"; "required": false; }; "masked": { "alias": "masked"; "required": false; }; "maskedValues": { "alias": "maskedValues"; "required": false; }; "showCopyToClipboard": { "alias": "showCopyToClipboard"; "required": false; }; "rightAlignIconButtons": { "alias": "rightAlignIconButtons"; "required": false; }; "elementClass": { "alias": "elementClass"; "required": false; }; "borderBottom": { "alias": "borderBottom"; "required": false; }; "valueClass": { "alias": "valueClass"; "required": false; }; "valueIsLink": { "alias": "valueIsLink"; "required": false; }; "valueSubLinkText": { "alias": "valueSubLinkText"; "required": false; }; "url": { "alias": "url"; "required": false; }; "externalUrlNewTab": { "alias": "externalUrlNewTab"; "required": false; }; "showSpinner": { "alias": "showSpinner"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; "valueIsUnselectable": { "alias": "valueIsUnselectable"; "required": false; }; "notificationMessage": { "alias": "notificationMessage"; "required": false; }; "notificationTheme": { "alias": "notificationTheme"; "required": false; }; "notificationIcon": { "alias": "notificationIcon"; "required": false; }; }, { "iconRightClicked": "iconRightClicked"; "linkClicked": "linkClicked"; "maskToggleClicked": "maskToggleClicked"; "copied": "copied"; }, never, never, false, never>;
}

declare class LinkComponent implements OnChanges {
    /**
    * Controls the color palette used when theme is 'primary', 'secondary', or 'tertiary'.
    * Has no effect when theme is 'link'.
    * - 'branded': Uses brand-specific colors (default)
    * - 'neutral': Uses neutral (gray-scale) colors
    **/
    themeGroup: ButtonThemeGroup;
    /**
    * Link theme.
    * Applies primary, secondary, tertiary, or link styling to link to indicate hierarchy
    **/
    theme: ButtonTheme;
    /**
    * Size of the link and icon. Only applicable for link and tertiary themes.
    **/
    size: 'sm' | 'md';
    /**
    * Link path.
    **/
    link: string;
    /**
    * Boolean to determine if href link will open in a new tab
    **/
    openLinkInNewTab: boolean;
    /**
    * Link text to display.
    **/
    message: string;
    /**
    * Material Icon string of icon to display.
    **/
    icon: string;
    /**
    * Icon position. Left or Right side of text, defaults to left
    **/
    iconPosition: 'left' | 'right';
    /**
    * Boolean to toggle disabled state.
    * Applies "disabled" classes and properties to prevent clicks, navigation, or focus.
    * This will apply to both the host element & link element. If "disabled", no interactions should be possible.
    **/
    disabled: boolean;
    /**
    * Class(es) to apply directly to link element
    * (default "class" property of LinkComponent is applied to the host element, this will apply directly to the link)
    **/
    linkClass: string;
    /**
    * Link width (minimum width)
    * By default link will be a minimum of 4rem wide & expand to contain its message, these options will size it further
    * 'wide' = min-width 10rem
    * 'wider' = min-width 13.75rem
    * 'full' = same as .btn-block - link will be as wide as possible
    **/
    width: '' | 'wide' | 'wider' | 'full';
    /**
    * ARIA Label attribute (aria-label)
    * Used to replace the link message with more descriptive text, screen-readers will read the ariaLabel, instead of message
    **/
    ariaLabel: string;
    /**
    * E2E testing - data-e2e attribute attached to link
    **/
    e2e: string;
    /**
    * Can only be paired with router links, not hrefs.
    **/
    urlParams: Params;
    buttonTheme: string;
    defaultLinkClass: string;
    isLinkTheme: boolean;
    isRouterLink: boolean;
    isSmall: boolean;
    showIcon: boolean;
    ngOnChanges(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LinkComponent, "ui-core-link", never, { "themeGroup": { "alias": "themeGroup"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "size": { "alias": "size"; "required": false; }; "link": { "alias": "link"; "required": false; }; "openLinkInNewTab": { "alias": "openLinkInNewTab"; "required": false; }; "message": { "alias": "message"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "iconPosition": { "alias": "iconPosition"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "linkClass": { "alias": "linkClass"; "required": false; }; "width": { "alias": "width"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; "urlParams": { "alias": "urlParams"; "required": false; }; }, {}, never, never, false, never>;
}

declare class LoadingOverlayComponent extends BaseTextComponent {
    protected textService: TextService;
    /**
    * Whether to show the loading overlay.
    **/
    show: boolean;
    /**
    * Custom message to display with the spinner (only for 'sm' size). Defaults to "Loading...".
    * 40 character limit for messages.
    **/
    message: string;
    /**
    * Spinner size: 'sm' displays with text, 'md' displays without text.
    **/
    spinnerSize: 'sm' | 'md';
    constructor(textService: TextService);
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoadingOverlayComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LoadingOverlayComponent, "ui-core-loading-overlay", never, { "show": { "alias": "show"; "required": false; }; "message": { "alias": "message"; "required": false; }; "spinnerSize": { "alias": "spinnerSize"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * Directive to apply a loading overlay to any element.
 *
 * Usage:
 * - Set [uiLoadingOverlay]="true" to show the overlay
 * - With default 'sm' size, text will always display. Defaults to "Loading..." if loadingMessage not provided.
 * - Customize loadingMessage to override the default text (e.g., "Generating...", "Processing...")
 * - Use loadingSpinnerSize='md' for standalone spinner without any text
 */
declare class LoadingOverlayDirective implements OnChanges, OnDestroy {
    private viewContainerRef;
    private renderer;
    private elementRef;
    uiLoadingOverlay: boolean;
    /**
     * Message to display with the spinner.
     * When loadingSpinnerSize is 'sm' (default), text will always display.
     * Defaults to "Loading..." if not provided. Customize to show different text.
     * 40 character limit for messages.
     */
    loadingMessage: string;
    /**
     * Spinner size: 'sm' displays with text (defaults to "Loading..."), 'md' displays without any text.
     */
    loadingSpinnerSize: 'sm' | 'md';
    private overlayRef?;
    private originalPosition?;
    constructor(viewContainerRef: ViewContainerRef, renderer: Renderer2, elementRef: ElementRef);
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    private showOverlay;
    private hideOverlay;
    private restorePosition;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoadingOverlayDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<LoadingOverlayDirective, "[uiLoadingOverlay]", never, { "uiLoadingOverlay": { "alias": "uiLoadingOverlay"; "required": false; }; "loadingMessage": { "alias": "loadingMessage"; "required": false; }; "loadingSpinnerSize": { "alias": "loadingSpinnerSize"; "required": false; }; }, {}, never, never, false, never>;
}

declare abstract class BaseModalComponent extends BaseTextComponent implements OnChanges, OnInit, OnDestroy {
    private analyticsService;
    protected modalService: ModalService;
    private windowService;
    e2eAttr: string;
    /**
    * Required. The title of the modal.
    **/
    title: string;
    /**
    * Optional subtitle of the modal.
    **/
    subtitle: string;
    /**
    * The Id of the current step being presented by the modal component.
    * This is required when the component performs internal navigation that
    * is not reflected by URL changes.
    **/
    currentStepId: string;
    /**
    * Set to true to disable buttons.
    **/
    disableButtons: boolean;
    /**
    * The text of the primary button.
    **/
    primaryButtonText: string;
    /**
    * The text of the primary button in its disabled state.
    **/
    primaryButtonDisabledText: string;
    /**
    * The text of the (optional) secondary button.
    **/
    secondaryButtonText: string;
    /**
    * The text of the (optional) action button.
    **/
    actionButtonText: string;
    /**
    * The icon within the (optional) action button.
    **/
    actionButtonIcon: string;
    /**
    * Set to true to prevent the modal from closing when the scrim (backdrop) is clicked or when
    * the ESC key is pressed. The modal can only be dismissed via its close (X), cancel, or submit
    * buttons, or programmatically (e.g. modalService.dismissAll()).
    *
    * Use this for modals where closing mid-flow is not allowed (e.g. a required multi-step process).
    * For form modals where you want to warn about unsaved changes, use confirmUnsavedChanges instead.
    * Avoid setting both lockScrim and confirmUnsavedChanges to true on the same modal — they have
    * overlapping but subtly different behavior and are not designed to be used together.
    **/
    lockScrim: boolean;
    /**
    * Optional callback invoked before the modal closes via the close (X) button, scrim click, or
    * ESC key. Return true to allow the close, or false / Promise<false> to cancel it.
    * Cancel and submit button closes bypass this callback and are handled by the component directly.
    *
    * This is an advanced input intended for internal library use. For form modals, prefer
    * confirmUnsavedChanges on the wrapper component (e.g. ui-forms-modal, ui-workflows-reason-modal).
    **/
    beforeClose: (() => boolean | Promise<boolean>) | null;
    /**
    * Set to true to show a "back" button in the top left corner of the modal.
    **/
    showBackButton: boolean;
    /**
    * Set to true to show a "close" button in the top right corner of the modal.
    **/
    showCloseButton: boolean;
    /**
    * E2E testing - data-e2e attribute attached to various parts of the modal.
    * Default is "modal".
    **/
    e2e: string;
    /**
    * If an id is provided, observables in the modal service will be used instead of backButtonClicked, primaryButtonClicked, etc.
    * This allows complex modals with nested child components to handle button click events by subscribing to observables from the modal service.
    **/
    buttonClickObservableId: string;
    /**
    * Emits when modal is closed by any means.
    * Depending on the implementation, the modal may be closed by button clicks.
    * Modals can always be closed by pressing the ESC key or clicking the backdrop.
    **/
    closed: EventEmitter<void>;
    /**
    * Emits when back button is clicked.
    **/
    backButtonClicked: EventEmitter<any>;
    /**
    * Emits when primary button is clicked.
    **/
    primaryButtonClicked: EventEmitter<any>;
    /**
    * Emits when secondary button is clicked.
    **/
    secondaryButtonClicked: EventEmitter<any>;
    /**
    * Emits when tertiary button is clicked.
    **/
    actionButtonClicked: EventEmitter<any>;
    e2ePrefix: string;
    isFullNav: boolean;
    isMobile: boolean;
    modalId: string;
    protected modalStackIndex: number;
    constructor(analyticsService: AnalyticsService, modalService: ModalService, textService: TextService, windowService: WindowService);
    ngOnChanges(changes: SimpleChanges): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    back(): void;
    close(): void;
    primaryButtonClick(event: Event): void;
    secondaryButtonClick(event: Event): void;
    actionButtonClick(event: Event): void;
    private get emitButtonClicks();
    get showButtons(): boolean;
    private setE2EAttr;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseModalComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BaseModalComponent, never, never, { "title": { "alias": "title"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "currentStepId": { "alias": "currentStepId"; "required": false; }; "disableButtons": { "alias": "disableButtons"; "required": false; }; "primaryButtonText": { "alias": "primaryButtonText"; "required": false; }; "primaryButtonDisabledText": { "alias": "primaryButtonDisabledText"; "required": false; }; "secondaryButtonText": { "alias": "secondaryButtonText"; "required": false; }; "actionButtonText": { "alias": "actionButtonText"; "required": false; }; "actionButtonIcon": { "alias": "actionButtonIcon"; "required": false; }; "lockScrim": { "alias": "lockScrim"; "required": false; }; "beforeClose": { "alias": "beforeClose"; "required": false; }; "showBackButton": { "alias": "showBackButton"; "required": false; }; "showCloseButton": { "alias": "showCloseButton"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; "buttonClickObservableId": { "alias": "buttonClickObservableId"; "required": false; }; }, { "closed": "closed"; "backButtonClicked": "backButtonClicked"; "primaryButtonClicked": "primaryButtonClicked"; "secondaryButtonClicked": "secondaryButtonClicked"; "actionButtonClicked": "actionButtonClicked"; }, never, never, true, never>;
}

declare class ModalComponent extends BaseModalComponent {
    useReducedMotion: boolean;
    /**
    * Optional template to use in place of a standard title.
    **/
    headerTemplate: TemplateRef<any>;
    /**
    * Optional template to use as a footer element.
    **/
    footerTemplate: TemplateRef<any>;
    /**
    * Set to true to remove padding from the body of the modal.
    **/
    noBodyPadding: boolean;
    /**
    * Set to true to remove the modal's header border.
    **/
    noHeaderBorder: boolean;
    /**
    * Set to true to specify that the modal uses FormRenderer buttons, allowing FormRenderer buttons to behave like modal buttons.
    **/
    useFormRendererButtons: boolean;
    /**
    * Set to true to move the modal buttons into the footer, so they stay in the bottom of the modal, below any footerTemplate.
    **/
    useFooterButtons: boolean;
    /**
    * Set to true to show a spinner on the primary button when disabled.
    **/
    showPrimarySpinner: boolean;
    /**
    * Set to true for the modal to use a Glass Background. Currently supported on mobile and tablet views only.
    **/
    useGlassBackground: boolean;
    glassV2Enabled: boolean;
    readonly GlassBackgroundLayout: typeof GlassBackgroundLayout;
    constructor(analyticsService: AnalyticsService, modalService: ModalService, textService: TextService, windowService: WindowService);
    get isSecondaryMobileModal(): boolean;
    back(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ModalComponent, "ui-core-modal", never, { "headerTemplate": { "alias": "headerTemplate"; "required": false; }; "footerTemplate": { "alias": "footerTemplate"; "required": false; }; "noBodyPadding": { "alias": "noBodyPadding"; "required": false; }; "noHeaderBorder": { "alias": "noHeaderBorder"; "required": false; }; "useFormRendererButtons": { "alias": "useFormRendererButtons"; "required": false; }; "useFooterButtons": { "alias": "useFooterButtons"; "required": false; }; "showPrimarySpinner": { "alias": "showPrimarySpinner"; "required": false; }; "useGlassBackground": { "alias": "useGlassBackground"; "required": false; }; }, {}, never, ["*"], false, never>;
}

type BannerNotificationTheme = Extract<NotificationTheme, NotificationTheme.NEUTRAL | NotificationTheme.ERROR | NotificationTheme.INFORMATION | NotificationTheme.SUCCESS | NotificationTheme.WARNING>;

declare class BannerNotificationComponent extends BaseTextComponent implements OnChanges {
    /**
    * Optional header text.
    * Either header or message text must be provided for the component to render.
    **/
    header: string;
    /**
    * Optional message text.
    * Either header or message text must be provided for the component to render.
    **/
    message: string;
    /**
    * The theme controls the icon and color scheme used.
    * Supports 'neutral', 'error', 'information', 'success', and 'warning'. Defaults to 'information'.
    * Note: 'gradient' is not a valid value for this component.
    * Use values from the NotificationTheme enum in implementations (e.g. NotificationTheme.WARNING).
    **/
    theme: BannerNotificationTheme;
    /**
    * A custom icon that overrides the theme's default icon. Only applies to the 'information' and 'neutral' themes.
    **/
    customIcon: string;
    /**
    * URL path of animation .json file. When set, renders a Lottie animation instead of an icon.
    * (Mutually exclusive with customAnimationData.) Only applies to the 'information' and 'neutral' themes.
    **/
    customAnimationPath: string;
    /**
    * JSON string of animation data. When set, renders a Lottie animation instead of an icon.
    * (Mutually exclusive with customAnimationPath.) Only applies to the 'information' and 'neutral' themes.
    **/
    customAnimationData: string;
    /**
    * Boolean to indicate that the animation should not animate, but display a single still frame.
    **/
    customAnimationFreeze: boolean;
    /**
    * Animation frame to display when freeze is true - animation becomes a "still image" of this frame.
    **/
    customAnimationFreezeFrame: number;
    /**
    * Boolean to indicate that the animation should loop & play continuously. If false, it will play once & stop.
    **/
    customAnimationLoop: boolean;
    /**
    * Number to indicate the total number of times the animation should loop. Only used when loop is true.
    * 0 enables infinite looping of animation (default).
    **/
    customAnimationLoopTotal: number;
    /**
    * Whether to show the close button. Defaults to false. If false, the closed event will not be emitted.
    **/
    showCloseButton: boolean;
    /**
    * Emitted when the close button is clicked.
    **/
    closed: EventEmitter<void>;
    iconValue: string;
    iconAriaLabel: string;
    iconColorClass: string;
    backgroundClass: string;
    animationPath: string;
    animationData: string;
    constructor(textService: TextService);
    ngOnChanges(changes: SimpleChanges): void;
    private setThemeProperties;
    closeButtonClicked(event: Event): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<BannerNotificationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BannerNotificationComponent, "ui-core-banner-notification", never, { "header": { "alias": "header"; "required": false; }; "message": { "alias": "message"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "customIcon": { "alias": "customIcon"; "required": false; }; "customAnimationPath": { "alias": "customAnimationPath"; "required": false; }; "customAnimationData": { "alias": "customAnimationData"; "required": false; }; "customAnimationFreeze": { "alias": "customAnimationFreeze"; "required": false; }; "customAnimationFreezeFrame": { "alias": "customAnimationFreezeFrame"; "required": false; }; "customAnimationLoop": { "alias": "customAnimationLoop"; "required": false; }; "customAnimationLoopTotal": { "alias": "customAnimationLoopTotal"; "required": false; }; "showCloseButton": { "alias": "showCloseButton"; "required": false; }; }, { "closed": "closed"; }, never, never, false, never>;
}

declare class BadgeComponent implements OnChanges {
    hostClass: string;
    /** Message text to display. */
    message: string;
    /** Boolean to drive framed badge (tinted background color with border) */
    framed: boolean;
    /** Sets style/color of badge */
    theme: BadgeTheme;
    /**
     * Sets style of badge
     *  - badge = pill-shaped badge containing text
     *  - dot = circular badge without text, intended as "notification dot"
     */
    type: 'dot' | 'badge';
    /** Boolean to vertically center the badge "dot". Only supported with "dot" type. */
    centered: boolean;
    /** Material Icon string of icon to display. Not supported with "dot" type. */
    icon: string;
    /** Icon position. Left or Right side of text, defaults to left */
    iconPosition: 'left' | 'right';
    badgeClass: string;
    iconColorClass: string;
    isDot: boolean;
    showLeftIcon: boolean;
    showRightIcon: boolean;
    badgeThemes: {
        error: string;
        success: string;
        warning: string;
        information: string;
        positive: string;
        negative: string;
        neutral: string;
    };
    private framedClasses;
    private iconColorClasses;
    private framedIconColorClasses;
    ngOnChanges(): void;
    private setHostClass;
    private setBadgeClass;
    static ɵfac: i0.ɵɵFactoryDeclaration<BadgeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BadgeComponent, "ui-core-badge", never, { "message": { "alias": "message"; "required": false; }; "framed": { "alias": "framed"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "type": { "alias": "type"; "required": false; }; "centered": { "alias": "centered"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "iconPosition": { "alias": "iconPosition"; "required": false; }; }, {}, never, never, false, never>;
}

interface NotificationButton {
    text: string;
    icon?: string;
}

declare class InLineNotificationComponent extends BaseTextComponent implements OnChanges {
    private router;
    /**
    * The header to display.
    **/
    header: string;
    /**
    * The message to display. This can be a text only message or html.
    * If html is used, it ONLY supports a single hyperlink (also known as an anchor: <a>).
    * The hyperlink can reference an internal url (/accounts), an external url, or a phone number (tel:).
    * Custom styles and classes are stripped out for rendering consistency.
    **/
    message: string;
    /**
    * Optional. Bullet list that displays under the message.
    **/
    bulletList: string[];
    /**
    * The theme controls the icon and color scheme used.
    * Current support is for 'neutral', 'error', 'information', 'success', 'warning', and 'gradient'.
    **/
    theme: NotificationTheme;
    /**
    * A custom icon that overrides the theme's default icon. Only applies to the 'information', 'neutral', and 'gradient' themes.
    **/
    customIcon: string;
    /**
    * URL path of animation .json file. When set, renders a Lottie animation instead of an icon.
    * (Mutually exclusive with customAnimationData.) Only applies to the 'information', 'neutral', and 'gradient' themes.
    **/
    customAnimationPath: string;
    /**
    * JSON string of animation data. When set, renders a Lottie animation instead of an icon.
    * (Mutually exclusive with customAnimationPath.) Only applies to the 'information', 'neutral', and 'gradient' themes.
    **/
    customAnimationData: string;
    /**
    * Boolean to indicate that the animation should not animate, but display a single still frame.
    **/
    customAnimationFreeze: boolean;
    /**
    * Animation frame to display when freeze is true - animation becomes a "still image" of this frame.
    **/
    customAnimationFreezeFrame: number;
    /**
    * Boolean to indicate that the animation should loop & play continuously. If false, it will play once & stop.
    **/
    customAnimationLoop: boolean;
    /**
    * Number to indicate the total number of times the animation should loop. Only used when loop is true.
    * 0 enables infinite looping of animation (default).
    **/
    customAnimationLoopTotal: number;
    /**
    * Array of buttons to display. Maximum of 2 buttons.
    * First button (index 0) uses neutral secondary theme.
    * Second button (index 1) uses neutral tertiary theme.
    * Note: Buttons with empty or whitespace-only text will not be rendered.
    * If more than 2 buttons are provided, only the first 2 will be displayed.
    **/
    buttons: NotificationButton[];
    /**
    * Whether to show the close button in the upper right corner.
    **/
    showCloseButton: boolean;
    /**
    * Emitted when a button is clicked. Emits the index of the button (0 for first, 1 for second).
    **/
    buttonClicked: EventEmitter<number>;
    /**
    * Emitted when the close button is clicked.
    **/
    closed: EventEmitter<void>;
    iconValue: string;
    iconAriaLabel: string;
    iconColorClass: string;
    backgroundClass: string;
    animationPath: string;
    animationData: string;
    preLinkText: string;
    linkText: string;
    postLinkText: string;
    url: string;
    private externalUrlNewTab;
    /**
     * Returns only valid buttons (buttons with non-empty text), limited to maximum of 2.
     */
    get validButtons(): NotificationButton[];
    constructor(textService: TextService, router: Router);
    ngOnChanges(): void;
    private setThemeProperties;
    private rebuildMessage;
    private resetLinkProperties;
    get clickable(): boolean;
    get anchorHref(): string;
    onClick(): void;
    onButtonClick(index: number, event: Event): void;
    getButtonTheme(index: number): 'secondary' | 'tertiary';
    closeButtonClicked(event: Event): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<InLineNotificationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InLineNotificationComponent, "ui-core-in-line-notification", never, { "header": { "alias": "header"; "required": false; }; "message": { "alias": "message"; "required": false; }; "bulletList": { "alias": "bulletList"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "customIcon": { "alias": "customIcon"; "required": false; }; "customAnimationPath": { "alias": "customAnimationPath"; "required": false; }; "customAnimationData": { "alias": "customAnimationData"; "required": false; }; "customAnimationFreeze": { "alias": "customAnimationFreeze"; "required": false; }; "customAnimationFreezeFrame": { "alias": "customAnimationFreezeFrame"; "required": false; }; "customAnimationLoop": { "alias": "customAnimationLoop"; "required": false; }; "customAnimationLoopTotal": { "alias": "customAnimationLoopTotal"; "required": false; }; "buttons": { "alias": "buttons"; "required": false; }; "showCloseButton": { "alias": "showCloseButton"; "required": false; }; }, { "buttonClicked": "buttonClicked"; "closed": "closed"; }, never, never, false, never>;
}

declare class MicroNotificationComponent extends BaseTextComponent implements OnChanges {
    /**
    * Message text to display.
    **/
    message: string;
    /**
    * Optional bold text that prefixes and is in line with the message text.
    **/
    boldText: string;
    /**
    * Sets default icon, icon color, and (when containerTheme is 'framed') notification background color.
    * Current support is for 'neutral', 'error', 'information', 'success', 'warning', and 'gradient'.
    **/
    theme: NotificationTheme;
    /**
    * Controls the container style. Current support is for 'transparent' or 'framed'.
    **/
    containerTheme: 'transparent' | 'framed';
    /**
    * A custom icon that overrides the theme's default icon.
    **/
    icon: string;
    /**
    * URL path of animation .json file. When set, renders a Lottie animation instead of an icon.
    * (Mutually exclusive with animationData.)
    **/
    animationPath: string;
    /**
    * JSON string of animation data. When set, renders a Lottie animation instead of an icon.
    * (Mutually exclusive with animationPath.)
    **/
    animationData: string;
    /**
    * Boolean to indicate that the animation should not animate, but display a single still frame.
    **/
    animationFreeze: boolean;
    /**
    * Animation frame to display when freeze is true - animation becomes a "still image" of this frame.
    **/
    animationFreezeFrame: number;
    /**
    * Boolean to indicate that the animation should loop & play continuously. If false, it will play once & stop.
    **/
    animationLoop: boolean;
    /**
    * Number to indicate the total number of times the animation should loop. Only used when loop is true.
    * 0 enables infinite looping of animation (default).
    **/
    animationLoopTotal: number;
    /**
    * Text to prefix notifications with for screen-readers, helps identify form inputs by label
    **/
    ariaPrefix: string;
    ariaText: string;
    backgroundClass: string;
    iconColorClass: string;
    iconValue: string;
    get containerClasses(): string;
    constructor(textService: TextService);
    ngOnChanges(): void;
    private setThemeProperties;
    private setFramedBackgroundClass;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<MicroNotificationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MicroNotificationComponent, "ui-core-micro-notification", never, { "message": { "alias": "message"; "required": false; }; "boldText": { "alias": "boldText"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "containerTheme": { "alias": "containerTheme"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "animationPath": { "alias": "animationPath"; "required": false; }; "animationData": { "alias": "animationData"; "required": false; }; "animationFreeze": { "alias": "animationFreeze"; "required": false; }; "animationFreezeFrame": { "alias": "animationFreezeFrame"; "required": false; }; "animationLoop": { "alias": "animationLoop"; "required": false; }; "animationLoopTotal": { "alias": "animationLoopTotal"; "required": false; }; "ariaPrefix": { "alias": "ariaPrefix"; "required": false; }; }, {}, never, never, false, never>;
}

declare class MicroNotificationModel {
    message: string;
    theme: NotificationTheme;
    icon?: string;
    constructor(message: string, theme?: NotificationTheme, icon?: string);
    ariaPrefix: string;
    boldText: string;
    containerTheme: 'transparent' | 'framed';
    static fromObject(data: any): MicroNotificationModel;
}

declare class StatusNotificationComponent {
    /**
    * The message to display.
    **/
    message: string;
    /**
    * A secondary message to display.
    **/
    subtext: string;
    /**
    * The theme of the card, which directly corresponds to our standard container classes.
    **/
    theme: 'bordered' | 'bordered-interactive' | 'default' | 'elevated' | 'elevated-interactive' | 'sunken' | 'brand';
    /**
    * Optional icon.
    **/
    icon: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<StatusNotificationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StatusNotificationComponent, "ui-core-status-notification", never, { "message": { "alias": "message"; "required": false; }; "subtext": { "alias": "subtext"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; }, {}, never, never, false, never>;
}

type ToastNotificationTheme = Extract<NotificationTheme, NotificationTheme.NEUTRAL | NotificationTheme.ERROR | NotificationTheme.INFORMATION | NotificationTheme.SUCCESS | NotificationTheme.WARNING>;

declare class ToastNotification {
    theme: ToastNotificationTheme;
    message: string;
    details?: string;
    readonly id: string;
    readonly totalLength: number;
    /**
     * Optional avatar for Level Up progress notifications.
     * Only set when INFORMATION theme is used with progressValue and progressMax.
     */
    avatar: AvatarModel;
    /**
     * Indicates this is a Level Up progress notification with animated avatar.
     * Set automatically by ToastStackService when avatar has progressValue and progressMax.
     */
    isProgressNotification: boolean;
    buttons: NotificationButton[];
    onButtonClick: (index: number) => void;
    customIcon: string;
    customAnimationPath: string;
    customAnimationData: string;
    customAnimationFreeze: boolean;
    customAnimationFreezeFrame: number;
    customAnimationLoop: boolean;
    customAnimationLoopTotal: number;
    constructor(theme: ToastNotificationTheme, message: string, details?: string);
}

declare class ToastStackService {
    private newNotificationSubject;
    newNotification$: rxjs.Observable<ToastNotification>;
    private removeNotificationSubject;
    removeNotification$: rxjs.Observable<string>;
    private timerSubscription;
    private notificationTimeSettings;
    private readonly minCharacterTimeMs;
    private readonly minNotificationTimeMs;
    constructor();
    setNotificationTime(theme: ToastNotificationTheme, timeMs: number): void;
    addNotification(theme: ToastNotificationTheme, message: string, details?: string, avatar?: AvatarModel, buttons?: NotificationButton[], onButtonClick?: (index: number) => void, customIcon?: string, customAnimationPath?: string, customAnimationData?: string, customAnimationFreeze?: boolean, customAnimationFreezeFrame?: number, customAnimationLoop?: boolean, customAnimationLoopTotal?: number): void;
    private initNotification;
    removeAllNotifications(): void;
    private createTimer;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToastStackService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ToastStackService>;
}

declare class ToastStackComponent extends BaseDestroyComponent {
    private windowService;
    private toastStackService;
    globalClass: boolean;
    /**
    * Set to true when footer navbar is visible to control mobile positioning.
    **/
    withFooterNavbar: boolean;
    isMobile: boolean;
    stack: ToastNotification[];
    constructor(windowService: WindowService, toastStackService: ToastStackService);
    private addToStack;
    removeFromStack(id: string): void;
    buttonClicked(notification: ToastNotification, index: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToastStackComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToastStackComponent, "ui-core-toast-stack", never, { "withFooterNavbar": { "alias": "withFooterNavbar"; "required": false; }; }, {}, never, never, false, never>;
}

declare class TooltipComponent extends BaseTextComponent implements OnChanges {
    private windowService;
    get hostClass(): string;
    _placement: string;
    isMobile: boolean;
    private isPopupHovered;
    private isTipHovered;
    /**
    * Text content to display in the tooltip popover bubble
    **/
    tooltip: string;
    /**
    * Direction to place the tooltip popover.
    * "auto" (default) will attempt to place the popover where it can be seen (based on container/window bounds)
    * See ng-bootstrap documentation for details.
    **/
    placement: 'auto' | 'top' | 'top-left' | 'top-right' | 'bottom' | 'bottom-left' | 'bottom-right' | 'left' | 'left-top' | 'left-bottom' | 'right' | 'right-top' | 'right-bottom';
    /**
    * Label text to display in front of tooltip icon (optional)
    **/
    label: string;
    /**
    * Icon to use for tooltip button
    **/
    icon: string;
    /**
    * Icon button size. Small/sm, Medium/md (default), or Large/lg
    **/
    size: 'sm' | 'md' | 'lg';
    /**
    * Icon button theme.
    * Applies primary or secondary styling to icon button
    **/
    theme: 'primary' | 'secondary';
    /**
    * Class(es) to apply directly to icon button element
    * (default "class" property of ui-core-tooltip is applied to the host element, this will apply directly to the button)
    **/
    buttonClass: string;
    /**
    * Boolean for inline vs block/flex styling, used to show tooltip icon inline with other text
    **/
    inline: boolean;
    /**
    * Label to apply to tooltip button for aria - will be prepended to text.ariaLabel: "{{ inlineLabel }} Additional Info"
    **/
    inlineLabel: string;
    /**
    * Label to apply to tooltip button for aria - will be appended to inlineLabel: "User Name {{ ariaLabel }}"
    **/
    ariaLabel: string;
    /**
    * E2E testing - data-e2e attribute attached to interactive elements of the component
    **/
    e2e: string;
    constructor(windowService: WindowService, textService: TextService);
    ngOnChanges(changes: SimpleChanges): void;
    tipHoverIn(popover: NgbPopover): void;
    tipHoverOut(event: Event, popover: NgbPopover): void;
    tipClick(event: Event, popover: NgbPopover): void;
    checkHoverOut(event: Event, popover: NgbPopover): void;
    private checkAndClosePopover;
    private setPlacement;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<TooltipComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TooltipComponent, "ui-core-tooltip", never, { "tooltip": { "alias": "tooltip"; "required": false; }; "placement": { "alias": "placement"; "required": false; }; "label": { "alias": "label"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "size": { "alias": "size"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "buttonClass": { "alias": "buttonClass"; "required": false; }; "inline": { "alias": "inline"; "required": false; }; "inlineLabel": { "alias": "inlineLabel"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; }, {}, never, never, false, never>;
}

declare class RouteValidatorService {
    protected routeValidator: UiRouteValidator;
    constructor(routeValidator: UiRouteValidator);
    isRouteValid(route: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<RouteValidatorService, [{ optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RouteValidatorService>;
}

declare class PageActionsComponent extends BaseTextComponent implements OnChanges {
    private windowService;
    protected textService: TextService;
    private router;
    private routeValidatorService;
    /**
    * When true and on mobile, the buttons will not be collapsed into the more menu.
    * They will be presented as if on desktop.
    **/
    withinModal: boolean;
    /**
    * When true and on mobile, icon button will use light theme to contrast against the navbar.
    **/
    withinNav: boolean;
    /**
    * When true and NOT on mobile and there are 3 or more actions, two of the page actions will show outside the More dropdown menu.
    **/
    showTwoOutsideMenu: boolean;
    /**
    * Aligns buttons/menu to the left side of the container instead of the right.
    **/
    alignLeft: boolean;
    /**
    * Optional. Sets the more menu button icon. Only customizable for desktop view. Defaults to three vertical dots.
    **/
    moreMenuIcon: string;
    /**
    * Optional. Sets the more menu button text. Defaults to 'More' for desktop view. No text shows in mobile view.
    **/
    moreMenuButtonText: string;
    /**
    * The actions to render.
    **/
    set actions(actions: PageActionItem[]);
    get actions(): PageActionItem[];
    private _actions;
    private _newActions;
    currentState: string;
    isMobile: boolean;
    mobileIconTheme: 'light' | '';
    firstAction: PageActionItem;
    secondAction: PageActionItem;
    actionCount: number;
    actionsSlice1: PageActionItem[];
    actionsSlice2: PageActionItem[];
    containerClass: string;
    get showDesktopView(): boolean;
    constructor(windowService: WindowService, textService: TextService, router: Router, routeValidatorService: RouteValidatorService);
    ngOnChanges(changes: SimpleChanges): void;
    onFadeDone(): void;
    private setVisibleActions;
    handleAction(action: PageActionItem): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageActionsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PageActionsComponent, "ui-core-page-actions", never, { "withinModal": { "alias": "withinModal"; "required": false; }; "withinNav": { "alias": "withinNav"; "required": false; }; "showTwoOutsideMenu": { "alias": "showTwoOutsideMenu"; "required": false; }; "alignLeft": { "alias": "alignLeft"; "required": false; }; "moreMenuIcon": { "alias": "moreMenuIcon"; "required": false; }; "moreMenuButtonText": { "alias": "moreMenuButtonText"; "required": false; }; "actions": { "alias": "actions"; "required": false; }; }, {}, never, never, false, never>;
}

interface ScriptInfo {
    id: string;
    type?: string;
    src?: string;
    text?: string;
    customAttributes?: Map<string, string>;
    onloadFnc?: () => any;
    isLoadedFnc?: () => boolean;
    loaded: boolean;
}
declare class ScriptInjectionService {
    private scriptsByCategory;
    constructor();
    /**
     * Attaches a script to the DOM under document.body and associates it with a category.
     * To remove scripts associated with a category, call unloadScriptsByCategory(category).
     * @param scriptInfo ScriptInfo describes the <script> tag that will be attached to document.body.
     * @param category Category groups related scripts together to allow them to be unloaded in a single call.
     * @returns resolves on success, else rejects if an error occurrs.
     */
    loadScript(scriptInfo: ScriptInfo, category: string): Promise<void>;
    /**
     * Remove all scripts from document.body given their category.
     * @param category Category groups related scripts together to allow them to be unloaded in a single call.
     */
    unloadScriptsByCategory(category: string): void;
    private addScriptToCategory;
    private unloadScript;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScriptInjectionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ScriptInjectionService>;
}

declare class ScrollboxComponent implements OnChanges, OnDestroy {
    element: ElementRef<HTMLElement>;
    private changeDetector;
    scrollElement: ElementRef;
    /**
    * Accepts content as a string. Allows HTML.
    **/
    content: string;
    /**
    * If enabled, will emit when the user has scrolled through all content.
    **/
    emitScroll: boolean;
    /**
    * Optional micronotification to appear below the scrollbox.
    **/
    message: string;
    /**
    * Label to apply to scrollable content.
    **/
    ariaLabel: string;
    /**
    * Boolean to toggle code view styles, preserves white-space to show object data
    **/
    codeView: boolean;
    /**
    * Boolean to toggle locked style where scrollbox mimics a disabled input
    **/
    locked: boolean;
    /**
    * E2E testing - data-e2e attribute attached to various parts of the scrollbox component.
    * Default is "scrollbox".
    **/
    e2e: string;
    /**
    * Initial height of the scrollbox. If this is not set, the scrollbox will use default values.
    **/
    height: string;
    /**
    * Minimum height of the scrollbox.
    **/
    minHeight: string;
    /**
    *  Emitted when user scrolls to bottom of content if emitScroll is enabled.
    **/
    scrolled: EventEmitter<boolean>;
    e2ePrefix: string;
    readonly notificationId: string;
    heightStyles: {};
    private scrollCompleted;
    private resizeSubscription;
    constructor(element: ElementRef<HTMLElement>, changeDetector: ChangeDetectorRef);
    ngOnChanges(changes: SimpleChanges): void;
    checkScrollStatus(): void;
    private renderContent;
    private resetScrollbox;
    private startResizeObserver;
    private stopResizeObserver;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScrollboxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ScrollboxComponent, "ui-core-scrollbox", never, { "content": { "alias": "content"; "required": false; }; "emitScroll": { "alias": "emitScroll"; "required": false; }; "message": { "alias": "message"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "codeView": { "alias": "codeView"; "required": false; }; "locked": { "alias": "locked"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; "height": { "alias": "height"; "required": false; }; "minHeight": { "alias": "minHeight"; "required": false; }; }, { "scrolled": "scrolled"; }, never, never, false, never>;
}

declare class SessionTimeoutModalComponent extends BaseTextComponent {
    private modalService;
    protected textService: TextService;
    timeoutModal: TemplateRef<any>;
    /**
    * Required. Time in seconds for countdown component.
    **/
    time: number;
    /**
    * Optional label of logout button
    **/
    logoutButtonText: string;
    /**
    * Optional text description of timeout modal
    **/
    infoText: string;
    /**
    * Emits when the user chooses to continue the session
    **/
    userStaysLoggedIn: EventEmitter<void>;
    /**
    * Emits when the user chooses to log out or the time runs out
    **/
    userIsLoggedOut: EventEmitter<void>;
    private valueEmitted;
    constructor(modalService: ModalService, textService: TextService);
    open(): void;
    continueSessionClick(): void;
    logoutClick(): void;
    timeout(): void;
    modalClosed(): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<SessionTimeoutModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SessionTimeoutModalComponent, "ui-core-session-timeout-modal", never, { "time": { "alias": "time"; "required": false; }; "logoutButtonText": { "alias": "logoutButtonText"; "required": false; }; "infoText": { "alias": "infoText"; "required": false; }; }, { "userStaysLoggedIn": "userStaysLoggedIn"; "userIsLoggedOut": "userIsLoggedOut"; }, never, never, false, never>;
}

declare class SlideChangeEvent {
    slideIndex: number;
    stackIsEmpty: boolean;
    actionConfirmed: boolean;
}

declare class StackComponent<T> extends BaseTextComponent implements OnChanges {
    swiperContainer: SwiperContainerComponent<T>;
    endOfStackMessageAria: ElementRef<HTMLElement>;
    /**
    * Items to render as "slides"
    **/
    slides: T[];
    /**
    * Template for rendering each slide.
    * Use "slide" property for template binding.
    **/
    slideTemplate: TemplateRef<any>;
    /**
     * Optional input to determine if the Cancel/Confirm buttons are shown.
     * Defaults to true.
     */
    showButtons: boolean;
    /**
     * Optional input to set the text for the Confirm button.
     * Defaults to 'Confirm'. This button displays to the right, and confirms that an action is needed.
     */
    confirmButtonMessage: string;
    /**
     * Optional input to set the text for the Cancel button.
     * Defaults to 'Cancel'. This button displays to the left, and cancels any action from taking place.
     */
    cancelButtonMessage: string;
    /**
     * Optional input to set a message to display when the stack is empty.
     */
    endOfStackMessage: string;
    /**
    * Hidden label to apply to the stack.
    **/
    ariaLabel: string;
    /**
    * Emits the new slide index when the visible slide has changed.
    **/
    slideChanged: EventEmitter<SlideChangeEvent>;
    currentIndex: number;
    currentItemMessage: string;
    isAriaActive: boolean;
    private confirmButton;
    private cancelButton;
    stackButtons: ButtonGridItem[];
    allSlidesSwiped: boolean;
    private isOnLastSlide;
    swiperOptions: object;
    constructor(textService: TextService);
    ngOnChanges(changes: SimpleChanges): void;
    removeSlide(index: number): void;
    removeCurrentSlide(): void;
    private buildButtons;
    private getSwiperOptions;
    private setAriaActive;
    private setSlideAccessibility;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<StackComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StackComponent<any>, "ui-core-stack", never, { "slides": { "alias": "slides"; "required": false; }; "slideTemplate": { "alias": "slideTemplate"; "required": false; }; "showButtons": { "alias": "showButtons"; "required": false; }; "confirmButtonMessage": { "alias": "confirmButtonMessage"; "required": false; }; "cancelButtonMessage": { "alias": "cancelButtonMessage"; "required": false; }; "endOfStackMessage": { "alias": "endOfStackMessage"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; }, { "slideChanged": "slideChanged"; }, never, never, false, never>;
}

declare class Tab {
    label: string;
    mobileLabel?: string;
    routerLink?: string;
    value?: string;
    icon?: string;
    hasError?: boolean;
    e2e?: string;
}

declare class TabFocusService {
    private currentTabRoute;
    setActiveTab(tabRoute: string): void;
    getActiveTab(): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabFocusService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TabFocusService>;
}

declare class TabsComponent extends BaseTextComponent implements OnInit, OnChanges {
    private analyticsService;
    private windowService;
    private router;
    private routeValidatorService;
    private tabFocusService;
    protected textService: TextService;
    class: boolean;
    /**
    * Array of Tab items that will each display as their own tab.
    **/
    tabs: Tab[];
    /**
    * When true, will redirect to the first visible tab. Used when enforcing a claim on a route.
    **/
    navigateToDefaultTab: boolean;
    /**
    * When true, tabs will display in the center of their container as opposed to starting on the left.
    **/
    centered: boolean;
    /**
    * Used when all tabs are values and none are routerLinks.
    * When set to the value of a tab, that tab will be the active one when the component loads.
    * If empty, active tab will be the first visible tab.
    **/
    selectedTab: string;
    /**
    * Emits the 'value' of the tab as an event when a tab is clicked.
    **/
    tabSelected: EventEmitter<string>;
    isMobile: boolean;
    activeTab: string;
    currentTabRoute: string;
    constructor(analyticsService: AnalyticsService, windowService: WindowService, router: Router, routeValidatorService: RouteValidatorService, tabFocusService: TabFocusService, textService: TextService);
    ngOnChanges(changes: SimpleChanges): void;
    ngOnInit(): void;
    private setActiveTab;
    tabIsVisible(tab: Tab): boolean;
    tabClicked(tab: Tab): void;
    tabRouteClick(route: string): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TabsComponent, "ui-core-tabs", never, { "tabs": { "alias": "tabs"; "required": false; }; "navigateToDefaultTab": { "alias": "navigateToDefaultTab"; "required": false; }; "centered": { "alias": "centered"; "required": false; }; "selectedTab": { "alias": "selectedTab"; "required": false; }; }, { "tabSelected": "tabSelected"; }, never, never, false, never>;
}

declare enum AccountTemplateStatus {
    ACTIVE = "ACTIVE",
    PENDING = "PENDING",
    LOCKED = "LOCKED",
    PROHIBITED = "PROHIBITED",
    NONE = ""
}

declare enum AccountTemplateType {
    CHECKING = "CHECKING",
    LOAN = "LOAN",
    SAVINGS = "SAVINGS",
    NONE = ""
}

declare class AccountTemplateComponent extends BaseTextComponent implements OnChanges {
    /**
    * The icon to show on the leftmost section of the account template.
    **/
    icon: string;
    /**
    * The background class used to control the color of the circle behind the icon.
    **/
    iconBackgroundClass: string;
    /**
    * The class used to control the color of the icon.
    **/
    iconColorClass: string;
    /**
    * If an image is desired, the URL of the image. This overrides the icon.
    **/
    imageUrl: string;
    /**
    * If enabled, uses an icon in place of an image with the same size/shape as the image.
    **/
    iconAsImage: boolean;
    /**
    * The string or number intended to display in the top left corner.
    **/
    topLeft: string | number;
    /**
    * Class(es) to apply directly to top left element.
    **/
    topLeftClass: string;
    /**
    * Boolean that specifies whether to format the top left element as currency.
    **/
    topLeftFormatCurrency: boolean;
    /**
    * E2E testing - data-e2e attribute attached to top left element
    **/
    e2eTopLeft: string;
    /**
    * Text that appears after the top left element.
    **/
    topLeftSubtext: string;
    /**
    * Class(es) to apply directly to top left subtext element.
    **/
    topLeftSubtextClass: string;
    /**
    * E2E testing - data-e2e attribute attached to top left subtext element
    **/
    e2eTopLeftSubtext: string;
    /**
    * The string or number intended to display in the top right corner.
    **/
    topRight: string | number;
    /**
    * Class(es) to apply directly to top right element.
    **/
    topRightClass: string;
    /**
    * Boolean that specifies whether to format the top right element as currency.
    **/
    topRightFormatCurrency: boolean;
    /**
    * E2E testing - data-e2e attribute attached to top right element
    **/
    e2eTopRight: string;
    /**
    * The string or number intended to display in the bottom left corner.
    **/
    bottomLeft: string | number;
    /**
    * Class(es) to apply directly to bottom left element.
    **/
    bottomLeftClass: string;
    /**
    * Boolean that specifies whether to format the bottom left element as currency.
    **/
    bottomLeftFormatCurrency: boolean;
    /**
    * E2E testing - data-e2e attribute attached to bottom left element
    **/
    e2eBottomLeft: string;
    /**
    * The string or number intended to display in the bottom right corner.
    **/
    bottomRight: string | number;
    /**
    * Class(es) to apply directly to bottom right element.
    **/
    bottomRightClass: string;
    /**
    * Boolean that specifies whether to format the bottom right element as currency.
    **/
    bottomRightFormatCurrency: boolean;
    /**
    * E2E testing - data-e2e attribute attached to bottom right element
    **/
    e2eBottomRight: string;
    /**
    * Optional. Triggers a micronotification in the bottom right corner.
    **/
    accountStatus: AccountTemplateStatus;
    /**
    * Optional. Provide an account type to be mapped to configurable text.
    **/
    accountType: AccountTemplateType;
    /**
    * Optional. Whether or not the account type should use the bottom left corner (defaults to bottom right corner).
    **/
    accountTypeUsesLeftCorner: boolean;
    /**
    * Shows the template in a disabled state.
    **/
    disabled: boolean;
    /**
    * When set to true, will allow text to wrap, top align content.
    * When false, will truncate or nowrap text and center align content.
    **/
    allowExpansion: boolean;
    bottomRightNotificationTheme: NotificationTheme;
    bottomRightNotificationMessage: string;
    constructor(textService: TextService);
    ngOnChanges(changes: SimpleChanges): void;
    private setAccountStatus;
    private setAccountType;
    get accountAriaLabel(): string;
    private getCornerLabel;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountTemplateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AccountTemplateComponent, "ui-core-account-template", never, { "icon": { "alias": "icon"; "required": false; }; "iconBackgroundClass": { "alias": "iconBackgroundClass"; "required": false; }; "iconColorClass": { "alias": "iconColorClass"; "required": false; }; "imageUrl": { "alias": "imageUrl"; "required": false; }; "iconAsImage": { "alias": "iconAsImage"; "required": false; }; "topLeft": { "alias": "topLeft"; "required": false; }; "topLeftClass": { "alias": "topLeftClass"; "required": false; }; "topLeftFormatCurrency": { "alias": "topLeftFormatCurrency"; "required": false; }; "e2eTopLeft": { "alias": "e2eTopLeft"; "required": false; }; "topLeftSubtext": { "alias": "topLeftSubtext"; "required": false; }; "topLeftSubtextClass": { "alias": "topLeftSubtextClass"; "required": false; }; "e2eTopLeftSubtext": { "alias": "e2eTopLeftSubtext"; "required": false; }; "topRight": { "alias": "topRight"; "required": false; }; "topRightClass": { "alias": "topRightClass"; "required": false; }; "topRightFormatCurrency": { "alias": "topRightFormatCurrency"; "required": false; }; "e2eTopRight": { "alias": "e2eTopRight"; "required": false; }; "bottomLeft": { "alias": "bottomLeft"; "required": false; }; "bottomLeftClass": { "alias": "bottomLeftClass"; "required": false; }; "bottomLeftFormatCurrency": { "alias": "bottomLeftFormatCurrency"; "required": false; }; "e2eBottomLeft": { "alias": "e2eBottomLeft"; "required": false; }; "bottomRight": { "alias": "bottomRight"; "required": false; }; "bottomRightClass": { "alias": "bottomRightClass"; "required": false; }; "bottomRightFormatCurrency": { "alias": "bottomRightFormatCurrency"; "required": false; }; "e2eBottomRight": { "alias": "e2eBottomRight"; "required": false; }; "accountStatus": { "alias": "accountStatus"; "required": false; }; "accountType": { "alias": "accountType"; "required": false; }; "accountTypeUsesLeftCorner": { "alias": "accountTypeUsesLeftCorner"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "allowExpansion": { "alias": "allowExpansion"; "required": false; }; }, {}, never, never, false, never>;
}

declare class CardTemplateComponent implements OnInit {
    /**
    * The icon to show on the leftmost section of the card template if cardImageUrl is not given.
    **/
    icon: string;
    /**
    * The background class used to control the color of the circle behind the icon.
    **/
    iconBackgroundClass: string;
    /**
    * The url for the cardImage.
    **/
    cardImageUrl: string;
    /**
    * The string or number intended to display in the top left corner.
    **/
    top: string;
    /**
    * Class(es) to apply directly to top left element.
    **/
    topClass: string;
    /**
    * E2E testing - data-e2e attribute attached to top left element
    **/
    e2eTop: string;
    /**
    * The string or number intended to display in the bottom left corner.
    **/
    bottom: string;
    /**
    * Class(es) to apply directly to bottom left element.
    **/
    bottomClass: string;
    /**
    * E2E testing - data-e2e attribute attached to bottom left element
    **/
    e2eBottom: string;
    /**
    * Shows the template in a disabled state.
    **/
    disabled: boolean;
    /**
    * When set to true, will allow text to wrap, top align content.
    * When false, will truncate or nowrap text and center align content.
    **/
    allowExpansion: boolean;
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CardTemplateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardTemplateComponent, "ui-core-card-template", never, { "icon": { "alias": "icon"; "required": false; }; "iconBackgroundClass": { "alias": "iconBackgroundClass"; "required": false; }; "cardImageUrl": { "alias": "cardImageUrl"; "required": false; }; "top": { "alias": "top"; "required": false; }; "topClass": { "alias": "topClass"; "required": false; }; "e2eTop": { "alias": "e2eTop"; "required": false; }; "bottom": { "alias": "bottom"; "required": false; }; "bottomClass": { "alias": "bottomClass"; "required": false; }; "e2eBottom": { "alias": "e2eBottom"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "allowExpansion": { "alias": "allowExpansion"; "required": false; }; }, {}, never, never, false, never>;
}

declare class MicroSummaryComponent implements OnChanges {
    /**
    * Optional header text.
    **/
    header: string;
    /**
    * The default style of the header. Can be customized with standard typography classes.
    **/
    headerClass: string;
    /**
    * Optional subheader text.
    **/
    subheader: string;
    /**
    * Optional icon.
    **/
    icon: string;
    /**
    * Optional badges.
    **/
    badges: BadgeModel[];
    /**
    * The background class used to control the color of the icon shape.
    **/
    iconBackgroundClass: string;
    hasBadges: boolean;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MicroSummaryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MicroSummaryComponent, "ui-core-micro-summary", never, { "header": { "alias": "header"; "required": false; }; "headerClass": { "alias": "headerClass"; "required": false; }; "subheader": { "alias": "subheader"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "badges": { "alias": "badges"; "required": false; }; "iconBackgroundClass": { "alias": "iconBackgroundClass"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ProgressBarComponent extends BaseTextComponent implements OnChanges {
    /**
     * The amount of progress completed.
     * Typically the current step or a dollar amount.
     **/
    completed: number;
    /**
     * The total amount used to calculate percent completed.
     * Typically the total number of steps or the total dollar amount.
     **/
    total: number;
    /**
     * The background class to use for the completed portion.
     **/
    completedBackgroundClass: string;
    /**
     * The background class to use for the total portion.
     **/
    totalBackgroundClass: string;
    /**
     * The height of the progress bar. Can be px, percents, or em.
     **/
    height: string;
    /**
     * Boolean that controls whether the progress bar should use a linear gradient.
     **/
    gradient: boolean;
    /**
     * Controls the shape of the progress bar. Options are "square", "rounded", or "hybrid",
     * which means the bar's edges will be square, but the right of the completed bar will be rounded.
     **/
    shape: 'square' | 'rounded' | 'hybrid';
    /**
     * Optional text to display on the left side of the progress bar with bold weight.
     **/
    leftBoldText: string;
    /**
     * Optional text to display on the left side of the progress bar with regular weight.
     **/
    leftRegularText: string;
    /**
     * Optional text to display on the right side of the progress bar with bold weight.
     **/
    rightBoldText: string;
    /**
     * Optional text to display on the right side of the progress bar with regular weight.
     **/
    rightRegularText: string;
    /**
    * Optional text used to override the default aria-label of the progress bar.
    **/
    ariaLabel: string;
    defaultAriaLabel: string;
    positionRight: string;
    showLeftProgressBarText: boolean;
    showRightProgressBarText: boolean;
    showOneSideOfProgressBarText: boolean;
    constructor(textService: TextService);
    ngOnChanges(changes: SimpleChanges): void;
    private calculatePositionRight;
    private setDefaultAriaLabel;
    protected getDefaultText(): {
        ariaLabel: string;
        ariaValueText: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<ProgressBarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProgressBarComponent, "ui-core-progress-bar", never, { "completed": { "alias": "completed"; "required": false; }; "total": { "alias": "total"; "required": false; }; "completedBackgroundClass": { "alias": "completedBackgroundClass"; "required": false; }; "totalBackgroundClass": { "alias": "totalBackgroundClass"; "required": false; }; "height": { "alias": "height"; "required": false; }; "gradient": { "alias": "gradient"; "required": false; }; "shape": { "alias": "shape"; "required": false; }; "leftBoldText": { "alias": "leftBoldText"; "required": false; }; "leftRegularText": { "alias": "leftRegularText"; "required": false; }; "rightBoldText": { "alias": "rightBoldText"; "required": false; }; "rightRegularText": { "alias": "rightRegularText"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ProgressCircleComponent implements OnChanges {
    private ngZone;
    chartPath: ElementRef;
    chartWrapper: ElementRef;
    backgroundColorVar: string;
    chartColorVar: string;
    wrapperPadding: string;
    private readonly DEFAULT_LINE_WIDTH;
    private readonly NOPADDING_LINE_WIDTH;
    private readonly MIN_LINE_WIDTH;
    private readonly MAX_LINE_WIDTH;
    /**
    * Animation delay, in ms, time to wait before animating to completed value
    **/
    animationDelay: number;
    /**
    * Number to indicate where chart should start animation
    *   if not -1, the chart will start from this value and animate to the "completed" value
    **/
    animationStartValue: number;
    /**
    * Background color value
    **/
    backgroundColor: ColorVariable;
    /**
    * Chart color value
    **/
    chartColor: ColorVariable;
    /**
    * Number to indicate current chart value
    **/
    completed: number;
    /**
    * The total possible value, used to calculate percent completed
    **/
    total: number;
    /**
    * String used to label progress for screen-readers
    **/
    label: string;
    /**
    * Width of the circle line
    *   This scales with the size of the circle, so isn't a pixel perfect value.
    *   Value must be between 1 and 80
    **/
    lineWidth: number;
    /**
    * Emits when progress animation is complete
    **/
    animationCompleted: EventEmitter<boolean>;
    constructor(ngZone: NgZone);
    ngOnChanges(): void;
    private drawChart;
    private animateChart;
    private setChartPadding;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProgressCircleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProgressCircleComponent, "ui-core-progress-circle", never, { "animationDelay": { "alias": "animationDelay"; "required": false; }; "animationStartValue": { "alias": "animationStartValue"; "required": false; }; "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "chartColor": { "alias": "chartColor"; "required": false; }; "completed": { "alias": "completed"; "required": false; }; "total": { "alias": "total"; "required": false; }; "label": { "alias": "label"; "required": false; }; "lineWidth": { "alias": "lineWidth"; "required": false; }; }, { "animationCompleted": "animationCompleted"; }, never, never, false, never>;
}

declare class SpinnerComponent extends BaseTextComponent implements OnChanges, OnInit {
    protected textService: TextService;
    private ngZone;
    private static readonly MAX_MESSAGE_LENGTH;
    /**
    * A loading message displayed to the user.
    * Usually something like "Loading..." or "Loading your accounts...".
    * If no message is provided, the spinner will use the primary color.
    * 40 character limit for messages.
    **/
    message: string;
    /**
    * The size of the spinner.
    * "sm" (default) is used inside of buttons or inline with text.
    * "md" is used as a stand alone spinner and will hide the message.
    * "h2" or "h3" should be used if the spinner is inside that html header element.
    **/
    size: 'sm' | 'md' | 'h2' | 'h3';
    /**
    * Icon will display inside enabled buttons (while spinner is hidden).
    * Must match material icon names.
    **/
    buttonIcon: string;
    /**
    * Used to hide the spinner for disabled buttons that are not disabled due to loading.
    **/
    hideSpinner: boolean;
    /**
    * Centers the spinner and message in the parent container.
    **/
    centered: boolean;
    /**
    * Used to fade in the spinner after a delay in milliseconds. If 0, no delay/fade in will be used.
    **/
    delayMs: number;
    /**
     * When spinner is inside a button -> turns off text truncation, max characters, align-items-center
     * + adds margin of 4px to top of spinner.
     */
    buttonSpinner: boolean;
    get alignItemsCenter(): boolean;
    radius: number;
    isHeader: boolean;
    delayHidden: boolean;
    delayVisible: boolean;
    ariaLabel: string;
    private ariaIntervalMs;
    constructor(textService: TextService, ngZone: NgZone);
    ngOnChanges(changes: SimpleChanges): void;
    ngOnInit(): void;
    private setSize;
    private setupDelay;
    private startAriaInterval;
    private ariaUpdate;
    get showMessage(): boolean;
    get displayMessage(): string;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<SpinnerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SpinnerComponent, "ui-core-spinner", never, { "message": { "alias": "message"; "required": false; }; "size": { "alias": "size"; "required": false; }; "buttonIcon": { "alias": "buttonIcon"; "required": false; }; "hideSpinner": { "alias": "hideSpinner"; "required": false; }; "centered": { "alias": "centered"; "required": false; }; "delayMs": { "alias": "delayMs"; "required": false; }; "buttonSpinner": { "alias": "buttonSpinner"; "required": false; }; }, {}, never, never, false, never>;
}

declare class SummaryDetail {
    message: string;
    messageCssClass?: string;
    icon?: string;
    iconCssClass?: string;
    e2eMessage: string;
    subtext: string;
    e2eSubtext: string;
    displayAbovePipedDetails: boolean;
}

declare class SummaryComponent extends BaseTextComponent implements OnInit, OnChanges {
    private windowService;
    /**
    * Shows a check mark icon before header details.
    **/
    showCheck: boolean;
    /**
    * These details display in a larger font, like a header, at the top of the component.
    **/
    headerDetails: SummaryDetail[];
    /**
    * These details display in a vertical list and make up the majority of the details.
    * They display below the piped details, unless displayAbovePipedDetails is true.
    **/
    summaryDetails: SummaryDetail[];
    /**
    * These details display in a horizontal list and are separated by pipes.
    **/
    pipedDetails: SummaryDetail[];
    /**
    * Shows an edit button.
    **/
    showEditButton: boolean;
    /**
    * Shows a delete button.
    **/
    showDeleteButton: boolean;
    /**
    * Disables the edit/delete buttons if they are visible.
    **/
    disableButtons: boolean;
    /**
    * Emits when edit button is clicked.
    **/
    editButtonClicked: EventEmitter<void>;
    /**
    * Emits when delete button is clicked.
    **/
    deleteButtonClicked: EventEmitter<void>;
    prioritizedDetails: SummaryDetail[];
    remainingDetails: SummaryDetail[];
    isMobile: boolean;
    constructor(windowService: WindowService, textService: TextService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    private setupSummaryDetails;
    buttonClicked(isEdit: boolean): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<SummaryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SummaryComponent, "ui-core-summary", never, { "showCheck": { "alias": "showCheck"; "required": false; }; "headerDetails": { "alias": "headerDetails"; "required": false; }; "summaryDetails": { "alias": "summaryDetails"; "required": false; }; "pipedDetails": { "alias": "pipedDetails"; "required": false; }; "showEditButton": { "alias": "showEditButton"; "required": false; }; "showDeleteButton": { "alias": "showDeleteButton"; "required": false; }; "disableButtons": { "alias": "disableButtons"; "required": false; }; }, { "editButtonClicked": "editButtonClicked"; "deleteButtonClicked": "deleteButtonClicked"; }, never, never, false, never>;
}

declare class UnsavedChangesModalComponent extends BaseTextComponent {
    private modalService;
    protected textService: TextService;
    unsavedChangesModal: TemplateRef<any>;
    /**
    * Optional modal title. Default is "Unsaved Changes"
    **/
    title: string;
    /**
    * Optional. The header message inside the modal. Default is "Are you sure you want to leave?"
    **/
    header: string;
    /**
    * Optional. The message inside the modal body. Default is "Your changes will be lost unless saved."
    **/
    message: string;
    /**
    * Optional primary button text. Default is "Continue Editing"
    **/
    primaryButtonText: string;
    /**
    * Optional secondary button text. Default is "Discard Changes"
    **/
    secondaryButtonText: string;
    /**
    * Set to true to prevent the modal from closing when the scrim (backdrop) is clicked or when
    * the ESC key is pressed. The modal can only be dismissed via its close, cancel, or submit
    * buttons, or programmatically (e.g. modalService.dismissAll()).
    **/
    lockScrim: boolean;
    modalTitle: string;
    headerMessage: string;
    bodyMessage: string;
    continueButtonText: string;
    discardButtonText: string;
    private discardChanges;
    constructor(modalService: ModalService, textService: TextService);
    private show;
    showUnsavedChangesModal(): Promise<boolean>;
    continue(): void;
    discard(): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnsavedChangesModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UnsavedChangesModalComponent, "ui-core-unsaved-changes-modal", never, { "title": { "alias": "title"; "required": false; }; "header": { "alias": "header"; "required": false; }; "message": { "alias": "message"; "required": false; }; "primaryButtonText": { "alias": "primaryButtonText"; "required": false; }; "secondaryButtonText": { "alias": "secondaryButtonText"; "required": false; }; "lockScrim": { "alias": "lockScrim"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ButtonMenuOptionComponent extends BaseDestroyComponent {
    private modalService;
    private router;
    private windowService;
    /**
    * Required. The menu option to render, including its text, optional icon, action or URL, and e2e attribute.
    **/
    option: ButtonMenuOption;
    isMobile: boolean;
    constructor(modalService: ModalService, router: Router, windowService: WindowService);
    optionSelected(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ButtonMenuOptionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ButtonMenuOptionComponent, "ui-core-button-menu-option", never, { "option": { "alias": "option"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ButtonGridItemComponent implements OnChanges {
    text: string;
    icon: string;
    e2e: string;
    iconAboveMessage: boolean;
    iconShape: 'circle' | 'rounded' | 'square' | '';
    rowIndex: number;
    rowLength: number;
    rowPosition: 'row' | 'more' | '';
    badgeTheme: BadgeTheme;
    badgeMessage: string;
    ariaExpanded: HtmlAttributeState | null;
    ariaControls: string;
    ariaHasPopup: HtmlAttributeState | null;
    ariaActiveDescendantId: string;
    buttonId: string;
    stackButtonClass: string;
    buttonClasses: string;
    messageClasses: string;
    isRow: boolean;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ButtonGridItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ButtonGridItemComponent, "ui-core-button-grid-item", never, { "text": { "alias": "text"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; "iconAboveMessage": { "alias": "iconAboveMessage"; "required": false; }; "iconShape": { "alias": "iconShape"; "required": false; }; "rowIndex": { "alias": "rowIndex"; "required": false; }; "rowLength": { "alias": "rowLength"; "required": false; }; "rowPosition": { "alias": "rowPosition"; "required": false; }; "badgeTheme": { "alias": "badgeTheme"; "required": false; }; "badgeMessage": { "alias": "badgeMessage"; "required": false; }; "ariaExpanded": { "alias": "ariaExpanded"; "required": false; }; "ariaControls": { "alias": "ariaControls"; "required": false; }; "ariaHasPopup": { "alias": "ariaHasPopup"; "required": false; }; "ariaActiveDescendantId": { "alias": "ariaActiveDescendantId"; "required": false; }; "buttonId": { "alias": "buttonId"; "required": false; }; "stackButtonClass": { "alias": "stackButtonClass"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ToastNotificationComponent implements OnChanges {
    /**
    * The message to display.
    **/
    message: string;
    /**
    * Optional. Additional details to display below the message.
    **/
    details: string;
    /**
    * The theme controls the icon and color scheme used. It also controls timing and other behaviors/features.
    * Use NotificationTheme when setting this value. ToastNotificationTheme is a union type that includes a subset of NotificationTheme values,
    * so NotificationTheme values are the correct type to use here.
    **/
    theme: ToastNotificationTheme;
    /**
    * A custom icon that overrides the theme's default icon. Only applies to the 'information' and 'neutral' themes.
    **/
    customIcon: string;
    /**
    * Optional avatar - only available for use with the progress notifications in CMS Level Up.
    * Only displayed when avatar has progressValue and progressMax set.
    * For standard notifications, themed icons are set automatically.
    **/
    avatar: AvatarModel;
    /**
    * Indicates if this is a progress notification (for special rendering).
    **/
    isProgressNotification: boolean;
    /**
    * URL path of animation .json file. When set, renders a Lottie animation instead of an icon.
    * (Mutually exclusive with customAnimationData.) Only applies to the 'information' and 'neutral' themes.
    **/
    customAnimationPath: string;
    /**
    * JSON string of animation data. When set, renders a Lottie animation instead of an icon.
    * (Mutually exclusive with customAnimationPath.) Only applies to the 'information' and 'neutral' themes.
    **/
    customAnimationData: string;
    /**
    * Boolean to indicate that the animation should not animate, but display a single still frame.
    **/
    customAnimationFreeze: boolean;
    /**
    * Animation frame to display when freeze is true - animation becomes a "still image" of this frame.
    **/
    customAnimationFreezeFrame: number;
    /**
    * Boolean to indicate that the animation should loop & play continuously. If false, it will play once & stop.
    **/
    customAnimationLoop: boolean;
    /**
    * Number to indicate the total number of times the animation should loop. Only used when loop is true.
    * 0 enables infinite looping of animation (default).
    **/
    customAnimationLoopTotal: number;
    /**
    * Array of buttons to display. Maximum of 2 buttons.
    * First button (index 0) uses neutral secondary theme.
    * Second button (index 1) uses neutral tertiary theme.
    * Note: Buttons with empty or whitespace-only text will not be rendered.
    * If more than 2 buttons are provided, only the first 2 will be displayed.
    **/
    buttons: NotificationButton[];
    /**
    * Emits DOM Event when close button is clicked.
    **/
    closed: EventEmitter<void>;
    /**
    * Emitted when a button is clicked. Emits the index of the button (0 for first, 1 for second).
    **/
    buttonClicked: EventEmitter<number>;
    e2e: string;
    icon: string;
    iconColorClass: string;
    animationPath: string;
    animationData: string;
    validButtons: NotificationButton[];
    constructor();
    ngOnChanges(changes: SimpleChanges): void;
    private setIconProperties;
    close(): void;
    getButtonTheme(index: number): 'secondary' | 'tertiary';
    onButtonClick(index: number, event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToastNotificationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToastNotificationComponent, "ui-core-toast-notification", never, { "message": { "alias": "message"; "required": false; }; "details": { "alias": "details"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "customIcon": { "alias": "customIcon"; "required": false; }; "avatar": { "alias": "avatar"; "required": false; }; "isProgressNotification": { "alias": "isProgressNotification"; "required": false; }; "customAnimationPath": { "alias": "customAnimationPath"; "required": false; }; "customAnimationData": { "alias": "customAnimationData"; "required": false; }; "customAnimationFreeze": { "alias": "customAnimationFreeze"; "required": false; }; "customAnimationFreezeFrame": { "alias": "customAnimationFreezeFrame"; "required": false; }; "customAnimationLoop": { "alias": "customAnimationLoop"; "required": false; }; "customAnimationLoopTotal": { "alias": "customAnimationLoopTotal"; "required": false; }; "buttons": { "alias": "buttons"; "required": false; }; }, { "closed": "closed"; "buttonClicked": "buttonClicked"; }, never, never, false, never>;
}

declare class UiCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UiCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UiCoreModule, [typeof AccountCardComponent, typeof AccountTemplateComponent, typeof ActionCardComponent, typeof ActionListComponent, typeof AnimationComponent, typeof AttachmentComponent, typeof AvatarComponent, typeof BackButtonComponent, typeof BadgeComponent, typeof BannerNotificationComponent, typeof BadgeListComponent, typeof BreadcrumbsComponent, typeof BulletListComponent, typeof ButtonComponent, typeof ButtonCardsComponent, typeof ButtonGridComponent, typeof ButtonGroupComponent, typeof ButtonMenuLegacyComponent, typeof ButtonMenuComponent, typeof ButtonMenuOptionComponent, typeof CardComponent, typeof CardGridComponent, typeof CardImageComponent, typeof CardTemplateComponent, typeof CarouselComponent, typeof ChinButtonsComponent, typeof ChipListComponent, typeof ClickableComponent, typeof CloseButtonComponent, typeof CollapsableComponent, typeof ContentCardComponent, typeof ContentComponent, typeof CopyToClipboardButtonComponent, typeof CountdownComponent, typeof DescriptionListComponent, typeof DocumentViewerComponent, typeof GlassBackgroundComponent, typeof GlassBackgroundV2Component, typeof GlassHeaderComponent, typeof GridLayoutComponent, typeof HtmlEditorContentComponent, typeof IconComponent, typeof IconBulletsComponent, typeof IconButtonComponent, typeof IconShapeComponent, typeof ImageDisplayComponent, typeof InlineActionsBarComponent, typeof InLineNotificationComponent, typeof LabelValueListComponent, typeof LabelValueComponent, typeof LinkComponent, typeof LoadingOverlayComponent, typeof LottieV1Component, typeof LottieV2Component, typeof MicroNotificationComponent, typeof MicroSummaryComponent, typeof ModalComponent, typeof NavIconComponent, typeof OrderedListComponent, typeof PageActionsComponent, typeof PipedDetailsComponent, typeof ProgressBarComponent, typeof ProgressCircleComponent, typeof SafeHtmlComponent, typeof ScrollboxComponent, typeof SessionTimeoutModalComponent, typeof SpinnerComponent, typeof StackComponent, typeof StatusNotificationComponent, typeof SummaryComponent, typeof TabsComponent, typeof TooltipComponent, typeof ToastStackComponent, typeof UnsavedChangesModalComponent, typeof VideoComponent, typeof AttributesDirective, typeof DropdownMenuDirective, typeof FocusDirective, typeof LoadingOverlayDirective, typeof HoverDirective, typeof IconRendererDirective, typeof ReplayMaskDirective, typeof ReplayUnmaskDirective, typeof ResizeDirective, typeof AccountMaskPipe, typeof DashedSsnPipe, typeof FormatPipe, typeof Last4FormattedSsnPipe, typeof Last4SsnPipe, typeof PhoneNumberPipe, typeof TimeZoneDatePipe, typeof ActionMenuComponent, typeof ButtonGridItemComponent, typeof ToastNotificationComponent], [typeof i95.CommonModule, typeof i96.NgbModule, typeof i97.RouterModule, typeof i98.ClipboardModule, typeof i95.NgOptimizedImage, typeof i99.ScrollingModule, typeof SwiperContainerComponent], [typeof AccountCardComponent, typeof AccountTemplateComponent, typeof ActionCardComponent, typeof ActionListComponent, typeof AnimationComponent, typeof AttachmentComponent, typeof AvatarComponent, typeof BackButtonComponent, typeof BadgeComponent, typeof BannerNotificationComponent, typeof BadgeListComponent, typeof BreadcrumbsComponent, typeof BulletListComponent, typeof ButtonComponent, typeof ButtonCardsComponent, typeof ButtonGridComponent, typeof ButtonGroupComponent, typeof ButtonMenuLegacyComponent, typeof ButtonMenuComponent, typeof CardComponent, typeof CardGridComponent, typeof CardImageComponent, typeof CardTemplateComponent, typeof CarouselComponent, typeof ChinButtonsComponent, typeof ChipListComponent, typeof ClickableComponent, typeof CloseButtonComponent, typeof CollapsableComponent, typeof ContentCardComponent, typeof ContentComponent, typeof CopyToClipboardButtonComponent, typeof CountdownComponent, typeof DescriptionListComponent, typeof DocumentViewerComponent, typeof GlassBackgroundComponent, typeof GlassBackgroundV2Component, typeof GlassHeaderComponent, typeof GridLayoutComponent, typeof HtmlEditorContentComponent, typeof IconComponent, typeof IconBulletsComponent, typeof IconButtonComponent, typeof IconShapeComponent, typeof ImageDisplayComponent, typeof InlineActionsBarComponent, typeof InLineNotificationComponent, typeof LabelValueListComponent, typeof LabelValueComponent, typeof LinkComponent, typeof LoadingOverlayComponent, typeof MicroNotificationComponent, typeof MicroSummaryComponent, typeof ModalComponent, typeof NavIconComponent, typeof OrderedListComponent, typeof PageActionsComponent, typeof PipedDetailsComponent, typeof ProgressBarComponent, typeof ProgressCircleComponent, typeof SafeHtmlComponent, typeof ScrollboxComponent, typeof SessionTimeoutModalComponent, typeof SpinnerComponent, typeof StackComponent, typeof StatusNotificationComponent, typeof SummaryComponent, typeof TabsComponent, typeof TooltipComponent, typeof ToastStackComponent, typeof UnsavedChangesModalComponent, typeof VideoComponent, typeof AttributesDirective, typeof DropdownMenuDirective, typeof FocusDirective, typeof HoverDirective, typeof IconRendererDirective, typeof LoadingOverlayDirective, typeof ReplayMaskDirective, typeof ReplayUnmaskDirective, typeof ResizeDirective, typeof AccountMaskPipe, typeof DashedSsnPipe, typeof FormatPipe, typeof Last4FormattedSsnPipe, typeof Last4SsnPipe, typeof PhoneNumberPipe, typeof TimeZoneDatePipe]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UiCoreModule>;
}

export { AccountCardComponent, AccountMaskPipe, AccountTemplateComponent, AccountTemplateStatus, AccountTemplateType, ActionCardComponent, ActionCardItem, ActionListComponent, ActionListItem, AnalyticsService, AnimationComponent, AnimationTimingFunction, AnimationUtils, AppInitializer, AttachmentComponent, AttachmentFile, AttachmentUtils, AttributesDirective, AvatarComponent, AvatarModel, BINARY_FILE_TYPES, BackButtonComponent, BadgeComponent, BadgeListComponent, BadgeModel, BadgeTheme, BannerNotificationComponent, BaseDestroyComponent, BaseMenuComponent, BaseMenuState, BaseTextComponent, BreadcrumbItem, BreadcrumbsComponent, BulletListComponent, ButtonCardItem, ButtonCardsComponent, ButtonComponent, ButtonGridComponent, ButtonGridItem, ButtonGroupComponent, ButtonMenuComponent, ButtonMenuLegacyComponent, ButtonMenuOption, CardComponent, CardGridComponent, CardGridItem, CardImageComponent, CardOrientation, CardTemplateComponent, CarouselComponent, ChinButtonsComponent, ChipListComponent, ChipListItem, ClickableComponent, CloseButtonComponent, CollapsableComponent, ContainerTheme, ContentCardComponent, ContentComponent, CopyToClipboardButtonComponent, CountdownComponent, DESKTOP_MENU_MAX_HEIGHT, DESKTOP_MENU_ON_MOBILE_MAX_HEIGHT, DashedSsnPipe, DescriptionListComponent, DescriptionListItem, DesktopMenuAlignment, DocumentAction, DocumentView, DocumentViewerComponent, DropdownMenuDirective, DynamicAttribute, EventUtils, FILE_TYPE_VARIATIONS, FeatureFlagClass, FileEncodingType, FileType, FileUtils, FocusDirective, FocusUtils, FormatPipe, GlassBackgroundComponent, GlassBackgroundLayout, GlassBackgroundV2Component, GlassHeaderComponent, GridItem, GridLayoutComponent, HoverDirective, HtmlAttributeState, HtmlEditorContentComponent, HtmlUtils, IMAGE_FILE_TYPES, IconBulletItem, IconBulletsComponent, IconButtonComponent, IconComponent, IconRendererDirective, IconShapeComponent, ImageDisplayComponent, ImageDisplayModel, InLineNotificationComponent, InlineAction, InlineActionsBarComponent, LabelValueComponent, LabelValueListComponent, LabelValueListItem, Last4FormattedSsnPipe, Last4SsnPipe, LinkComponent, LinkParts, LoadingOverlayComponent, LoadingOverlayDirective, LottieV1Component, LottieV2Component, MicroNotificationComponent, MicroNotificationModel, MicroSummaryComponent, ModalBridgeService, ModalButtonType, ModalComponent, ModalService, NativeMobileStatusBarTextColor, NativeMobileUtils, NavIconComponent, NotificationTheme, ObjectPosition, ObservableUtils, OrderedListComponent, PageActionItem, PageActionsComponent, PhoneNumberPipe, PhoneNumberUtils, PipedDetail, PipedDetailsComponent, ProgressBarComponent, ProgressCircleComponent, ReplayMaskDirective, ReplayUnmaskDirective, ResizeDirective, ResizeEvent, ResizeObservable, SafeHtmlComponent, SanitizationUtils, ScriptInjectionService, ScrollUtils, ScrollboxComponent, SessionTimeoutModalComponent, SlideChangeEvent, SpacingConfig, SpacingElement, SpacingUtils, SpinnerComponent, StackComponent, StatusNotificationComponent, SummaryComponent, SummaryDetail, Tab, TabsComponent, TextService, TextSize, ThemeSize, TimeZoneDatePipe, ToastStackComponent, ToastStackService, TooltipComponent, TransitionEffect, TransitionStateChange, UI_ANALYTICS_PUBLISHER, UI_ROUTE_VALIDATOR, UI_TEXT_PROVIDER, UiCoreModule, UnsavedChangesModalComponent, UuidUtils, VideoComponent, WindowService, WindowSize, WindowUtils, collapse, collapseConditional, collapseEffect, collapseOrSlideState, collapseState, expandEffect, fadeInAnimation, fadeInEffect, fadeInOut, fadeOutEffect, slideDownEffect, slideInOutFromLeft, slideInOutFromRight, slideLeftEffect, slideRightEffect, slideToTop, slideToTopState, slideUp, slideUpEffect };
export type { Action, BannerNotificationTheme, ImageDisplayMode, NotificationButton, OrderedListInput, OrderedListItem, ScriptInfo, ToastNotificationTheme, UiAnalyticsPublisher, UiRouteValidator, UiTextProvider, UserChangeDetails };
//# sourceMappingURL=index.d.ts.map
