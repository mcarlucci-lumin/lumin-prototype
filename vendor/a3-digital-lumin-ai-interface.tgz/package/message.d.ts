export declare class Message {
    id: string;
    assistantId: string;
    attachments: any[];
    completedAt: number;
    content: any[];
    createdAt: number;
    incompleteAt: number;
    incompleteDetails: any;
    metadata: any;
    object: string;
    role: string;
    runId: string;
    status: string;
    threadId: string;
    constructor(id: string, assistantId: string, attachments: any[], completedAt: number, content: any[], createdAt: number, incompleteAt: number, incompleteDetails: any, metadata: any, object: string, role: string, runId: string, status: string, threadId: string);
}
