export class LuminAiWebSocketEvent {
}
//# sourceMappingURL=lumin-ai-web-socket-event.js.map