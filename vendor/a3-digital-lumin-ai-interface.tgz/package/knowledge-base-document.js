export class KnowledgeBaseDocument {
}
//# sourceMappingURL=knowledge-base-document.js.map