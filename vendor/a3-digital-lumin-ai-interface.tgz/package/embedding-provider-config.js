export {};
//# sourceMappingURL=embedding-provider-config.js.map