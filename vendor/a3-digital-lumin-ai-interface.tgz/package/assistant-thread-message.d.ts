export declare class AssistantThreadMessage {
    id: number;
    userId: string;
    assistantId: string;
    threadId: string;
    requestMessage: string;
    responseMessage: string;
    insertDate: Date;
    lastModified: Date;
}
