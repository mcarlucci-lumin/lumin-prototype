export class LuminAiAssistant {
}
//# sourceMappingURL=lumin-ai-assistant.js.map