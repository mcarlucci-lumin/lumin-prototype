export class AssistantThreadMessage {
}
//# sourceMappingURL=assistant-thread-message.js.map