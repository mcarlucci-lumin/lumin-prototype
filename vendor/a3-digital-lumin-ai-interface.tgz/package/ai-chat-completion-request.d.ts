export declare class AiChatCompletionRequest {
    conversationId: string;
    userId: string;
    message: string;
}
