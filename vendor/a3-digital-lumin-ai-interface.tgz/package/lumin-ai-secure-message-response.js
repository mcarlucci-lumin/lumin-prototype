export class LuminAiSecureMessageResponse {
}
//# sourceMappingURL=lumin-ai-secure-message-response.js.map