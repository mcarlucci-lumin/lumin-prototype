import { Assistant } from './assistant.js';
import { LuminAiBaseResponse } from './lumin-ai-base-response.js';
export declare class LuminAiGetAssistantsResponse extends LuminAiBaseResponse {
    assistants: Assistant[];
}
