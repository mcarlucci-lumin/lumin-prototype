import { LuminAiWebSocketEventType } from './lumin-ai-web-socket-event-type.js';
export declare class LuminAiWebSocketEvent {
    eventType: LuminAiWebSocketEventType;
    userId: string;
    assistantId: string;
    threadId: string;
    message: string;
}
