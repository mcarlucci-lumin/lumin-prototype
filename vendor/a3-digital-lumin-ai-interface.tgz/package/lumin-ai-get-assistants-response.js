import { LuminAiBaseResponse } from './lumin-ai-base-response.js';
export class LuminAiGetAssistantsResponse extends LuminAiBaseResponse {
}
//# sourceMappingURL=lumin-ai-get-assistants-response.js.map