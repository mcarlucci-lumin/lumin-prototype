export class LuminAiCreateMessageRequest {
}
//# sourceMappingURL=lumin-ai-create-message-request.js.map