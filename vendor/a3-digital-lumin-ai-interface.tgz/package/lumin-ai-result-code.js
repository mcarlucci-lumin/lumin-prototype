export var LuminAiResultCode;
(function (LuminAiResultCode) {
    LuminAiResultCode["OK"] = "OK";
    LuminAiResultCode["SERVER_ERROR"] = "SERVER_ERROR";
    LuminAiResultCode["PERMISSION_DENIED"] = "PERMISSION_DENIED";
    LuminAiResultCode["UNKNOWN_ERROR"] = "UNKNOWN_ERROR";
    LuminAiResultCode["NO_CONTENT"] = "NO_CONTENT";
    LuminAiResultCode["BAD_REQUEST"] = "BAD_REQUEST";
    LuminAiResultCode["MISSING_PARAMETER"] = "MISSING_PARAMETER";
    LuminAiResultCode["MISSING_VALUE"] = "MISSING_VALUE";
    LuminAiResultCode["UNAUTHORIZED"] = "UNAUTHORIZED";
    LuminAiResultCode["NOT_FOUND"] = "NOT_FOUND";
})(LuminAiResultCode || (LuminAiResultCode = {}));
//# sourceMappingURL=lumin-ai-result-code.js.map