import { z } from 'zod';
import { LlmUsageRequest } from '../usage/llm-usage-request.js';
import { VectorStoreUsageRequest } from '../usage/vector-store-usage-request.js';
import { RecordUsageRequest } from '../usage/record-usage-request.js';
export declare const LlmUsageRequestSchema: z.ZodType<LlmUsageRequest, z.ZodTypeDef, unknown>;
export declare const VectorStoreUsageRequestSchema: z.ZodType<VectorStoreUsageRequest, z.ZodTypeDef, unknown>;
export declare const RecordUsageRequestSchema: z.ZodType<RecordUsageRequest, z.ZodTypeDef, unknown>;
