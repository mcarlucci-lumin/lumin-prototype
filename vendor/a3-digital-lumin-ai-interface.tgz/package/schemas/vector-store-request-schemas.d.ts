import { z } from 'zod';
import { DeleteRecordsRequest, FetchIdsQuery, HybridSearchRequest, SemanticSearchRequest, UpsertRecordsRequest } from '../vector-store/vector-store-requests.js';
export declare const UpsertRecordsRequestSchema: z.ZodType<UpsertRecordsRequest, z.ZodTypeDef, unknown>;
export declare const DeleteRecordsRequestSchema: z.ZodType<DeleteRecordsRequest, z.ZodTypeDef, unknown>;
export declare const SemanticSearchRequestSchema: z.ZodType<SemanticSearchRequest, z.ZodTypeDef, unknown>;
export declare const HybridSearchRequestSchema: z.ZodType<HybridSearchRequest, z.ZodTypeDef, unknown>;
export declare const FetchIdsQuerySchema: z.ZodType<FetchIdsQuery, z.ZodTypeDef, unknown>;
