import { z } from 'zod';
export declare function schemaFor<T>(): <S extends { [K in keyof T]-?: z.ZodType<T[K], z.ZodTypeDef, unknown>; } & { [K in Exclude<keyof S, keyof T>]: never; }>(shape: S) => z.ZodType<T, z.ZodTypeDef, unknown>;
