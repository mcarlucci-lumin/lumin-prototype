import { z } from 'zod';
type ShapeFor<T, S> = {
    [K in keyof T]-?: z.ZodType<T[K], z.ZodTypeDef, unknown>;
} & {
    [K in Exclude<keyof S, keyof T>]: never;
};
export declare function schemaFor<T>(): <S extends ShapeFor<T, S>>(shape: S) => z.ZodType<T, z.ZodTypeDef, unknown>;
export declare function objectFor<T>(): <S extends ShapeFor<T, S>>(shape: S) => z.ZodObject<S, "passthrough", z.ZodTypeAny, z.objectOutputType<S, z.ZodTypeAny, "passthrough">, z.objectInputType<S, z.ZodTypeAny, "passthrough">>;
export {};
