import { z } from 'zod';
import { CompletionResultUsage } from '../llm/completion-result-usage.js';
import { Document } from '../vector-store/document.js';
export declare const tokenCount: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
export declare const CompletionResultUsageSchema: z.ZodType<CompletionResultUsage, z.ZodTypeDef, unknown>;
export declare const DocumentSchema: z.ZodType<Document, z.ZodTypeDef, unknown>;
