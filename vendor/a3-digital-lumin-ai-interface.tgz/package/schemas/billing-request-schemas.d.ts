import { z } from 'zod';
import { UpdateFeatureConfigRequest } from '../billing/update-feature-config-request.js';
import { CreateGroupQuotaRequest } from '../billing/create-group-quota-request.js';
import { UpdateGroupQuotaRequest } from '../billing/update-group-quota-request.js';
import { EnablementQuery } from '../billing/enablement-query.js';
export declare const UpdateFeatureConfigRequestSchema: z.ZodType<UpdateFeatureConfigRequest, z.ZodTypeDef, unknown>;
export declare const EnablementQuerySchema: z.ZodType<EnablementQuery, z.ZodTypeDef, unknown>;
export declare const CreateGroupQuotaRequestSchema: z.ZodType<CreateGroupQuotaRequest, z.ZodTypeDef, unknown>;
export declare const UpdateGroupQuotaRequestSchema: z.ZodType<UpdateGroupQuotaRequest, z.ZodTypeDef, unknown>;
