import { z } from 'zod';
import { UpdateFeaturesRequest } from '../billing/update-features-request.js';
import { CreateGroupQuotaRequest } from '../billing/create-group-quota-request.js';
import { UpdateGroupQuotaRequest } from '../billing/update-group-quota-request.js';
import { EnablementQuery } from '../billing/enablement-query.js';
export declare const UpdateFeaturesRequestSchema: z.ZodType<UpdateFeaturesRequest, z.ZodTypeDef, unknown>;
export declare const EnablementQuerySchema: z.ZodType<EnablementQuery, z.ZodTypeDef, unknown>;
export declare const CreateGroupQuotaRequestSchema: z.ZodType<CreateGroupQuotaRequest, z.ZodTypeDef, unknown>;
export declare const UpdateGroupQuotaRequestSchema: z.ZodType<UpdateGroupQuotaRequest, z.ZodTypeDef, unknown>;
