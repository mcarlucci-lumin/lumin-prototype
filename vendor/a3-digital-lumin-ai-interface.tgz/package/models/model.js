export class Model {
    constructor(type, name, provider, approvedForPII, calculateCredits) {
        this.type = type;
        this.name = name;
        this.provider = provider;
        this.approvedForPII = approvedForPII;
        this.calculateCredits = calculateCredits;
    }
}
//# sourceMappingURL=model.js.map