import { LLMProvider } from '../llm/llm-provider.js';
import { Model } from './model.js';
import { ModelType } from './model-type.js';
export class ModelRegistry {
    static { this.models = {
        [ModelType.ANTHROPIC_OPUS_4_8]: new Model(ModelType.ANTHROPIC_OPUS_4_8, 'claude-opus-4-8', LLMProvider.ANTHROPIC, false, (inputTokens, outputTokens) => Math.ceil(inputTokens / 1000 + outputTokens / 200)),
        [ModelType.ANTHROPIC_OPUS_4_7]: new Model(ModelType.ANTHROPIC_OPUS_4_7, 'claude-opus-4-7', LLMProvider.ANTHROPIC, false, (inputTokens, outputTokens) => Math.ceil(inputTokens / 1000 + outputTokens / 200)),
        [ModelType.ANTHROPIC_OPUS_4_6]: new Model(ModelType.ANTHROPIC_OPUS_4_6, 'claude-opus-4-6', LLMProvider.ANTHROPIC, false, (inputTokens, outputTokens) => Math.ceil(inputTokens / 1000 + outputTokens / 200)),
        [ModelType.ANTHROPIC_OPUS_4_5]: new Model(ModelType.ANTHROPIC_OPUS_4_5, 'claude-opus-4-5', LLMProvider.ANTHROPIC, false, (inputTokens, outputTokens) => Math.ceil(inputTokens / 1000 + outputTokens / 200)),
        [ModelType.ANTHROPIC_SONNET_4_6]: new Model(ModelType.ANTHROPIC_SONNET_4_6, 'claude-sonnet-4-6', LLMProvider.ANTHROPIC, false, (inputTokens, outputTokens) => Math.ceil(inputTokens / 1667 + outputTokens / 333)),
        [ModelType.ANTHROPIC_SONNET_4_5]: new Model(ModelType.ANTHROPIC_SONNET_4_5, 'claude-sonnet-4-5', LLMProvider.ANTHROPIC, false, (inputTokens, outputTokens) => Math.ceil(inputTokens / 1667 + outputTokens / 333)),
        [ModelType.ANTHROPIC_HAIKU_4_5]: new Model(ModelType.ANTHROPIC_HAIKU_4_5, 'claude-haiku-4-5', LLMProvider.ANTHROPIC, false, (inputTokens, outputTokens) => Math.ceil(inputTokens / 5000 + outputTokens / 1000)),
        [ModelType.BEDROCK_OPUS_4_8]: new Model(ModelType.BEDROCK_OPUS_4_8, 'anthropic.claude-opus-4-8', LLMProvider.BEDROCK, true, (inputTokens, outputTokens) => Math.ceil(inputTokens / 1000 + outputTokens / 200)),
        [ModelType.BEDROCK_OPUS_4_7]: new Model(ModelType.BEDROCK_OPUS_4_7, 'anthropic.claude-opus-4-7', LLMProvider.BEDROCK, true, (inputTokens, outputTokens) => Math.ceil(inputTokens / 1000 + outputTokens / 200)),
        [ModelType.BEDROCK_OPUS_4_6]: new Model(ModelType.BEDROCK_OPUS_4_6, 'anthropic.claude-opus-4-6-v1', LLMProvider.BEDROCK, true, (inputTokens, outputTokens) => Math.ceil(inputTokens / 1000 + outputTokens / 200)),
        [ModelType.BEDROCK_OPUS_4_5]: new Model(ModelType.BEDROCK_OPUS_4_5, 'anthropic.claude-opus-4-5-20251101-v1:0', LLMProvider.BEDROCK, true, (inputTokens, outputTokens) => Math.ceil(inputTokens / 1000 + outputTokens / 200)),
        [ModelType.BEDROCK_SONNET_4_6]: new Model(ModelType.BEDROCK_SONNET_4_6, 'anthropic.claude-sonnet-4-6', LLMProvider.BEDROCK, true, (inputTokens, outputTokens) => Math.ceil(inputTokens / 1667 + outputTokens / 333)),
        [ModelType.BEDROCK_SONNET_4_5]: new Model(ModelType.BEDROCK_SONNET_4_5, 'anthropic.claude-sonnet-4-5-20250929-v1:0', LLMProvider.BEDROCK, true, (inputTokens, outputTokens) => Math.ceil(inputTokens / 1667 + outputTokens / 333)),
        [ModelType.BEDROCK_HAIKU_4_5]: new Model(ModelType.BEDROCK_HAIKU_4_5, 'anthropic.claude-haiku-4-5-20251001-v1:0', LLMProvider.BEDROCK, true, (inputTokens, outputTokens) => Math.ceil(inputTokens / 5000 + outputTokens / 1000)),
        [ModelType.OPENAI_GPT_5_5]: new Model(ModelType.OPENAI_GPT_5_5, 'gpt-5.5', LLMProvider.OPEN_AI, false, (inputTokens, outputTokens) => Math.ceil(inputTokens / 1000 + outputTokens / 167)),
        [ModelType.OPENAI_GPT_5_5_PRO]: new Model(ModelType.OPENAI_GPT_5_5_PRO, 'gpt-5.5-pro', LLMProvider.OPEN_AI, false, (inputTokens, outputTokens) => Math.ceil(inputTokens / 167 + outputTokens / 28)),
        [ModelType.OPENAI_GPT_5_4]: new Model(ModelType.OPENAI_GPT_5_4, 'gpt-5.4', LLMProvider.OPEN_AI, false, (inputTokens, outputTokens) => Math.ceil(inputTokens / 2000 + outputTokens / 333)),
        [ModelType.OPENAI_GPT_5_4_MINI]: new Model(ModelType.OPENAI_GPT_5_4_MINI, 'gpt-5.4-mini', LLMProvider.OPEN_AI, false, (inputTokens, outputTokens) => Math.ceil(inputTokens / 6667 + outputTokens / 1111)),
        [ModelType.OPENAI_GPT_5_4_NANO]: new Model(ModelType.OPENAI_GPT_5_4_NANO, 'gpt-5.4-nano', LLMProvider.OPEN_AI, false, (inputTokens, outputTokens) => Math.ceil(inputTokens / 25000 + outputTokens / 4000)),
        [ModelType.OPENAI_GPT_5_4_PRO]: new Model(ModelType.OPENAI_GPT_5_4_PRO, 'gpt-5.4-pro', LLMProvider.OPEN_AI, false, (inputTokens, outputTokens) => Math.ceil(inputTokens / 167 + outputTokens / 28)),
    }; }
    static getModel(type) {
        return ModelRegistry.models[type];
    }
}
//# sourceMappingURL=model-registry.js.map