export var ModelType;
(function (ModelType) {
    ModelType["ANTHROPIC_OPUS_4_8"] = "ANTHROPIC_OPUS_4_8";
    ModelType["ANTHROPIC_OPUS_4_7"] = "ANTHROPIC_OPUS_4_7";
    ModelType["ANTHROPIC_OPUS_4_6"] = "ANTHROPIC_OPUS_4_6";
    ModelType["ANTHROPIC_OPUS_4_5"] = "ANTHROPIC_OPUS_4_5";
    ModelType["ANTHROPIC_SONNET_4_6"] = "ANTHROPIC_SONNET_4_6";
    ModelType["ANTHROPIC_SONNET_4_5"] = "ANTHROPIC_SONNET_4_5";
    ModelType["ANTHROPIC_HAIKU_4_5"] = "ANTHROPIC_HAIKU_4_5";
    ModelType["BEDROCK_OPUS_4_8"] = "BEDROCK_OPUS_4_8";
    ModelType["BEDROCK_OPUS_4_7"] = "BEDROCK_OPUS_4_7";
    ModelType["BEDROCK_OPUS_4_6"] = "BEDROCK_OPUS_4_6";
    ModelType["BEDROCK_OPUS_4_5"] = "BEDROCK_OPUS_4_5";
    ModelType["BEDROCK_SONNET_4_6"] = "BEDROCK_SONNET_4_6";
    ModelType["BEDROCK_SONNET_4_5"] = "BEDROCK_SONNET_4_5";
    ModelType["BEDROCK_HAIKU_4_5"] = "BEDROCK_HAIKU_4_5";
    ModelType["OPENAI_GPT_5_5"] = "OPENAI_GPT_5_5";
    ModelType["OPENAI_GPT_5_5_PRO"] = "OPENAI_GPT_5_5_PRO";
    ModelType["OPENAI_GPT_5_4"] = "OPENAI_GPT_5_4";
    ModelType["OPENAI_GPT_5_4_MINI"] = "OPENAI_GPT_5_4_MINI";
    ModelType["OPENAI_GPT_5_4_NANO"] = "OPENAI_GPT_5_4_NANO";
    ModelType["OPENAI_GPT_5_4_PRO"] = "OPENAI_GPT_5_4_PRO";
})(ModelType || (ModelType = {}));
//# sourceMappingURL=model-type.js.map