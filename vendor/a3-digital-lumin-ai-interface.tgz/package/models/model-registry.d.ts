import { Model } from './model.js';
import { ModelType } from './model-type.js';
export declare class ModelRegistry {
    private static readonly models;
    static getModel(type: ModelType): Model;
}
