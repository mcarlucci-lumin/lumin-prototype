export class LuminAiEmbeddingRequest {
}
//# sourceMappingURL=lumin-ai-embedding-request.js.map