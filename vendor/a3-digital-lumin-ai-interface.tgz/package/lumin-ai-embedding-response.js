export class LuminAiEmbeddingResponse {
}
//# sourceMappingURL=lumin-ai-embedding-response.js.map