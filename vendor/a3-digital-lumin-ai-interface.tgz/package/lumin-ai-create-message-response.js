import { LuminAiBaseResponse } from './lumin-ai-base-response.js';
export class LuminAiCreateMessageResponse extends LuminAiBaseResponse {
}
//# sourceMappingURL=lumin-ai-create-message-response.js.map