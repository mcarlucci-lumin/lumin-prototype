export declare enum AgentAudience {
    USER_FACING = "USER_FACING",
    ADMIN_FACING = "ADMIN_FACING"
}
