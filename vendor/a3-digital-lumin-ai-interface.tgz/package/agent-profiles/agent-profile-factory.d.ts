import { AgentProfileType } from '../agent-profile-type.js';
import { AgentProfile } from './agent-profile.js';
export declare class AgentProfileFactory {
    private readonly registry;
    isRegistered(type: unknown): type is AgentProfileType;
    create(type: AgentProfileType): AgentProfile;
}
