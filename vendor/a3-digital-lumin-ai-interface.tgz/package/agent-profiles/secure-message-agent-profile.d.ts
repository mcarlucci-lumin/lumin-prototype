import { z } from 'zod';
import { GuardrailType } from './guardrail-type.js';
import { AgentProfile } from './agent-profile.js';
import { AgentProfileType } from '../agent-profile-type.js';
import { FeatureSet } from '../llm/feature-set.js';
import { SecureMessageAgentSessionInput } from '../llm/secure-message-agent-session-input.js';
import { AgentAudience } from './agent-audience.js';
export declare class SecureMessageAgentProfile extends AgentProfile {
    type: AgentProfileType;
    audience: AgentAudience;
    featureSet: FeatureSet;
    guardrails: GuardrailType[];
    sessionInputSchema: z.ZodObject<{
        threadId: z.ZodString;
        memberId: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        memberId?: string;
        threadId?: string;
    }, {
        memberId?: string;
        threadId?: string;
    }>;
    allowedToolNames: string[];
    identity: string;
    agentObjective: string;
    instructions: string;
    reminders: string;
    sessionContext(_workflowContext: unknown, sessionInput: SecureMessageAgentSessionInput): string;
}
