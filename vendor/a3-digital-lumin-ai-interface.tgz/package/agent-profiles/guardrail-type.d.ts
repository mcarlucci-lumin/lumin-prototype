export declare enum GuardrailType {
    UPSET_OR_PROFANITY = "upset-or-profanity",
    FINANCIAL_ADVICE = "financial-advice",
    PROMPT_INJECTION = "prompt-injection",
    OFF_TOPIC = "off-topic"
}
export declare const ALL_GUARDRAILS: GuardrailType[];
