import { type ZodType } from 'zod';
import { AgentProfileType } from '../agent-profile-type.js';
import { FeatureSet } from '../llm/feature-set.js';
import { GuardrailType } from './guardrail-type.js';
import { AgentAudience } from './agent-audience.js';
export declare abstract class AgentProfile {
    abstract type: AgentProfileType;
    abstract audience: AgentAudience;
    abstract featureSet: FeatureSet;
    abstract identity: string;
    abstract agentObjective: string;
    abstract instructions: string;
    abstract reminders: string;
    abstract guardrails: GuardrailType[];
    sessionInputSchema: ZodType;
    allowedToolNames?: string[];
    sessionContext?(context: unknown, sessionInput: any): Promise<string> | string;
}
