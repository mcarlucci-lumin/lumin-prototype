import { z } from 'zod';
import { GuardrailType } from './guardrail-type.js';
import { AgentProfile } from './agent-profile.js';
import { AgentProfileType } from '../agent-profile-type.js';
import { FeatureSet } from '../llm/feature-set.js';
import { RelationshipAgentSessionInput } from '../llm/relationship-agent-session-input.js';
import { AgentAudience } from './agent-audience.js';
export declare class RelationshipAgentProfile extends AgentProfile {
    type: AgentProfileType;
    audience: AgentAudience;
    featureSet: FeatureSet;
    guardrails: GuardrailType[];
    sessionInputSchema: z.ZodObject<{
        memberId: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        memberId?: string;
    }, {
        memberId?: string;
    }>;
    allowedToolNames: string[];
    identity: string;
    agentObjective: string;
    instructions: string;
    reminders: string;
    sessionContext(_workflowContext: unknown, sessionInput: RelationshipAgentSessionInput): string;
}
