import { z } from 'zod';
import { AgentProfile } from './agent-profile.js';
import { AgentProfileType } from '../agent-profile-type.js';
import { FeatureSet } from '../llm/feature-set.js';
import { AgentAudience } from './agent-audience.js';
export declare class LumiProfile extends AgentProfile {
    type: AgentProfileType;
    audience: AgentAudience;
    featureSet: FeatureSet;
    guardrails: import("./guardrail-type.js").GuardrailType[];
    sessionInputSchema: z.ZodObject<{}, "strict", z.ZodTypeAny, {}, {}>;
    identity: string;
    agentObjective: string;
    instructions: string;
    reminders: string;
}
