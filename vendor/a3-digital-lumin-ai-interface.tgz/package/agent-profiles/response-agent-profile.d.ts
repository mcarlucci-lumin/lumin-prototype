import { z } from 'zod';
import { GuardrailType } from './guardrail-type.js';
import { AgentProfile } from './agent-profile.js';
import { AgentProfileType } from '../agent-profile-type.js';
import { FeatureSet } from '../llm/feature-set.js';
import { ResponseAgentSessionInput } from '../llm/response-agent-session-input.js';
import { AgentAudience } from './agent-audience.js';
export declare class ResponseAgentProfile extends AgentProfile {
    type: AgentProfileType;
    audience: AgentAudience;
    featureSet: FeatureSet;
    guardrails: GuardrailType[];
    sessionInputSchema: z.ZodObject<{
        chatId: z.ZodString;
        memberId: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        chatId?: string;
        memberId?: string;
    }, {
        chatId?: string;
        memberId?: string;
    }>;
    allowedToolNames: string[];
    identity: string;
    agentObjective: string;
    instructions: string;
    reminders: string;
    sessionContext(_workflowContext: unknown, sessionInput: ResponseAgentSessionInput): string;
}
