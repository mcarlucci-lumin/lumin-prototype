export class LuminAiSecureMessageAddDocumentResponse {
}
//# sourceMappingURL=lumin-ai-secure-message-add-document-response.js.map