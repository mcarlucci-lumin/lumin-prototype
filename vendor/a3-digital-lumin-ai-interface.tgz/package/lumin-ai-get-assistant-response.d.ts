import { Assistant } from './assistant.js';
import { LuminAiBaseResponse } from './lumin-ai-base-response.js';
export declare class LuminAiGetAssistantResponse extends LuminAiBaseResponse {
    assistant: Assistant;
}
