import { LuminAiBaseResponse } from './lumin-ai-base-response.js';
export class AiChatMessageResponse extends LuminAiBaseResponse {
}
//# sourceMappingURL=ai-chat-message-response.js.map