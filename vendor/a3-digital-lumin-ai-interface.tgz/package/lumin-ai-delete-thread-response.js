import { LuminAiBaseResponse } from './lumin-ai-base-response.js';
export class LuminAiDeleteThreadResponse extends LuminAiBaseResponse {
}
//# sourceMappingURL=lumin-ai-delete-thread-response.js.map