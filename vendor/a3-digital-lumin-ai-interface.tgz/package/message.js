export class Message {
    constructor(id, assistantId, attachments = [], completedAt, content = [], createdAt, incompleteAt, incompleteDetails, metadata, object, role, runId, status, threadId) {
        this.attachments = [];
        this.content = [];
        this.id = id;
        this.assistantId = assistantId;
        this.attachments = attachments;
        this.completedAt = completedAt;
        this.content = content;
        this.createdAt = createdAt;
        this.incompleteAt = incompleteAt;
        this.incompleteDetails = incompleteDetails;
        this.metadata = metadata;
        this.object = object;
        this.role = role;
        this.runId = runId;
        this.status = status;
        this.threadId = threadId;
    }
}
//# sourceMappingURL=message.js.map