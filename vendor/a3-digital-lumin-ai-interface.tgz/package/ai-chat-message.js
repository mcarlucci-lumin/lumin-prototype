export class AiChatMessage {
}
//# sourceMappingURL=ai-chat-message.js.map