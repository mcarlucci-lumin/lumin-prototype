export declare enum EmbeddingProvider {
    OPEN_AI = "OPEN_AI",
    BEDROCK = "BEDROCK",
    PINECONE = "PINECONE",
    TEST = "TEST"
}
