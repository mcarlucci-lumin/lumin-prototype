export var LuminAiAssistantType;
(function (LuminAiAssistantType) {
    LuminAiAssistantType["SEARCH"] = "SEARCH";
    LuminAiAssistantType["SUGGESTION"] = "SUGGESTION";
    LuminAiAssistantType["REVIEW"] = "REVIEW";
    LuminAiAssistantType["SUMMARY"] = "SUMMARY";
    LuminAiAssistantType["MISC"] = "MISC";
})(LuminAiAssistantType || (LuminAiAssistantType = {}));
//# sourceMappingURL=lumin-ai-assistant-type.js.map