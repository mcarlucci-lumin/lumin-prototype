import { LlmUsageRequest } from './llm-usage-request.js';
import { VectorStoreUsageRequest } from './vector-store-usage-request.js';
export type RecordUsageRequest = LlmUsageRequest | VectorStoreUsageRequest;
