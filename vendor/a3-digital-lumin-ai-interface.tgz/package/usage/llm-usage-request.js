import { UsageRequest } from './usage-request.js';
export class LlmUsageRequest extends UsageRequest {
}
//# sourceMappingURL=llm-usage-request.js.map