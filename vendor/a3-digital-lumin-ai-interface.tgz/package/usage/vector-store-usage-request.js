import { UsageRequest } from './usage-request.js';
export class VectorStoreUsageRequest extends UsageRequest {
}
//# sourceMappingURL=vector-store-usage-request.js.map