export var UsageType;
(function (UsageType) {
    UsageType["LLM"] = "LLM";
    UsageType["VECTOR_STORE"] = "VECTOR_STORE";
})(UsageType || (UsageType = {}));
//# sourceMappingURL=usage-type.js.map