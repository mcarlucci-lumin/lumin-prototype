export class UsageRequest {
}
//# sourceMappingURL=usage-request.js.map