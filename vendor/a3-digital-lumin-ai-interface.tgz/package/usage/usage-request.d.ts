import { UsageType } from './usage-type.js';
import { LuminAiFeature } from '../llm/lumin-ai-feature.js';
import { FeatureSet } from '../llm/feature-set.js';
export declare class UsageRequest {
    type: UsageType;
    feature: LuminAiFeature;
    featureSet: FeatureSet;
    modelName: string;
    occurredAt: string;
}
