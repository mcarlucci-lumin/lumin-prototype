import { UsageRequest } from './usage-request.js';
export declare const USAGE_EVENTS_TOPIC = "solaire-billing.usage.events";
/**
 * Envelope published to VirtualTopic.solaire-billing.usage.events
 */
export interface UsageEvent {
    request: UsageRequest;
    /** UUID v7 minted at publish, so a redelivered message keeps its id. */
    eventId: string;
    /** Correlation id of the completion that incurred the usage. */
    correlationId?: string;
}
