import { LuminAiBaseResponse } from './lumin-ai-base-response.js';
export class LuminAiThreadMessagesResponse extends LuminAiBaseResponse {
}
//# sourceMappingURL=lumin-ai-thread-messages-response.js.map