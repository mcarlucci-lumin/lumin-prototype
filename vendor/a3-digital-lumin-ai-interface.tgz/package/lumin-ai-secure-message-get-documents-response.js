export class LuminAiSecureMessageGetDocumentsResponse {
    constructor() {
        this.documents = [];
    }
}
//# sourceMappingURL=lumin-ai-secure-message-get-documents-response.js.map