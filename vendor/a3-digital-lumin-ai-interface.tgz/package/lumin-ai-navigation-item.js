export class LuminAiAssistantNavigationItem {
}
//# sourceMappingURL=lumin-ai-navigation-item.js.map