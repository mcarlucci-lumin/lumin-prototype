import { LuminAiResultCode } from './lumin-ai-result-code.js';
export declare class LuminAiBaseResponse {
    resultCode: LuminAiResultCode;
}
