export var EmbeddingProvider;
(function (EmbeddingProvider) {
    EmbeddingProvider["OPEN_AI"] = "OPEN_AI";
    EmbeddingProvider["BEDROCK"] = "BEDROCK";
    EmbeddingProvider["PINECONE"] = "PINECONE";
    EmbeddingProvider["TEST"] = "TEST";
})(EmbeddingProvider || (EmbeddingProvider = {}));
//# sourceMappingURL=embedding-provider.js.map