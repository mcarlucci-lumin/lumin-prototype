export class CompletionResult {
}
//# sourceMappingURL=completion-result.js.map