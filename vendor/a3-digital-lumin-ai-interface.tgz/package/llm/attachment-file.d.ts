export declare enum FileType {
    ACH = ".ach",
    CSV = "text/csv",
    DOC = "application/doc",
    GIF = "image/gif",
    JPG = "image/jpg",
    TFF = "image/tiff",
    JSON = "application/json",
    PDF = "application/pdf",
    PNG = "image/png",
    SVG = "image/svg+xml",
    TXT = "text/plain",
    OTF = "font/otf",
    TTF = "font/ttf",
    WOFF = "font/woff",
    XLS = "application/xls",
    ICO = "image/x-icon"
}
export declare enum FileEncodingType {
    BASE64 = "base64",
    TEXT = "text"
}
export declare class AttachmentFile {
    name: string;
    contents: string;
    encoding?: FileEncodingType;
    size?: number;
    type?: FileType;
}
