export interface SecureMessageAgentSessionInput {
    threadId: string;
    memberId: string;
}
