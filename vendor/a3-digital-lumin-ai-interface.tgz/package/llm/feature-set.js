export var FeatureSet;
(function (FeatureSet) {
    FeatureSet["UNKNOWN"] = "UNKNOWN";
    FeatureSet["AGENT_CHAT"] = "AGENT_CHAT";
    FeatureSet["CMS_MSG_REFINEMENT"] = "CMS_MSG_REFINEMENT";
    FeatureSet["SECURE_MESSAGING"] = "SECURE_MESSAGING";
    FeatureSet["SECURE_FORMS"] = "SECURE_FORMS";
    FeatureSet["USER_SEG_GENERATE_RULES"] = "USER_SEG_GENERATE_RULES";
    FeatureSet["USER_STRUGGLE"] = "USER_STRUGGLE";
    FeatureSet["NAVIGATION_SEARCH"] = "NAVIGATION_SEARCH";
    FeatureSet["KNOWLEDGE_DOCUMENTATION"] = "KNOWLEDGE_DOCUMENTATION";
})(FeatureSet || (FeatureSet = {}));
//# sourceMappingURL=feature-set.js.map