import { CompletionResultInfo } from './completion-result-info.js';
import { CompletionResultUsage } from './completion-result-usage.js';
export declare class CompletionResult {
    usage: CompletionResultUsage;
    info: CompletionResultInfo;
    result: string | any;
}
