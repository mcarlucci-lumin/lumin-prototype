export var FileType;
(function (FileType) {
    FileType["ACH"] = ".ach";
    FileType["CSV"] = "text/csv";
    FileType["DOC"] = "application/doc";
    FileType["GIF"] = "image/gif";
    FileType["JPG"] = "image/jpg";
    FileType["TFF"] = "image/tiff";
    FileType["JSON"] = "application/json";
    FileType["PDF"] = "application/pdf";
    FileType["PNG"] = "image/png";
    FileType["SVG"] = "image/svg+xml";
    FileType["TXT"] = "text/plain";
    FileType["OTF"] = "font/otf";
    FileType["TTF"] = "font/ttf";
    FileType["WOFF"] = "font/woff";
    FileType["XLS"] = "application/xls";
    FileType["ICO"] = "image/x-icon";
})(FileType || (FileType = {}));
export var FileEncodingType;
(function (FileEncodingType) {
    FileEncodingType["BASE64"] = "base64";
    FileEncodingType["TEXT"] = "text";
})(FileEncodingType || (FileEncodingType = {}));
export class AttachmentFile {
}
//# sourceMappingURL=attachment-file.js.map