export declare class CompletionResultUsage {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
}
