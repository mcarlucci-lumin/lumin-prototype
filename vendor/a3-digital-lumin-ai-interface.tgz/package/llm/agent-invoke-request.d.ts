import { AgentMessageRequest } from './agent-message-request.js';
export interface AgentInvokeRequest extends AgentMessageRequest {
    userId: string;
    sessionId: string;
}
