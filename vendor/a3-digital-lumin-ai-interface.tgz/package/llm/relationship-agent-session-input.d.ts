export interface RelationshipAgentSessionInput {
    memberId: string;
}
