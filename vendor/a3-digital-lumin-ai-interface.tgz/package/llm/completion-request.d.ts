import { AttachmentFile } from './attachment-file.js';
import { FeatureSet } from './feature-set.js';
import { ProviderConfig } from './llm-provider-config.js';
import { LuminAiFeature } from './lumin-ai-feature.js';
export interface CompletionRequest {
    systemContext: string;
    prompt: string;
    config: ProviderConfig;
    fallbackProviderList?: ProviderConfig[];
    file?: AttachmentFile;
    featureName?: LuminAiFeature;
    featureSet?: FeatureSet;
}
