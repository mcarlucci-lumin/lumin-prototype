export interface ResponseAgentSessionInput {
    chatId: string;
    memberId: string;
}
