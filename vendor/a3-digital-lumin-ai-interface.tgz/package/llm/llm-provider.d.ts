export declare enum LLMProvider {
    OPEN_AI = "OPEN_AI",
    ANTHROPIC = "ANTHROPIC",
    BEDROCK = "BEDROCK",
    TEST = "TEST"
}
