export interface AgentMessageRequest {
    message: string;
    timestamp?: Date;
    sessionInput?: Record<string, unknown>;
}
