import { AttachmentFile } from './attachment-file.js';
import { FeatureSet } from './feature-set.js';
import { LuminAiFeature } from './lumin-ai-feature.js';
export interface FeatureAIRequest {
    feature: LuminAiFeature;
    promptData?: Record<string, any>;
    systemContextData?: Record<string, any>;
    file?: AttachmentFile;
    featureSet?: FeatureSet;
}
