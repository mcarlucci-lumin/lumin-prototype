export class CompletionResultInfo {
}
//# sourceMappingURL=completion-result-info.js.map