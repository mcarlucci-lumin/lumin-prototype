import { JsonSchema } from 'json-schema-to-zod';
import { CompletionRequest } from './completion-request.js';
export type StructuredCompletionRequest = CompletionRequest & {
    schema: JsonSchema;
};
