export var LLMProvider;
(function (LLMProvider) {
    LLMProvider["OPEN_AI"] = "OPEN_AI";
    LLMProvider["ANTHROPIC"] = "ANTHROPIC";
    LLMProvider["BEDROCK"] = "BEDROCK";
    LLMProvider["TEST"] = "TEST";
})(LLMProvider || (LLMProvider = {}));
//# sourceMappingURL=llm-provider.js.map