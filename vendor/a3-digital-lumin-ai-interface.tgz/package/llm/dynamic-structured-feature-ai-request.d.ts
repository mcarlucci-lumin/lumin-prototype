import { JsonSchema } from 'json-schema-to-zod';
import { FeatureAIRequest } from './feature-ai-request.js';
/**
 * Feature request for structured-output features whose output schema is built at runtime
 * (rather than defined statically on the prompt class via payloadStructure). Used when the
 * schema depends on per-request data.
 */
export interface DynamicStructuredFeatureAIRequest extends FeatureAIRequest {
    schema: JsonSchema;
}
