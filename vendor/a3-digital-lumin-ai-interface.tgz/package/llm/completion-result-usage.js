export class CompletionResultUsage {
}
//# sourceMappingURL=completion-result-usage.js.map