export class LuminAiSecureMessageAddDocumentRequest {
}
//# sourceMappingURL=lumin-ai-secure-message-add-document-request.js.map