import { LuminAiBaseResponse } from './lumin-ai-base-response.js';
import { Thread } from './thread.js';
export declare class LuminAiCreateThreadResponse extends LuminAiBaseResponse {
    thread: Thread;
}
