import { FeatureSetConfigItem } from './feature-set-config-item.js';
export declare class FeatureCatalogResponse {
    endUserFeatureSets: FeatureSetConfigItem[];
    adminFeatureSets: FeatureSetConfigItem[];
    /** 'HH:mm' in `timeZone`; when every end user's daily credit unit usage resets. */
    dailyResetTime: string;
    timeZone: string;
    /** The FI-wide per-user daily credit unit cap on END_USER feature sets; null is unlimited. */
    endUserDailyCreditUnitCap: number | null;
    /** Display-only price per credit unit, in dollars; what the admin is told a credit unit costs. */
    creditUnitPrice: number;
}
