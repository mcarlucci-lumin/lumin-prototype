import { FeatureSetConfigItem } from './feature-set-config-item.js';
export declare class FeatureCatalogResponse {
    endUserFeatureSets: FeatureSetConfigItem[];
    adminFeatureSets: FeatureSetConfigItem[];
}
