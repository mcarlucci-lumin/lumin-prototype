import { FeatureSetConfigItem } from './feature-set-config-item.js';
export declare class FeatureCatalogResponse {
    endUserFeatureSets: FeatureSetConfigItem[];
    adminFeatureSets: FeatureSetConfigItem[];
    /** 'HH:mm' in `timeZone`; when every end user's daily credit unit usage resets. */
    dailyResetTime: string;
    timeZone: string;
}
