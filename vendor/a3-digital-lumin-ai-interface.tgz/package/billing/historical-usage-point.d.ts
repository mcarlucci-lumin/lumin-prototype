export declare class HistoricalUsagePoint {
    month: string;
    totalCredits: number;
}
