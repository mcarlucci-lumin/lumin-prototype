import { FeatureSet } from '../llm/feature-set.js';
export declare class CurrentUsageItem {
    featureSet: FeatureSet;
    creditsUsedThisCycle: number;
    quota: number | null;
    quotaMonth: Date;
    lastEdited: Date;
    groupQuota: number | null;
}
