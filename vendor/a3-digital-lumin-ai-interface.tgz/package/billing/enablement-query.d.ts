export declare class EnablementQuery {
    /** The end user asking; required by billing for END_USER-audience feature sets. */
    userId?: string;
}
