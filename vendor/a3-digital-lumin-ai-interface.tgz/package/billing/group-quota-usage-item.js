export class GroupQuotaUsageItem {
}
//# sourceMappingURL=group-quota-usage-item.js.map