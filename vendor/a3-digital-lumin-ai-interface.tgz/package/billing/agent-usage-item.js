export class AgentUsageItem {
}
//# sourceMappingURL=agent-usage-item.js.map