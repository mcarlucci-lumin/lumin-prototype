import { FeatureSet } from '../llm/feature-set.js';
export declare class AdminFeatureConfigUpdate {
    featureSet: FeatureSet;
    enabled: boolean;
    quota: number | null;
}
