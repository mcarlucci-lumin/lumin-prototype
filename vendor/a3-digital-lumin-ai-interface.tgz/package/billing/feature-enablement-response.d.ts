import { FeatureSet } from '../llm/feature-set.js';
/**
 * Whether a feature set may be used right now. `enabled` is the AND of Lumin's global availability
 * config for the feature set and the FI admin's own enablement toggle, so a caller can gate on this
 * single boolean without knowing which of the two switches is off.
 *
 * The endpoint fails closed: an unrecognized or unavailable feature set answers
 * `{ featureSet: FeatureSet.UNKNOWN, enabled: false }` rather than erroring.
 */
export declare class FeatureEnablementResponse {
    featureSet: FeatureSet;
    enabled: boolean;
}
