import { FeatureSet } from '../llm/feature-set.js';
import { EnablementReason } from './enablement-reason.js';
/**
 * Whether a feature set may be used right now. `enabled` is the AND of Lumin's global availability
 * config for the feature set and the FI admin's own enablement toggle, and remains the only field a
 * caller needs to gate on; `reason` is advisory, for callers that want to explain the `false`.
 *
 * The endpoint fails closed: an unrecognized or unavailable feature set answers
 * `{ featureSet: FeatureSet.UNKNOWN, enabled: false }` rather than erroring.
 */
export declare class FeatureEnablementResponse {
    featureSet: FeatureSet;
    enabled: boolean;
    /** Present only when enabled is false. Absent for FeatureSet.UNKNOWN - that's a caller/version-skew bug, not a "why". */
    reason?: EnablementReason;
}
