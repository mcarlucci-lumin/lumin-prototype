export class CreateGroupQuotaRequest {
}
//# sourceMappingURL=create-group-quota-request.js.map