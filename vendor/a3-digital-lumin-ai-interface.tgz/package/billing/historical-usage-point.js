export class HistoricalUsagePoint {
}
//# sourceMappingURL=historical-usage-point.js.map