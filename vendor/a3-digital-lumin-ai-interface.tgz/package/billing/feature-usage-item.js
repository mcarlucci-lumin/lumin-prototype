export class FeatureUsageItem {
}
//# sourceMappingURL=feature-usage-item.js.map