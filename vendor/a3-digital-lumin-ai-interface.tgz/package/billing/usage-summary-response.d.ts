import { HistoricalUsagePoint } from './historical-usage-point.js';
import { AgentUsageItem } from './agent-usage-item.js';
import { FeatureUsageItem } from './feature-usage-item.js';
export declare class UsageSummaryResponse {
    totalCreditsThisMonth: number;
    percentChangeFromLastCycle: number | null;
    endOfMonthProjection: number;
    remainingBillingCycleDays: number;
    historicalMonthlyTotals: HistoricalUsagePoint[];
    usageByAgent: AgentUsageItem[];
    featureUsage: FeatureUsageItem[];
}
