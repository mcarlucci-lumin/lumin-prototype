import { HistoricalUsagePoint } from './historical-usage-point.js';
import { AgentUsageItem } from './agent-usage-item.js';
import { FeatureSetUsageItem } from './feature-set-usage-item.js';
export declare class UsageSummaryResponse {
    totalCreditsThisMonth: number;
    /**
     * Sum of the quotas of every enabled feature set, in credits. Null when any enabled feature set is unlimited.
     */
    creditLimit: number | null;
    percentChangeFromLastCycle: number | null;
    endOfMonthProjection: number;
    remainingBillingCycleDays: number;
    historicalMonthlyTotals: HistoricalUsagePoint[];
    usageByAgent: AgentUsageItem[];
    featureSetUsage: FeatureSetUsageItem[];
}
