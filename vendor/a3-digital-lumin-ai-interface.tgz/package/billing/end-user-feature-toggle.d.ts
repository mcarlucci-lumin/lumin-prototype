import { FeatureSet } from '../llm/feature-set.js';
export declare class EndUserFeatureToggle {
    featureSet: FeatureSet;
    enabled: boolean;
}
