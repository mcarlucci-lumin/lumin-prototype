import { FeatureSet } from '../llm/feature-set.js';
export declare class UpdateGroupQuotaRequest {
    featureSets?: FeatureSet[];
    quota?: number;
}
