export class UpdateGroupQuotaRequest {
}
//# sourceMappingURL=update-group-quota-request.js.map