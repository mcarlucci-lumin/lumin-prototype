import { FeatureSet } from '../llm/feature-set.js';
export declare class GroupQuotaUsageItem {
    featureSet: FeatureSet;
    currentUsage: number;
}
