export class UsageSummaryResponse {
}
//# sourceMappingURL=usage-summary-response.js.map