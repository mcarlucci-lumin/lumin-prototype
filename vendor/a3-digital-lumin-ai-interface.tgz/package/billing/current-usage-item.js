export class CurrentUsageItem {
}
//# sourceMappingURL=current-usage-item.js.map