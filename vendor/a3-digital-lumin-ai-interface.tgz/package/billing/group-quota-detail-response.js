export class GroupQuotaDetailResponse {
}
//# sourceMappingURL=group-quota-detail-response.js.map