import { FeatureAudience } from './feature-audience.js';
import { EndUserFeatureToggle } from './end-user-feature-toggle.js';
export declare class UpdateEndUserFeaturesRequest {
    audience: FeatureAudience.END_USER;
    featureSets: EndUserFeatureToggle[];
    dailyCreditUnitCap: number | null;
}
