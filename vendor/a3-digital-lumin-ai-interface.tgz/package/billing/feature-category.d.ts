export declare enum FeatureCategory {
    ASSISTANTS = "ASSISTANTS",
    AGENTS = "AGENTS"
}
