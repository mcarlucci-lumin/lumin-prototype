export declare enum FeatureCategory {
    ASSISTANTS = "ASSISTANTS",
    AGENTS = "AGENTS",
    KNOWLEDGE_BASE = "KNOWLEDGE_BASE"
}
