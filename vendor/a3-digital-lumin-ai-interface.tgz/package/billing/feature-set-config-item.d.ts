import { FeatureSet } from '../llm/feature-set.js';
import { FeatureCategory } from './feature-category.js';
export declare class FeatureSetConfigItem {
    featureSet: FeatureSet;
    displayName: string;
    category: FeatureCategory;
    description: string;
    creditUnitUsageEstimate: string;
    enabled: boolean;
    /**
     * A null quota indicates Unlimited
     */
    quota: number | null;
}
