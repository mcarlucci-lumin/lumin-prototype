import { FeatureSet } from '../llm/feature-set.js';
import { FeatureCategory } from './feature-category.js';
import { FeatureAudience } from './feature-audience.js';
export declare class FeatureSetConfigItem {
    featureSet: FeatureSet;
    displayName: string;
    category: FeatureCategory;
    audience: FeatureAudience;
    description: string;
    creditUnitUsageEstimate: string;
    enabled: boolean;
    /**
     * A null quota indicates Unlimited
     */
    quota: number | null;
}
