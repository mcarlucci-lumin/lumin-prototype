import { FeatureSet } from '../llm/feature-set.js';
export declare class FeatureSetUsageItem {
    featureSet: FeatureSet;
    creditsUsedThisCycle: number;
}
