/**
 * Why a feature set's enablement resolved the way it did. Only ever set alongside `enabled: false`
 * today; the optionality, not the type, is what carries that. See FeatureEnablementResponse.reason.
 */
export declare enum EnablementReason {
    NOT_AVAILABLE = "NOT_AVAILABLE",
    NOT_ENABLED_BY_ADMIN = "NOT_ENABLED_BY_ADMIN",
    INSUFFICIENT_QUOTA = "INSUFFICIENT_QUOTA"
}
