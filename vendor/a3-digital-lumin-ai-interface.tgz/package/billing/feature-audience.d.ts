export declare enum FeatureAudience {
    END_USER = "END_USER",
    ADMIN = "ADMIN"
}
