import { FeatureAudience } from './feature-audience.js';
import { AdminFeatureConfigUpdate } from './admin-feature-config-update.js';
export declare class UpdateAdminFeaturesRequest {
    audience: FeatureAudience.ADMIN;
    featureSets: AdminFeatureConfigUpdate[];
}
