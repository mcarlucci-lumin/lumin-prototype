import { LuminAiFeature } from '../llm/lumin-ai-feature.js';
export declare class FeatureUsageItem {
    feature: LuminAiFeature;
    creditsUsedThisCycle: number;
}
