export declare class UpdateFeatureConfigRequest {
    enabled: boolean;
    quota: number | null;
}
