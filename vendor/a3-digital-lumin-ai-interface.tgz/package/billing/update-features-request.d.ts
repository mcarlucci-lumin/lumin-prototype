import { UpdateEndUserFeaturesRequest } from './update-end-user-features-request.js';
import { UpdateAdminFeaturesRequest } from './update-admin-features-request.js';
export type UpdateFeaturesRequest = UpdateEndUserFeaturesRequest | UpdateAdminFeaturesRequest;
