import { Button } from './button.js';
export declare class AiChatCompletionResponse {
    reply: string;
    escalate: boolean;
    buttons?: Button[];
}
