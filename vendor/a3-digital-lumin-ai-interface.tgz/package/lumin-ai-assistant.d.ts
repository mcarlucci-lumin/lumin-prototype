import { LuminAiAssistantType } from './lumin-ai-assistant-type.js';
import { LuminAiAssistantNavigationItem } from './lumin-ai-navigation-item.js';
export declare class LuminAiAssistant {
    id: string;
    name: string;
    assistantType: LuminAiAssistantType;
    navigation: LuminAiAssistantNavigationItem[];
}
