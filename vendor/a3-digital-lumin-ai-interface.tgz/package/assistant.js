export class Assistant {
    constructor(id, createdAt, description, instructions, metadata, model, name, object, tools, responseFormat, temperature, toolResources) {
        this.id = id;
        this.createdAt = createdAt;
        this.description = description;
        this.instructions = instructions;
        this.metadata = metadata;
        this.model = model;
        this.name = name;
        this.object = object;
        this.tools = tools;
        this.responseFormat = responseFormat;
        this.temperature = temperature;
        this.toolResources = toolResources;
    }
}
//# sourceMappingURL=assistant.js.map