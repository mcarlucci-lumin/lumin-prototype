import { KnowledgeBaseDocument } from './knowledge-base-document.js';
export declare class LuminAiSecureMessageAddDocumentRequest {
    document: KnowledgeBaseDocument;
}
