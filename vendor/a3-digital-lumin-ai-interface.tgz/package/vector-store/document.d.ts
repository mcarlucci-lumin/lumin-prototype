export declare class Document {
    id: string;
    content: string;
    metadata: Record<string, string | number | boolean | string[]>;
    constructor(id: string, content: string, metadata?: Record<string, string | number | boolean | string[]>);
}
