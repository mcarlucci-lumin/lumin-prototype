export class Document {
    constructor(id, content, metadata = {}) {
        this.id = id;
        this.content = content;
        this.metadata = metadata;
    }
}
//# sourceMappingURL=document.js.map