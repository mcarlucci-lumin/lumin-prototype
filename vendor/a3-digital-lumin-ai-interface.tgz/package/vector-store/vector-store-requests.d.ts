import { Document } from './document.js';
export interface UpsertRecordsRequest {
    records: Document[];
    namespace?: string;
}
export interface DeleteRecordsRequest {
    ids: string[];
    namespace?: string;
}
export interface SemanticSearchRequest {
    query: string;
    topK: number;
    filter?: Record<string, any>;
    namespace?: string;
}
export interface HybridSearchRequest extends SemanticSearchRequest {
    alpha: number;
}
export interface FetchIdsQuery {
    pageSize?: number;
    namespace?: string;
}
