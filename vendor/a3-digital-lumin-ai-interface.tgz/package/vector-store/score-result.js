export class ScoreResult {
}
//# sourceMappingURL=score-result.js.map