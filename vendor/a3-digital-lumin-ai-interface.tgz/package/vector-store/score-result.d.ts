export declare class ScoreResult<T> {
    result: T;
    score: number;
}
