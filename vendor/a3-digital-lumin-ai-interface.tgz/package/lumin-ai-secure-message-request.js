// depending on the work, these may move to their own shared interfaces
export class LuminAiSecureMessageRequest {
}
//# sourceMappingURL=lumin-ai-secure-message-request.js.map