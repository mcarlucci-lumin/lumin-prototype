import { LuminAiBaseResponse } from './lumin-ai-base-response.js';
export declare class LuminAiSendMessageResponse extends LuminAiBaseResponse {
    messages: string[];
    sessionId: string;
}
