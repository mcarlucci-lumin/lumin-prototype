export class LuminAiBaseResponse {
}
//# sourceMappingURL=lumin-ai-base-response.js.map