export var LuminAiWebSocketEventType;
(function (LuminAiWebSocketEventType) {
    LuminAiWebSocketEventType["LUMIN_INTELLIGENT_ASSIST_MESSAGE_DELTA_EVENT"] = "LUMIN_INTELLIGENT_ASSIST_MESSAGE_DELTA_EVENT";
})(LuminAiWebSocketEventType || (LuminAiWebSocketEventType = {}));
//# sourceMappingURL=lumin-ai-web-socket-event-type.js.map