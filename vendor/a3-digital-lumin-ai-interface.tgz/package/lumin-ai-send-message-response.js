import { LuminAiBaseResponse } from './lumin-ai-base-response.js';
export class LuminAiSendMessageResponse extends LuminAiBaseResponse {
}
//# sourceMappingURL=lumin-ai-send-message-response.js.map