export class Thread {
    constructor(id, createdAt, metadata, object, toolResources) {
        this.id = id;
        this.createdAt = createdAt;
        this.metadata = metadata;
        this.object = object;
        this.toolResources = toolResources;
    }
}
//# sourceMappingURL=thread.js.map