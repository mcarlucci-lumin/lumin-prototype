import { LuminAiBaseResponse } from './lumin-ai-base-response.js';
export class LuminAiCreateThreadResponse extends LuminAiBaseResponse {
}
//# sourceMappingURL=lumin-ai-create-thread-response.js.map