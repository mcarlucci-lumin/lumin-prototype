import { LuminAiBaseResponse } from './lumin-ai-base-response.js';
export class LuminAiGetAssistantResponse extends LuminAiBaseResponse {
}
//# sourceMappingURL=lumin-ai-get-assistant-response.js.map