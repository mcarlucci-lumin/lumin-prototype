export declare enum LuminAiAssistantType {
    SEARCH = "SEARCH",
    SUGGESTION = "SUGGESTION",
    REVIEW = "REVIEW",
    SUMMARY = "SUMMARY",
    MISC = "MISC"
}
