export declare class ValidationResult {
    valid: boolean;
    message?: string;
    validData?: any;
}
