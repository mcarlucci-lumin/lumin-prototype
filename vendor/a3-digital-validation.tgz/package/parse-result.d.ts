export interface ParseResult<T> {
    valid: boolean;
    data?: T;
    errMsg?: string;
}
