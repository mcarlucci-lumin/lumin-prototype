export class ValidationResult {
    constructor() {
        this.valid = false;
    }
}
//# sourceMappingURL=validation-results.js.map