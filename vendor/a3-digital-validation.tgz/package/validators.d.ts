import { ValidationResult } from './validation-results.js';
export declare function compose(...validators: Array<(value: any) => ValidationResult>): (value: any) => ValidationResult;
export declare function optional(validator: (value: any) => ValidationResult): (value: any) => ValidationResult;
export declare function combineResults(...results: Array<{
    key: string;
    result: ValidationResult;
}>): ValidationResult;
export declare function required(value: any): ValidationResult;
export declare function anything(value: any): ValidationResult;
export declare function isString(value: any): ValidationResult;
export declare function isNumber(value: any): ValidationResult;
export declare function isBoolean(value: any): ValidationResult;
export declare function isDate(value: any): ValidationResult;
export declare function isArray(typeValidator?: (value: any) => ValidationResult): (value: any) => ValidationResult;
export declare function minLength(length: number): (value: any) => ValidationResult;
export declare function maxLength(length: number): (value: any) => ValidationResult;
export declare function maxNumericChars(max: number): (value: any) => ValidationResult;
export declare function validStateCode(value: any): ValidationResult;
export declare function validCity(value: any): ValidationResult;
export declare function validZipCode(value: any): ValidationResult;
export declare function matchesRegEx(regEx: RegExp, failMessage: string): (value: any) => ValidationResult;
export declare function noRegExMatch(regEx: RegExp, failMessage: string): (value: any) => ValidationResult;
export declare function expression(exp: (x: any) => boolean, failMessage?: string): (value: any) => ValidationResult;
export declare function openCloseCharMatch(openChar: string, closeChar: string): (value: any) => ValidationResult;
export declare function validPhone(value: any): ValidationResult;
export declare function validDomesticPhone(value: any): ValidationResult;
export declare function validDomesticOrInternationalPhone(value: any): ValidationResult;
export declare function validEmail(value: any): ValidationResult;
export declare const PO_BOX_REGEX: RegExp;
/**
 * Matches only values that contain no PO Box. Use with Angular's `Validators.pattern`,
 * which treats a match as valid; use `notPOBox` for server-side validation instead.
 */
export declare const NOT_PO_BOX_REGEX: RegExp;
/** Passes when the value holds no PO Box. Empty, null, undefined and non-string values pass. */
export declare function notPOBox(value: any): ValidationResult;
export declare const URL_REGEX: RegExp;
export declare function validUrl(value: string): ValidationResult;
export declare const FQDN_REGEX: RegExp;
export declare function validFqdn(value: any): ValidationResult;
export declare const TICKET_REGEX: RegExp;
export declare function validTicket(value: any): ValidationResult;
export declare const BASE64_REGEX: RegExp;
export declare function validBase64(value: any): ValidationResult;
export declare const VAULT_KEY_REGEX: RegExp;
export declare function validVaultKey(value: any): ValidationResult;
export declare function allDigits(value: any): ValidationResult;
export declare function validDateString(value: any): ValidationResult;
export declare function validTimeOfDay(value: any): ValidationResult;
export declare function validMonthYear(value: any): ValidationResult;
export declare function oneOf(values: Array<any>, failMessage?: string): (value: any) => ValidationResult;
export declare function validEnumValue(enumType: any): (value: any) => ValidationResult;
export declare function atLeastOneIsValid(values: Array<any>, validator: (value: any) => ValidationResult, errMessage: string): ValidationResult;
export declare function matchesAllRegEx(values: RegExp[]): (value: any) => ValidationResult;
export declare function positiveAmount(value: any): ValidationResult;
export declare function nonNegativeAmount(value: any): ValidationResult;
export declare function validAchAccountNumber(value: any): ValidationResult;
export declare function validAchRoutingNumber(value: any): ValidationResult;
export declare function validCardNumber(value: any): ValidationResult;
export declare function validCardCode(value: any): ValidationResult;
export declare function atLeastOneLetter(value: string): ValidationResult;
export declare function atLeastOneNumber(value: string): ValidationResult;
export declare function atLeastOneUppercase(value: string): ValidationResult;
export declare function atLeastOneLowercase(value: string): ValidationResult;
export declare function noWhiteSpace(value: string): ValidationResult;
export declare function firstCharIsLetter(value: string): ValidationResult;
export declare function firstCharIsNumber(value: string): ValidationResult;
export declare function alphanumeric(value: string): ValidationResult;
export declare function asciiOnly(value: any): ValidationResult;
export declare function validJson(value: string): ValidationResult;
export declare function validJsonFiles(values: {
    contents: string;
}[]): ValidationResult;
export declare function validCertificateOrKey(standard: string): (value: any) => ValidationResult;
