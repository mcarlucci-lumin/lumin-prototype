import { firstCharIsNumber } from '../validators.js';
import { BaseCriteria } from './base-criteria.js';
import { CriteriaName } from './criteria-name.js';
export class StartWithNumber extends BaseCriteria {
    constructor(config) {
        super(CriteriaName.START_WITH_NUMBER, config);
    }
    validateCriteria(input) {
        const result = firstCharIsNumber(input);
        return result.valid;
    }
}
//# sourceMappingURL=start-with-number.js.map