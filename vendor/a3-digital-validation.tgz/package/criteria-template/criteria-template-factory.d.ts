import { BaseCriteria } from './base-criteria.js';
import { CriteriaConfig } from './criteria-config.js';
import { CriteriaName } from './criteria-name.js';
export declare class CriteriaTemplateFactory {
    static parseConfig(config: Record<CriteriaName, CriteriaConfig>): BaseCriteria[];
    private static generateCriteriaTemplate;
    static validateAllCriteria(criteria: BaseCriteria[], input: string): boolean;
}
