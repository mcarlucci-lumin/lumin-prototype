import { BaseCriteria } from './base-criteria.js';
import { CriteriaName } from './criteria-name.js';
import { atLeastOneLetter } from '../validators.js';
export class AtLeastOneLetter extends BaseCriteria {
    constructor(config) {
        super(CriteriaName.AT_LEAST_ONE_LETTER, config);
    }
    validateCriteria(input) {
        const result = atLeastOneLetter(input);
        return result.valid;
    }
}
//# sourceMappingURL=at-least-one-letter.js.map