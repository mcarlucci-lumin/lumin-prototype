import { StringUtils } from '@a3-digital/utils';
import { compose, isString, noRegExMatch } from '../validators.js';
import { BaseCriteria } from './base-criteria.js';
import { CriteriaName } from './criteria-name.js';
export class NotContainSpecialChars extends BaseCriteria {
    constructor(config) {
        super(CriteriaName.NOT_CONTAIN_SPECIAL_CHARS, config);
        if (!config.chars) {
            throw Error('Invalid NotContainSpecialChars config missing chars property');
        }
        this.chars = config.chars;
        this.regex = new RegExp(`(?=.*[${StringUtils.escapeRegExp(this.chars)}])`);
    }
    validateCriteria(input) {
        const result = compose(isString, noRegExMatch(this.regex, `Special chars ${this.chars} found`))(input);
        return result.valid;
    }
    generateTextParams() {
        return {
            chars: this.chars
        };
    }
}
//# sourceMappingURL=not-contain-special-chars.js.map