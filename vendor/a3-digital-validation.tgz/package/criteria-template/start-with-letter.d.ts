import { BaseCriteria } from './base-criteria.js';
import { CriteriaConfig } from './criteria-config.js';
export declare class StartWithLetter extends BaseCriteria {
    constructor(config: CriteriaConfig);
    protected validateCriteria(input: string): boolean;
}
