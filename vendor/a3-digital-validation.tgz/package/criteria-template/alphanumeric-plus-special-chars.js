import { StringUtils } from '@a3-digital/utils';
import { compose, isString, matchesRegEx } from '../validators.js';
import { BaseCriteria } from './base-criteria.js';
import { CriteriaName } from './criteria-name.js';
export class AlphanumericPlusSpecialChars extends BaseCriteria {
    constructor(config) {
        super(CriteriaName.ALPHANUMERIC_PLUS_SPECIAL_CHARS, config);
        this.chars = config.chars;
        this.regex = new RegExp(`^[a-zA-Z0-9${StringUtils.escapeRegExp(this.chars)}]*$`);
    }
    validateCriteria(input) {
        const result = compose(isString, matchesRegEx(this.regex, ''))(input);
        return result.valid;
    }
    generateTextParams() {
        return {
            chars: this.chars
        };
    }
}
//# sourceMappingURL=alphanumeric-plus-special-chars.js.map