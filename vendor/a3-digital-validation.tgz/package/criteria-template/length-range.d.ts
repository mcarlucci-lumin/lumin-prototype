import { BaseCriteria } from './base-criteria.js';
import { CriteriaConfig } from './criteria-config.js';
export declare class LengthRange extends BaseCriteria {
    min: number;
    max: number;
    constructor(config: CriteriaConfig);
    validateCriteria(input: string): boolean;
    generateTextParams(): any;
}
