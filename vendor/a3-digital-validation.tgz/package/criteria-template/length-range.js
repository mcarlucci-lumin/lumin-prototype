import { compose, isString, maxLength, minLength } from '../validators.js';
import { BaseCriteria } from './base-criteria.js';
import { CriteriaName } from './criteria-name.js';
export class LengthRange extends BaseCriteria {
    constructor(config) {
        super(CriteriaName.LENGTH_RANGE, config);
        if (!config.max) {
            throw Error('Invalid LengthRange config missing max field');
        }
        if (!config.min) {
            throw Error('Invalid LengthRange config missing min field');
        }
        this.min = Number(config.min);
        this.max = Number(config.max);
    }
    validateCriteria(input) {
        const result = compose(isString, minLength(this.min), maxLength(this.max))(input);
        return result.valid;
    }
    generateTextParams() {
        return {
            min: this.min,
            max: this.max
        };
    }
}
//# sourceMappingURL=length-range.js.map