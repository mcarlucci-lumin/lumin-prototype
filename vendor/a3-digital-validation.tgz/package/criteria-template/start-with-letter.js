import { firstCharIsLetter } from '../validators.js';
import { BaseCriteria } from './base-criteria.js';
import { CriteriaName } from './criteria-name.js';
export class StartWithLetter extends BaseCriteria {
    constructor(config) {
        super(CriteriaName.START_WITH_LETTER, config);
    }
    validateCriteria(input) {
        const result = firstCharIsLetter(input);
        return result.valid;
    }
}
//# sourceMappingURL=start-with-letter.js.map