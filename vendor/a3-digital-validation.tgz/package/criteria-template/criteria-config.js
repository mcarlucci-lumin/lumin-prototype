export {};
//# sourceMappingURL=criteria-config.js.map