import { compose, isString, maxNumericChars } from '../validators.js';
import { BaseCriteria } from './base-criteria.js';
import { CriteriaName } from './criteria-name.js';
export class MaxNumericChars extends BaseCriteria {
    constructor(config) {
        super(CriteriaName.MAX_NUMERIC_CHARS, config);
        if (!config.max) {
            throw Error('Invalid MaxNumericChars config missing max property');
        }
        this.max = Number(config.max);
    }
    validateCriteria(input) {
        const result = compose(isString, maxNumericChars(this.max))(input);
        return result.valid;
    }
    generateTextParams() {
        return {
            max: this.max
        };
    }
}
//# sourceMappingURL=max-numeric-chars.js.map