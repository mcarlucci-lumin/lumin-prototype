import { StringUtils } from '@a3-digital/utils';
import { compose, isString, matchesRegEx } from '../validators.js';
import { BaseCriteria } from './base-criteria.js';
import { CriteriaName } from './criteria-name.js';
export class AtLeastOneSpecialChar extends BaseCriteria {
    constructor(config) {
        super(CriteriaName.AT_LEAST_ONE_SPECIAL_CHAR, config);
        if (!config.chars) {
            throw Error('Invalid AtLeastOneSpecialChar config missing chars property');
        }
        this.chars = config.chars;
        this.regex = new RegExp(`(?=.*[${StringUtils.escapeRegExp(this.chars)}])`);
    }
    validateCriteria(input) {
        const result = compose(isString, matchesRegEx(this.regex, `Failed to match at least one of ${this.chars}`))(input);
        return result.valid;
    }
    generateTextParams() {
        return {
            chars: this.chars
        };
    }
}
//# sourceMappingURL=at-least-one-special-char.js.map