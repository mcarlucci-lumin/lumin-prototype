import { BaseCriteria } from './base-criteria.js';
import { CriteriaConfig } from './criteria-config.js';
export declare class AlphanumericPlusSpecialChars extends BaseCriteria {
    private regex;
    private chars;
    constructor(config: CriteriaConfig);
    protected validateCriteria(input: string): boolean;
    generateTextParams(): {
        chars: string;
    };
}
