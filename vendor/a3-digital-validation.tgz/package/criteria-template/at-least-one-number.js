import { BaseCriteria } from './base-criteria.js';
import { CriteriaName } from './criteria-name.js';
import { atLeastOneNumber } from '../validators.js';
export class AtLeastOneNumber extends BaseCriteria {
    constructor(config) {
        super(CriteriaName.AT_LEAST_ONE_NUMBER, config);
    }
    validateCriteria(input) {
        const result = atLeastOneNumber(input);
        return result.valid;
    }
}
//# sourceMappingURL=at-least-one-number.js.map