export var CriteriaName;
(function (CriteriaName) {
    CriteriaName["LENGTH_RANGE"] = "LENGTH_RANGE";
    CriteriaName["MIN_LENGTH"] = "MIN_LENGTH";
    CriteriaName["MAX_LENGTH"] = "MAX_LENGTH";
    CriteriaName["MAX_NUMERIC_CHARS"] = "MAX_NUMERIC_CHARS";
    CriteriaName["ALPHANUMERIC"] = "ALPHANUMERIC";
    CriteriaName["ALPHANUMERIC_PLUS_SPECIAL_CHARS"] = "ALPHANUMERIC_PLUS_SPECIAL_CHARS";
    CriteriaName["AT_LEAST_ONE_LETTER"] = "AT_LEAST_ONE_LETTER";
    CriteriaName["AT_LEAST_ONE_NUMBER"] = "AT_LEAST_ONE_NUMBER";
    CriteriaName["AT_LEAST_ONE_SPECIAL_CHAR"] = "AT_LEAST_ONE_SPECIAL_CHAR";
    CriteriaName["AT_LEAST_ONE_UPPERCASE"] = "AT_LEAST_ONE_UPPERCASE";
    CriteriaName["AT_LEAST_ONE_LOWERCASE"] = "AT_LEAST_ONE_LOWERCASE";
    CriteriaName["NO_WHITE_SPACE"] = "NO_WHITE_SPACE";
    CriteriaName["NOT_CONTAIN_SPECIAL_CHARS"] = "NOT_CONTAIN_SPECIAL_CHARS";
    CriteriaName["START_WITH_LETTER"] = "START_WITH_LETTER";
    CriteriaName["START_WITH_NUMBER"] = "START_WITH_NUMBER";
})(CriteriaName || (CriteriaName = {}));
//# sourceMappingURL=criteria-name.js.map