import { compose, isString, noWhiteSpace } from '../validators.js';
import { BaseCriteria } from './base-criteria.js';
import { CriteriaName } from './criteria-name.js';
export class NoWhiteSpace extends BaseCriteria {
    constructor(config) {
        super(CriteriaName.NO_WHITE_SPACE, config);
    }
    validateCriteria(input) {
        const result = compose(isString, noWhiteSpace)(input);
        return result.valid;
    }
}
//# sourceMappingURL=no-white-space.js.map