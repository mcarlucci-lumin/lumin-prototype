import { BaseCriteria } from './base-criteria.js';
import { CriteriaName } from './criteria-name.js';
import { CriteriaConfig } from './criteria-config.js';
type CriteriaConstructor = new (config: CriteriaConfig) => BaseCriteria;
export declare const CriteriaConstructors: Record<CriteriaName, CriteriaConstructor>;
export {};
