import { atLeastOneLowercase } from '../validators.js';
import { BaseCriteria } from './base-criteria.js';
import { CriteriaName } from './criteria-name.js';
export class AtLeastOneLowercase extends BaseCriteria {
    constructor(config) {
        super(CriteriaName.AT_LEAST_ONE_LOWERCASE, config);
    }
    validateCriteria(input) {
        const result = atLeastOneLowercase(input);
        return result.valid;
    }
}
//# sourceMappingURL=at-least-one-lowercase.js.map