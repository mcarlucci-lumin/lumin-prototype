import { ArrayUtils } from '@a3-digital/utils';
import { CriteriaConstructors } from './criteria-constructors.js';
import { CriteriaName } from './criteria-name.js';
export class CriteriaTemplateFactory {
    static parseConfig(config) {
        const criteria = [];
        for (let templateName of Object.values(CriteriaName)) {
            try {
                const templateConfig = config[templateName];
                if (templateConfig?.enabled) {
                    const parsedCriteria = this.generateCriteriaTemplate(templateName, templateConfig);
                    if (parsedCriteria) {
                        criteria.push(parsedCriteria);
                    }
                }
            }
            catch (err) {
            }
        }
        // Order was added after the original config, so only sort if there is a non-zero value
        if (criteria.some(c => c.order !== 0)) {
            return ArrayUtils.sortByField(criteria, 'order');
        }
        return criteria;
    }
    static generateCriteriaTemplate(name, config) {
        const ctor = CriteriaConstructors[name];
        if (!ctor) {
            return null;
        }
        return new ctor(config);
    }
    static validateAllCriteria(criteria, input) {
        if (!input) {
            return false;
        }
        for (let c of criteria || []) {
            const valid = c.validate(input);
            if (!valid) {
                return false;
            }
        }
        return true;
    }
}
//# sourceMappingURL=criteria-template-factory.js.map