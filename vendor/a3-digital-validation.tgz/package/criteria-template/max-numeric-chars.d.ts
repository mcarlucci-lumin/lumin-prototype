import { BaseCriteria } from './base-criteria.js';
import { CriteriaConfig } from './criteria-config.js';
export declare class MaxNumericChars extends BaseCriteria {
    private max;
    constructor(config: CriteriaConfig);
    protected validateCriteria(input: string): boolean;
    generateTextParams(): {
        max: number;
    };
}
