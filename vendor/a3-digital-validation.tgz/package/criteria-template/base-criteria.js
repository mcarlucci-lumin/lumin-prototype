export class BaseCriteria {
    constructor(criteriaName, config) {
        this.criteriaName = criteriaName;
        this.enabled = config?.enabled;
        this.order = config.order || 0;
    }
    validate(input) {
        if (!input) {
            return false;
        }
        return this.validateCriteria(input);
    }
    generateValidationFn() {
        // used to maintain "this" context of class
        return (input) => {
            return this.validate(input);
        };
    }
    generateTextParams() {
        return {};
    }
}
//# sourceMappingURL=base-criteria.js.map