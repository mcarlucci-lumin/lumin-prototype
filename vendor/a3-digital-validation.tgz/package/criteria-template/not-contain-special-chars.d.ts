import { BaseCriteria } from './base-criteria.js';
import { CriteriaConfig } from './criteria-config.js';
export declare class NotContainSpecialChars extends BaseCriteria {
    private chars;
    private regex;
    constructor(config: CriteriaConfig);
    protected validateCriteria(input: string): boolean;
    generateTextParams(): {
        chars: string;
    };
}
