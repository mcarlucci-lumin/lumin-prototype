import { atLeastOneUppercase } from '../validators.js';
import { BaseCriteria } from './base-criteria.js';
import { CriteriaName } from './criteria-name.js';
export class AtLeastOneUppercase extends BaseCriteria {
    constructor(config) {
        super(CriteriaName.AT_LEAST_ONE_UPPERCASE, config);
    }
    validateCriteria(input) {
        const result = atLeastOneUppercase(input);
        return result.valid;
    }
}
//# sourceMappingURL=at-least-one-uppercase.js.map