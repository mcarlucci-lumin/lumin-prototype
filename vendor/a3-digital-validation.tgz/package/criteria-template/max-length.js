import { compose, isString, maxLength } from '../validators.js';
import { BaseCriteria } from './base-criteria.js';
import { CriteriaName } from './criteria-name.js';
export class MaxLength extends BaseCriteria {
    constructor(config) {
        super(CriteriaName.MAX_LENGTH, config);
        if (!config.max) {
            throw Error('Invalid MaxLength config missing max property');
        }
        this.max = Number(config.max);
    }
    validateCriteria(input) {
        const result = compose(isString, maxLength(this.max))(input);
        return result.valid;
    }
    generateTextParams() {
        return {
            max: this.max
        };
    }
}
//# sourceMappingURL=max-length.js.map