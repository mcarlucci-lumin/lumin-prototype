import { AtLeastOneLetter } from './at-least-one-letter.js';
import { AtLeastOneNumber } from './at-least-one-number.js';
import { AtLeastOneSpecialChar } from './at-least-one-special-char.js';
import { LengthRange } from './length-range.js';
import { MaxLength } from './max-length.js';
import { MaxNumericChars } from './max-numeric-chars.js';
import { MinLength } from './min-length.js';
import { NoWhiteSpace } from './no-white-space.js';
import { NotContainSpecialChars } from './not-contain-special-chars.js';
import { CriteriaName } from './criteria-name.js';
import { StartWithLetter } from './start-with-letter.js';
import { StartWithNumber } from './start-with-number.js';
import { AtLeastOneLowercase } from './at-least-one-lowercase.js';
import { AtLeastOneUppercase } from './at-least-one-uppercase.js';
import { Alphanumeric } from './alphanumeric.js';
import { AlphanumericPlusSpecialChars } from './alphanumeric-plus-special-chars.js';
export const CriteriaConstructors = {
    [CriteriaName.LENGTH_RANGE]: LengthRange,
    [CriteriaName.MIN_LENGTH]: MinLength,
    [CriteriaName.MAX_LENGTH]: MaxLength,
    [CriteriaName.MAX_NUMERIC_CHARS]: MaxNumericChars,
    [CriteriaName.ALPHANUMERIC]: Alphanumeric,
    [CriteriaName.ALPHANUMERIC_PLUS_SPECIAL_CHARS]: AlphanumericPlusSpecialChars,
    [CriteriaName.AT_LEAST_ONE_LETTER]: AtLeastOneLetter,
    [CriteriaName.AT_LEAST_ONE_NUMBER]: AtLeastOneNumber,
    [CriteriaName.AT_LEAST_ONE_SPECIAL_CHAR]: AtLeastOneSpecialChar,
    [CriteriaName.AT_LEAST_ONE_UPPERCASE]: AtLeastOneUppercase,
    [CriteriaName.AT_LEAST_ONE_LOWERCASE]: AtLeastOneLowercase,
    [CriteriaName.NO_WHITE_SPACE]: NoWhiteSpace,
    [CriteriaName.NOT_CONTAIN_SPECIAL_CHARS]: NotContainSpecialChars,
    [CriteriaName.START_WITH_LETTER]: StartWithLetter,
    [CriteriaName.START_WITH_NUMBER]: StartWithNumber
};
//# sourceMappingURL=criteria-constructors.js.map