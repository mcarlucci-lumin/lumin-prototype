import { BaseCriteria } from './base-criteria.js';
import { CriteriaConfig } from './criteria-config.js';
export declare class MinLength extends BaseCriteria {
    private min;
    constructor(config: CriteriaConfig);
    protected validateCriteria(input: string): boolean;
    generateTextParams(): {
        min: number;
    };
}
