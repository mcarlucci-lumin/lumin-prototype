import { compose, isString, minLength } from '../validators.js';
import { BaseCriteria } from './base-criteria.js';
import { CriteriaName } from './criteria-name.js';
export class MinLength extends BaseCriteria {
    constructor(config) {
        super(CriteriaName.MIN_LENGTH, config);
        if (!config.min) {
            throw Error('Invalid MinLength config missing min property');
        }
        this.min = Number(config.min);
    }
    validateCriteria(input) {
        const result = compose(isString, minLength(this.min))(input);
        return result.valid;
    }
    generateTextParams() {
        return {
            min: this.min
        };
    }
}
//# sourceMappingURL=min-length.js.map