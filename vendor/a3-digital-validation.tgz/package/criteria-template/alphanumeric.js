import { alphanumeric, compose, isString } from '../validators.js';
import { BaseCriteria } from './base-criteria.js';
import { CriteriaName } from './criteria-name.js';
export class Alphanumeric extends BaseCriteria {
    constructor(config) {
        super(CriteriaName.ALPHANUMERIC, config);
    }
    validateCriteria(input) {
        const result = compose(isString, alphanumeric)(input);
        return result.valid;
    }
}
//# sourceMappingURL=alphanumeric.js.map