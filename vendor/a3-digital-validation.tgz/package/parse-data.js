import { ObjectUtils } from '@a3-digital/utils';
export function parseData(results, ctor) {
    let parsedData = typeof ctor === 'function' ? new ctor() : {};
    if (Array.isArray(results)) {
        return parseArrayData(results, parsedData);
    }
    else {
        return parseIndividualData(results, parsedData);
    }
}
function parseIndividualData(result, target) {
    let parseResult = {
        valid: true,
    };
    parseResult.valid = result.result.valid;
    parseResult.errMsg = result.result.message;
    if (parseResult.valid) {
        ObjectUtils.setPropertyValue(target, String(result.key), result.result.validData, true);
    }
    parseResult.data = parseResult.valid ? target : null;
    return parseResult;
}
function parseArrayData(results, target) {
    let parseResult = {
        valid: true,
    };
    let messages = [];
    for (let r of results) {
        if (!r.result.valid) {
            parseResult.valid = false;
            let msg = r.result.message || 'Invalid';
            messages.push(`${String(r.key)}: ${msg}`);
        }
        else {
            ObjectUtils.setPropertyValue(target, String(r.key), r.result.validData, true);
        }
    }
    parseResult.errMsg = messages.join(', ');
    parseResult.data = parseResult.valid ? target : null;
    return parseResult;
}
//# sourceMappingURL=parse-data.js.map