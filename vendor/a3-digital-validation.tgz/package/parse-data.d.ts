import { ParseResult } from './parse-result.js';
import { ValidationResult } from './validation-results.js';
export declare function parseData<T>(results: {
    key: keyof T;
    result: ValidationResult;
}[] | {
    key: keyof T;
    result: ValidationResult;
}, ctor?: new (...args: any) => T): ParseResult<T>;
