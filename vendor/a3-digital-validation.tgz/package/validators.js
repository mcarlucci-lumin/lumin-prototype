import { ValidationResult } from './validation-results.js';
import { DateUtils } from '@a3-digital/date-utils';
import { STATES, StringUtils } from '@a3-digital/utils';
export function compose(...validators) {
    return (value) => {
        for (let validator of validators) {
            let result = validator(value);
            if (!result.valid) {
                return result;
            }
        }
        return { valid: true, validData: value };
    };
}
export function optional(validator) {
    return (value) => {
        if (!value) {
            return { valid: true, validData: value };
        }
        else {
            return validator(value);
        }
    };
}
export function combineResults(...results) {
    let result = new ValidationResult();
    result.valid = true;
    let messages = [];
    for (let r of results) {
        if (!r.result.valid) {
            result.valid = false;
            let msg = r.result.message || 'Invalid';
            messages.push(`${r.key}: ${msg}`);
        }
    }
    result.message = messages.join(', ');
    return result;
}
export function required(value) {
    if (value) {
        return { valid: true, validData: value };
    }
    else {
        if (value === 0) {
            return { valid: true, validData: value };
        }
        return { valid: false, message: 'Required' };
    }
}
export function anything(value) {
    return { valid: true, validData: value };
}
export function isString(value) {
    let type = typeof value;
    if (type !== 'string') {
        return { valid: false, message: 'Invalid Type' };
    }
    else {
        return { valid: true, validData: value };
    }
}
export function isNumber(value) {
    let type = typeof value;
    if (type !== 'number') {
        return { valid: false, message: 'Invalid Type' };
    }
    else {
        return { valid: true, validData: value };
    }
}
export function isBoolean(value) {
    let type = typeof value;
    if (type !== 'boolean') {
        return { valid: false, message: 'Invalid Type' };
    }
    else {
        return { valid: true, validData: value };
    }
}
export function isDate(value) {
    // not a great way to detect date, so check if item has 
    // the functions a date has
    let duckTypeDate = value.getTime && value.getHours && value.getYear;
    return duckTypeDate ? { valid: true, validData: value } : { valid: false, message: 'Invalid Date' };
}
export function isArray(typeValidator) {
    return (value) => {
        const result = new ValidationResult();
        result.valid = true;
        if (!Array.isArray(value)) {
            result.valid = false;
            result.message = 'Value is not an array';
            return result;
        }
        if (typeValidator) {
            const valid = value.reduce((prev, current) => prev && typeValidator(current).valid, true);
            if (!valid) {
                result.valid = false;
                result.message = 'At least one value of array has invalid type';
            }
        }
        result.validData = value;
        return result;
    };
}
export function minLength(length) {
    return (value) => {
        if (value && value.length >= length) {
            return { valid: true, validData: value };
        }
        else {
            return { valid: false, message: `Min Length is ${length}` };
        }
    };
}
export function maxLength(length) {
    return (value) => {
        if (!value || value.length <= length) {
            return { valid: true, validData: true };
        }
        else {
            return { valid: false, message: `Max Length is ${length}` };
        }
    };
}
export function maxNumericChars(max) {
    return (value) => {
        if (typeof value !== 'string') {
            return { valid: false, message: 'Invalid Type' };
        }
        const numericCount = (value.match(/[0-9]/g) || []).length;
        if (numericCount <= max) {
            return { valid: true, validData: value };
        }
        else {
            return { valid: false, message: `Max numeric characters is ${max}` };
        }
    };
}
export function validStateCode(value) {
    let codes = STATES.map(x => x.abbr);
    return oneOf(codes, 'Invalid State')(value);
}
export function validCity(value) {
    let cityRegEx = /^[a-zA-Z]+(?:[\s-][a-zA-Z]+)*$/;
    let fn = compose(isString, matchesRegEx(cityRegEx, 'Invalid City'));
    return fn(value);
}
export function validZipCode(value) {
    let type = typeof value;
    if (type !== 'string') {
        return { valid: false, message: 'Invalid' };
    }
    let valueString = value;
    let zipRegEx = /^\d{5}(?:[-]?\d{4})?$/;
    let match = valueString.match(zipRegEx);
    return match ? { valid: true, validData: value } : { valid: false, message: 'Invalid' };
}
export function matchesRegEx(regEx, failMessage) {
    return (value) => {
        let type = typeof value;
        if (type !== 'string') {
            return { valid: false, message: failMessage };
        }
        let valueString = value;
        let match = valueString.match(regEx);
        return match ? { valid: true, validData: value } : { valid: false, message: failMessage };
    };
}
export function noRegExMatch(regEx, failMessage) {
    return (value) => {
        let type = typeof value;
        if (type !== 'string') {
            return { valid: false, message: failMessage };
        }
        let valueString = value;
        let match = valueString.match(regEx);
        return match ? { valid: false, message: failMessage } : { valid: true, validData: value };
    };
}
export function expression(exp, failMessage) {
    failMessage = failMessage || 'Expression validation failed';
    return (value) => {
        let valid = exp(value);
        return valid ? { valid, validData: value } : { valid, message: failMessage };
    };
}
export function openCloseCharMatch(openChar, closeChar) {
    return (value) => {
        const result = new ValidationResult();
        if (StringUtils.confirmOpenCharMatchesClosingChar(value, openChar, closeChar)) {
            result.valid = true;
            return result;
        }
        else {
            result.valid = false;
            result.message = `Open Close Mismatch:  ${openChar} ${closeChar}`;
            return result;
        }
    };
}
// TODO - delete this. Find all usages of validPhone and port to either domestic or international regex. See DEV-39641
const PHONE_NUM_REG_EX = /^\s*(?:\+?(\d{1,3}))?[-. (]*(\d{3})[-. )]*(\d{3})[-. ]*(\d{4})(?: *x(\d+))?\s*$/;
export function validPhone(value) {
    let fn = compose(isString, matchesRegEx(PHONE_NUM_REG_EX, 'Invalid Phone'));
    return fn(value);
}
// Must match exactly '(X23) 123-1234' or 'X231231234', where X cannot be 1 or a 0.
// TODO - once NFX is live and form lib usages are completely removed, we can remove support for parenthesis.
// See DEV-39701
const PHONE_DOMESTIC_REG_EX = /^(?:\([2-9]{1}\d{2}\) \d{3}-\d{4}|[2-9]{1}\d{9})$/;
export function validDomesticPhone(value) {
    let fn = compose(isString, matchesRegEx(PHONE_DOMESTIC_REG_EX, 'Invalid Phone'));
    return fn(value);
}
// Non-US values must start with a +, have a valid country code, have a space, and have 4-13 digits (unformatted) as the actual number.
// Niue is the shortest with 4 digits (+683 XXXX). China and Italy can have up to 13 digits.
// US values may be formatted with or without the +1 country code, as either 'X231231234' or '+1 X231231234', where X cannot be 1 or 0.
const PHONE_INTERNATIONAL_REG_EX = /^(\+(9[976]\d|8[987530]\d|6[987]\d|5[90]\d|42\d|3[875]\d|2[98654321]\d|9[8543210]|8[6421]|6[6543210]|5[87654321]|4[987654310]|3[9643210]|2[70]|7) \d{4,13}|(?:\+1 )?[2-9]{1}\d{9})$/;
export function validDomesticOrInternationalPhone(value) {
    let fn = compose(isString, matchesRegEx(PHONE_INTERNATIONAL_REG_EX, 'Invalid Phone'));
    return fn(value);
}
// https://html.spec.whatwg.org/multipage/input.html#valid-e-mail-address
// Modified to require one or more dotted domain labels
const EMAIL_REG_EX = /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/;
export function validEmail(value) {
    let fn = compose(isString, matchesRegEx(EMAIL_REG_EX, 'Invalid Email'));
    return fn(value);
}
// https://gist.github.com/dperini/729294
export const URL_REGEX = new RegExp('^' +
    // protocol identifier (optional)
    // short syntax // still required
    '(?:(?:(?:https?|ftp):)?\\/\\/)' +
    // user:pass BasicAuth (optional)
    '(?:\\S+(?::\\S*)?@)?' +
    '(?:' +
    // IP address exclusion
    // private & local networks
    '(?!(?:10|127)(?:\\.\\d{1,3}){3})' +
    '(?!(?:169\\.254|192\\.168)(?:\\.\\d{1,3}){2})' +
    '(?!172\\.(?:1[6-9]|2\\d|3[0-1])(?:\\.\\d{1,3}){2})' +
    // IP address dotted notation octets
    // excludes loopback network 0.0.0.0
    // excludes reserved space >= 224.0.0.0
    // excludes network & broadcast addresses
    // (first & last IP address of each class)
    '(?:[1-9]\\d?|1\\d\\d|2[01]\\d|22[0-3])' +
    '(?:\\.(?:1?\\d{1,2}|2[0-4]\\d|25[0-5])){2}' +
    '(?:\\.(?:[1-9]\\d?|1\\d\\d|2[0-4]\\d|25[0-4]))' +
    '|' +
    // host & domain names, may end with dot
    // can be replaced by a shortest alternative
    // (?![-_])(?:[-\\w\\u00a1-\\uffff]{0,63}[^-_]\\.)+
    '(?:' +
    '(?:' +
    '[a-z0-9\\u00a1-\\uffff]' +
    '[a-z0-9\\u00a1-\\uffff_-]{0,62}' +
    ')?' +
    '[a-z0-9\\u00a1-\\uffff]\\.' +
    ')+' +
    // TLD identifier name, may end with dot
    '(?:[a-z\\u00a1-\\uffff]{2,}\\.?)' +
    ')' +
    // port number (optional)
    '(?::\\d{2,5})?' +
    // resource path (optional)
    '(?:[/?#]\\S*)?' +
    '$', 'i');
export function validUrl(value) {
    return matchesRegEx(URL_REGEX, 'Invalid URL')(value);
}
export function allDigits(value) {
    return matchesRegEx(/^[0-9]+$/, 'Must be all numbers')(value);
}
export function validDateString(value) {
    let type = typeof value;
    if (type !== 'string') {
        return { valid: false, message: 'Invalid Date' };
    }
    else {
        let val = DateUtils.parseFIDate(value);
        return val ? { valid: true, validData: value } : { valid: false, message: 'Invalid Date' };
    }
}
export function validTimeOfDay(value) {
    let mt = DateUtils.parseTimeOfDay(value);
    if (mt === null) {
        return { valid: false, message: 'Invalid time of day' };
    }
    else {
        return { valid: true, validData: value };
    }
}
export function validMonthYear(value) {
    const digits = value && value.toString().replace(/\D+/g, '');
    if (!digits || digits.length !== 6) {
        return { valid: false, message: 'Invalid Date' };
    }
    const dateString = `${digits.substring(0, 2)}/01/${digits.substring(2)}`;
    if (DateUtils.parseFIDate(dateString) === null) {
        return { valid: false, message: 'Invalid Date' };
    }
    else {
        return { valid: true, validData: value };
    }
}
export function oneOf(values, failMessage) {
    failMessage = failMessage || 'Invalid';
    return (value) => {
        if (!values || !values.find) {
            return { valid: false, message: failMessage };
        }
        let found = values.find(x => x === value);
        if (found) {
            return { valid: true, validData: value };
        }
        else {
            return { valid: false, message: failMessage };
        }
    };
}
export function validEnumValue(enumType) {
    let validValues = Object.keys(enumType);
    return (value) => {
        for (let validValue of validValues) {
            if (validValue === value) {
                return { valid: true, validData: value };
            }
        }
        return { valid: false, message: 'Invalid enum value' };
    };
}
export function atLeastOneIsValid(values, validator, errMessage) {
    for (let item of values) {
        let result = validator(item);
        if (result.valid) {
            return { valid: true, validData: values };
        }
    }
    return { valid: false, message: errMessage };
}
export function matchesAllRegEx(values) {
    return (value) => {
        let type = typeof value;
        if (type !== 'string') {
            return { valid: false };
        }
        let valueString = value;
        let allMatch = true;
        values.forEach(regex => {
            let result = valueString.match(regex);
            if (!result) {
                allMatch = false;
            }
        });
        return allMatch ? { valid: true, validData: value } : { valid: false };
    };
}
export function positiveAmount(value) {
    // If it is a string, remove commas
    if (value && typeof value === 'string') {
        value = value.replace(/,/g, '');
    }
    let float = parseFloat(value);
    return !isNaN(float) && float > 0 ? { valid: true, validData: value } : { valid: false };
}
export function nonNegativeAmount(value) {
    // If it is a string, remove commas
    if (value && typeof value === 'string') {
        value = value.replace(/,/g, '');
    }
    let float = parseFloat(value);
    return !isNaN(float) && float >= 0 ? { valid: true, validData: value } : { valid: false };
}
// Allows alphanumeric and special characters. Does NOT enforce length.
const ACH_ACCOUNT_REG_EX = /^[0-9a-zA-Z!"#$%&'()*+,-.\/:;<>=?@\[\]\\^_`{}|~ ]*$/;
export function validAchAccountNumber(value) {
    let fn = compose(isString, matchesRegEx(ACH_ACCOUNT_REG_EX, 'Invalid ACH account number'));
    return fn(value);
}
// Exactly 9 numeric digits
const ACH_ROUTING_REG_EX = /^[0-9]{9}$/;
export function validAchRoutingNumber(value) {
    let fn = compose(isString, matchesRegEx(ACH_ROUTING_REG_EX, 'Invalid ACH routing number'));
    return fn(value);
}
// Exactly 16 numeric digits
const CARD_NUMBER_REG_EX = /^[0-9]{16}$/;
export function validCardNumber(value) {
    let fn = compose(isString, matchesRegEx(CARD_NUMBER_REG_EX, 'Invalid card number'));
    return fn(value);
}
// 3-4 numeric digits
const CARD_CODE_REG_EX = /^[0-9]{3,4}$/;
export function validCardCode(value) {
    let fn = compose(isString, matchesRegEx(CARD_CODE_REG_EX, 'Invalid card code'));
    return fn(value);
}
const AT_LEAST_ONE_LETTER_REG_EX = /(?=.*[a-zA-Z])/;
export function atLeastOneLetter(value) {
    let fn = compose(isString, matchesRegEx(AT_LEAST_ONE_LETTER_REG_EX, 'Failed to match at least one letter'));
    return fn(value);
}
const AT_LEAST_ONE_NUMBER_REG_EX = /(?=.*[0-9])/;
export function atLeastOneNumber(value) {
    let fn = compose(isString, matchesRegEx(AT_LEAST_ONE_NUMBER_REG_EX, 'Failed to match at least one number'));
    return fn(value);
}
const AT_LEAST_ONE_UPPERCASE_REG_EX = /(?=.*[A-Z])/;
export function atLeastOneUppercase(value) {
    let fn = compose(isString, matchesRegEx(AT_LEAST_ONE_UPPERCASE_REG_EX, 'Failed to match at least one uppercase'));
    return fn(value);
}
const AT_LEAST_ONE_LOWERCASE_REG_EX = /(?=.*[a-z])/;
export function atLeastOneLowercase(value) {
    let fn = compose(isString, matchesRegEx(AT_LEAST_ONE_LOWERCASE_REG_EX, 'Failed to match at least one lowercase'));
    return fn(value);
}
const NO_WHITE_SPACE_REG_EX = /[\s]/;
export function noWhiteSpace(value) {
    let fn = compose(isString, noRegExMatch(NO_WHITE_SPACE_REG_EX, 'Whitespace characters found'));
    return fn(value);
}
const FIRST_CHAR_IS_LETTER_REG_EX = /^[A-Za-z]/;
export function firstCharIsLetter(value) {
    const fn = compose(isString, matchesRegEx(FIRST_CHAR_IS_LETTER_REG_EX, `First character is not a letter`));
    return fn(value);
}
const FIRST_CHAR_IS_NUMBER_REG_EX = /^[\d]/;
export function firstCharIsNumber(value) {
    const fn = compose(isString, matchesRegEx(FIRST_CHAR_IS_NUMBER_REG_EX, `First character is not a number`));
    return fn(value);
}
// Does not enforce length (empty string is valid)
const ALPHANUMERIC_REG_EX = /^[a-zA-Z0-9]*$/;
export function alphanumeric(value) {
    const fn = compose(isString, matchesRegEx(ALPHANUMERIC_REG_EX, `Must be all letters or numbers`));
    return fn(value);
}
const PRINTABLE_ASCII_REG_EX = /^[\x20-\x7E]*$/;
export function asciiOnly(value) {
    const fn = compose(isString, matchesRegEx(PRINTABLE_ASCII_REG_EX, 'Contains non-ASCII characters'));
    return fn(value);
}
export function validJson(value) {
    let result = { valid: true };
    if (value) {
        try {
            JSON.parse(value);
        }
        catch (e) {
            // An error means this is invalid JSON.
            result = { valid: false };
        }
    }
    return result;
}
export function validJsonFiles(values) {
    let result = { valid: true };
    if (values?.length) {
        values.forEach(value => {
            if (result.valid) {
                result = validJson(value.contents);
            }
        });
    }
    return result;
}
//# sourceMappingURL=validators.js.map