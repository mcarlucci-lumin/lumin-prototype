module.exports ={ 
    customSyntax: 'postcss-scss',
    ignoreFiles: [
        '**/dist/**',
        '**/ui-styles/styles/third-party/**/*.scss',
    ],
    rules: {
        'declaration-property-value-disallowed-list': {
            'transition': ['/^all/'], // Use a regex so it matches against the rest of the values
            'transition-property': ['all']
        },
        'declaration-property-value-allowed-list': [
            {
                'backdrop-filter': [
                    'blur(1px)',
                    'blur(2px)',
                    'blur(3px)',
                    'blur(4px)',
                    'blur(5px)',
                    'blur(6px)',
                    'blur(7px)',
                    'blur(8px)',
                    'blur(9px)',
                    'blur(10px)',
                    'var(--backdrop-filter-blur)'
                ]
            },
            {
                message: 'Please use a blur value between 1px-10px.'
            }
        ]
    }
};
