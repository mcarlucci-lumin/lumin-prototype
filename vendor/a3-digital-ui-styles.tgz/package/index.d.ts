import { Subject } from 'rxjs';
import * as i0 from '@angular/core';
import * as i1 from '@angular/common';

declare enum BackgroundColorClass {
    SUCCESS = "bg-color-success",
    WARNING = "bg-color-warning",
    INFO = "bg-color-info",
    DANGER = "bg-color-danger",
    ACCENT_COLOR_1 = "bg-color-account-1",
    ACCENT_COLOR_2 = "bg-color-account-2",
    ACCENT_COLOR_3 = "bg-color-account-3",
    ACCENT_COLOR_4 = "bg-color-account-4",
    ACCENT_COLOR_5 = "bg-color-account-5",
    ACCENT_COLOR_6 = "bg-color-account-6",
    ACCENT_COLOR_7 = "bg-color-account-7",
    GRAY_100 = "bg-color-gray-100",
    GRAY_200 = "bg-color-gray-200",
    GRAY_500 = "bg-color-gray-500",
    GRAY_800 = "bg-color-gray-800"
}

declare enum BaseVariable {
    COLOR_DEFAULT = "--color-default",
    COLOR_CONTENT_NEUTRAL = "--color-content-neutral"
}

declare enum BrandingTokens {
    FONT_FAMILY_BASE = "--font-family-base",
    ICON_FONT_FAMILY = "--icon-font-family",
    COLOR_PRIMARY = "--color-primary",
    COLOR_SECONDARY = "--color-secondary",
    COLOR_CONTENT_PRIMARY = "--color-content-primary",
    COLOR_SUCCESS = "--color-success",
    COLOR_WARNING = "--color-warning",
    COLOR_DANGER = "--color-danger",
    COLOR_INFO = "--color-info",
    COLOR_ACCOUNT_1 = "--color-account-1",
    COLOR_ACCOUNT_2 = "--color-account-2",
    COLOR_ACCOUNT_3 = "--color-account-3",
    COLOR_ACCOUNT_4 = "--color-account-4",
    COLOR_ACCOUNT_5 = "--color-account-5",
    COLOR_ACCOUNT_6 = "--color-account-6",
    COLOR_ACCOUNT_7 = "--color-account-7",
    COLOR_BACKGROUND_ACCOUNT_1 = "--color-background-account-1",
    COLOR_BACKGROUND_ACCOUNT_2 = "--color-background-account-2",
    COLOR_BACKGROUND_ACCOUNT_3 = "--color-background-account-3",
    COLOR_BACKGROUND_ACCOUNT_4 = "--color-background-account-4",
    COLOR_BACKGROUND_ACCOUNT_5 = "--color-background-account-5",
    COLOR_BACKGROUND_ACCOUNT_6 = "--color-background-account-6",
    COLOR_BACKGROUND_ACCOUNT_7 = "--color-background-account-7",
    COLOR_CHART_1 = "--color-chart-1",
    COLOR_CHART_2 = "--color-chart-2",
    COLOR_CHART_3 = "--color-chart-3",
    COLOR_CHART_4 = "--color-chart-4",
    COLOR_CHART_5 = "--color-chart-5",
    COLOR_CHART_6 = "--color-chart-6",
    COLOR_CHART_7 = "--color-chart-7",
    COLOR_CHART_8 = "--color-chart-8",
    COLOR_CHART_9 = "--color-chart-9",
    COLOR_CHART_10 = "--color-chart-10",
    COLOR_CHART_11 = "--color-chart-11",
    COLOR_CHART_12 = "--color-chart-12",
    COLOR_BACKGROUND_1 = "--color-background-1",
    COLOR_BACKGROUND_2 = "--color-background-2",
    COLOR_BACKGROUND_3 = "--color-background-3",
    COLOR_BACKGROUND_OVERLAY = "--color-background-overlay",
    COLOR_POSITIVE = "--color-positive",
    COLOR_NEGATIVE = "--color-negative",
    COLOR_CASHFLOW_IN = "--color-cashflow-in",
    COLOR_CASHFLOW_OUT = "--color-cashflow-out",
    COLOR_BACKGROUND_PENDING = "--color-background-pending",
    COLOR_CONTENT_PENDING = "--color-content-pending",
    GLASS_UI_BACKGROUND_STYLE = "--glass-ui-background-style",
    CONTAINERS_SHAPE = "--containers-shape",
    FORMS_SHAPE = "--forms-shape",
    BUTTON_SHAPE = "--button-shape",
    BUTTON_COLOR_PRIMARY_1 = "--button-color-primary-1",
    BUTTON_COLOR_PRIMARY_2 = "--button-color-primary-2",
    BUTTON_COLOR_PRIMARY_ON = "--button-color-primary-on",
    BUTTON_SIZE_PRIMARY_BORDER = "--button-size-primary-border",
    BUTTON_COLOR_PRIMARY_BORDER = "--button-color-primary-border",
    BUTTON_COLOR_PRIMARY_HOVER_1 = "--button-color-primary-hover-1",
    BUTTON_COLOR_PRIMARY_HOVER_2 = "--button-color-primary-hover-2",
    BUTTON_COLOR_PRIMARY_HOVER_ON = "--button-color-primary-hover-on",
    BUTTON_COLOR_PRIMARY_BORDER_HOVER = "--button-color-primary-border-hover",
    BUTTON_COLOR_PRIMARY_ACTIVE_1 = "--button-color-primary-active-1",
    BUTTON_COLOR_PRIMARY_ACTIVE_2 = "--button-color-primary-active-2",
    BUTTON_COLOR_PRIMARY_ACTIVE_ON = "--button-color-primary-active-on",
    BUTTON_COLOR_PRIMARY_BORDER_ACTIVE = "--button-color-primary-border-active",
    BUTTON_COLOR_PRIMARY_TEXT_WEIGHT = "--button-color-primary-text-weight",
    BUTTON_COLOR_PRIMARY_TEXT_TRANSFORM = "--button-color-primary-text-transform",
    BUTTON_COLOR_SECONDARY_1 = "--button-color-secondary-1",
    BUTTON_COLOR_SECONDARY_2 = "--button-color-secondary-2",
    BUTTON_COLOR_SECONDARY_ON = "--button-color-secondary-on",
    BUTTON_SIZE_SECONDARY_BORDER = "--button-size-secondary-border",
    BUTTON_COLOR_SECONDARY_BORDER = "--button-color-secondary-border",
    BUTTON_COLOR_SECONDARY_HOVER_1 = "--button-color-secondary-hover-1",
    BUTTON_COLOR_SECONDARY_HOVER_2 = "--button-color-secondary-hover-2",
    BUTTON_COLOR_SECONDARY_HOVER_ON = "--button-color-secondary-hover-on",
    BUTTON_COLOR_SECONDARY_BORDER_HOVER = "--button-color-secondary-border-hover",
    BUTTON_COLOR_SECONDARY_ACTIVE_1 = "--button-color-secondary-active-1",
    BUTTON_COLOR_SECONDARY_ACTIVE_2 = "--button-color-secondary-active-2",
    BUTTON_COLOR_SECONDARY_ACTIVE_ON = "--button-color-secondary-active-on",
    BUTTON_COLOR_SECONDARY_BORDER_ACTIVE = "--button-color-secondary-border-active",
    BUTTON_COLOR_SECONDARY_TEXT_WEIGHT = "--button-color-secondary-text-weight",
    BUTTON_COLOR_SECONDARY_TEXT_TRANSFORM = "--button-color-secondary-text-transform",
    BUTTON_COLOR_TERTIARY = "--button-color-tertiary",
    BUTTON_COLOR_TERTIARY_ON = "--button-color-tertiary-on",
    BUTTON_COLOR_TERTIARY_HOVER = "--button-color-tertiary-hover",
    BUTTON_COLOR_TERTIARY_HOVER_ON = "--button-color-tertiary-hover-on",
    BUTTON_COLOR_TERTIARY_ACTIVE = "--button-color-tertiary-active",
    BUTTON_COLOR_TERTIARY_ACTIVE_ON = "--button-color-tertiary-active-on",
    BUTTON_TEXT_TERTIARY_WEIGHT = "--button-text-tertiary-weight",
    BUTTON_TEXT_TERTIARY_TRANSFORM = "--button-text-tertiary-transform",
    FORM_COLOR = "--form-color",
    COLOR_HOVER = "--color-hover",
    LINK_COLOR = "--link-color",
    LINK_TEXT_TRANSFORM = "--link-text-transform",
    LINK_TEXT_DECORATION = "--link-text-decoration",
    LINK_COLOR_HOVER = "--link-color-hover",
    LINK_COLOR_ACTIVE = "--link-color-active",
    LINK_TEXT_WEIGHT = "--link-text-weight",
    LINK_TEXT_DECORATION_HOVER = "--link-text-decoration-hover",
    LINK_TEXT_DECORATION_ACTIVE = "--link-text-decoration-active",
    NAV_DESKTOP_COLOR = "--nav-desktop-color",
    NAV_DESKTOP_COLOR_ON = "--nav-desktop-color-on",
    NAV_DESKTOP_COLOR_HOVER = "--nav-desktop-color-hover",
    NAV_DESKTOP_COLOR_HOVER_ON = "--nav-desktop-color-hover-on",
    NAV_DESKTOP_COLOR_ACTIVE = "--nav-desktop-color-active",
    NAV_DESKTOP_COLOR_ACTIVE_ON = "--nav-desktop-color-active-on",
    NAV_MOBILE_TOP_COLOR = "--nav-mobile-top-color",
    NAV_MOBILE_TOP_COLOR_ON = "--nav-mobile-top-color-on",
    NAV_MOBILE_BOTTOM_COLOR = "--nav-mobile-bottom-color",
    NAV_MOBILE_BOTTOM_COLOR_ON = "--nav-mobile-bottom-color-on",
    NAV_MOBILE_BOTTOM_COLOR_ACTIVE = "--nav-mobile-bottom-color-active",
    NAV_MOBILE_BOTTOM_COLOR_ACTIVE_ON = "--nav-mobile-bottom-color-active-on",
    NAV_SEARCH_COLOR = "--nav-search-color",
    NAV_SEARCH_COLOR_ON = "--nav-search-color-on",
    NAV_SEARCH_COLOR_ACTIVE = "--nav-search-color-active",
    NAV_SEARCH_COLOR_ACTIVE_ON = "--nav-search-color-active-on",
    NAV_SEARCH_COLOR_HINT_ON = "--nav-search-color-hint-on",
    NAV_SEARCH_COLOR_ICON = "--nav-search-color-icon",
    NAV_SEARCH_COLOR_ICON_ACTIVE = "--nav-search-color-icon-active",
    NAV_MOBILE_SEARCH_COLOR_CLOSE = "--nav-mobile-search-color-close",
    IMAGE_CREDIT = "--image-credit",
    IMAGE_DEBIT = "--image-debit",
    IMAGE_LOGO_DEFAULT = "--image-logo-default",
    IMAGE_LOGO_WHITE = "--image-logo-white",
    IMAGE_FACEBOOK = "--image-facebook",
    IMAGE_INSTAGRAM = "--image-instagram",
    IMAGE_LINKEDIN = "--image-linkedin",
    IMAGE_TWITTER = "--image-twitter",
    IMAGE_YOUTUBE = "--image-youtube",
    IMAGE_SOCIAL_1 = "--image-social-1",
    IMAGE_SOCIAL_2 = "--image-social-2",
    IMAGE_SOCIAL_3 = "--image-social-3"
}

declare enum ColorClass {
    SUCCESS = "color-success",
    WARNING = "color-warning",
    INFO = "color-info",
    DANGER = "color-danger",
    ACCENT_COLOR_1 = "color-account-1",
    ACCENT_COLOR_2 = "color-account-2",
    ACCENT_COLOR_3 = "color-account-3",
    ACCENT_COLOR_4 = "color-account-4",
    ACCENT_COLOR_5 = "color-account-5",
    ACCENT_COLOR_6 = "color-account-6",
    ACCENT_COLOR_7 = "color-account-7"
}

declare enum ColorVariable {
    PRIMARY = "--color-primary",
    SECONDARY = "--color-secondary",
    SUCCESS = "--color-success",
    INFO = "--color-info",
    WARNING = "--color-warning",
    ERROR = "--color-danger",
    POSITIVE_COLOR = "--color-positive",
    NEGATIVE_COLOR = "--color-negative",
    ACCENT_COLOR_1 = "--color-account-1",
    ACCENT_COLOR_2 = "--color-account-2",
    ACCENT_COLOR_3 = "--color-account-3",
    ACCENT_COLOR_4 = "--color-account-4",
    ACCENT_COLOR_5 = "--color-account-5",
    ACCENT_COLOR_6 = "--color-account-6",
    ACCENT_COLOR_7 = "--color-account-7",
    GRAY_100 = "--color-gray-100",
    GRAY_200 = "--color-gray-200",
    GRAY_300 = "--color-gray-300",
    GRAY_400 = "--color-gray-400",
    GRAY_500 = "--color-gray-500",
    GRAY_600 = "--color-gray-600",
    GRAY_700 = "--color-gray-700",
    GRAY_800 = "--color-gray-800",
    GRAY_900 = "--color-gray-900"
}

declare enum ContrastStandard {
    THREE_TO_ONE = "3",
    DOUBLE_A = "4.5",
    TRIPLE_A = "7"
}

declare enum RootVariable {
    REM_SCALE = "--rem-scale",
    ANDROID_REM_SCALE = "--android-rem-scale",
    FDIC_HEADER_HEIGHT = "--fdic-header-height"
}

declare class AccentColorUtils {
    static readonly ACCENT_COLOR_COUNT: number;
    static readonly backgroundClasses: readonly BackgroundColorClass[];
    static readonly colorClasses: readonly ColorClass[];
    static indexForPosition(position: number): number;
    static backgroundClassForPosition(position: number): BackgroundColorClass;
    static colorClassForPosition(position: number): ColorClass;
    static isValidIndex(index: number): boolean;
    static backgroundClassForIndex(index: number, fallback?: string): string;
    static colorClassForIndex(index: number, fallback?: string): string;
    static tokenForIndex(index: number): BrandingTokens;
}

declare class AdaUtils {
    static contrastTest(contrast: number, contrastStandard: ContrastStandard): boolean;
    static getFontScale(): number;
    static isReducedMotionDevice(): boolean;
    static setDisableAnimations(force?: boolean): boolean;
}

declare class ColorObject {
    red: number;
    green: number;
    blue: number;
}
declare class ColorVariation {
    color: string;
    amount: number;
}
declare const WHITE_HEX = "#FFFFFF";
declare const hexRegEx: RegExp;
declare class ColorUtils {
    static normalize(rgb: ColorObject): ColorObject;
    static hexToRGB(hex: string): ColorObject;
    static rgbToHex(value: number): string;
    static isHexCode(hex: string): boolean;
    static normalizeColor(value: number): number;
    static getLuminance(hex: string): number;
    static fullColorHex(rgb: ColorObject): string;
    static zeroValueCheck(rgb: ColorObject): ColorObject;
    static maxValueCheck(rgb: ColorObject): ColorObject;
    static darkenValues(hex: string, amount: number): string;
    static lightenValues(hex: string, amount: number): string;
    static getContrast(c1: string, c2: string): number;
    static getContrastWhiteBg(fg: string): number;
}

type IconFill = 'Filled' | 'Outlined';
type IconRadius = 'Sharp' | 'Rounded';
type IconWeight = 'Thin' | 'Regular' | 'Bold';
interface MaterialSymbolConfig {
    fill: IconFill;
    radius: IconRadius;
    weight: IconWeight;
}
declare const DEFAULT_MATERIAL_SYMBOL_CONFIG: MaterialSymbolConfig;
declare function getMaterialSymbolFontFamily(config: MaterialSymbolConfig): string;

declare class NativeVariableUtils {
    static readonly variablesChanged$: Subject<void>;
    private static cachedBaseVariables;
    private static cachedTokenVariables;
    private static cachedCustomVariables;
    private static readonly generatedTokens;
    static getTokenValue(token: BrandingTokens): string;
    static getCustomValue(variable: string): string;
    static getAccentColorValue(index: number): string;
    static getChartColorValue(index: number): string;
    static getMobileStatusBarColor(): string;
    static getConditionalBorderRadius(nonZeroValue: number): number;
    static setThemeVariables(variables: object, element?: HTMLElement): void;
    static removeVariables(element?: HTMLElement): void;
    protected static clearCachedVariables(): void;
    protected static getComputedVariableValue(variable: string, map: Map<string, string>): string;
    private static formatNativeVariable;
}

declare class StyleInjectionUtils {
    static injectBundle(bundleName: string, bundleVersion: number, testClass?: string): void;
    static injectCss(id: string, css: string): void;
    static elementExists(id: any): boolean;
    private static createLink;
    private static injectAndDestroyTestClass;
}

declare class UiStylesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UiStylesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UiStylesModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UiStylesModule>;
}

export { AccentColorUtils, AdaUtils, BackgroundColorClass, BaseVariable, BrandingTokens, ColorClass, ColorObject, ColorUtils, ColorVariable, ColorVariation, ContrastStandard, DEFAULT_MATERIAL_SYMBOL_CONFIG, NativeVariableUtils, RootVariable, StyleInjectionUtils, UiStylesModule, WHITE_HEX, getMaterialSymbolFontFamily, hexRegEx };
export type { IconFill, IconRadius, IconWeight, MaterialSymbolConfig };
//# sourceMappingURL=index.d.ts.map
