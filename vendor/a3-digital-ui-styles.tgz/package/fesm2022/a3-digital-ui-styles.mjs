import { StringUtils } from '@a3-digital/utils';
import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

var BackgroundColorClass;
(function (BackgroundColorClass) {
    // Brand Colors
    BackgroundColorClass["SUCCESS"] = "bg-success";
    BackgroundColorClass["WARNING"] = "bg-warning";
    BackgroundColorClass["INFO"] = "bg-info";
    BackgroundColorClass["ERROR"] = "bg-danger";
    // Accent Colors
    BackgroundColorClass["ACCENT_COLOR_1"] = "bg-accent-color-1";
    BackgroundColorClass["ACCENT_COLOR_2"] = "bg-accent-color-2";
    BackgroundColorClass["ACCENT_COLOR_3"] = "bg-accent-color-3";
    BackgroundColorClass["ACCENT_COLOR_4"] = "bg-accent-color-4";
    BackgroundColorClass["ACCENT_COLOR_5"] = "bg-accent-color-5";
    BackgroundColorClass["ACCENT_COLOR_6"] = "bg-accent-color-6";
    BackgroundColorClass["ACCENT_COLOR_7"] = "bg-accent-color-7";
    // Grays
    BackgroundColorClass["GRAY_100"] = "bg-gray-100";
    BackgroundColorClass["GRAY_200"] = "bg-gray-200";
    BackgroundColorClass["GRAY_500"] = "bg-gray-500";
    BackgroundColorClass["GRAY_800"] = "bg-gray-800";
})(BackgroundColorClass || (BackgroundColorClass = {}));

// These are native variables that are not modified via branding/theming,
// but are exposed for native mobile usages, dark mode, or other base product features.
var BaseVariable;
(function (BaseVariable) {
    // Neutral Colors
    BaseVariable["NEUTRAL_BG_COLOR"] = "--neutral-bg-color";
    BaseVariable["NEUTRAL_COLOR"] = "--neutral-color";
})(BaseVariable || (BaseVariable = {}));

// FI-themeable design tokens that can be customized per FI via Theme Designer.
// Meant to eventually replace the legacy BrandingVariable enum file.
// The CSS variables themselves live in _base-tokens.scss alongside the non-themeable BaseTokens. 
// This enum is the metadata that says "Theme Designer is allowed to author these".
var BrandingTokens;
(function (BrandingTokens) {
    // Typography
    BrandingTokens["FONT_FAMILY_BASE"] = "--font-family-base";
    // Brand — headline colors
    BrandingTokens["COLOR_PRIMARY"] = "--color-primary";
    BrandingTokens["COLOR_SECONDARY"] = "--color-secondary";
    // Content
    BrandingTokens["COLOR_CONTENT_PRIMARY"] = "--color-content-primary";
    // Messaging headline + on-color (must pass AA contrast)
    BrandingTokens["COLOR_SUCCESS"] = "--color-success";
    BrandingTokens["COLOR_SUCCESS_ON"] = "--color-success-on";
    BrandingTokens["COLOR_WARNING"] = "--color-warning";
    BrandingTokens["COLOR_WARNING_ON"] = "--color-warning-on";
    BrandingTokens["COLOR_DANGER"] = "--color-danger";
    BrandingTokens["COLOR_DANGER_ON"] = "--color-danger-on";
    BrandingTokens["COLOR_INFO"] = "--color-info";
    BrandingTokens["COLOR_INFO_ON"] = "--color-info-on";
    // Account headlines (on-color and ramp positions stay non-themeable)
    BrandingTokens["COLOR_ACCOUNT_1"] = "--color-account-1";
    BrandingTokens["COLOR_ACCOUNT_2"] = "--color-account-2";
    BrandingTokens["COLOR_ACCOUNT_3"] = "--color-account-3";
    BrandingTokens["COLOR_ACCOUNT_4"] = "--color-account-4";
    BrandingTokens["COLOR_ACCOUNT_5"] = "--color-account-5";
    BrandingTokens["COLOR_ACCOUNT_6"] = "--color-account-6";
    BrandingTokens["COLOR_ACCOUNT_7"] = "--color-account-7";
    // Account background colors
    BrandingTokens["COLOR_BACKGROUND_ACCOUNT_1"] = "--color-background-account-1";
    BrandingTokens["COLOR_BACKGROUND_ACCOUNT_2"] = "--color-background-account-2";
    BrandingTokens["COLOR_BACKGROUND_ACCOUNT_3"] = "--color-background-account-3";
    BrandingTokens["COLOR_BACKGROUND_ACCOUNT_4"] = "--color-background-account-4";
    BrandingTokens["COLOR_BACKGROUND_ACCOUNT_5"] = "--color-background-account-5";
    BrandingTokens["COLOR_BACKGROUND_ACCOUNT_6"] = "--color-background-account-6";
    BrandingTokens["COLOR_BACKGROUND_ACCOUNT_7"] = "--color-background-account-7";
    // Chart headlines (on-color stays non-themeable)
    BrandingTokens["COLOR_CHART_1"] = "--color-chart-1";
    BrandingTokens["COLOR_CHART_2"] = "--color-chart-2";
    BrandingTokens["COLOR_CHART_3"] = "--color-chart-3";
    BrandingTokens["COLOR_CHART_4"] = "--color-chart-4";
    BrandingTokens["COLOR_CHART_5"] = "--color-chart-5";
    BrandingTokens["COLOR_CHART_6"] = "--color-chart-6";
    BrandingTokens["COLOR_CHART_7"] = "--color-chart-7";
    BrandingTokens["COLOR_CHART_8"] = "--color-chart-8";
    BrandingTokens["COLOR_CHART_9"] = "--color-chart-9";
    BrandingTokens["COLOR_CHART_10"] = "--color-chart-10";
    // Backgrounds — gradient/overlay
    BrandingTokens["COLOR_BACKGROUND_1"] = "--color-background-1";
    BrandingTokens["COLOR_BACKGROUND_2"] = "--color-background-2";
    BrandingTokens["COLOR_BACKGROUND_3"] = "--color-background-3";
    BrandingTokens["COLOR_BACKGROUND_OVERLAY"] = "--color-background-overlay";
    // Transaction colors
    BrandingTokens["COLOR_POSITIVE"] = "--color-positive";
    BrandingTokens["COLOR_NEGATIVE"] = "--color-negative";
    BrandingTokens["COLOR_CASHFLOW_IN"] = "--color-cashflow-in";
    BrandingTokens["COLOR_CASHFLOW_OUT"] = "--color-cashflow-out";
    BrandingTokens["COLOR_BACKGROUND_PENDING"] = "--color-background-pending";
    BrandingTokens["COLOR_CONTENT_PENDING"] = "--color-content-pending";
    // Shape / border radius
    BrandingTokens["CONTAINERS_SHAPE"] = "--containers-shape";
    BrandingTokens["FORMS_SHAPE"] = "--forms-shape";
    BrandingTokens["BUTTON_SHAPE"] = "--button-shape";
    // Buttons — Primary
    BrandingTokens["BUTTON_COLOR_PRIMARY_1"] = "--button-color-primary-1";
    BrandingTokens["BUTTON_COLOR_PRIMARY_2"] = "--button-color-primary-2";
    BrandingTokens["BUTTON_COLOR_PRIMARY_ON"] = "--button-color-primary-on";
    BrandingTokens["BUTTON_SIZE_PRIMARY_BORDER"] = "--button-size-primary-border";
    BrandingTokens["BUTTON_COLOR_PRIMARY_BORDER"] = "--button-color-primary-border";
    BrandingTokens["BUTTON_COLOR_PRIMARY_HOVER_1"] = "--button-color-primary-hover-1";
    BrandingTokens["BUTTON_COLOR_PRIMARY_HOVER_2"] = "--button-color-primary-hover-2";
    BrandingTokens["BUTTON_COLOR_PRIMARY_HOVER_ON"] = "--button-color-primary-hover-on";
    BrandingTokens["BUTTON_COLOR_PRIMARY_BORDER_HOVER"] = "--button-color-primary-border-hover";
    BrandingTokens["BUTTON_COLOR_PRIMARY_ACTIVE_1"] = "--button-color-primary-active-1";
    BrandingTokens["BUTTON_COLOR_PRIMARY_ACTIVE_2"] = "--button-color-primary-active-2";
    BrandingTokens["BUTTON_COLOR_PRIMARY_ACTIVE_ON"] = "--button-color-primary-active-on";
    BrandingTokens["BUTTON_COLOR_PRIMARY_BORDER_ACTIVE"] = "--button-color-primary-border-active";
    BrandingTokens["BUTTON_COLOR_PRIMARY_TEXT_WEIGHT"] = "--button-color-primary-text-weight";
    BrandingTokens["BUTTON_COLOR_PRIMARY_TEXT_TRANSFORM"] = "--button-color-primary-text-transform";
    BrandingTokens["BUTTON_COLOR_PRIMARY_DISABLED"] = "--button-color-primary-disabled";
    BrandingTokens["BUTTON_COLOR_PRIMARY_DISABLED_ON"] = "--button-color-primary-disabled-on";
    // Buttons — Secondary
    BrandingTokens["BUTTON_COLOR_SECONDARY_1"] = "--button-color-secondary-1";
    BrandingTokens["BUTTON_COLOR_SECONDARY_2"] = "--button-color-secondary-2";
    BrandingTokens["BUTTON_COLOR_SECONDARY_ON"] = "--button-color-secondary-on";
    BrandingTokens["BUTTON_SIZE_SECONDARY_BORDER"] = "--button-size-secondary-border";
    BrandingTokens["BUTTON_COLOR_SECONDARY_BORDER"] = "--button-color-secondary-border";
    BrandingTokens["BUTTON_COLOR_SECONDARY_HOVER_1"] = "--button-color-secondary-hover-1";
    BrandingTokens["BUTTON_COLOR_SECONDARY_HOVER_2"] = "--button-color-secondary-hover-2";
    BrandingTokens["BUTTON_COLOR_SECONDARY_HOVER_ON"] = "--button-color-secondary-hover-on";
    BrandingTokens["BUTTON_COLOR_SECONDARY_BORDER_HOVER"] = "--button-color-secondary-border-hover";
    BrandingTokens["BUTTON_COLOR_SECONDARY_ACTIVE_1"] = "--button-color-secondary-active-1";
    BrandingTokens["BUTTON_COLOR_SECONDARY_ACTIVE_2"] = "--button-color-secondary-active-2";
    BrandingTokens["BUTTON_COLOR_SECONDARY_ACTIVE_ON"] = "--button-color-secondary-active-on";
    BrandingTokens["BUTTON_COLOR_SECONDARY_BORDER_ACTIVE"] = "--button-color-secondary-border-active";
    BrandingTokens["BUTTON_COLOR_SECONDARY_TEXT_WEIGHT"] = "--button-color-secondary-text-weight";
    BrandingTokens["BUTTON_COLOR_SECONDARY_TEXT_TRANSFORM"] = "--button-color-secondary-text-transform";
    // Buttons — Tertiary
    BrandingTokens["BUTTON_COLOR_TERTIARY"] = "--button-color-tertiary";
    BrandingTokens["BUTTON_COLOR_TERTIARY_ON"] = "--button-color-tertiary-on";
    BrandingTokens["BUTTON_COLOR_TERTIARY_HOVER"] = "--button-color-tertiary-hover";
    BrandingTokens["BUTTON_COLOR_TERTIARY_HOVER_ON"] = "--button-color-tertiary-hover-on";
    BrandingTokens["BUTTON_COLOR_TERTIARY_ACTIVE"] = "--button-color-tertiary-active";
    BrandingTokens["BUTTON_COLOR_TERTIARY_ACTIVE_ON"] = "--button-color-tertiary-active-on";
    BrandingTokens["BUTTON_TEXT_TERTIARY_WEIGHT"] = "--button-text-tertiary-weight";
    BrandingTokens["BUTTON_TEXT_TERTIARY_TRANSFORM"] = "--button-text-tertiary-transform";
    // Forms / hover (color-focus and size-focus-border stay non-themeable)
    BrandingTokens["FORM_COLOR"] = "--form-color";
    BrandingTokens["COLOR_HOVER"] = "--color-hover";
    // Link
    BrandingTokens["LINK_COLOR"] = "--link-color";
    BrandingTokens["LINK_TEXT_TRANSFORM"] = "--link-text-transform";
    BrandingTokens["LINK_TEXT_DECORATION"] = "--link-text-decoration";
    BrandingTokens["LINK_COLOR_HOVER"] = "--link-color-hover";
    BrandingTokens["LINK_COLOR_ACTIVE"] = "--link-color-active";
    BrandingTokens["LINK_TEXT_WEIGHT"] = "--link-text-weight";
    BrandingTokens["LINK_TEXT_DECORATION_HOVER"] = "--link-text-decoration-hover";
    BrandingTokens["LINK_TEXT_DECORATION_ACTIVE"] = "--link-text-decoration-active";
    // Navigation — desktop
    BrandingTokens["NAV_DESKTOP_COLOR"] = "--nav-desktop-color";
    BrandingTokens["NAV_DESKTOP_COLOR_ON"] = "--nav-desktop-color-on";
    BrandingTokens["NAV_DESKTOP_COLOR_HOVER"] = "--nav-desktop-color-hover";
    BrandingTokens["NAV_DESKTOP_COLOR_HOVER_ON"] = "--nav-desktop-color-hover-on";
    BrandingTokens["NAV_DESKTOP_COLOR_ACTIVE"] = "--nav-desktop-color-active";
    BrandingTokens["NAV_DESKTOP_COLOR_ACTIVE_ON"] = "--nav-desktop-color-active-on";
    // Navigation — mobile
    BrandingTokens["NAV_MOBILE_TOP_COLOR"] = "--nav-mobile-top-color";
    BrandingTokens["NAV_MOBILE_TOP_COLOR_ON"] = "--nav-mobile-top-color-on";
    BrandingTokens["NAV_MOBILE_BOTTOM_COLOR"] = "--nav-mobile-bottom-color";
    BrandingTokens["NAV_MOBILE_BOTTOM_COLOR_ON"] = "--nav-mobile-bottom-color-on";
    BrandingTokens["NAV_MOBILE_BOTTOM_COLOR_ACTIVE"] = "--nav-mobile-bottom-color-active";
    BrandingTokens["NAV_MOBILE_BOTTOM_COLOR_ACTIVE_ON"] = "--nav-mobile-bottom-color-active-on";
    // Navigation — search
    BrandingTokens["NAV_SEARCH_COLOR"] = "--nav-search-color";
    BrandingTokens["NAV_SEARCH_COLOR_ON"] = "--nav-search-color-on";
    BrandingTokens["NAV_SEARCH_COLOR_ACTIVE"] = "--nav-search-color-active";
    BrandingTokens["NAV_SEARCH_COLOR_ACTIVE_ON"] = "--nav-search-color-active-on";
    BrandingTokens["NAV_SEARCH_COLOR_HINT_ON"] = "--nav-search-color-hint-on";
    BrandingTokens["NAV_SEARCH_COLOR_ICON"] = "--nav-search-color-icon";
    BrandingTokens["NAV_SEARCH_COLOR_ICON_ACTIVE"] = "--nav-search-color-icon-active";
    BrandingTokens["NAV_MOBILE_SEARCH_COLOR_CLOSE"] = "--nav-mobile-search-color-close";
    // Brand imagery
    BrandingTokens["IMAGE_CREDIT"] = "--image-credit";
    BrandingTokens["IMAGE_DEBIT"] = "--image-debit";
    BrandingTokens["IMAGE_LOGO_DEFAULT"] = "--image-logo-default";
    BrandingTokens["IMAGE_LOGO_WHITE"] = "--image-logo-white";
    BrandingTokens["IMAGE_FACEBOOK"] = "--image-facebook";
    BrandingTokens["IMAGE_INSTAGRAM"] = "--image-instagram";
    BrandingTokens["IMAGE_LINKEDIN"] = "--image-linkedin";
    BrandingTokens["IMAGE_TWITTER"] = "--image-twitter";
    BrandingTokens["IMAGE_YOUTUBE"] = "--image-youtube";
    BrandingTokens["IMAGE_SOCIAL_1"] = "--image-social-1";
    BrandingTokens["IMAGE_SOCIAL_2"] = "--image-social-2";
    BrandingTokens["IMAGE_SOCIAL_3"] = "--image-social-3";
})(BrandingTokens || (BrandingTokens = {}));

// This enum is intended to control the native variables that are modified via the branding tool.
// This file should eventually be replaced by the new BrandingTokens enum file.
var BrandingVariable;
(function (BrandingVariable) {
    // Typography
    BrandingVariable["FONT_FAMILY_BASE"] = "--font-family-base";
    BrandingVariable["ICON_FONT_FAMILY"] = "--icon-font-family";
    // Brand Colors
    BrandingVariable["BRAND_PRIMARY"] = "--brand-primary";
    BrandingVariable["BRAND_PRIMARY_DARK"] = "--brand-primary-dark";
    BrandingVariable["BRAND_PRIMARY_LIGHT"] = "--brand-primary-light";
    BrandingVariable["BRAND_SECONDARY"] = "--brand-secondary";
    BrandingVariable["BRAND_SECONDARY_LIGHT"] = "--brand-secondary-light";
    BrandingVariable["BRAND_NEUTRAL"] = "--brand-neutral";
    BrandingVariable["BRAND_BACKGROUND"] = "--brand-background";
    // Accent Colors
    BrandingVariable["ACCENT_COLOR_1"] = "--accent-color-1";
    BrandingVariable["ACCENT_COLOR_2"] = "--accent-color-2";
    BrandingVariable["ACCENT_COLOR_3"] = "--accent-color-3";
    BrandingVariable["ACCENT_COLOR_4"] = "--accent-color-4";
    BrandingVariable["ACCENT_COLOR_5"] = "--accent-color-5";
    BrandingVariable["ACCENT_COLOR_6"] = "--accent-color-6";
    BrandingVariable["ACCENT_COLOR_7"] = "--accent-color-7";
    // Pending Transaction Colors
    BrandingVariable["PENDING_FILL"] = "--pending-fill";
    BrandingVariable["PENDING_TEXT"] = "--pending-text";
    // Balance Colors
    BrandingVariable["POSITIVE_COLOR"] = "--positive-color";
    BrandingVariable["NEGATIVE_COLOR"] = "--negative-color";
    // Cash Flow Colors
    BrandingVariable["CASH_FLOW_POS_COLOR"] = "--cash-flow-pos-color";
    BrandingVariable["CASH_FLOW_NEG_COLOR"] = "--cash-flow-neg-color";
    // Alert and Form Validation Colors
    BrandingVariable["SUCCESS"] = "--success";
    BrandingVariable["INFO"] = "--info";
    BrandingVariable["WARNING"] = "--warning";
    BrandingVariable["DANGER"] = "--danger";
    // Alert Text Colors
    BrandingVariable["SUCCESS_TEXT"] = "--success-text";
    BrandingVariable["INFO_TEXT"] = "--info-text";
    BrandingVariable["WARNING_TEXT"] = "--warning-text";
    BrandingVariable["DANGER_TEXT"] = "--danger-text";
    // Link Text Colors
    BrandingVariable["LINK_COLOR"] = "--link-color";
    BrandingVariable["LINK_HOVER_COLOR"] = "--link-hover-color";
    // Link Text Modifications
    BrandingVariable["LINK_FONT_WEIGHT"] = "--link-font-weight";
    BrandingVariable["LINK_TEXT_TRANSFORM"] = "--link-text-transform";
    BrandingVariable["LINK_TEXT_DECORATION"] = "--link-text-decoration";
    BrandingVariable["LINK_ACTIVE_TEXT_DECORATION"] = "--link-active-text-decoration";
    BrandingVariable["LINK_HOVER_TEXT_DECORATION"] = "--link-hover-text-decoration";
    // Hover
    BrandingVariable["HOVER_COLOR"] = "--hover-color";
    // Primary Button
    BrandingVariable["BTN_PRIMARY"] = "--btn-primary";
    BrandingVariable["BTN_PRIMARY_GRADIENT"] = "--btn-primary-gradient";
    BrandingVariable["BTN_PRIMARY_BORDER"] = "--btn-primary-border";
    BrandingVariable["BTN_PRIMARY_BORDER_SIZE"] = "--btn-primary-border-size";
    BrandingVariable["BTN_PRIMARY_ACTIVE"] = "--btn-primary-active";
    BrandingVariable["BTN_PRIMARY_ACTIVE_GRADIENT"] = "--btn-primary-active-gradient";
    BrandingVariable["BTN_PRIMARY_ACTIVE_BORDER"] = "--btn-primary-active-border";
    BrandingVariable["BTN_PRIMARY_ACTIVE_TEXT"] = "--btn-primary-active-text";
    BrandingVariable["BTN_PRIMARY_FONT_WEIGHT"] = "--btn-primary-font-weight";
    BrandingVariable["BTN_PRIMARY_HOVER"] = "--btn-primary-hover";
    BrandingVariable["BTN_PRIMARY_HOVER_GRADIENT"] = "--btn-primary-hover-gradient";
    BrandingVariable["BTN_PRIMARY_HOVER_BORDER"] = "--btn-primary-hover-border";
    BrandingVariable["BTN_PRIMARY_HOVER_TEXT"] = "--btn-primary-hover-text";
    BrandingVariable["BTN_PRIMARY_TEXT"] = "--btn-primary-text";
    BrandingVariable["BTN_PRIMARY_TEXT_TRANSFORM"] = "--btn-primary-text-transform";
    // Secondary Button
    BrandingVariable["BTN_SECONDARY"] = "--btn-secondary";
    BrandingVariable["BTN_SECONDARY_GRADIENT"] = "--btn-secondary-gradient";
    BrandingVariable["BTN_SECONDARY_BORDER"] = "--btn-secondary-border";
    BrandingVariable["BTN_SECONDARY_BORDER_SIZE"] = "--btn-secondary-border-size";
    BrandingVariable["BTN_SECONDARY_ACTIVE"] = "--btn-secondary-active";
    BrandingVariable["BTN_SECONDARY_ACTIVE_GRADIENT"] = "--btn-secondary-active-gradient";
    BrandingVariable["BTN_SECONDARY_ACTIVE_BORDER"] = "--btn-secondary-active-border";
    BrandingVariable["BTN_SECONDARY_ACTIVE_TEXT"] = "--btn-secondary-active-text";
    BrandingVariable["BTN_SECONDARY_FONT_WEIGHT"] = "--btn-secondary-font-weight";
    BrandingVariable["BTN_SECONDARY_HOVER"] = "--btn-secondary-hover";
    BrandingVariable["BTN_SECONDARY_HOVER_GRADIENT"] = "--btn-secondary-hover-gradient";
    BrandingVariable["BTN_SECONDARY_HOVER_BORDER"] = "--btn-secondary-hover-border";
    BrandingVariable["BTN_SECONDARY_HOVER_TEXT"] = "--btn-secondary-hover-text";
    BrandingVariable["BTN_SECONDARY_TEXT"] = "--btn-secondary-text";
    BrandingVariable["BTN_SECONDARY_TEXT_TRANSFORM"] = "--btn-secondary-text-transform";
    // Tertiary Button
    BrandingVariable["BTN_TERTIARY_FONT_WEIGHT"] = "--btn-tertiary-font-weight";
    BrandingVariable["BTN_TERTIARY_TEXT_TRANSFORM"] = "--btn-tertiary-text-transform";
    // Disabled Button
    BrandingVariable["BTN_DISABLED"] = "--btn-disabled";
    BrandingVariable["BTN_DISABLED_TEXT"] = "--btn-disabled-text";
    // Primary Navigation Button
    BrandingVariable["BTN_NAVIGATION_ACTIVE"] = "--btn-navigation-active";
    BrandingVariable["BTN_NAVIGATION_ACTIVE_TEXT"] = "--btn-navigation-active-text";
    BrandingVariable["BTN_NAVIGATION_HOVER"] = "--btn-navigation-hover";
    BrandingVariable["BTN_NAVIGATION_HOVER_TEXT"] = "--btn-navigation-hover-text";
    // Primary Navigation Search
    BrandingVariable["NAV_SEARCH_FILL_ACTIVE"] = "--nav-search-fill-active";
    BrandingVariable["NAV_SEARCH_TEXT_ACTIVE"] = "--nav-search-text-active";
    BrandingVariable["NAV_SEARCH_ICON_ACTIVE"] = "--nav-search-icon-active";
    BrandingVariable["NAV_SEARCH_FILL_INACTIVE"] = "--nav-search-fill-inactive";
    BrandingVariable["NAV_SEARCH_TEXT_INACTIVE"] = "--nav-search-text-inactive";
    BrandingVariable["NAV_SEARCH_ICON_INACTIVE"] = "--nav-search-icon-inactive";
    BrandingVariable["NAV_SEARCH_HINT_TEXT"] = "--nav-search-hint-text";
    BrandingVariable["NAV_SEARCH_MOBILE_CLOSE_ICON"] = "--nav-search-mobile-close-icon";
    // Glass Circles
    BrandingVariable["GLASS_UI_BACKGROUND_STYLE"] = "--glass-ui-background-style";
    BrandingVariable["GLASS_UI_WHITE_OVERLAY_OPACITY"] = "--glass-ui-white-overlay-opacity";
    BrandingVariable["GLASS_UI_CIRCLE_PRIMARY_COLOR"] = "--glass-ui-circle-primary-color";
    BrandingVariable["GLASS_UI_CIRCLE_SECONDARY_COLOR"] = "--glass-ui-circle-secondary-color";
    BrandingVariable["GLASS_UI_CIRCLE_TERTIARY_COLOR"] = "--glass-ui-circle-tertiary-color";
    // Glass Circle Colors
    BrandingVariable["GLASS_UI_CIRCLE_ACCENT_COLOR_1"] = "--glass-ui-circle-accent-color-1";
    BrandingVariable["GLASS_UI_CIRCLE_ACCENT_COLOR_2"] = "--glass-ui-circle-accent-color-2";
    BrandingVariable["GLASS_UI_CIRCLE_ACCENT_COLOR_3"] = "--glass-ui-circle-accent-color-3";
    BrandingVariable["GLASS_UI_CIRCLE_ACCENT_COLOR_4"] = "--glass-ui-circle-accent-color-4";
    BrandingVariable["GLASS_UI_CIRCLE_ACCENT_COLOR_5"] = "--glass-ui-circle-accent-color-5";
    BrandingVariable["GLASS_UI_CIRCLE_ACCENT_COLOR_6"] = "--glass-ui-circle-accent-color-6";
    BrandingVariable["GLASS_UI_CIRCLE_ACCENT_COLOR_7"] = "--glass-ui-circle-accent-color-7";
    // Form Components
    BrandingVariable["UI_FORMS_ACCENT_COLOR"] = "--ui-forms-accent-color";
    // Border radius
    BrandingVariable["BORDER_RADIUS"] = "--border-radius";
    BrandingVariable["BTN_BORDER_RADIUS"] = "--btn-border-radius";
    BrandingVariable["UI_FORMS_BORDER_RADIUS"] = "--ui-forms-border-radius";
    // LEGACY IMAGES BELOW - delete with branding tool
    BrandingVariable["LOGO_WHITE"] = "--logo-white";
    BrandingVariable["LOGO_COLOR"] = "--logo-color";
    BrandingVariable["CREDIT_CARD_IMG"] = "--credit-card-img";
    BrandingVariable["DEBIT_CARD_IMG"] = "--debit-card-img";
    BrandingVariable["FACEBOOK_ICON"] = "--facebook-icon";
    BrandingVariable["INSTAGRAM_ICON"] = "--instagram-icon";
    BrandingVariable["LINKEDIN_ICON"] = "--linkedin-icon";
    BrandingVariable["TWITTER_ICON"] = "--twitter-icon";
    BrandingVariable["YOUTUBE_ICON"] = "--youtube-icon";
    BrandingVariable["GENERICSOCIALICON1"] = "--genericSocialIcon1";
    BrandingVariable["GENERICSOCIALICON2"] = "--genericSocialIcon2";
    BrandingVariable["GENERICSOCIALICON3"] = "--genericSocialIcon3";
    // END LEGACY IMAGES
})(BrandingVariable || (BrandingVariable = {}));

var ColorClass;
(function (ColorClass) {
    // Brand Colors
    ColorClass["SUCCESS"] = "color-success";
    ColorClass["WARNING"] = "color-warning";
    ColorClass["INFO"] = "color-info";
    ColorClass["ERROR"] = "color-error";
    // Accent Colors
    ColorClass["ACCENT_COLOR_1"] = "accent-color-1";
    ColorClass["ACCENT_COLOR_2"] = "accent-color-2";
    ColorClass["ACCENT_COLOR_3"] = "accent-color-3";
    ColorClass["ACCENT_COLOR_4"] = "accent-color-4";
    ColorClass["ACCENT_COLOR_5"] = "accent-color-5";
    ColorClass["ACCENT_COLOR_6"] = "accent-color-6";
    ColorClass["ACCENT_COLOR_7"] = "accent-color-7";
})(ColorClass || (ColorClass = {}));

var ColorVariable;
(function (ColorVariable) {
    // Brand Colors
    ColorVariable["PRIMARY"] = "--color-primary";
    ColorVariable["SECONDARY"] = "--color-secondary";
    ColorVariable["SUCCESS"] = "--color-success";
    ColorVariable["INFO"] = "--color-info";
    ColorVariable["WARNING"] = "--color-warning";
    ColorVariable["ERROR"] = "--color-danger";
    // Balance Colors
    ColorVariable["POSITIVE_COLOR"] = "--color-positive";
    ColorVariable["NEGATIVE_COLOR"] = "--color-negative";
    // Accent Colors
    ColorVariable["ACCENT_COLOR_1"] = "--color-account-1";
    ColorVariable["ACCENT_COLOR_2"] = "--color-account-2";
    ColorVariable["ACCENT_COLOR_3"] = "--color-account-3";
    ColorVariable["ACCENT_COLOR_4"] = "--color-account-4";
    ColorVariable["ACCENT_COLOR_5"] = "--color-account-5";
    ColorVariable["ACCENT_COLOR_6"] = "--color-account-6";
    ColorVariable["ACCENT_COLOR_7"] = "--color-account-7";
    // Grays
    ColorVariable["GRAY_100"] = "--color-gray-100";
    ColorVariable["GRAY_200"] = "--color-gray-200";
    ColorVariable["GRAY_300"] = "--color-gray-300";
    ColorVariable["GRAY_400"] = "--color-gray-400";
    ColorVariable["GRAY_500"] = "--color-gray-500";
    ColorVariable["GRAY_600"] = "--color-gray-600";
    ColorVariable["GRAY_700"] = "--color-gray-700";
    ColorVariable["GRAY_800"] = "--color-gray-800";
    ColorVariable["GRAY_900"] = "--color-gray-900";
})(ColorVariable || (ColorVariable = {}));

var ContrastStandard;
(function (ContrastStandard) {
    ContrastStandard["THREE_TO_ONE"] = "3";
    ContrastStandard["DOUBLE_A"] = "4.5";
    ContrastStandard["TRIPLE_A"] = "7";
})(ContrastStandard || (ContrastStandard = {}));

// These are native variables that are not modified via branding or theming.
// These are applied at the root of the document only.
var RootVariable;
(function (RootVariable) {
    // Layout & Scaling
    RootVariable["REM_SCALE"] = "--rem-scale";
    RootVariable["ANDROID_REM_SCALE"] = "--android-rem-scale";
    RootVariable["FDIC_HEADER_HEIGHT"] = "--fdic-header-height";
})(RootVariable || (RootVariable = {}));

class AdaUtils {
    static contrastTest(contrast, contrastStandard) {
        if (contrast >= parseFloat(contrastStandard)) {
            return true;
        }
        return false;
    }
    static getFontScale() {
        return parseFloat(document.documentElement.style.getPropertyValue(RootVariable.REM_SCALE)) || 1;
    }
    static isReducedMotionDevice() {
        return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    }
    static setDisableAnimations(force = false) {
        const disabled = force || this.isReducedMotionDevice();
        document.body.classList.toggle('animations-disabled', disabled);
        return disabled;
    }
}

/* eslint-disable max-classes-per-file */
class ColorObject {
}
class ColorVariation {
}
const WHITE_HEX = '#FFFFFF';
const hexRegEx = /^(#[A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/;
// calculation methods from https://jsfiddle.net/enjinoir/7ek82h3v/543/
// values used are from https://www.w3.org/WAI/WCAG21/Techniques/general/G18#tests
class ColorUtils {
    static normalize(rgb) {
        const rgbObj = {
            red: Math.round(rgb.red * 255),
            green: Math.round(rgb.green * 255),
            blue: Math.round(rgb.blue * 255),
        };
        return rgbObj;
    }
    // convert hex to rgb
    static hexToRGB(hex) {
        let hexValue = hex.toString().replace('#', '');
        const r = parseInt(hexValue.substring(0, 2), 16);
        const g = parseInt(hexValue.substring(2, 4), 16);
        const b = parseInt(hexValue.substring(4, 6), 16);
        const rgbObj = {
            red: r / 255,
            green: g / 255,
            blue: b / 255,
        };
        return rgbObj;
    }
    // convert red, blue, or green number values to hex
    static rgbToHex(value) {
        let hex = Number(value).toString(16).toUpperCase();
        if (hex.length < 2) {
            hex = `0${hex}`;
        }
        return hex;
    }
    // checks if string is a hex color
    static isHexCode(hex) {
        return hexRegEx.test(hex);
    }
    // normalize color for the w3 contrast check
    static normalizeColor(value) {
        let color = value;
        if (color <= 0.03928) {
            color /= 12.92;
        }
        else {
            color = ((color + 0.055) / 1.055) ** 2.4;
        }
        return color;
    }
    // get the luminance value for checking the contrast ratio
    static getLuminance(hex) {
        let rgbObj = this.hexToRGB(hex);
        rgbObj.red = this.normalizeColor(rgbObj.red);
        rgbObj.green = this.normalizeColor(rgbObj.green);
        rgbObj.blue = this.normalizeColor(rgbObj.blue);
        const luminance = 0.2126 * rgbObj.red + 0.7152 * rgbObj.green + 0.0722 * rgbObj.blue;
        return luminance;
    }
    // convert the color obj used to a proper hex color
    static fullColorHex(rgb) {
        const red = this.rgbToHex(rgb.red);
        const green = this.rgbToHex(rgb.green);
        const blue = this.rgbToHex(rgb.blue);
        return red + green + blue;
    }
    // checks that the values returned are non negative
    static zeroValueCheck(rgb) {
        const rgbObj = {
            red: rgb.red < 0 ? 0 : rgb.red,
            green: rgb.green < 0 ? 0 : rgb.green,
            blue: rgb.blue < 0 ? 0 : rgb.blue,
        };
        return rgbObj;
    }
    // checks that the values returned are not above 255
    static maxValueCheck(rgb) {
        const rgbObj = {
            red: rgb.red > 255 ? 255 : rgb.red,
            green: rgb.green > 255 ? 255 : rgb.green,
            blue: rgb.blue > 255 ? 255 : rgb.blue,
        };
        return rgbObj;
    }
    // generate shade hex values
    static darkenValues(hex, amount) {
        let colorSource = new ColorObject();
        const darkenByAmount = Math.round(255 * amount / 100);
        colorSource = this.hexToRGB(hex);
        colorSource = this.normalize(colorSource);
        colorSource.red -= darkenByAmount;
        colorSource.green -= darkenByAmount;
        colorSource.blue -= darkenByAmount;
        colorSource = this.zeroValueCheck(colorSource);
        const outputColor = this.fullColorHex(colorSource);
        return `#${outputColor}`;
    }
    // generate tint hex values
    static lightenValues(hex, amount) {
        let colorSource = new ColorObject();
        const lightenByAmount = Math.round(255 * amount / 100);
        colorSource = this.hexToRGB(hex);
        colorSource = this.normalize(colorSource);
        colorSource.red += lightenByAmount;
        colorSource.green += lightenByAmount;
        colorSource.blue += lightenByAmount;
        colorSource = this.maxValueCheck(colorSource);
        const outputColor = this.fullColorHex(colorSource);
        return `#${outputColor}`;
    }
    static getContrast(c1, c2) {
        let color1 = this.getLuminance(c1);
        let color2 = this.getLuminance(c2);
        let contrast = color1 > color2 ? ((color1 + 0.05) / (color2 + 0.05)) : ((color2 + 0.05) / (color1 + 0.05));
        contrast = Math.round(contrast * 100) / 100;
        return contrast;
    }
    static getContrastWhiteBg(fg) {
        return this.getContrast(WHITE_HEX, fg);
    }
}

const DEFAULT_MATERIAL_SYMBOL_CONFIG = {
    fill: 'Filled',
    radius: 'Sharp',
    weight: 'Regular',
};
function getMaterialSymbolFontFamily(config) {
    return `Material Symbols ${config.radius} ${config.fill} ${config.weight}`;
}

const DARK_MODE_DEFAULTS = new Map([
    [BrandingVariable.BRAND_PRIMARY, '#FBFBFB'],
    [BrandingVariable.BRAND_PRIMARY_DARK, '#F5F5F5'],
    [BrandingVariable.BRAND_PRIMARY_LIGHT, '#FCFCFC'],
    [BrandingVariable.BRAND_NEUTRAL, '#FBFBFB'],
    [BrandingVariable.BRAND_SECONDARY, '#52DB8F'],
    [BrandingVariable.BRAND_SECONDARY_LIGHT, '#9EFABE'],
    [BrandingVariable.BRAND_BACKGROUND, '#262626'],
    [BrandingVariable.ACCENT_COLOR_1, '#00A2B8'],
    [BrandingVariable.ACCENT_COLOR_2, '#0191A4'],
    [BrandingVariable.ACCENT_COLOR_3, '#018090'],
    [BrandingVariable.ACCENT_COLOR_4, '#017785'],
    [BrandingVariable.ACCENT_COLOR_5, '#026E7B'],
    [BrandingVariable.ACCENT_COLOR_6, '#026671'],
    [BrandingVariable.ACCENT_COLOR_7, '#025D67'],
    [BrandingVariable.POSITIVE_COLOR, '#84CDBF'],
    [BrandingVariable.NEGATIVE_COLOR, '#CD8C84'],
    [BrandingVariable.CASH_FLOW_POS_COLOR, '#84CDBF'],
    [BrandingVariable.CASH_FLOW_NEG_COLOR, '#CD8C84'],
    [BrandingVariable.SUCCESS, '#84CDBF'],
    [BrandingVariable.SUCCESS_TEXT, '#1A1A1A'],
    [BrandingVariable.INFO, '#84B7CD'],
    [BrandingVariable.INFO_TEXT, '#1A1A1A'],
    [BrandingVariable.WARNING, '#CDBB84'],
    [BrandingVariable.WARNING_TEXT, '#FBFBFB'],
    [BrandingVariable.DANGER, '#CD8C84'],
    [BrandingVariable.DANGER_TEXT, '#1A1A1A'],
    [BrandingVariable.LINK_COLOR, '#FBFBFB'],
    [BrandingVariable.LINK_HOVER_COLOR, '#FFFFFF'],
    [BrandingVariable.HOVER_COLOR, 'rgba(32, 32, 32, 0.08)'],
    [BrandingVariable.BTN_PRIMARY, '#005A66'],
    [BrandingVariable.BTN_PRIMARY_GRADIENT, '#005A66'],
    [BrandingVariable.BTN_PRIMARY_BORDER, '#005A66'],
    [BrandingVariable.BTN_PRIMARY_TEXT, '#FBFBFB'],
    [BrandingVariable.BTN_PRIMARY_HOVER, '#177D71'],
    [BrandingVariable.BTN_PRIMARY_HOVER_GRADIENT, '#177D71'],
    [BrandingVariable.BTN_PRIMARY_HOVER_BORDER, '#177D71'],
    [BrandingVariable.BTN_PRIMARY_HOVER_TEXT, '#FBFBFB'],
    [BrandingVariable.BTN_PRIMARY_ACTIVE, '#01454E'],
    [BrandingVariable.BTN_PRIMARY_ACTIVE_GRADIENT, '#01454E'],
    [BrandingVariable.BTN_PRIMARY_ACTIVE_BORDER, '#01454E'],
    [BrandingVariable.BTN_PRIMARY_ACTIVE_TEXT, '#FBFBFB'],
    [BrandingVariable.BTN_SECONDARY, '#EBEEEF'],
    [BrandingVariable.BTN_SECONDARY_GRADIENT, '#EBEEEF'],
    [BrandingVariable.BTN_SECONDARY_BORDER, '#005A66'],
    [BrandingVariable.BTN_SECONDARY_TEXT, '#6B6B6B'],
    [BrandingVariable.BTN_SECONDARY_HOVER, '#3B3B3B'],
    [BrandingVariable.BTN_SECONDARY_HOVER_GRADIENT, '#3B3B3B'],
    [BrandingVariable.BTN_SECONDARY_HOVER_BORDER, '#005A66'],
    [BrandingVariable.BTN_SECONDARY_HOVER_TEXT, '#FBFBFB'],
    [BrandingVariable.BTN_SECONDARY_ACTIVE, '#292929'],
    [BrandingVariable.BTN_SECONDARY_ACTIVE_GRADIENT, '#292929'],
    [BrandingVariable.BTN_SECONDARY_ACTIVE_BORDER, '#005A66'],
    [BrandingVariable.BTN_SECONDARY_ACTIVE_TEXT, '#FBFBFB'],
    [BrandingVariable.BTN_DISABLED, '#525252'],
    [BrandingVariable.BTN_DISABLED_TEXT, '#8C8C8C'],
    [BrandingVariable.BTN_NAVIGATION_ACTIVE, '#333333'],
    [BrandingVariable.BTN_NAVIGATION_ACTIVE_TEXT, '#FBFBFB'],
    [BrandingVariable.BTN_NAVIGATION_HOVER, '#333333'],
    [BrandingVariable.BTN_NAVIGATION_HOVER_TEXT, '#FBFBFB'],
    [BrandingVariable.NAV_SEARCH_FILL_ACTIVE, '#404040'],
    [BrandingVariable.NAV_SEARCH_TEXT_ACTIVE, '#FBFBFB'],
    [BrandingVariable.NAV_SEARCH_ICON_ACTIVE, '#FBFBFB'],
    [BrandingVariable.NAV_SEARCH_FILL_INACTIVE, '#333333'],
    [BrandingVariable.NAV_SEARCH_TEXT_INACTIVE, '#8C8C8C'],
    [BrandingVariable.NAV_SEARCH_ICON_INACTIVE, '#8C8C8C'],
    [BrandingVariable.NAV_SEARCH_HINT_TEXT, '#8C8C8C'],
    [BrandingVariable.NAV_SEARCH_MOBILE_CLOSE_ICON, '#8C8C8C'],
    [BrandingVariable.PENDING_FILL, '#262626'],
    [BrandingVariable.PENDING_TEXT, '#FBFBFB'],
    [BrandingVariable.GLASS_UI_CIRCLE_PRIMARY_COLOR, '#002429'],
    [BrandingVariable.GLASS_UI_CIRCLE_SECONDARY_COLOR, '#52DB8F'],
    [BrandingVariable.GLASS_UI_CIRCLE_TERTIARY_COLOR, '#007180'],
    [BrandingVariable.GLASS_UI_CIRCLE_ACCENT_COLOR_1, '#00A2B8'],
    [BrandingVariable.GLASS_UI_CIRCLE_ACCENT_COLOR_2, '#0191A4'],
    [BrandingVariable.GLASS_UI_CIRCLE_ACCENT_COLOR_3, '#018090'],
    [BrandingVariable.GLASS_UI_CIRCLE_ACCENT_COLOR_4, '#017785'],
    [BrandingVariable.GLASS_UI_CIRCLE_ACCENT_COLOR_5, '#026E7B'],
    [BrandingVariable.GLASS_UI_CIRCLE_ACCENT_COLOR_6, '#026671'],
    [BrandingVariable.GLASS_UI_CIRCLE_ACCENT_COLOR_7, '#025D67'],
    [BrandingVariable.UI_FORMS_ACCENT_COLOR, '#9EFABE'],
]);
const CUSTOMIZABLE_BRANDING_VARIABLES = new Set([
    // Brand Colors
    BrandingVariable.BRAND_SECONDARY,
    // Accent Colors
    BrandingVariable.ACCENT_COLOR_1,
    BrandingVariable.ACCENT_COLOR_2,
    BrandingVariable.ACCENT_COLOR_3,
    BrandingVariable.ACCENT_COLOR_4,
    BrandingVariable.ACCENT_COLOR_5,
    BrandingVariable.ACCENT_COLOR_6,
    BrandingVariable.ACCENT_COLOR_7,
    // Balance Colors
    BrandingVariable.POSITIVE_COLOR,
    BrandingVariable.NEGATIVE_COLOR,
    // Cash Flow Colors
    BrandingVariable.CASH_FLOW_POS_COLOR,
    BrandingVariable.CASH_FLOW_NEG_COLOR,
    // Alert and Form Validation Colors
    BrandingVariable.SUCCESS,
    BrandingVariable.INFO,
    BrandingVariable.WARNING,
    BrandingVariable.DANGER,
    // Alert Text Colors
    BrandingVariable.SUCCESS_TEXT,
    BrandingVariable.INFO_TEXT,
    BrandingVariable.WARNING_TEXT,
    BrandingVariable.DANGER_TEXT,
    // Link Text Colors
    BrandingVariable.LINK_COLOR,
    BrandingVariable.LINK_HOVER_COLOR,
    // Primary Button
    BrandingVariable.BTN_PRIMARY,
    BrandingVariable.BTN_PRIMARY_GRADIENT,
    BrandingVariable.BTN_PRIMARY_BORDER,
    BrandingVariable.BTN_PRIMARY_TEXT,
    BrandingVariable.BTN_PRIMARY_HOVER,
    BrandingVariable.BTN_PRIMARY_HOVER_GRADIENT,
    BrandingVariable.BTN_PRIMARY_HOVER_BORDER,
    BrandingVariable.BTN_PRIMARY_HOVER_TEXT,
    BrandingVariable.BTN_PRIMARY_ACTIVE,
    BrandingVariable.BTN_PRIMARY_ACTIVE_GRADIENT,
    BrandingVariable.BTN_PRIMARY_ACTIVE_BORDER,
    BrandingVariable.BTN_PRIMARY_ACTIVE_TEXT,
    // Secondary Button
    BrandingVariable.BTN_SECONDARY,
    BrandingVariable.BTN_SECONDARY_GRADIENT,
    BrandingVariable.BTN_SECONDARY_BORDER,
    BrandingVariable.BTN_SECONDARY_TEXT,
    BrandingVariable.BTN_SECONDARY_HOVER,
    BrandingVariable.BTN_SECONDARY_HOVER_GRADIENT,
    BrandingVariable.BTN_SECONDARY_HOVER_BORDER,
    BrandingVariable.BTN_SECONDARY_HOVER_TEXT,
    BrandingVariable.BTN_SECONDARY_ACTIVE,
    BrandingVariable.BTN_SECONDARY_ACTIVE_GRADIENT,
    BrandingVariable.BTN_SECONDARY_ACTIVE_BORDER,
    BrandingVariable.BTN_SECONDARY_ACTIVE_TEXT,
    // Glass Circles
    BrandingVariable.GLASS_UI_CIRCLE_PRIMARY_COLOR,
    BrandingVariable.GLASS_UI_CIRCLE_SECONDARY_COLOR,
    BrandingVariable.GLASS_UI_CIRCLE_TERTIARY_COLOR,
    // Glass Circle Colors
    BrandingVariable.GLASS_UI_CIRCLE_ACCENT_COLOR_1,
    BrandingVariable.GLASS_UI_CIRCLE_ACCENT_COLOR_2,
    BrandingVariable.GLASS_UI_CIRCLE_ACCENT_COLOR_3,
    BrandingVariable.GLASS_UI_CIRCLE_ACCENT_COLOR_4,
    BrandingVariable.GLASS_UI_CIRCLE_ACCENT_COLOR_5,
    BrandingVariable.GLASS_UI_CIRCLE_ACCENT_COLOR_6,
    BrandingVariable.GLASS_UI_CIRCLE_ACCENT_COLOR_7,
    // Form Components
    BrandingVariable.UI_FORMS_ACCENT_COLOR,
]);
class DarkModeUtils {
    static getVariables(theme) {
        const result = new Map();
        Object.values(BaseVariable).forEach(baseVar => {
            const value = DARK_MODE_DEFAULTS.get(baseVar) || '';
            if (value) {
                result.set(baseVar, value);
            }
        });
        Object.values(BrandingVariable).forEach(brandingVar => {
            const defaultValue = DARK_MODE_DEFAULTS.get(brandingVar) || '';
            if (defaultValue) {
                if (this.variableCanBeThemed(brandingVar) && theme) {
                    const value = theme[brandingVar] || defaultValue;
                    result.set(brandingVar, value);
                }
                else {
                    result.set(brandingVar, defaultValue);
                }
            }
        });
        return result;
    }
    // Not all branding variables are allowed to be customized when used for dark mode.
    static variableCanBeThemed(variable) {
        return CUSTOMIZABLE_BRANDING_VARIABLES.has(variable);
    }
}

class NativeVariableUtils {
    // Cache variables. Hopefully this is a performance increase vs. querying the DOM each time.
    static { this.cachedBrandingVariables = new Map(); }
    static { this.cachedBaseVariables = new Map(); }
    // TODO: remove this. Keeping it as a separate cache for easier deletion.
    static { this.cachedCustomVariables = new Map(); }
    /* Get Variable Values */
    static getBrandingValue(variable) {
        return this.cachedBrandingVariables.get(variable) || this.getComputedVariableValue(variable, this.cachedBrandingVariables);
    }
    // TODO: The string option is required for custom card images.
    // Can be removed after the branding tool hosts images.
    static getCustomValue(variable) {
        if (!variable) {
            return '';
        }
        const formattedName = this.formatNativeVariable(variable);
        return this.cachedCustomVariables.get(formattedName) || this.getComputedVariableValue(formattedName, this.cachedCustomVariables);
    }
    static getAccentColorValue(index) {
        let variable = BrandingVariable.ACCENT_COLOR_1;
        switch (index) {
            case 2:
                variable = BrandingVariable.ACCENT_COLOR_2;
                break;
            case 3:
                variable = BrandingVariable.ACCENT_COLOR_3;
                break;
            case 4:
                variable = BrandingVariable.ACCENT_COLOR_4;
                break;
            case 5:
                variable = BrandingVariable.ACCENT_COLOR_5;
                break;
            case 6:
                variable = BrandingVariable.ACCENT_COLOR_6;
                break;
            case 7:
                variable = BrandingVariable.ACCENT_COLOR_7;
                break;
        }
        return this.getBrandingValue(variable);
    }
    // TODO: eventually, refactor method below to use COLOR_CHART values from the BrandingTokens file
    static getChartColorValue(index) {
        return this.getAccentColorValue(index);
    }
    static getMobileStatusBarColor() {
        // Right now this is the only base variable exposed.
        // This may change with dark mode, but for now - limiting exposure to as-needed for base variables.
        return this.cachedBaseVariables.get(BaseVariable.NEUTRAL_BG_COLOR) || this.getComputedVariableValue(BaseVariable.NEUTRAL_BG_COLOR, this.cachedBaseVariables);
    }
    static getConditionalBorderRadius(nonZeroValue) {
        if (nonZeroValue <= 0) {
            return 0;
        }
        const brandingValue = this.getBrandingValue(BrandingVariable.BORDER_RADIUS) || '';
        // Strip out all non-numeric. This will also remove decimals, but the intent is to find out if it's zero.
        // So 8.5 will be treated as 85, which is fine for this use case.
        const digitsOnly = StringUtils.stripNonNumeric(brandingValue) || '0';
        const borderRadius = parseInt(digitsOnly, 10);
        return borderRadius === 0 ? 0 : nonZeroValue;
    }
    /* Modify Variables */
    static setThemeVariables(variables, element = null) {
        if (!element) {
            // Clear the cache if we are applying to the body.
            this.clearCachedVariables();
        }
        const elementToModify = element || document.body;
        // Use the variables map to ensure unique entries
        Object.entries(variables).forEach(([key, value]) => {
            const formattedName = this.formatNativeVariable(key);
            if (Object.values(BrandingVariable).includes(formattedName)) {
                this.cachedBrandingVariables.set(formattedName, value);
            }
            else {
                // TODO: This is a hacky workaround while we allow custom card images for themes.
                // This entire Object.entries loop should be replaced with the commented out loop below.
                const isBaseVar = Object.values(BaseVariable).includes(formattedName);
                if (!isBaseVar) {
                    this.cachedCustomVariables.set(formattedName, value);
                }
            }
        });
        /* TODO: Use something like this in future version where custom variables don't exist, that way we can optimize the loops.
        Object.values(BrandingVariable).forEach(key => {
            const value = variables[key];
            if (value) {
                elementToModify.style.setProperty(key, value);
            }
        });
        */
        this.cachedBrandingVariables.forEach((value, key) => {
            elementToModify.style.setProperty(key, value);
        });
        this.cachedCustomVariables.forEach((value, key) => {
            elementToModify.style.setProperty(key, value);
        });
    }
    static setDarkModeVariables(variables, element = null) {
        if (!element) {
            // Clear the cache if we are applying to the body.
            this.clearCachedVariables();
        }
        const elementToModify = element || document.body;
        const darkModeVars = DarkModeUtils.getVariables(variables);
        // TODO: consider rebuilding the caches. Ultimately there should probably just be one cache of
        // body variables. For now, this is just a PoC so keeping it simple.
        darkModeVars.forEach((value, key) => {
            elementToModify.style.setProperty(key, value);
        });
    }
    static removeVariables(element = null) {
        const elementToModify = element || document.body;
        Object.values(BrandingVariable).forEach(key => {
            elementToModify.style.removeProperty(key);
        });
        Object.values(BaseVariable).forEach(key => {
            elementToModify.style.removeProperty(key);
        });
        this.cachedCustomVariables.forEach((value, key) => {
            elementToModify.style.removeProperty(key);
        });
        // Reset the caches
        if (!element) {
            this.clearCachedVariables();
        }
    }
    /* Private/Protected Helpers */
    static clearCachedVariables() {
        // Always clear the themed variables
        this.cachedBrandingVariables.clear();
        this.cachedCustomVariables.clear();
        this.cachedBaseVariables.clear();
    }
    static getComputedVariableValue(variable, map) {
        // Read the "computed" style from the body, more like a "runtime value".
        // For example, color variables should return a hex value even if the variable is referencing a different variable.
        const styles = window.getComputedStyle(document.body);
        const result = (styles.getPropertyValue(variable) || '').trim();
        // If we found it, stash it away so it can be retrieved from the map.
        if (result && map) {
            map.set(variable, result);
        }
        return result;
    }
    static formatNativeVariable(variable) {
        const cssVariableRegex = /^--/gm;
        const result = variable.match(cssVariableRegex);
        if (!result) {
            return `--${variable}`;
        }
        return variable;
    }
}

class StyleInjectionUtils {
    static injectBundle(bundleName, bundleVersion, testClass = '') {
        const uniqueName = `${bundleName}-v${bundleVersion}`;
        this.createLink(`bundle-${uniqueName}`, `${uniqueName}.css`);
        // If a test class is provided, inject a simple div to force these styles to load
        if (testClass) {
            this.injectAndDestroyTestClass(testClass, uniqueName);
        }
    }
    static injectCss(id, css) {
        this.createLink(id, `data:text/css;charset=UTF-8,${encodeURIComponent(css)}`);
    }
    static elementExists(id) {
        return !!document.getElementById(id);
    }
    static createLink(id, href) {
        if (this.elementExists(id)) {
            return;
        }
        const linkElement = document.createElement('link');
        linkElement.setAttribute('id', id);
        linkElement.setAttribute('rel', 'stylesheet');
        linkElement.setAttribute('type', 'text/css');
        linkElement.setAttribute('href', href);
        document.head.appendChild(linkElement);
    }
    static injectAndDestroyTestClass(testClass, bundleName) {
        const id = `${bundleName}-test-div`;
        const styles = 'height: 0; width: 0; opacity: 0; position: absolute; top: -1000px; left: -1000px';
        const element = document.getElementById(id);
        if (element) {
            document.body.removeChild(element);
        }
        const divElement = document.createElement('div');
        divElement.setAttribute('id', id);
        divElement.innerText = 'injecting style...';
        divElement.setAttribute('style', styles);
        divElement.className = testClass;
        const testElement = document.body.appendChild(divElement);
        setTimeout(() => testElement.remove(), 100);
    }
}

// enums

class UiStylesModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: UiStylesModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.17", ngImport: i0, type: UiStylesModule, imports: [CommonModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: UiStylesModule, imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: UiStylesModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule]
                }]
        }] });

/*
 * Public API Surface of ui-styles
 */
// Components and Common

/**
 * Generated bundle index. Do not edit.
 */

export { AdaUtils, BackgroundColorClass, BaseVariable, BrandingTokens, BrandingVariable, ColorClass, ColorObject, ColorUtils, ColorVariable, ColorVariation, ContrastStandard, DEFAULT_MATERIAL_SYMBOL_CONFIG, NativeVariableUtils, RootVariable, StyleInjectionUtils, UiStylesModule, WHITE_HEX, getMaterialSymbolFontFamily, hexRegEx };
//# sourceMappingURL=a3-digital-ui-styles.mjs.map
