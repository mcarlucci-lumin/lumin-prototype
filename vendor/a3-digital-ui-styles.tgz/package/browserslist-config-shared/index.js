/*

This file is used by the build system to adjust CSS and JS output to support the specified browsers below.
For additional information regarding the format and rule options, please see:
https://github.com/browserslist/browserslist#queries

You can see what browsers were selected by your queries by running:
npx browserslist

For additional information regarding this shared config file, please see:
https://github.com/browserslist/browserslist?tab=readme-ov-file#shareable-configs

*/

module.exports = [
    'last 2 Chrome versions',
    'last 2 Firefox versions',
    'last 2 Edge versions',
    'Safari >= 18.2',
    'iOS >= 16',
    'last 3 ChromeAndroid major versions'
];
