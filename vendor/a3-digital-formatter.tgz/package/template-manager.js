import handleBars from 'handlebars';
import { HandleBarsTemplate } from './handle-bars-template.js';
import { DateUtils } from '@a3-digital/date-utils';
import { StringUtils } from '@a3-digital/utils';
import moment from 'moment-timezone';
import { globalSettings } from '@a3-digital/configurability';
export class TemplateManager {
    static { this._loaded = false; }
    static { this._formatter = new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }); }
    // drop the .00 For some amounts, the .00 is just noise (e.g, RDC Limits)
    static { this._dollarFormatter = new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }); }
    constructor() {
        if (!TemplateManager._loaded) {
            TemplateManager._loaded = true;
            handleBars.registerHelper('ltrim', (value, char) => {
                if (!value) {
                    return '';
                }
                if (!this.isParamProvided(char)) {
                    return value;
                }
                let regexString = `[^${char}].*`;
                let regExp = new RegExp(regexString);
                let results = value.match(regExp);
                if (!results || !results.length) {
                    return value;
                }
                return results[0];
            });
            handleBars.registerHelper('rtrim', (value, char) => {
                if (!value) {
                    return '';
                }
                if (!this.isParamProvided(char)) {
                    return value;
                }
                let regexString = `.+[^${char}]`;
                let regExp = new RegExp(regexString);
                let results = value.match(regExp);
                if (!results || !results.length) {
                    return value;
                }
                return results[0];
            });
            handleBars.registerHelper('trim', (value) => {
                if (!value) {
                    return '';
                }
                if (typeof value === 'string') {
                    return value.trim();
                }
                return ('' + value).trim(); // Convert to string if needed
            });
            handleBars.registerHelper('uppercase', (value) => {
                if (!value) {
                    return '';
                }
                return ('' + value).toUpperCase();
            });
            handleBars.registerHelper('lowercase', (value) => {
                if (!value) {
                    return '';
                }
                return ('' + value).toLowerCase();
            });
            handleBars.registerHelper('capitalize', (value) => {
                if (!value) {
                    return '';
                }
                const str = '' + value;
                // Capitalize first letter of each word
                return str.replace(/\b\w/g, (char) => char.toUpperCase());
            });
            handleBars.registerHelper('currency', (amount) => {
                if (isNaN(amount)) {
                    amount = 0;
                }
                return TemplateManager._formatter.format(amount);
            });
            handleBars.registerHelper('dollars', (amount) => {
                if (isNaN(amount)) {
                    amount = 0;
                }
                return TemplateManager._dollarFormatter.format(amount);
            });
            handleBars.registerHelper('percent', (amount, minDecimalPlaces, maxDecimalPlaces) => {
                if (isNaN(amount)) {
                    amount = 0;
                }
                let minDecimalLength = this.isParamProvided(minDecimalPlaces) ? minDecimalPlaces : 0;
                let maxDecimalLength = this.isParamProvided(maxDecimalPlaces) ? maxDecimalPlaces : 5;
                return Number(amount).toLocaleString('en-US', { style: 'percent', minimumFractionDigits: minDecimalLength, maximumFractionDigits: maxDecimalLength });
            });
            handleBars.registerHelper('number', (value, decimals) => {
                const num = Number(value);
                if (isNaN(num)) {
                    return '0';
                }
                // Default to 0 decimal places if not provided
                const decimalPlaces = this.isParamProvided(decimals) ? Number(decimals) : 0;
                const validDecimals = isNaN(decimalPlaces) || decimalPlaces < 0 ? 0 : decimalPlaces;
                return num.toLocaleString('en-US', {
                    minimumFractionDigits: validDecimals,
                    maximumFractionDigits: validDecimals
                });
            });
            handleBars.registerHelper('date', (date, dateFormat) => {
                if (!date) {
                    return '';
                }
                dateFormat = this.isParamProvided(dateFormat) ? dateFormat : 'MM/DD/YYYY';
                return DateUtils.getFIDateFormatString(date, dateFormat);
            });
            handleBars.registerHelper('dateNowAtFI', (dateFormat) => {
                const fiDateTime = DateUtils.getFIDateTimeAsMoment().toDate();
                if (!this.isParamProvided(dateFormat)) {
                    return moment.tz(fiDateTime, globalSettings.fiTimeZone).format(); // ISO format with FI timezone offset
                }
                return DateUtils.getFIDateFormatString(fiDateTime, dateFormat);
            });
            handleBars.registerHelper('dateNowAtUtc', (dateFormat) => {
                const currentDateTime = new Date();
                if (!this.isParamProvided(dateFormat)) {
                    return currentDateTime.toISOString(); // ISO format in UTC
                }
                return DateUtils.getDateFormatString(currentDateTime, dateFormat);
            });
            handleBars.registerHelper('toUtcDate', (date, dateFormat) => {
                if (!date) {
                    return '';
                }
                const dateValue = new Date(date);
                if (isNaN(dateValue.getTime())) {
                    return '';
                }
                if (!this.isParamProvided(dateFormat)) {
                    return dateValue.toISOString(); // Returns UTC date in ISO format
                }
                // Use moment.utc to ensure formatting in UTC timezone
                return moment.utc(dateValue).format(dateFormat);
            });
            handleBars.registerHelper('toFiDate', (date, dateFormat) => {
                if (!date) {
                    return '';
                }
                const dateValue = new Date(date);
                if (!this.isParamProvided(dateFormat)) {
                    return moment.tz(dateValue, globalSettings.fiTimeZone).format(); // Returns ISO format with FI timezone offset
                }
                return DateUtils.getFIDateFormatString(dateValue, dateFormat);
            });
            handleBars.registerHelper('firstDayOfWeek', (date, dateFormat) => {
                if (!date) {
                    return '';
                }
                const dateValue = new Date(date);
                if (isNaN(dateValue.getTime())) {
                    return '';
                }
                const m = moment.tz(dateValue, globalSettings.fiTimeZone);
                const firstDay = m.startOf('week').toDate();
                if (!this.isParamProvided(dateFormat)) {
                    return moment.tz(firstDay, globalSettings.fiTimeZone).format(); // ISO format with FI timezone offset
                }
                return DateUtils.getFIDateFormatString(firstDay, dateFormat);
            });
            handleBars.registerHelper('lastDayOfWeek', (date, dateFormat) => {
                if (!date) {
                    return '';
                }
                const dateValue = new Date(date);
                if (isNaN(dateValue.getTime())) {
                    return '';
                }
                const m = moment.tz(dateValue, globalSettings.fiTimeZone);
                const lastDay = m.endOf('week').toDate();
                if (!this.isParamProvided(dateFormat)) {
                    return moment.tz(lastDay, globalSettings.fiTimeZone).format(); // ISO format with FI timezone offset
                }
                return DateUtils.getFIDateFormatString(lastDay, dateFormat);
            });
            handleBars.registerHelper('firstDayOfMonth', (date, dateFormat) => {
                if (!date) {
                    return '';
                }
                const dateValue = new Date(date);
                if (isNaN(dateValue.getTime())) {
                    return '';
                }
                const m = moment.tz(dateValue, globalSettings.fiTimeZone);
                const firstDay = m.startOf('month').toDate();
                if (!this.isParamProvided(dateFormat)) {
                    return moment.tz(firstDay, globalSettings.fiTimeZone).format(); // ISO format with FI timezone offset
                }
                return DateUtils.getFIDateFormatString(firstDay, dateFormat);
            });
            handleBars.registerHelper('lastDayOfMonth', (date, dateFormat) => {
                if (!date) {
                    return '';
                }
                const dateValue = new Date(date);
                if (isNaN(dateValue.getTime())) {
                    return '';
                }
                const m = moment.tz(dateValue, globalSettings.fiTimeZone);
                const lastDay = m.endOf('month').toDate();
                if (!this.isParamProvided(dateFormat)) {
                    return moment.tz(lastDay, globalSettings.fiTimeZone).format(); // ISO format with FI timezone offset
                }
                return DateUtils.getFIDateFormatString(lastDay, dateFormat);
            });
            handleBars.registerHelper('firstDayOfYear', (date, dateFormat) => {
                if (!date) {
                    return '';
                }
                const dateValue = new Date(date);
                if (isNaN(dateValue.getTime())) {
                    return '';
                }
                const m = moment.tz(dateValue, globalSettings.fiTimeZone);
                const firstDay = m.startOf('year').toDate();
                if (!this.isParamProvided(dateFormat)) {
                    return moment.tz(firstDay, globalSettings.fiTimeZone).format(); // ISO format with FI timezone offset
                }
                return DateUtils.getFIDateFormatString(firstDay, dateFormat);
            });
            handleBars.registerHelper('lastDayOfYear', (date, dateFormat) => {
                if (!date) {
                    return '';
                }
                const dateValue = new Date(date);
                if (isNaN(dateValue.getTime())) {
                    return '';
                }
                const m = moment.tz(dateValue, globalSettings.fiTimeZone);
                const lastDay = m.endOf('year').toDate();
                if (!this.isParamProvided(dateFormat)) {
                    return moment.tz(lastDay, globalSettings.fiTimeZone).format(); // ISO format with FI timezone offset
                }
                return DateUtils.getFIDateFormatString(lastDay, dateFormat);
            });
            handleBars.registerHelper('mask', (value, maskLength, maskChr) => {
                if (!value) {
                    return '';
                }
                let length = this.isParamProvided(maskLength) ? maskLength : 6;
                maskChr = this.isParamProvided(maskChr) ? maskChr : '*';
                if (!value.length || value.length <= length) {
                    return value;
                }
                value = '' + value;
                return maskChr + value.slice(value.length - length, value.length);
            });
            handleBars.registerHelper('padLeft', (value, padLength, padChr) => {
                if (this.isParamProvided(padLength) && this.isParamProvided(padChr)) {
                    if (value === undefined) {
                        value = '';
                    }
                    else {
                        value = '' + value; // force to string
                    }
                    return StringUtils.padString(value, padLength, padChr, false);
                }
                else {
                    return value;
                }
            });
            handleBars.registerHelper('left', (value, leftLength) => {
                if (this.isParamProvided(leftLength)) {
                    if (value === undefined || value === null) {
                        value = '';
                    }
                    else {
                        value = '' + value; // force to string
                    }
                    return StringUtils.left(value, leftLength);
                }
                else {
                    return value;
                }
            });
            handleBars.registerHelper('right', (value, rightLength) => {
                if (this.isParamProvided(rightLength)) {
                    if (value === undefined || value === null) {
                        value = '';
                    }
                    else {
                        value = '' + value; // force to string
                    }
                    return StringUtils.right(value, rightLength);
                }
                else {
                    return value;
                }
            });
            handleBars.registerHelper('substring', (value, start, end) => {
                if (!value) {
                    return '';
                }
                if (!value.substring) {
                    // not a string
                    return '';
                }
                let endPos = this.isParamProvided(end) ? end : undefined;
                let startPos = this.isParamProvided(start) ? start : 0;
                if (endPos) {
                    return value.substring(startPos, endPos);
                }
                else {
                    return value.substring(startPos);
                }
            });
            handleBars.registerHelper('slice', (value, start, end) => {
                if (!value) {
                    return '';
                }
                value = StringUtils.ensureIsString(value);
                let endPos = this.isParamProvided(end) ? end : undefined;
                let startPos = this.isParamProvided(start) ? start : 0;
                if (endPos) {
                    return value.slice(startPos, endPos);
                }
                else {
                    return value.slice(startPos);
                }
            });
            handleBars.registerHelper('regex', (value, regexString, desiredGroup) => {
                if (!value) {
                    return '';
                }
                if (!this.isParamProvided(regexString)) {
                    return value;
                }
                try {
                    let desiredGroupNum = this.isParamProvided(desiredGroup) ? Number(desiredGroup) : 1;
                    let regExp = new RegExp(regexString);
                    let results = value.match(regExp);
                    if (this.isParamProvided(desiredGroup) && !results) {
                        return '';
                    }
                    if (!results || !results.length) {
                        return value;
                    }
                    return results[desiredGroupNum] ? results[desiredGroupNum] : results[0];
                }
                catch (err) {
                    return value;
                }
            });
            const equalDelegate = (value, toCompare) => {
                if (!value) {
                    // if both items are falsy, they are "equal" but return true instead of the value... since the value would be falsy
                    return this.isParamProvided(toCompare) ? '' : true;
                }
                let c = this.isParamProvided(toCompare) ? toCompare : undefined;
                return value?.toString() === c?.toString() ? value : '';
            };
            handleBars.registerHelper('eq', equalDelegate); // backwards compatibility
            handleBars.registerHelper('equals', equalDelegate);
            handleBars.registerHelper('notEquals', (value, toCompare) => {
                // Handle case where both are falsy
                const valueIsFalsy = !value;
                const toCompareIsFalsy = !this.isParamProvided(toCompare);
                if (valueIsFalsy && toCompareIsFalsy) {
                    return false; // Both falsy means equal, so notEquals is false
                }
                if (valueIsFalsy || toCompareIsFalsy) {
                    return true; // One falsy, one truthy means not equal
                }
                // Both are truthy - compare as strings
                return value.toString() !== toCompare.toString();
            });
            // Numeric comparison helpers
            handleBars.registerHelper('greaterThan', (value, toCompare) => {
                const numbers = this.validateNumericArguments([value, toCompare]);
                if (!numbers) {
                    return false;
                }
                const [numValue, numToCompare] = numbers;
                return numValue > numToCompare;
            });
            handleBars.registerHelper('greaterThanOrEqualTo', (value, toCompare) => {
                const numbers = this.validateNumericArguments([value, toCompare]);
                if (!numbers) {
                    return false;
                }
                const [numValue, numToCompare] = numbers;
                return numValue >= numToCompare;
            });
            handleBars.registerHelper('lessThan', (value, toCompare) => {
                const numbers = this.validateNumericArguments([value, toCompare]);
                if (!numbers) {
                    return false;
                }
                const [numValue, numToCompare] = numbers;
                return numValue < numToCompare;
            });
            handleBars.registerHelper('lessThanOrEqualTo', (value, toCompare) => {
                const numbers = this.validateNumericArguments([value, toCompare]);
                if (!numbers) {
                    return false;
                }
                const [numValue, numToCompare] = numbers;
                return numValue <= numToCompare;
            });
            handleBars.registerHelper('between', (value, min, max) => {
                const numbers = this.validateNumericArguments([value, min, max]);
                if (numbers === null) {
                    return false;
                }
                const [numValue, numMin, numMax] = numbers;
                return numValue >= numMin && numValue <= numMax;
            });
            // Date comparison helpers (with time, FI timezone aware)
            handleBars.registerHelper('dateGreaterThan', (value, toCompare, ignoreTime) => {
                const shouldIgnoreTime = this.isParamProvided(ignoreTime) ? ignoreTime : false;
                const result = shouldIgnoreTime
                    ? this.validateDatesInFITimezoneIgnoringTime(value, toCompare)
                    : this.validateDatesInFITimezone(value, toCompare);
                if (!result) {
                    return false;
                }
                const [dateValue, dateToCompare] = result;
                return dateValue.getTime() > dateToCompare.getTime();
            });
            handleBars.registerHelper('dateGreaterThanOrEqualTo', (value, toCompare, ignoreTime) => {
                const shouldIgnoreTime = this.isParamProvided(ignoreTime) ? ignoreTime : false;
                const result = shouldIgnoreTime
                    ? this.validateDatesInFITimezoneIgnoringTime(value, toCompare)
                    : this.validateDatesInFITimezone(value, toCompare);
                if (!result) {
                    return false;
                }
                const [dateValue, dateToCompare] = result;
                return dateValue.getTime() >= dateToCompare.getTime();
            });
            handleBars.registerHelper('dateLessThan', (value, toCompare, ignoreTime) => {
                const shouldIgnoreTime = this.isParamProvided(ignoreTime) ? ignoreTime : false;
                const result = shouldIgnoreTime
                    ? this.validateDatesInFITimezoneIgnoringTime(value, toCompare)
                    : this.validateDatesInFITimezone(value, toCompare);
                if (!result) {
                    return false;
                }
                const [dateValue, dateToCompare] = result;
                return dateValue.getTime() < dateToCompare.getTime();
            });
            handleBars.registerHelper('dateLessThanOrEqualTo', (value, toCompare, ignoreTime) => {
                const shouldIgnoreTime = this.isParamProvided(ignoreTime) ? ignoreTime : false;
                const result = shouldIgnoreTime
                    ? this.validateDatesInFITimezoneIgnoringTime(value, toCompare)
                    : this.validateDatesInFITimezone(value, toCompare);
                if (!result) {
                    return false;
                }
                const [dateValue, dateToCompare] = result;
                return dateValue.getTime() <= dateToCompare.getTime();
            });
            handleBars.registerHelper('dateEqual', (value, toCompare, ignoreTime) => {
                const shouldIgnoreTime = this.isParamProvided(ignoreTime) ? ignoreTime : false;
                const result = shouldIgnoreTime
                    ? this.validateDatesInFITimezoneIgnoringTime(value, toCompare)
                    : this.validateDatesInFITimezone(value, toCompare);
                if (!result) {
                    return false;
                }
                const [dateValue, dateToCompare] = result;
                return dateValue.getTime() === dateToCompare.getTime();
            });
            handleBars.registerHelper('dateBetween', (date, minDate, maxDate, ignoreTime) => {
                const shouldIgnoreTime = this.isParamProvided(ignoreTime) ? ignoreTime : false;
                const dates = shouldIgnoreTime
                    ? this.validateMultipleDatesInFITimezoneIgnoringTime([date, minDate, maxDate])
                    : this.validateMultipleDatesInFITimezone([date, minDate, maxDate]);
                if (!dates) {
                    return false;
                }
                const [dateValue, minDateValue, maxDateValue] = dates;
                return dateValue.getTime() >= minDateValue.getTime() && dateValue.getTime() <= maxDateValue.getTime();
            });
            handleBars.registerHelper('timeUnitsBetweenDates', (date1, date2, timeUnit) => {
                if (!date1 || !date2) {
                    return null;
                }
                const dateValue1 = new Date(date1);
                const dateValue2 = new Date(date2);
                if (isNaN(dateValue1.getTime()) || isNaN(dateValue2.getTime())) {
                    return null;
                }
                if (!this.isParamProvided(timeUnit)) {
                    return null; // timeUnit is required
                }
                // Use DateUtils.diff to calculate difference in specified time units (FI timezone aware)
                return DateUtils.diff(dateValue2, dateValue1, timeUnit);
            });
            handleBars.registerHelper('addTimeUnitsToDate', (date, amount, timeUnit, dateFormat) => {
                if (!date) {
                    return '';
                }
                const dateValue = new Date(date);
                if (isNaN(dateValue.getTime())) {
                    return '';
                }
                if (!this.isParamProvided(amount) || !this.isParamProvided(timeUnit)) {
                    return ''; // amount and timeUnit are required
                }
                const numAmount = Number(amount);
                if (isNaN(numAmount)) {
                    return '';
                }
                // Add time units using moment in FI timezone
                const momentDate = moment.tz(dateValue, globalSettings.fiTimeZone);
                const resultDate = momentDate.add(numAmount, timeUnit);
                // Return ISO format by default, or use specified format
                if (!this.isParamProvided(dateFormat)) {
                    return resultDate.format(); // ISO format with FI timezone offset
                }
                return DateUtils.getFIDateFormatString(resultDate.toDate(), dateFormat);
            });
            handleBars.registerHelper('and', (...args) => {
                // Remove the handlebars options object (last argument)
                const values = args.slice(0, -1);
                return values.every(val => !!val);
            });
            handleBars.registerHelper('or', (...args) => {
                // Remove the handlebars options object (last argument)
                const values = args.slice(0, -1);
                return values.some(val => !!val);
            });
            handleBars.registerHelper('not', (value) => {
                return !value;
            });
            handleBars.registerHelper('concat', (...args) => {
                // Remove the handlebars options object (last argument)
                const values = args.slice(0, -1);
                return values.join('');
            });
            handleBars.registerHelper('sum', (...args) => {
                // Remove the handlebars options object (last argument)
                const values = args.slice(0, -1);
                const numbers = this.validateNumericArguments(values);
                if (numbers === null) {
                    return 0; // Return 0 if any value is invalid
                }
                return numbers.reduce((sum, num) => sum + num, 0);
            });
            handleBars.registerHelper('subtract', (...args) => {
                // Remove the handlebars options object (last argument)
                const values = args.slice(0, -1);
                const numbers = this.validateNumericArguments(values);
                if (numbers === null) {
                    return 0; // Return 0 if any value is invalid
                }
                if (numbers.length === 0) {
                    return 0;
                }
                // Start with first number, subtract all subsequent numbers
                return numbers.slice(1).reduce((result, num) => result - num, numbers[0]);
            });
            handleBars.registerHelper('multiply', (...args) => {
                // Remove the handlebars options object (last argument)
                const values = args.slice(0, -1);
                const numbers = this.validateNumericArguments(values);
                if (numbers === null) {
                    return 0; // Return 0 if any value is invalid
                }
                if (numbers.length === 0) {
                    return 0;
                }
                // Multiply all numbers together
                return numbers.reduce((result, num) => result * num, 1);
            });
            handleBars.registerHelper('divide', (...args) => {
                // Remove the handlebars options object (last argument)
                const values = args.slice(0, -1);
                const numbers = this.validateNumericArguments(values);
                if (numbers === null) {
                    return 0; // Return 0 if any value is invalid
                }
                if (numbers.length === 0) {
                    return 0;
                }
                // Start with first number, divide by all subsequent numbers
                const result = numbers.slice(1).reduce((acc, num) => {
                    if (num === 0) {
                        return null; // Division by zero
                    }
                    return acc / num;
                }, numbers[0]);
                return result;
            });
            handleBars.registerHelper('abs', (value) => {
                const num = Number(value);
                if (isNaN(num)) {
                    return 0; // Return 0 if value is invalid
                }
                return Math.abs(num);
            });
            handleBars.registerHelper('round', (value, decimalPlaces) => {
                const num = Number(value);
                if (isNaN(num)) {
                    return 0; // Return 0 if value is invalid
                }
                // If no decimal places provided, round to nearest integer
                if (!this.isParamProvided(decimalPlaces)) {
                    return Math.round(num);
                }
                const decimals = Number(decimalPlaces);
                if (isNaN(decimals) || decimals < 0) {
                    return Math.round(num); // Default to integer if invalid
                }
                const multiplier = Math.pow(10, decimals);
                return Math.round(num * multiplier) / multiplier;
            });
            handleBars.registerHelper('avg', (...args) => {
                // Remove the handlebars options object (last argument)
                const values = args.slice(0, -1);
                const numbers = this.validateNumericArguments(values);
                if (numbers === null) {
                    return 0; // Return 0 if any value is invalid
                }
                if (numbers.length === 0) {
                    return 0;
                }
                // Calculate average
                const sum = numbers.reduce((acc, num) => acc + num, 0);
                return sum / numbers.length;
            });
            handleBars.registerHelper('min', (...args) => {
                // Remove the handlebars options object (last argument)
                const values = args.slice(0, -1);
                const numbers = this.validateNumericArguments(values);
                if (numbers === null) {
                    return 0; // Return 0 if any value is invalid
                }
                if (numbers.length === 0) {
                    return 0;
                }
                return Math.min(...numbers);
            });
            handleBars.registerHelper('max', (...args) => {
                // Remove the handlebars options object (last argument)
                const values = args.slice(0, -1);
                const numbers = this.validateNumericArguments(values);
                if (numbers === null) {
                    return 0; // Return 0 if any value is invalid
                }
                if (numbers.length === 0) {
                    return 0;
                }
                return Math.max(...numbers);
            });
            handleBars.registerHelper('mod', (value, divisor) => {
                const numbers = this.validateNumericArguments([value, divisor]);
                if (numbers === null) {
                    return 0; // Return 0 if any value is invalid
                }
                const [numValue, numDivisor] = numbers;
                if (numDivisor === 0) {
                    return 0; // Return 0 for modulo by zero
                }
                return numValue % numDivisor;
            });
            handleBars.registerHelper('floor', (value) => {
                const num = Number(value);
                if (isNaN(num)) {
                    return 0; // Return 0 if value is invalid
                }
                return Math.floor(num);
            });
            handleBars.registerHelper('ceil', (value) => {
                const num = Number(value);
                if (isNaN(num)) {
                    return 0; // Return 0 if value is invalid
                }
                return Math.ceil(num);
            });
            handleBars.registerHelper('default', (value, fallbackValue) => {
                // Return fallback if value is null, undefined, or empty string
                if (value === null || value === undefined || value === '') {
                    return this.isParamProvided(fallbackValue) ? fallbackValue : '';
                }
                return value;
            });
            handleBars.registerHelper('length', (value) => {
                if (value === null || value === undefined) {
                    return 0;
                }
                // Handle strings
                if (typeof value === 'string') {
                    return value.length;
                }
                // Handle arrays
                if (Array.isArray(value)) {
                    return value.length;
                }
                // Handle objects with length property
                if (typeof value.length === 'number') {
                    return value.length;
                }
                // Convert to string and get length
                return ('' + value).length;
            });
            handleBars.registerHelper('startsWith', (value, prefix) => {
                if (value === null || value === undefined) {
                    return false;
                }
                // Check if prefix parameter was actually provided (not just empty string)
                if (prefix === null || prefix === undefined || (typeof prefix === 'object' && prefix.hash)) {
                    return false;
                }
                const str = '' + value;
                const prefixStr = '' + prefix;
                return str.startsWith(prefixStr);
            });
            handleBars.registerHelper('endsWith', (value, suffix) => {
                if (value === null || value === undefined) {
                    return false;
                }
                // Check if suffix parameter was actually provided (not just empty string)
                if (suffix === null || suffix === undefined || (typeof suffix === 'object' && suffix.hash)) {
                    return false;
                }
                const str = '' + value;
                const suffixStr = '' + suffix;
                return str.endsWith(suffixStr);
            });
            handleBars.registerHelper('replace', (value, searchStr, replaceStr) => {
                if (!value) {
                    return '';
                }
                if (!this.isParamProvided(searchStr)) {
                    return value;
                }
                const str = '' + value;
                const search = '' + searchStr;
                const replacement = this.isParamProvided(replaceStr) ? '' + replaceStr : '';
                // Replace all occurrences (global replace)
                return str.split(search).join(replacement);
            });
            handleBars.registerHelper('first', (array) => {
                if (!Array.isArray(array)) {
                    return '';
                }
                if (array.length === 0) {
                    return '';
                }
                return array[0];
            });
            handleBars.registerHelper('last', (array) => {
                if (!Array.isArray(array)) {
                    return '';
                }
                if (array.length === 0) {
                    return '';
                }
                return array[array.length - 1];
            });
            handleBars.registerHelper('at', (array, index) => {
                if (!Array.isArray(array)) {
                    return '';
                }
                // Check specifically for null/undefined, not falsy (0 is valid!)
                if (index === null || index === undefined || (typeof index === 'object' && index.hash)) {
                    return '';
                }
                const idx = Number(index);
                if (isNaN(idx)) {
                    return '';
                }
                // Support negative indexing (like JavaScript)
                const actualIndex = idx < 0 ? array.length + idx : idx;
                if (actualIndex < 0 || actualIndex >= array.length) {
                    return ''; // Out of bounds
                }
                return array[actualIndex];
            });
            handleBars.registerHelper('join', (array, delimiter) => {
                if (!Array.isArray(array)) {
                    return '';
                }
                // Check specifically for null/undefined/handlebars object, not falsy (empty string "" is valid!)
                const delim = (delimiter === null || delimiter === undefined || (typeof delimiter === 'object' && delimiter.hash))
                    ? ','
                    : '' + delimiter;
                return array.join(delim);
            });
            handleBars.registerHelper('includes', (itemToFind, ...args) => {
                // Remove the handlebars options object (last argument)
                const options = args.slice(0, -1);
                if (options.length === 0) {
                    return false; // Need at least one option to compare against
                }
                // Handle null/undefined itemToFind
                if (itemToFind === null || itemToFind === undefined) {
                    return options.some(opt => opt === null || opt === undefined);
                }
                // Check if itemToFind matches any option (using toString comparison like 'eq' helper)
                return options.some(option => {
                    if (option === null || option === undefined) {
                        return false;
                    }
                    return itemToFind.toString() === option.toString();
                });
            });
        }
    }
    createTemplate(template) {
        let tmpl = new HandleBarsTemplate(handleBars.compile(template));
        return tmpl;
    }
    isParamProvided(param) {
        if (!param) {
            return false;
        }
        if (param.hash) {
            // handlebars passed is some default object with hash
            // for first missing param
            return false;
        }
        return true;
    }
    // Validation helper methods for comparison helpers
    validateDatesInFITimezone(value, toCompare) {
        if (value === null || value === undefined || toCompare === null || toCompare === undefined) {
            return null;
        }
        // First validate using Date constructor to avoid moment warnings with invalid dates
        const dateValue = new Date(value);
        const dateToCompare = new Date(toCompare);
        if (isNaN(dateValue.getTime()) || isNaN(dateToCompare.getTime())) {
            return null;
        }
        // Convert valid dates to FI timezone context
        const momentValue = moment.tz(dateValue, globalSettings.fiTimeZone);
        const momentToCompare = moment.tz(dateToCompare, globalSettings.fiTimeZone);
        return [momentValue.toDate(), momentToCompare.toDate()];
    }
    validateDatesInFITimezoneIgnoringTime(value, toCompare) {
        if (value === null || value === undefined || toCompare === null || toCompare === undefined) {
            return null;
        }
        // First validate using Date constructor to avoid moment warnings with invalid dates
        const dateValue = new Date(value);
        const dateToCompare = new Date(toCompare);
        if (isNaN(dateValue.getTime()) || isNaN(dateToCompare.getTime())) {
            return null;
        }
        // Get YYYY-MM-DD string in FI timezone for each date
        const dateStr1 = DateUtils.getFIDateString(dateValue);
        const dateStr2 = DateUtils.getFIDateString(dateToCompare);
        // Parse the date strings to get year, month, day
        const [year1, month1, day1] = dateStr1.split('-').map(Number);
        const [year2, month2, day2] = dateStr2.split('-').map(Number);
        // Get start of day in FI timezone for each date
        const fiDate1 = DateUtils.getFIStartOfDay(year1, month1, day1);
        const fiDate2 = DateUtils.getFIStartOfDay(year2, month2, day2);
        return [fiDate1, fiDate2];
    }
    validateMultipleDatesInFITimezone(dates) {
        const validDates = [];
        for (const date of dates) {
            if (date === null || date === undefined) {
                return null;
            }
            // First validate using Date constructor to avoid moment warnings with invalid dates
            const dateValue = new Date(date);
            if (isNaN(dateValue.getTime())) {
                return null;
            }
            // Convert valid date to FI timezone context
            const momentValue = moment.tz(dateValue, globalSettings.fiTimeZone);
            validDates.push(momentValue.toDate());
        }
        return validDates;
    }
    validateMultipleDatesInFITimezoneIgnoringTime(dates) {
        const validDates = [];
        for (const date of dates) {
            if (date === null || date === undefined) {
                return null;
            }
            // First validate using Date constructor to avoid moment warnings with invalid dates
            const dateValue = new Date(date);
            if (isNaN(dateValue.getTime())) {
                return null;
            }
            // Get YYYY-MM-DD string in FI timezone
            const dateStr = DateUtils.getFIDateString(dateValue);
            // Parse the date string to get year, month, day
            const [year, month, day] = dateStr.split('-').map(Number);
            // Get start of day in FI timezone
            const fiDate = DateUtils.getFIStartOfDay(year, month, day);
            validDates.push(fiDate);
        }
        return validDates;
    }
    validateNumericArguments(values) {
        const numbers = [];
        for (const val of values) {
            // Explicitly check for null/undefined before converting
            if (val === null || val === undefined) {
                return null; // Return null if any value is null or undefined
            }
            const num = Number(val);
            if (isNaN(num)) {
                return null; // Return null if any value is not a valid number
            }
            numbers.push(num);
        }
        return numbers;
    }
}
//# sourceMappingURL=template-manager.js.map