export class Template {
}
//# sourceMappingURL=template.js.map