import { Template } from './template.js';
export declare class HandleBarsTemplate implements Template {
    private compileTemplated;
    constructor(compileTemplated: any);
    format(params: any): string;
}
