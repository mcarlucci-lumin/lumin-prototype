import { Template } from './template.js';
export declare function simpleFormat(template: string, params?: any): string;
export declare function format(template: string, params?: any): string;
export declare function createCompiledTemplate(template: string): Template;
export declare function formatWithCompiledTemplate(template: Template, params?: any): string;
