export class EnvironmentHelper {
    static get POD_NAMESPACE() {
        return process.env.POD_NAMESPACE;
    }
}
//# sourceMappingURL=environment-helper.js.map