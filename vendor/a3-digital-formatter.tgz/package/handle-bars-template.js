import { globalSettings } from '@a3-digital/configurability';
// do not export this class in index it is an implementation detail
// outside world shouldn't know about handlebars.
export class HandleBarsTemplate {
    constructor(compileTemplated) {
        this.compileTemplated = compileTemplated;
    }
    format(params) {
        params = params || {};
        params['globalSettings'] = globalSettings || {};
        let result = this.compileTemplated(params, { allowProtoPropertiesByDefault: true });
        delete params['globalSettings'];
        return result;
    }
}
//# sourceMappingURL=handle-bars-template.js.map