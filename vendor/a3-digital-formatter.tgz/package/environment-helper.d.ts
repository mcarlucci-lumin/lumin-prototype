export declare class EnvironmentHelper {
    static get POD_NAMESPACE(): string;
}
