import { TemplateManager } from './template-manager.js';
import { ObjectUtils } from '@a3-digital/utils';
let mgr = new TemplateManager();
export function simpleFormat(template, params) {
    try {
        let chunk = template.split('{{');
        if (chunk.length === 1) {
            return chunk[0];
        }
        if (!params || params && params.removeSimpleFormat) {
            return null;
        }
        let result = [];
        result.push(chunk[0]);
        for (let i = 1; i < chunk.length; i++) {
            let parts = chunk[i].split('}}');
            let prop = parts[0].trim();
            let value = ObjectUtils.getPropertyValue(params, prop).toString();
            if (/[&<>"'`=]/.test(value)) { // special characters sent to handlebars "& < > \" ' ` ="
                return null;
            }
            result.push(value);
            result.push(parts[1]);
        }
        return result.join('');
    }
    catch (ex) {
        // eat any exception and return null to fallback to handlebarsjs
        return null;
    }
}
export function format(template, params) {
    // This allows TpvHttpClient to log requests with binary data 
    // Note that the binary data is NOT logged faithfully. It's going into a 'text' field
    // in the database, so non-UTF bytes sequences have to be converted to . in ascii
    if (template && typeof template !== 'string' && template['toString']) {
        template = String(template);
        template = template.replace(/[^\x00-\x7F]/g, '.');
        // handlebars.createTemplate() requires a string, and is confused by random {'s in the binary data
        // If it wasn't a string, it isn't really a template. Don't bother trying to compile it
        return template;
    }
    let formattedString = simpleFormat(template, params);
    if (formattedString) {
        return formattedString;
    }
    params = params || {};
    let tmpl = mgr.createTemplate(template);
    return tmpl.format(params);
}
export function createCompiledTemplate(template) {
    return mgr.createTemplate(template);
}
export function formatWithCompiledTemplate(template, params) {
    params = params || {};
    return template.format(params);
}
//# sourceMappingURL=format.js.map