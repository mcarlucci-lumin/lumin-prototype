import * as i0 from '@angular/core';
import { OnChanges, OnDestroy, ElementRef, SimpleChanges } from '@angular/core';
import * as i9 from '@a3-digital/ui-core';
import { BaseTextComponent, TextService, WindowService } from '@a3-digital/ui-core';
import { ChartTypeRegistry, Chart } from 'chart.js';
import * as i10 from '@a3-digital/ui-styles';
import { ColorVariable, BrandingTokens } from '@a3-digital/ui-styles';
import * as i8 from '@angular/common';

declare class BarChartDataset {
    amounts: number[];
    color: string;
    label: string;
    constructor(amounts: number[], color: string, label: string);
}

interface ChartDataTableSeries {
    label: string;
    amounts: number[];
}
/**
 * A data table for screen readers only: a canvas has no readable content, so charts offer this in its place.
 * Series that don't have one amount per category are left out, as the charts do when drawing. A chart
 * whose series carry no labels, such as a pie, gets one column of amounts and no header row.
 */
declare class ChartDataTableComponent implements OnChanges {
    /** Required. One row per category. */
    categories: string[];
    /** Required. One column per series, each with an amount for every category. */
    series: ChartDataTableSeries[];
    amountFormat: 'number' | 'currency';
    /** Names the table. */
    ariaLabel: string;
    /** Names the table by the id of another element, when there is no ariaLabel. */
    ariaLabelledBy: string | null;
    protected validSeries: ChartDataTableSeries[];
    protected hasSeriesLabels: boolean;
    ngOnChanges(): void;
    protected formatAmount(amount: number): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChartDataTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChartDataTableComponent, "ui-charts-data-table", never, { "categories": { "alias": "categories"; "required": false; }; "series": { "alias": "series"; "required": false; }; "amountFormat": { "alias": "amountFormat"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; }; }, {}, never, never, false, never>;
}

declare abstract class BaseChartJsComponent<T extends keyof ChartTypeRegistry> extends BaseTextComponent implements OnDestroy {
    canvas: ElementRef;
    /**
    * String used to label the chart.
    **/
    ariaLabel: string;
    /**
    * Optional. Adds a data table for screen readers and hides the canvas from them, since a canvas
    * has no readable content. Off by default. Which data the table lists is described on each chart.
    **/
    showDataTable: boolean;
    /**
    * Optional. Id of an element that names the chart, used instead of the default label when there
    * is no ariaLabel. Only applies to the data table, so it needs showDataTable.
    **/
    ariaLabelledBy: string | null;
    /** What the data table lists, kept as a field so its inputs stay stable between checks. */
    protected tableSeries: ChartDataTableSeries[];
    protected chart: Chart<T>;
    protected get dataTableLabel(): string;
    constructor(textService: TextService, textConfigKey: string);
    ngOnDestroy(): void;
    protected destroyChart(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseChartJsComponent<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BaseChartJsComponent<any>, never, never, { "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "showDataTable": { "alias": "showDataTable"; "required": false; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; }; }, {}, never, never, true, never>;
}

declare class BarChartComponent extends BaseChartJsComponent<'bar'> implements OnChanges, OnDestroy {
    /**
    * Required. Data rendered.
    **/
    datasets: BarChartDataset[];
    /**
    * Required. The categories rendered along the x-axis of the chart.
    * Each dataset should have one amount for each category.
    **/
    categories: string[];
    /**
    * Control the format of the amounts displayed in the chart.
    **/
    amountFormat: 'number' | 'currency';
    /**
    * If enabled, amounts in the y-axis will be rounded to a unit.
    * If horizontal display is enabled, these units appear on the x-axis.
    * For example, $1,5000 will be presented as $1.5K.
    **/
    roundAxisToUnit: boolean;
    /**
    * If set, controls the number of ticks on the y-axis.
    * If horizontal display is enabled, these units appear on the x-axis.
    **/
    maxTicks: number;
    /**
    * By default, amounts from different datasets are grouped together per category.
    * Set this to 'stacked' to stack the amounts on top of each other in a single column.
    **/
    display: 'default' | 'stacked';
    /**
    * Boolean that controls whether the bar chart displays horizontal or vertical bars.
    * Default is false, which will display vertical bars.
    **/
    displayHorizontally: boolean;
    /**
    * Optional. Width divided by height, e.g. 1.5. Defaults to 1 on a mobile-sized window and 2
    * otherwise, judged by the window rather than the chart's container.
    **/
    aspectRatio: number | null;
    /**
    * Optional. Extra pixels between the legend and the chart. Chart.js leaves a fixed 10px and has no
    * option to change it. Defaults to 0.
    **/
    legendGap: number;
    private isMobile;
    constructor(windowService: WindowService, textService: TextService);
    ngOnChanges(changes: SimpleChanges): void;
    private drawChart;
    private buildChartData;
    private mapDataset;
    private getXAxisScales;
    private getYAxisScales;
    private buildChartOptions;
    private ticksCallback;
    private tooltipLabelCallback;
    protected getDefaultText(): {
        ariaLabel: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<BarChartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BarChartComponent, "ui-charts-bar", never, { "datasets": { "alias": "datasets"; "required": false; }; "categories": { "alias": "categories"; "required": false; }; "amountFormat": { "alias": "amountFormat"; "required": false; }; "roundAxisToUnit": { "alias": "roundAxisToUnit"; "required": false; }; "maxTicks": { "alias": "maxTicks"; "required": false; }; "display": { "alias": "display"; "required": false; }; "displayHorizontally": { "alias": "displayHorizontally"; "required": false; }; "aspectRatio": { "alias": "aspectRatio"; "required": false; }; "legendGap": { "alias": "legendGap"; "required": false; }; }, {}, never, never, false, never>;
}

declare class DonutChartDataset {
    amounts: number[];
    colors: string[];
    labels: string[];
    constructor(amounts: number[], colors: string[], labels?: string[]);
    totalAmount: number;
    tooltipLine1Format: string;
    tooltipLine2Format: string;
}

declare module 'chart.js' {
    interface ChartTypeRegistry {
        A3Doughnut: ChartTypeRegistry['doughnut'];
    }
}
declare class DonutChartComponent extends BaseChartJsComponent<'A3Doughnut'> implements OnChanges, OnDestroy {
    private windowService;
    tooltip: ElementRef;
    /**
    * Required. Data used to render the outer layer of the chart.
    **/
    primaryData: DonutChartDataset;
    /**
    * Optional. Data used to render the inner layer of the chart.
    **/
    secondaryData: DonutChartDataset;
    /**
    * First row of text. Usually a large size, but customizable via "mainTextCssClass".
    **/
    mainText: string;
    /**
    * Customizes the look of the mainText.
    **/
    mainTextCssClass: string;
    /**
    * Second row of text. Customizable via "subTextCssClass".
    **/
    subText: string;
    /**
    * Customizes the look of the subText.
    **/
    subTextCssClass: string;
    /**
    * Optional text displays under the chart and is customizable via "captionTextCssClass".
    **/
    captionText: string;
    /**
    * Customizes the look of the captionText.
    **/
    captionTextCssClass: string;
    /**
    * Controls the size of the donut hole. The larger the value, the thinner the donut becomes.
    * Minimum value is 50. Max is 90.
    **/
    cutoutPercentage: number;
    /**
    * Required. Overall height of the donut chart.
    **/
    height: string;
    /**
    * The shape of the donut. "whole" results in a full circle. "half" results in a semi-circle.
    **/
    shape: 'whole' | 'half';
    /**
    * If true, show the donut info text (mainText and subText) in line.
    **/
    showTextInline: boolean;
    /**
    * If true, tooltips become inverted if they will overflow the chart container.
    * This is useful for preventing tooltips from being cut off in very narrow spaces.
    * If false, the tooltips become inverted if they will overflow the browser screen.
    **/
    preventChartOverflow: boolean;
    /**
    * Optional. Format of the amounts in the data table (showDataTable). The table lists one row per
    * slice of the primary data, so the data needs labels; the secondary data is not included. The
    * donut has no default label, so name the table with ariaLabel or ariaLabelledBy. The tooltips
    * are formatted by the datasets' tooltipLine1Format and tooltipLine2Format instead.
    **/
    amountFormat: 'number' | 'currency';
    tooltipClass: string;
    tooltipStyles: {};
    tooltipTitle: string;
    tooltipLine1: string;
    tooltipLine2: string;
    donutChartInfoCssClass: string;
    constructor(windowService: WindowService);
    ngOnChanges(changes: SimpleChanges): void;
    private drawChart;
    private buildChartData;
    private mapDataset;
    private buildChartOptions;
    private get tooltipEl();
    private tooltipCallback;
    private tooltipWillOverflow;
    private setHoverStyleCallback;
    private removeHoverStyleCallback;
    private hideTooltip;
    refresh(): void;
    protected getDefaultText(): {};
    static ɵfac: i0.ɵɵFactoryDeclaration<DonutChartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DonutChartComponent, "ui-charts-donut", never, { "primaryData": { "alias": "primaryData"; "required": false; }; "secondaryData": { "alias": "secondaryData"; "required": false; }; "mainText": { "alias": "mainText"; "required": false; }; "mainTextCssClass": { "alias": "mainTextCssClass"; "required": false; }; "subText": { "alias": "subText"; "required": false; }; "subTextCssClass": { "alias": "subTextCssClass"; "required": false; }; "captionText": { "alias": "captionText"; "required": false; }; "captionTextCssClass": { "alias": "captionTextCssClass"; "required": false; }; "cutoutPercentage": { "alias": "cutoutPercentage"; "required": false; }; "height": { "alias": "height"; "required": false; }; "shape": { "alias": "shape"; "required": false; }; "showTextInline": { "alias": "showTextInline"; "required": false; }; "preventChartOverflow": { "alias": "preventChartOverflow"; "required": false; }; "amountFormat": { "alias": "amountFormat"; "required": false; }; }, {}, never, never, false, never>;
}

declare enum LineChartDatasetDisplay {
    DEFAULT = "DEFAULT",// Solid line
    DASHED_LINE = "DASHED_LINE",// Dashes
    FILLED_SOLID = "FILLED_SOLID",// Filled with a solid color
    FILLED_GRADIENT = "FILLED_GRADIENT"
}
declare class LineChartDataset {
    amounts: number[];
    color: string;
    label: string;
    display: LineChartDatasetDisplay;
    /**
    * If enabled, colors this line relative to a baseline of 0: segments and points above 0
    * render in success green, below 0 in danger red, with a translucent fill to the baseline.
    * When enabled, `color` and `display` are ignored in favor of this fixed styling.
    **/
    positiveNegative: boolean;
    constructor(amounts: number[], color: string, label: string);
}

declare class LineChartComponent extends BaseChartJsComponent<'line'> implements OnChanges, OnDestroy {
    /**
    * Required. Data rendered.
    **/
    datasets: LineChartDataset[];
    /**
    * Required. The categories rendered along the x-axis of the chart.
    * Each dataset should have one amount for each category.
    **/
    categories: string[];
    /**
    * Control the format of the amounts displayed in the chart.
    **/
    amountFormat: 'number' | 'currency';
    /**
    * If enabled, amounts in the y-axis will be rounded to a unit.
    * For example, $1,5000 will be presented as $1.5K.
    **/
    roundAxisToUnit: boolean;
    /**
     * Controls the display of background grid lines in the chart.
     *  'x' - only vertical lines
     *  'y' - only horizontal lines
     */
    showGridLines: 'x' | 'y' | 'both' | 'none';
    /**
     * String label displayed on the x-axis.
     */
    xLabel: string;
    /**
     * String label displayed on the y-axis.
     */
    yLabel: string;
    /**
     * By default, the chart scales the y-axis to fit the data
     * Define this to set a suggested max amount for the y-axis (will be ignored if data exceeds max amount)
     */
    suggestedMaxAmount: number;
    /**
     * By default, the chart will use the lowest data point as the min amount for the y-axis
     * Define this to set a suggested min amount for the y-axis (will be ignored if data is below min amount)
     */
    suggestedMinAmount: number;
    /**
    * If set, controls the number of ticks on the y-axis.
    **/
    maxTicks: number;
    /**
    * Control the display of hover line points & tooltips
    **/
    showHoverPoints: boolean;
    /**
    * Control the radius (in pixels) of the hover points, when showHoverPoints is enabled.
    **/
    hoverPointSize: number;
    /**
    * Control the style of the lines
    **/
    smoothLines: boolean;
    /**
    * Optional. Width divided by height, e.g. 1.5. Defaults to 1 on a mobile-sized window and 2
    * otherwise, judged by the window rather than the chart's container.
    **/
    aspectRatio: number | null;
    /**
    * Optional. Extra pixels between the legend and the chart. Chart.js leaves a fixed 10px and has no
    * option to change it. Defaults to 0.
    **/
    legendGap: number;
    private isMobile;
    private gridColor;
    private baselineColor;
    constructor(windowService: WindowService, textService: TextService);
    ngOnChanges(changes: SimpleChanges): void;
    private drawChart;
    private buildChartData;
    private mapPositiveNegativeDataset;
    private mapDataset;
    private buildChartOptions;
    private buildXScaleGrid;
    private buildXScaleTitle;
    private buildCategoryXScale;
    private buildLinearXScale;
    private isZeroTick;
    private getYGridLineColor;
    private ticksCallback;
    private tooltipLabelCallback;
    protected getDefaultText(): {
        ariaLabel: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<LineChartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LineChartComponent, "ui-charts-line", never, { "datasets": { "alias": "datasets"; "required": false; }; "categories": { "alias": "categories"; "required": false; }; "amountFormat": { "alias": "amountFormat"; "required": false; }; "roundAxisToUnit": { "alias": "roundAxisToUnit"; "required": false; }; "showGridLines": { "alias": "showGridLines"; "required": false; }; "xLabel": { "alias": "xLabel"; "required": false; }; "yLabel": { "alias": "yLabel"; "required": false; }; "suggestedMaxAmount": { "alias": "suggestedMaxAmount"; "required": false; }; "suggestedMinAmount": { "alias": "suggestedMinAmount"; "required": false; }; "maxTicks": { "alias": "maxTicks"; "required": false; }; "showHoverPoints": { "alias": "showHoverPoints"; "required": false; }; "hoverPointSize": { "alias": "hoverPointSize"; "required": false; }; "smoothLines": { "alias": "smoothLines"; "required": false; }; "aspectRatio": { "alias": "aspectRatio"; "required": false; }; "legendGap": { "alias": "legendGap"; "required": false; }; }, {}, never, never, false, never>;
}

declare class PieChartDataset {
    amounts: number[];
    colors: string[];
    labels: string[];
    constructor(amounts: number[], colors: string[], labels?: string[]);
}

declare class PieChartComponent extends BaseChartJsComponent<'pie'> implements OnChanges, OnDestroy {
    /**
    * Required. Data used to render the outer layer of the chart.
    **/
    primaryData: PieChartDataset;
    /**
    * Control the format of the amounts displayed in the chart.
    **/
    amountFormat: 'number' | 'currency';
    /**
    * Optional. Fixed height of the pie chart.
    * If not provided, responsive behaviors will try to fill the space provided.
    **/
    height: string;
    heightStyles: {};
    constructor(textService: TextService);
    ngOnChanges(changes: SimpleChanges): void;
    private drawChart;
    private buildChartData;
    private mapDataset;
    private buildChartOptions;
    private tooltipLabelCallback;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<PieChartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PieChartComponent, "ui-charts-pie", never, { "primaryData": { "alias": "primaryData"; "required": false; }; "amountFormat": { "alias": "amountFormat"; "required": false; }; "height": { "alias": "height"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ProgressRingComponent extends BaseTextComponent implements OnChanges, OnDestroy {
    /**
    * Number percentage to display in text & show in the progress ring.
    * This should be between 0 and 100.
    **/
    percentComplete: number;
    /**
    * Number percentage where ring should start animation.
    *   If not -1, the ring will start from this value and animate to the "percentComplete" value
    **/
    animationStartValue: number;
    /**
    * Background of ring color value
    **/
    backgroundColor: ColorVariable;
    /**
    * Ring color value
    **/
    chartColor: ColorVariable;
    /**
    * String used to label the chart for screen-readers, replaces default text: "Progress Completed:"
    * Will be added to the progress value like this "{{ ariaLabel }}: 50%".
    **/
    ariaLabel: string;
    progressText: string;
    constructor(textService: TextService);
    ngOnChanges(): void;
    protected getDefaultText(): {
        ariaLabel: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<ProgressRingComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProgressRingComponent, "ui-charts-progress-ring", never, { "percentComplete": { "alias": "percentComplete"; "required": false; }; "animationStartValue": { "alias": "animationStartValue"; "required": false; }; "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "chartColor": { "alias": "chartColor"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ProgressTrackerCell {
    label: string;
    brandingColor: BrandingTokens;
    constructor(label: string, brandingColor?: BrandingTokens);
}

declare class ProgressTrackerComponent extends BaseTextComponent implements OnChanges {
    private windowService;
    private textService;
    /**
    * Required. The various cells from left to right. Each cell must have a "label" and may also have an
    * optional "brandingColor" specified. The default cell color matches the "color-secondary" variable.
    **/
    cells: ProgressTrackerCell[];
    /**
    * The number of cells that should be filled.
    **/
    numFilled: number;
    activeColor: string;
    activeLabel: string;
    isMobile: boolean;
    constructor(windowService: WindowService, textService: TextService);
    ngOnChanges(changes: SimpleChanges): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProgressTrackerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProgressTrackerComponent, "ui-charts-progress-tracker", never, { "cells": { "alias": "cells"; "required": false; }; "numFilled": { "alias": "numFilled"; "required": false; }; }, {}, never, never, false, never>;
}

declare class UiChartsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UiChartsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UiChartsModule, [typeof BarChartComponent, typeof ChartDataTableComponent, typeof DonutChartComponent, typeof LineChartComponent, typeof PieChartComponent, typeof ProgressRingComponent, typeof ProgressTrackerComponent], [typeof i8.CommonModule, typeof i9.UiCoreModule, typeof i10.UiStylesModule], [typeof BarChartComponent, typeof DonutChartComponent, typeof LineChartComponent, typeof PieChartComponent, typeof ProgressRingComponent, typeof ProgressTrackerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UiChartsModule>;
}

export { BarChartComponent, BarChartDataset, DonutChartComponent, DonutChartDataset, LineChartComponent, LineChartDataset, LineChartDatasetDisplay, PieChartComponent, PieChartDataset, ProgressRingComponent, ProgressTrackerCell, ProgressTrackerComponent, UiChartsModule };
//# sourceMappingURL=index.d.ts.map
