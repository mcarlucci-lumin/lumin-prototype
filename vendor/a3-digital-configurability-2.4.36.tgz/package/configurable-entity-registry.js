import 'reflect-metadata';
export const CONFIGURABLE_CLASS_METADATA_KEY = 'ConfigurableClassMetadata';
export const CONFIGURABLE_PROPERTIES_METADATA_KEY = 'ConfigurablePropertiesMetadata';
export const EXPORTED_PROPERTIES_METADATA_KEY = 'ExportedPropertiesMetadata';
// Private symbol for tracking configured state - only this package knows about it
export const CONFIGURED_VERSION_SYMBOL = Symbol('__configured_version');
// Configuration version counter - incremented on each uninitialize
let __configurationVersion = 0;
export class ConfigurableEntityRegistry {
    static initialize(activeConfig) {
        if (this._instance) {
            throw Error('ConfigurableEntityRegistry has already been initialized.');
        }
        try {
            let config = {};
            if (activeConfig) {
                config = activeConfig;
            }
            __configurationVersion++;
            this._instance = new ConfigurableEntityRegistry(config, __configurationVersion);
        }
        catch (err) {
            throw Error('failed to load active configuration from provided source.');
        }
    }
    static uninitialize() {
        if (!this._instance) {
            // eslint-disable-next-line max-len
            throw Error('ConfigurableEntityRegistry has not been initialized - initializeFromSource() must be called before uninitialize()');
        }
        this._instance = null;
        // Increment version to invalidate all existing configured instances
        __configurationVersion++;
    }
    static instance() {
        if (!this._instance) {
            throw Error('ConfigurableEntityRegistry is in an invalid state - initializeFromSource() must be called before instance()');
        }
        return this._instance;
    }
    get currentConfigurationVersion() {
        return this.configurationVersion;
    }
    constructor(activeConfiguration, configurationVersion) {
        this.activeConfiguration = activeConfiguration;
        this.configurationVersion = configurationVersion;
    }
    setActiveConfigurationFor(instance) {
        let active = this.calculateActiveConfigurationFor(instance.constructor);
        Object.getOwnPropertyNames(active).forEach(key => {
            instance[`__${key}`] = active[key];
        });
        // Store the configuration version instead of just a boolean flag
        instance[CONFIGURED_VERSION_SYMBOL] = this.configurationVersion;
    }
    calculateActiveConfigurationFor(root) {
        let active = {};
        // if there are base classes we need to get their default values added to active object
        // NOTE: this is needed so that all base class properties are set to their defaults and NOT to some
        // override set somewhere else in the inheritance chain. All configurable "leaf" classes need to stand
        // on their own (either defaults OR overrides configured on them specifically).
        this.applyDefaults(root, active);
        // apply active configuration overrides
        this.applyOverrides(root, active);
        return active;
    }
    applyOverrides(target, active) {
        let classMeta = Reflect.getMetadata(CONFIGURABLE_CLASS_METADATA_KEY, target);
        if (classMeta) {
            if (this.activeConfiguration && this.activeConfiguration[classMeta.configurationKey]) {
                Object.assign(active, this.activeConfiguration[classMeta.configurationKey]);
            }
        }
    }
    applyDefaults(target, active) {
        let base = Object.getPrototypeOf(target);
        if (base && base.name !== '') {
            // recurse into base so that defaults are layered
            this.applyDefaults(base, active);
        }
        let targetConstructor = target.prototype.constructor;
        if (targetConstructor) {
            // make sure this is a configurable class
            let cm = Reflect.getOwnMetadata(CONFIGURABLE_CLASS_METADATA_KEY, targetConstructor);
            if (cm) {
                let cpm = Reflect.getOwnMetadata(CONFIGURABLE_PROPERTIES_METADATA_KEY, targetConstructor) || {};
                if (cpm) {
                    Object.getOwnPropertyNames(cpm).forEach(prop => {
                        active[prop] = cpm[prop].default;
                    });
                }
            }
        }
    }
}
