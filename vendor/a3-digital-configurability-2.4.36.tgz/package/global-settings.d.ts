import { FiType } from './fi-type.js';
import { HostSystem } from './host-system.js';
import { Holiday } from '@a3-digital/date-utils';
export declare class GlobalSettings {
    fiName: string;
    fiNickname: string;
    fiTimeZone: string;
    fiID: string;
    useHostRoutingNumber: boolean;
    routingNumber: string;
    maskExternalAccountNumbersInAdmin: boolean;
    fiPhoneNumber: string;
    fiEmail: string;
    browserTitle: string;
    supportedLanguages: string[];
    smsProgramName: string;
    fiType: FiType;
    isBankMode(override?: FiType): boolean;
    fiHostSystem: HostSystem;
    _luminConversionDateString: string;
    get luminConversionDate(): Date | null;
    holidaySchedule: Holiday[];
    static getConfigPropertiesMetaData(): any;
}
export declare let globalSettings: GlobalSettings;
