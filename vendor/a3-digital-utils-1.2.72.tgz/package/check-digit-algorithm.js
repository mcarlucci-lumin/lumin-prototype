export var CheckDigitAlgorithm;
(function (CheckDigitAlgorithm) {
    CheckDigitAlgorithm["LUHN"] = "Luhn";
    CheckDigitAlgorithm["MOD9"] = "Mod9";
})(CheckDigitAlgorithm || (CheckDigitAlgorithm = {}));
//# sourceMappingURL=check-digit-algorithm.js.map