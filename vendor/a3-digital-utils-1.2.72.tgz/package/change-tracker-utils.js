export function formatFieldChanges(changes, separator, labels, valueFormatter) {
    labels = labels || [];
    separator = separator || ', ';
    valueFormatter = valueFormatter || defaultValueFormatter;
    let changeText = changes.map(x => {
        let label = labels.find(l => l.fieldName === x.fieldName);
        return `${label ? label.label : x.fieldName}: changed ${valueFormatter(x.fieldName, x.oldValue)} to ${valueFormatter(x.fieldName, x.newValue)}`;
    }).join(separator);
    return changeText;
}
export function defaultValueFormatter(fieldName, value) {
    if (typeof (value) === 'number') {
        return value.toFixed(2);
    }
    else {
        return `${value}`;
    }
}
//# sourceMappingURL=change-tracker-utils.js.map