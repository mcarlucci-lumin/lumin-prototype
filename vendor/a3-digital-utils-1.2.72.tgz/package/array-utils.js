import { StringUtils } from './string-utils.js';
export class ArrayUtils {
    static getUniqueFieldValues(array, fieldName) {
        return this.getUniqueExpressionValues(array, x => x[fieldName]);
    }
    static getUniqueExpressionValues(array, exp) {
        return [...new Set(array.map(item => exp(item)))];
    }
    /*
    splits an array in to a key: array map where for each unique key value, you get all the array values
    */
    static createKeyValuesMap(array, keyFieldName) {
        return this.createExpressionKeyValuesMap(array, x => x[keyFieldName]);
    }
    /* use an expression to define your key e.g x => x.date.year */
    /* create a key map that has all values that match your expression */
    static createExpressionKeyValuesMap(array, exp) {
        const keys = this.getUniqueExpressionValues(array, exp);
        let output = { keys };
        for (let key of keys) {
            output[key] = array.filter(x => exp(x) === key);
        }
        return output;
    }
    static findMax(array, expression) {
        if (!array || array.length === 0) {
            return null;
        }
        let maxVal = expression(array[0]);
        let maxItem = array[0];
        for (let item of array) {
            let val = expression(item);
            if (val > maxVal) {
                maxVal = val;
                maxItem = item;
            }
        }
        return maxItem;
    }
    static findMin(array, expression) {
        if (!array || array.length === 0) {
            return null;
        }
        let minVal = expression(array[0]);
        let minItem = array[0];
        for (let item of array) {
            let val = expression(item);
            if (val < minVal) {
                minVal = val;
                minItem = item;
            }
        }
        return minItem;
    }
    static moveItem(array, fromIndex, toIndex) {
        if (!array) {
            return array;
        }
        if (fromIndex === undefined || fromIndex < 0 || fromIndex >= array.length) {
            throw Error(`Invalid from index ${fromIndex}`);
        }
        if (toIndex === undefined || toIndex < 0 || toIndex >= array.length) {
            throw Error(`Invalid to index ${toIndex}`);
        }
        let idx = 0;
        let newArray = [];
        for (let item of array) {
            if (idx !== fromIndex) {
                newArray.push(item);
            }
            if (idx === toIndex) {
                newArray.push(array[fromIndex]);
            }
            idx++;
        }
        return newArray;
    }
    static compareValues(a, b) {
        let val = 0;
        if (a === null || a === undefined) {
            if (b === null || b === undefined) {
                return 0;
            }
            else {
                return -1;
            }
        }
        if (b === null || b === undefined) {
            return 1;
        }
        // If these are strings, do a case insensitive comparison.
        // If the case insensitive values are equal, let the default sorting handle it.
        // Otherwise Javascript would sort "Z" before "a".
        if (StringUtils.isString(a) && StringUtils.isString(b)) {
            const aString = a.toLowerCase();
            const bString = b.toLowerCase();
            if (aString < bString) {
                return -1;
            }
            else if (aString > bString) {
                return 1;
            }
        }
        if (a < b) {
            val = -1;
        }
        else if (a > b) {
            val = 1;
        }
        return val;
    }
    static sortByField(array, fieldName, descending) {
        return this.sortByFields(array, { fieldName, descending });
    }
    static sortByFields(array, ...sortFields) {
        const clone = [...array];
        if (!sortFields || sortFields.length === 0) {
            return clone;
        }
        const sortFn = (a, b) => {
            let value = 0;
            let fieldIndex = 0;
            while (value === 0 && sortFields.length > fieldIndex) {
                value = this.compareValues(a[sortFields[fieldIndex].fieldName], b[sortFields[fieldIndex].fieldName]);
                let flipper = sortFields[fieldIndex].descending ? -1 : 1;
                value = value * flipper;
                fieldIndex++;
            }
            return value;
        };
        return clone.sort(sortFn);
    }
    // randomly sort an array
    static shuffleArray(array) {
        let itemsToShuffle = array.map(item => ({ item, sortWeight: Math.random() }));
        itemsToShuffle = ArrayUtils.sortByField(itemsToShuffle, 'sortWeight');
        return itemsToShuffle.map(x => x.item);
    }
    static sumFieldValue(items, fieldName) {
        let sum = 0;
        for (let item of items) {
            sum += Number(item[fieldName]);
        }
        return sum;
    }
}
//# sourceMappingURL=array-utils.js.map