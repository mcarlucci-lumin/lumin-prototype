import { StringUtils } from './string-utils.js';
import cardValidator from 'card-validator';
export class CardUtils {
    static isValidCardNumber(cardNum) {
        if (cardNum && cardNum.length && cardNum.length >= 12) {
            let val = cardValidator.number(cardNum);
            return val.isPotentiallyValid;
        }
        else {
            return false;
        }
    }
    // do minimum pci redact requirements
    // show first 4 and last 6
    static redactCardNumber(cardNum) {
        const isCard = this.isValidCardNumber(cardNum);
        if (isCard) {
            const maskLength = cardNum.length - 10;
            return `${StringUtils.left(cardNum, 6)}${StringUtils.padString('*', maskLength, '*', true)}${StringUtils.right(cardNum, 4)}`;
        }
        else {
            return cardNum;
        }
    }
}
//# sourceMappingURL=card-utils.js.map