import { CheckDigitAlgorithm } from './check-digit-algorithm.js';
export class MicrNumberUtils {
    static generateCheckDigit(micrNumber, algorithm = CheckDigitAlgorithm.LUHN) {
        if (algorithm === CheckDigitAlgorithm.MOD9) {
            return this.mod9Algorithm(micrNumber);
        }
        return this.luhnAlgorithm(micrNumber);
    }
    static mod9Algorithm(micrNumber) {
        const digits = micrNumber.replace(/\D/g, '').split('').map(Number);
        const sum = digits.reduce((acc, d) => acc + d, 0);
        return String((9 - (sum % 9)) % 9);
    }
    static luhnAlgorithm(micrNumber) {
        const digits = (micrNumber + '0').replace(/\D/g, '').split('').map(Number);
        let sum = 0;
        let isSecond = false;
        for (let i = digits.length - 1; i >= 0; i--) {
            let digit = digits[i];
            if (isSecond) {
                digit *= 2;
                if (digit > 9) {
                    digit -= 9;
                }
            }
            sum += digit;
            isSecond = !isSecond;
        }
        const checksum = sum % 10;
        return checksum === 0 ? '0' : String(10 - checksum);
    }
}
//# sourceMappingURL=micr-number-utils.js.map