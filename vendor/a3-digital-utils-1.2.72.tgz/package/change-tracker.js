export class ChangeTracker {
    constructor(item, calculatedFieldTrackers) {
        this.calculatedFieldTrackers = calculatedFieldTrackers;
        this.calculatedFieldTrackers = this.calculatedFieldTrackers || [];
        this.original = Object.assign({}, item);
        this.calculatedFields = this.evaluateCalculatedFields(item);
        this.current = item;
    }
    evaluateCalculatedFields(item) {
        let fields = {};
        for (let cft of this.calculatedFieldTrackers) {
            fields[cft.fieldName] = cft.getValue(item);
        }
        return fields;
    }
    getChanges() {
        let changes = [];
        let calculatedFieldKeys = Object.keys(this.calculatedFields);
        for (let key of Object.keys(this.original)) {
            // if its not a calculated field do a simple field compare test
            if (calculatedFieldKeys.indexOf(key) === -1) {
                if (this.fieldModified(this.original[key], this.current[key])) {
                    changes.push({ fieldName: key, oldValue: this.original[key], newValue: this.current[key] });
                }
            }
        }
        let currentCalculatedFields = this.evaluateCalculatedFields(this.current);
        for (let key of calculatedFieldKeys) {
            if (this.fieldModified(this.calculatedFields[key], currentCalculatedFields[key])) {
                changes.push({ fieldName: key, oldValue: this.calculatedFields[key], newValue: currentCalculatedFields[key] });
            }
        }
        return changes;
    }
    isDate(input) {
        if (input === undefined || input === null) {
            return false;
        }
        if (Object.prototype.toString.call(input) === '[object Date]') {
            return true;
        }
        else {
            return false;
        }
    }
    isEmpty(input) {
        return input === undefined || input === null || input === '';
    }
    fieldModified(originalValue, newValue) {
        if (this.isEmpty(originalValue) && this.isEmpty(newValue)) {
            return false;
        }
        try {
            if (this.isDate(originalValue) && this.isDate(newValue)) {
                return originalValue.getTime() !== newValue.getTime();
            }
        }
        catch (err) { /* if date compare fails, fall back to regular compare */ }
        return originalValue !== newValue;
    }
}
//# sourceMappingURL=change-tracker.js.map