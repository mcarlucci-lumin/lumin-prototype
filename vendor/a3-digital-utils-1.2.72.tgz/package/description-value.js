export class DescriptionValue {
}
//# sourceMappingURL=description-value.js.map