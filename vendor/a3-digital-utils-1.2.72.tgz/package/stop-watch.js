export class StopWatch {
    constructor() {
        this.startTime = null;
    }
    static createAndStart() {
        const sw = new StopWatch();
        sw.start();
        return sw;
    }
    start() {
        this.startTime = new Date();
    }
    /* returns number of ms elapsed */
    stop() {
        if (!this.startTime) {
            throw Error('stop watch not started');
        }
        const end = new Date();
        return end.getTime() - this.startTime.getTime();
    }
}
//# sourceMappingURL=stop-watch.js.map