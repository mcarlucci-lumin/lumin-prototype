export class SortField {
}
//# sourceMappingURL=sort-field.js.map