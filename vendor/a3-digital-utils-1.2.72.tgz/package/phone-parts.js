export class PhoneParts {
    constructor() {
        this.dialCode = '';
        this.country = null;
        this.number = '';
        this.fullNumber = '';
        this.raw = '';
        this.partialCountryMatches = [];
    }
}
//# sourceMappingURL=phone-parts.js.map