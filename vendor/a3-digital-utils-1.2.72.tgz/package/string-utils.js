export class StringUtils {
    static { this.reRegExpChar = /[\\^$.*+?()[\]{}|-]/g; }
    static { this.reHasRegExpChar = RegExp(StringUtils.reRegExpChar.source); }
    static { this.reHasEmoticonChar = /\ud83d[\ud000-\udfff]/ig; } // This is in the reHasEmojiChar but that doesn't match some emojis
    static { this.reHasEmojiChar = /(\u00a9|\u00ae|[\u2000-\u3300]|\ud83c[\ud000-\udfff]|\ud83d[\ud000-\udfff]|\ud83e[\ud000-\udfff])/ig; }
    static { this.reHasEmojiFlagChar = /[\ud83c][\udde6-\uddff][\ud83c][\udde6-\udfff]/i; }
    static escapeRegExp(val) {
        return (val && StringUtils.reHasRegExpChar.test(val))
            ? val.replace(StringUtils.reRegExpChar, '\\$&')
            : (val || '');
    }
    static truncateString(str, maxLength) {
        str = StringUtils.ensureIsString(str);
        return str.length <= maxLength ? str : str.substring(0, maxLength);
    }
    static right(str, numChrs) {
        str = StringUtils.ensureIsString(str);
        return str.length <= numChrs ? str : str.substring(str.length - numChrs);
    }
    static truncateOrPadString(str, targetLength, padStr, padEnd) {
        str = StringUtils.ensureIsString(str);
        str = this.padString(str, targetLength, padStr, padEnd);
        return this.truncateString(str, targetLength);
    }
    static padString(str, targetLength, padString, padEnd) {
        str = StringUtils.ensureIsString(str);
        if (str.length > targetLength) {
            return str;
        }
        else {
            targetLength = targetLength - str.length;
            if (targetLength > padString.length) {
                padString += padString.repeat(targetLength / padString.length); // append to original to ensure we are longer than needed
            }
            if (padEnd) {
                return str + padString.slice(0, targetLength);
            }
            else {
                return padString.slice(0, targetLength) + str;
            }
        }
    }
    static zeroPadNumber(num, targetLength) {
        const str = num ? num.toString() : '';
        return this.truncateOrPadString(str, targetLength, '0', false);
    }
    static trimLeadingZeros(str) {
        str = this.ensureIsString(str);
        return str.replace(/^0+/, '');
    }
    static left(str, numChrs) {
        str = StringUtils.ensureIsString(str);
        return str.length <= numChrs ? str : str.substring(0, numChrs);
    }
    static replaceAll(str, find, replace) {
        str = this.ensureIsString(str);
        find = StringUtils.escapeRegExp(find);
        return str.replace(new RegExp(find, 'g'), replace);
    }
    static ensureIsString(str) {
        if (!str || str === '') {
            return '';
        }
        if (this.isString(str)) {
            return str;
        }
        else {
            return str.toString();
        }
    }
    static firstCharLowerCase(str) {
        if (!str || str === '') {
            return '';
        }
        if (!str.charAt) {
            str = str.toString();
        }
        return str.charAt(0).toLowerCase() + str.slice(1);
    }
    static redactCreditCardNumbers(text) {
        if (!text) {
            return text;
        }
        // match 13 to 16 digits, keeping the last 4 as a group
        // match 16 digits with hyphen or space every 4, keeping the last 4 as a group
        // matches if 0th character is not a digit, hyphen, or period beginning of line
        // matches if 17th character is not a digit or period or hyphen
        // matches if 17th character is period followed by non digit
        // matches if 17th character is end of content
        // see unit tests to understand the various scenarios
        const regEx = new RegExp(/([^\d\-\.]|^)(\d{9,12}|\d\d\d\d[- ]\d\d\d\d[- ]\d\d\d\d[- ])(\d{4})(\b|[^\d\-\.]{1}|(\.\D)|(\.$)|$)/, 'g');
        let val = text.replace(regEx, '$1**REDACTED**$3$4');
        return val;
    }
    static redactSsn(text) {
        if (!text) {
            return text;
        }
        // match 9 digits, keeping the last 4 as a group
        // match 9 digits with hyphen or space in the SSN format (3-2-4), keeping the last 4 as a group
        // matches if 0th character is not a digit or hyphen or beginning of line
        // matches if 10th character is not a digit or period or hyphen
        // matches if 10th character is period followed by non digit
        // matches if 10th character is end of content
        // see unit tests to understand the various scenarios
        const regEx = new RegExp(/([^\d\-]|^)(\d{5}|\d\d\d[- ]\d\d[- ])(\d{4})([^\d\-\.]{1}|(\.\D)|(\.$)|$)/, 'g');
        let val = text.replace(regEx, '$1**REDACTED**$3$4');
        return val;
    }
    static stripNonNumeric(input, maxLength = 0) {
        if (!input || !input.replace) {
            return '';
        }
        let result = input.replace(/\D/g, '');
        if (maxLength > 0) {
            return result.substring(0, maxLength);
        }
        return result;
    }
    static toTitleCase(origText) {
        if (origText === undefined || origText === null) {
            return origText;
        }
        const chrArray = this.toCharArray(origText.toLowerCase().trim());
        for (let i = 0; i < chrArray.length; i++) {
            if (i === 0) {
                // first letter caps
                chrArray[i] = chrArray[i].toUpperCase();
            }
            else {
                let prevChar = chrArray[i - 1];
                if ((prevChar >= 'a' && prevChar <= 'z') || (prevChar >= 'A' && prevChar <= 'Z')) {
                    // previous character was a letter
                    if (prevChar === 'c' && i > 1 && chrArray[i - 2] === 'M') {
                        // the Mc rule (e.g. McNutt, McMahan)
                        chrArray[i] = chrArray[i].toUpperCase();
                    }
                }
                else if (prevChar === "'") {
                    // check for posessive s
                    if (chrArray[i] !== 's' || (i !== chrArray.length - 1 && chrArray[i + 1] !== ' ')) {
                        // the ' appears either before a non-s character (think O'Neill) 
                        // OR the following s character is subsequently followed by another character (think O'Shea)
                        chrArray[i] = chrArray[i].toUpperCase();
                    }
                }
                else {
                    // previous character was not a letter
                    chrArray[i] = chrArray[i].toUpperCase();
                }
            }
        }
        return chrArray.join('');
    }
    // Certain punctuations such as Apple's "Smart Punctuation" and Microsoft's "Smart Quotes" 
    // is setting apostrophe characters to unicode \u2018 (char code 8216)
    // if it's at the beginning of the string and unicode \u2019 (char code 8217) if anywhere else.
    // Replace all if found to the standard apostrophe which is unicode \u0027 (char code 39)
    static replaceSmartQuotes(str) {
        if (str === undefined) {
            return undefined;
        }
        str = this.ensureIsString(str);
        return str?.replace(/[\u2018\u2019]+/gu, '\'');
    }
    static toCharArray(str) {
        return [...str];
    }
    // Borrowed from lodash:
    static isString(val) {
        return typeof val === 'string' || ((!!val && typeof val === 'object') && Object.prototype.toString.call(val) === '[object String]');
    }
    // split a very large string, into an array where each element is at most maxChunkSize chars
    static splitToChunks(input, maxChunkSize) {
        if (maxChunkSize <= 0) {
            throw Error('Invalid maxChunkSize');
        }
        if (!input) {
            return [input];
        }
        const length = input.length;
        if (length <= maxChunkSize) {
            return [input];
        }
        const chunks = [];
        let pos = 0;
        while (pos + maxChunkSize <= length) {
            chunks.push(input.substring(pos, pos + maxChunkSize));
            pos += maxChunkSize;
        }
        if (pos < length) {
            // remainder
            chunks.push(input.substring(pos));
        }
        return chunks;
    }
    static toSSNFormat(input) {
        if (input === undefined || input === null || input === '' || input.length > 9 || input.length < 9) {
            return input;
        }
        let ssn = input.replace(/\D/g, '');
        ssn = ssn.replace(/^(\d{3})(\d{2})(\d{4}).*/g, '$1-$2-$3');
        return ssn;
    }
    static toEINFormat(input) {
        if (input === undefined || input === null || input === '' || input.length > 9 || input.length < 9) {
            return input;
        }
        let ein = input.replace(/\D/g, '');
        ein = ein.replace(/^(\d{2})(\d{7}).*/g, '$1-$2');
        return ein;
    }
    static areEqualIgnoreCase(string1, string2) {
        if (string1 === string2) {
            return true;
        }
        const val1 = string1 || '';
        const val2 = string2 || '';
        return val1.toLocaleLowerCase() === val2.toLocaleLowerCase();
    }
    static containsEmojis(input) {
        // WARNING: This probably doesn't cover all possible emojis but I'm not sure that's possible.
        // Falsey strings do not contain emojis.
        // Country flags are a different set of unicode chars, so check both.
        return !!input && (this.reHasEmoticonChar.test(input) || this.reHasEmojiChar.test(input) || this.reHasEmojiFlagChar.test(input));
    }
    /* Strips every thing that is not A-z in ascii character range
    */
    static stripNonAsciiAlpha(input, maxLength = 0) {
        if (!input || !input.replace) {
            return '';
        }
        let result = input.replace(/[^A-z]/g, '');
        if (maxLength > 0) {
            return result.substring(0, maxLength);
        }
        return result;
    }
    static areAsciiAlphaCharactersEqual(value1, value2, ignoreCase, requireAtleastOneAlphaCharacter = true) {
        let val1 = this.stripNonAsciiAlpha(value1);
        if (!val1 && requireAtleastOneAlphaCharacter) {
            // we already checked if both strings are falsey
            return false;
        }
        let val2 = this.stripNonAsciiAlpha(value2);
        if (ignoreCase) {
            val1 = val1.toLocaleLowerCase();
            val2 = val2.toLocaleLowerCase();
        }
        return val1 === val2;
    }
    // Returns a fraction between 0 and 1, which indicates the degree of similarity between the two strings. 
    // 0 indicates completely different strings, 1 indicates identical strings. The comparison is case-sensitive.
    static compareTwoStrings(first, second) {
        first = first.replace(/\s+/g, '');
        second = second.replace(/\s+/g, '');
        if (first === second) {
            return 1;
        } // identical or empty
        if (first.length < 2 || second.length < 2) {
            return 0;
        } // if either is a 0-letter or 1-letter string
        let firstBigrams = new Map();
        for (let i = 0; i < first.length - 1; i++) {
            const bigram = first.substring(i, i + 2);
            const count = firstBigrams.has(bigram) ? (firstBigrams.get(bigram) + 1) : 1;
            firstBigrams.set(bigram, count);
        }
        let intersectionSize = 0;
        for (let i = 0; i < second.length - 1; i++) {
            const bigram = second.substring(i, i + 2);
            const count = firstBigrams.has(bigram) ? firstBigrams.get(bigram) : 0;
            if (count > 0) {
                firstBigrams.set(bigram, count - 1);
                intersectionSize++;
            }
        }
        // Applying Dice Coefficient
        return (2.0 * intersectionSize) / (first.length + second.length - 2);
    }
    static htmlEncode(html) {
        if (html === undefined) {
            return undefined;
        }
        else {
            return html.replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/'/g, '&#39;')
                .replace(/"/g, '&#34;');
        }
    }
    static { this.xmlMap = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&apos;',
    }; }
    /**
    * Escapes XML special characters and truncates without breaking escape sequences.
    * Example:
    *   XmlUtils.safeTruncateAndEscape("Refund & Reimbursement", 20)
    *   → "Refund &amp; Reimbur"
    *   XmlUtils.safeTruncateAndEscape("Refund & Reimbursement", 10)
    *   → "Refund"
    *   (instead of "Refund &amp;" or broken "Refund &am")
    * Performance Note:
    * Uses a pre-defined `xmlMap` and processes input character-by-character
    * to avoid re-escaping the entire string in each loop iteration. This is
    * significantly faster than repeatedly calling xmlEscape() on substrings,
    * especially in large transaction exports.
    */
    static safeTruncateAndEscape(input, maxEscapedLength) {
        if (input === undefined) {
            return undefined;
        }
        const parts = [];
        let currentLength = 0;
        for (let i = 0; i < input.length; i++) {
            const ch = input[i];
            const escaped = this.xmlMap[ch] ?? ch;
            if ((currentLength + escaped.length) > maxEscapedLength) {
                break;
            }
            parts.push(escaped);
            currentLength += escaped.length;
        }
        return parts.join('');
    }
    static confirmOpenCharMatchesClosingChar(text, openChar, closeChar) {
        if (openChar === closeChar) {
            // if char is the same (e.g. quotes) just check for even number
            return this.confirmEvenNumberOfChars(text, openChar);
        }
        let currentBraceDepth = 0;
        let currentlyClosing = false;
        for (let i = 0; i < text.length; i++) {
            if (text[i] === openChar) {
                if (currentlyClosing) {
                    return false; // we opened a new brace beforing finish closing
                }
                currentBraceDepth++;
            }
            if (text[i] === closeChar) {
                currentlyClosing = true;
                currentBraceDepth--;
                if (currentBraceDepth === 0) {
                    currentlyClosing = false; // full closed
                }
                if (currentBraceDepth < 0) {
                    return false; // more closing braces then appropriate
                }
            }
        }
        return currentBraceDepth === 0;
    }
    static confirmEvenNumberOfChars(text, char) {
        let count = 0;
        for (let i = 0; i < text.length; i++) {
            if (text[i] === char) {
                count++;
            }
        }
        return count % 2 === 0;
    }
}
//# sourceMappingURL=string-utils.js.map