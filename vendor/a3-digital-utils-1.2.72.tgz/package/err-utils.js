export class ErrUtils {
    static isTiemoutError(err) {
        if (err && err.code === 'ESOCKETTIMEDOUT') {
            return true;
        }
        if (err && err.message === 'ESOCKETTIMEDOUT') {
            return true;
        }
        return false;
    }
}
//# sourceMappingURL=err-utils.js.map