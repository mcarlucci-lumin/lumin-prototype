export const CANADA_PROVINCES = [
    { abbr: 'NL', name: 'Newfoundland and Labrador' },
    { abbr: 'PE', name: 'Prince Edward Island' },
    { abbr: 'NS', name: 'Nova Scotia' },
    { abbr: 'NB', name: 'New Brunswick' },
    { abbr: 'QC', name: 'Quebec' },
    { abbr: 'ON', name: 'Ontario' },
    { abbr: 'MB', name: 'Manitoba' },
    { abbr: 'SK', name: 'Saskatchewan' },
    { abbr: 'AB', name: 'Alberta' },
    { abbr: 'BC', name: 'British Columbia' },
    { abbr: 'YT', name: 'Yukon' },
    { abbr: 'NT', name: 'Northwest Territories' },
    { abbr: 'NU', name: 'Nunavut' }
];
//# sourceMappingURL=canada-provinces.js.map