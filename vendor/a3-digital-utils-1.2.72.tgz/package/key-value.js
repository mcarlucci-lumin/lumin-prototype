export class KeyValue {
}
//# sourceMappingURL=key-value.js.map