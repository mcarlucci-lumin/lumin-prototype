export class LanguageArray extends Array {
    constructor(languages, englishLanguage) {
        super();
        for (let i = 0; i < languages.length; i++) {
            this.push(languages[i]);
        }
        this.English = englishLanguage;
    }
}
export const LANGUAGE_CODES = {
    English: 'en',
    Spanish: 'es',
    Burmese: 'my'
};
export const LANGUAGES = new LanguageArray([
    { code: LANGUAGE_CODES.English, name: 'English', nativeName: 'English' },
    { code: LANGUAGE_CODES.Spanish, name: 'Spanish', nativeName: 'Español' },
    { code: LANGUAGE_CODES.Burmese, name: 'Burmese', nativeName: 'မြန်မာ' }
], { code: LANGUAGE_CODES.English, name: 'English', nativeName: 'English' });
export const LANGUAGE_WILDCARD = '*';
//# sourceMappingURL=languages.js.map