export class ObjectUtils {
    /// gets a value from an object using field1.subfield1.subfield2
    /// e.g. getPropertyValue(item, 'user.firstName') = 'Scott'
    /// used to get field values for property expressions
    static getPropertyValue(item, propertyExpression) {
        if (item === undefined) {
            return undefined;
        }
        if (item === null) {
            return null;
        }
        if (!propertyExpression) {
            return undefined;
        }
        const fields = propertyExpression.split('.').map(x => x.trim());
        let currentItem = item;
        for (let field of fields) {
            if (currentItem[field] === undefined) {
                return undefined;
            }
            else if (currentItem[field] === null) {
                return null;
            }
            else {
                currentItem = currentItem[field];
            }
        }
        return currentItem;
    }
    // set a property or subproperty on the item to the value
    // if a parent property is missing (e.g. expression hostData.myValue and hostData is undefined)
    // you can either choose to not set the property at all, or to initialize the parent property to {} if it is missing 
    static setPropertyValue(item, propertyExpression, value, initalizeParentPropertyIfMissing) {
        if (item === undefined) {
            return;
        }
        if (item === null) {
            return;
        }
        if (!propertyExpression) {
            return;
        }
        let fields = propertyExpression.split('.').map(x => x.trim());
        // get the item that has the actual field property
        // for a simple expression with no subproperties (i.e. dots) item is what we want
        let currentItem = item;
        let propertyName = fields[fields.length - 1];
        if (fields.length > 1) {
            fields = fields.slice(0, fields.length - 1);
            // loop throuh parent fields and initialize if undefined
            for (let field of fields) {
                if (currentItem[field] === undefined) {
                    if (initalizeParentPropertyIfMissing) {
                        currentItem[field] = {};
                    }
                    else {
                        return;
                    }
                }
                else if (currentItem[field] === null) {
                    if (initalizeParentPropertyIfMissing) {
                        currentItem[field] = {};
                    }
                    else {
                        return;
                    }
                }
                currentItem = currentItem[field];
            }
        }
        currentItem[propertyName] = value;
    }
    static overlayProperties(dest, src, ignoreValues) {
        if (!dest) {
            throw Error(`Invalid dest parameter: ${dest}`);
        }
        if (!src) {
            throw Error(`Invalid src parameter: ${src}`);
        }
        const ignoreSet = new Set(ignoreValues);
        const parentStack = [[dest, src]];
        while (parentStack.length > 0) {
            const [curDest, curSrc] = parentStack.pop();
            for (let [key, nextSrc] of Object.entries(curSrc)) {
                if (nextSrc instanceof Object) {
                    let nextDest = curDest[key];
                    if (!nextDest) {
                        nextDest = {};
                    }
                    curDest[key] = nextDest;
                    parentStack.push([nextDest, nextSrc]);
                }
                else if (!ignoreSet.has(nextSrc)) {
                    if (nextSrc !== undefined) {
                        curDest[key] = nextSrc;
                    }
                }
            }
        }
    }
}
//# sourceMappingURL=object-utils.js.map