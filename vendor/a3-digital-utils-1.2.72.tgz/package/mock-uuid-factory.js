import { UuidFactory } from './uuid-factory.js';
import { v4 as uuidv4 } from 'uuid';
export class MockUuidFactory extends UuidFactory {
    constructor() {
        super();
        this.testIndex = -1;
    }
    setTestUuids(testUuids) {
        this.testUuids = testUuids;
        this.testIndex = 0;
    }
    create() {
        if (!this.testUuids || this.testUuids.length === 0) {
            return uuidv4();
        }
        else if (this.testIndex >= this.testUuids.length) {
            this.testIndex = 0;
            return this.testUuids[this.testIndex++];
        }
        else {
            return this.testUuids[this.testIndex++];
        }
    }
}
//# sourceMappingURL=mock-uuid-factory.js.map