// This list is specific to currency mappings and is distinct in utility from COUNTRIES for currencies used multiple places such as Euros
export const CURRENCIES = [
    {
        symbol: '€',
        name: 'Euro',
        alphaCode: 'EUR',
        flagEmoji: '💶'
    },
    {
        symbol: '$',
        name: 'US Dollar',
        alphaCode: 'USD',
        flagEmoji: '🇺🇸'
    },
    {
        symbol: 'CA$',
        name: 'Canadian Dollar',
        alphaCode: 'CAD',
        flagEmoji: '🇨🇦'
    },
    {
        symbol: 'AED',
        name: 'United Arab Emirates Dirham',
        alphaCode: 'AED',
        flagEmoji: '🇦🇪'
    },
    {
        symbol: 'Af',
        name: 'Afghan Afghani',
        alphaCode: 'AFN',
        flagEmoji: '🇦🇫'
    },
    {
        symbol: 'ALL',
        name: 'Albanian Lek',
        alphaCode: 'ALL',
        flagEmoji: '🇦🇱'
    },
    {
        symbol: 'AMD',
        name: 'Armenian Dram',
        alphaCode: 'AMD',
        flagEmoji: '🇦🇲'
    },
    {
        symbol: 'ƒ',
        name: 'Netherlands Antillean guilder',
        alphaCode: 'ANG',
        flagEmoji: '🇨🇼'
    },
    {
        symbol: 'Kz',
        name: 'Angolan Kwanza',
        alphaCode: 'AOA',
        flagEmoji: '🇦🇴'
    },
    {
        symbol: 'AR$',
        name: 'Argentine Peso',
        alphaCode: 'ARS',
        flagEmoji: '🇦🇷'
    },
    {
        symbol: 'AU$',
        name: 'Australian Dollar',
        alphaCode: 'AUD',
        flagEmoji: '🇦🇺'
    },
    {
        symbol: 'Afl',
        name: 'Aruban Florin',
        alphaCode: 'AWG',
        flagEmoji: '🇦🇼'
    },
    {
        symbol: 'man.',
        name: 'Azerbaijani Manat',
        alphaCode: 'AZN',
        flagEmoji: '🇦🇿'
    },
    {
        symbol: 'KM',
        name: 'Bosnia-Herzegovina Convertible Mark',
        alphaCode: 'BAM',
        flagEmoji: '🇧🇦'
    },
    {
        symbol: 'Tk',
        name: 'Bangladeshi Taka',
        alphaCode: 'BDT',
        flagEmoji: '🇧🇩'
    },
    {
        symbol: 'BGN',
        name: 'Bulgarian Lev',
        alphaCode: 'BGN',
        flagEmoji: '🇧🇬'
    },
    {
        symbol: 'BD',
        name: 'Bahraini Dinar',
        alphaCode: 'BHD',
        flagEmoji: '🇧🇭'
    },
    {
        symbol: 'FBu',
        name: 'Burundian Franc',
        alphaCode: 'BIF',
        flagEmoji: '🇧🇮'
    },
    {
        symbol: 'BN$',
        name: 'Brunei Dollar',
        alphaCode: 'BND',
        flagEmoji: '🇧🇳'
    },
    {
        symbol: 'BBD$',
        name: 'Barbadian dollar',
        alphaCode: 'BBD',
        flagEmoji: '🇧🇧'
    },
    {
        symbol: 'B$',
        name: 'Bahamian Dollar',
        alphaCode: 'BSD',
        flagEmoji: '🇧🇸'
    },
    {
        symbol: '$',
        name: 'Bermudian Dollar',
        alphaCode: 'BMD',
        flagEmoji: '🇧🇲'
    },
    {
        symbol: 'Bs',
        name: 'Bolivian Boliviano',
        alphaCode: 'BOB',
        flagEmoji: '🇧🇴'
    },
    {
        symbol: 'R$',
        name: 'Brazilian Real',
        alphaCode: 'BRL',
        flagEmoji: '🇧🇷'
    },
    {
        symbol: 'Nu.',
        name: 'Bhutanese Ngultrum',
        alphaCode: 'BTN',
        flagEmoji: '🇧🇹'
    },
    {
        symbol: 'BWP',
        name: 'Botswanan Pula',
        alphaCode: 'BWP',
        flagEmoji: '🇧🇼'
    },
    {
        symbol: 'BYR',
        name: 'Belarusian Ruble',
        alphaCode: 'BYR',
        flagEmoji: '🇧🇾'
    },
    {
        symbol: 'BZ$',
        name: 'Belize Dollar',
        alphaCode: 'BZD',
        flagEmoji: '🇧🇿'
    },
    {
        symbol: 'CDF',
        name: 'Congolese Franc',
        alphaCode: 'CDF',
        flagEmoji: '🇨🇩'
    },
    {
        symbol: 'CHF',
        name: 'Swiss Franc',
        alphaCode: 'CHF',
        flagEmoji: '🇨🇭'
    },
    {
        symbol: 'CL$',
        name: 'Chilean Peso',
        alphaCode: 'CLP',
        flagEmoji: '🇨🇱'
    },
    {
        symbol: 'CUC$',
        name: 'Cuban convertible peso',
        alphaCode: 'CUC',
        flagEmoji: '🇨🇺'
    },
    {
        symbol: 'CN¥',
        name: 'Chinese Yuan',
        alphaCode: 'CNY',
        flagEmoji: '🇨🇳'
    },
    {
        symbol: 'CO$',
        name: 'Colombian Peso',
        alphaCode: 'COP',
        flagEmoji: '🇨🇴'
    },
    {
        symbol: '$MN',
        name: 'Cuban peso',
        alphaCode: 'CUP',
        flagEmoji: '🇨🇺'
    },
    {
        symbol: '₡',
        name: 'Costa Rican Colón',
        alphaCode: 'CRC',
        flagEmoji: '🇨🇷'
    },
    {
        symbol: 'CV$',
        name: 'Cape Verdean Escudo',
        alphaCode: 'CVE',
        flagEmoji: '🇨🇻'
    },
    {
        symbol: 'Kč',
        name: 'Czech Republic Koruna',
        alphaCode: 'CZK',
        flagEmoji: '🇨🇿'
    },
    {
        symbol: 'Fdj',
        name: 'Djiboutian Franc',
        alphaCode: 'DJF',
        flagEmoji: '🇩🇯'
    },
    {
        symbol: 'Dkr',
        name: 'Danish Krone',
        alphaCode: 'DKK',
        flagEmoji: '🇩🇰'
    },
    {
        symbol: 'RD$',
        name: 'Dominican Peso',
        alphaCode: 'DOP',
        flagEmoji: '🇩🇴'
    },
    {
        symbol: 'DA',
        name: 'Algerian Dinar',
        alphaCode: 'DZD',
        flagEmoji: '🇩🇿'
    },
    {
        symbol: 'Ekr',
        name: 'Estonian Kroon',
        alphaCode: 'EEK',
        flagEmoji: '🇪🇪'
    },
    {
        symbol: 'EGP',
        name: 'Egyptian Pound',
        alphaCode: 'EGP',
        flagEmoji: '🇪🇬'
    },
    {
        symbol: 'Nfk',
        name: 'Eritrean Nakfa',
        alphaCode: 'ERN',
        flagEmoji: '🇪🇷'
    },
    {
        symbol: 'Br',
        name: 'Ethiopian Birr',
        alphaCode: 'ETB',
        flagEmoji: '🇪🇹'
    },
    {
        symbol: '£',
        name: 'Falkland Island Pound',
        alphaCode: 'FKP',
        flagEmoji: '🇫🇰'
    },
    {
        symbol: 'FJ$',
        name: 'Fijian dollar',
        alphaCode: 'FJD',
        flagEmoji: '🇫🇯'
    },
    {
        symbol: '£',
        name: 'British Pound Sterling',
        alphaCode: 'GBP',
        flagEmoji: '🇬🇧'
    },
    {
        symbol: 'GEL',
        name: 'Georgian Lari',
        alphaCode: 'GEL',
        flagEmoji: '🇬🇪'
    },
    {
        symbol: 'GH₵',
        name: 'Ghanaian Cedi',
        alphaCode: 'GHS',
        flagEmoji: '🇬🇭'
    },
    {
        symbol: '£',
        name: 'Gibraltar Pound',
        alphaCode: 'GIP',
        flagEmoji: '🇬🇮'
    },
    {
        symbol: 'FG',
        name: 'Guinean Franc',
        alphaCode: 'GNF',
        flagEmoji: '🇬🇳'
    },
    {
        symbol: 'GTQ',
        name: 'Guatemalan Quetzal',
        alphaCode: 'GTQ',
        flagEmoji: '🇬🇹'
    },
    {
        symbol: 'G$',
        name: 'Guyanese dollar',
        alphaCode: 'GYD',
        flagEmoji: '🇬🇾'
    },
    {
        symbol: 'D',
        name: 'Gambian Dalasi',
        alphaCode: 'GMD',
        flagEmoji: '🇬🇲'
    },
    {
        symbol: '£',
        name: 'Guernsey Pound',
        alphaCode: 'GGP',
        flagEmoji: '🇬🇬'
    },
    {
        symbol: 'HK$',
        name: 'Hong Kong Dollar',
        alphaCode: 'HKD',
        flagEmoji: '🇭🇰'
    },
    {
        symbol: 'HNL',
        name: 'Honduran Lempira',
        alphaCode: 'HNL',
        flagEmoji: '🇭🇳'
    },
    {
        symbol: 'kn',
        name: 'Croatian Kuna',
        alphaCode: 'HRK',
        flagEmoji: '🇭🇷'
    },
    {
        symbol: 'Ft',
        name: 'Hungarian Forint',
        alphaCode: 'HUF',
        flagEmoji: '🇭🇺'
    },
    {
        symbol: 'G',
        name: 'Haitian Gourde',
        alphaCode: 'HTG',
        flagEmoji: '🇭🇹'
    },
    {
        symbol: 'Rp',
        name: 'Indonesian Rupiah',
        alphaCode: 'IDR',
        flagEmoji: '🇮🇩'
    },
    {
        symbol: '₪',
        name: 'Israeli New Sheqel',
        alphaCode: 'ILS',
        flagEmoji: '🇮🇱'
    },
    {
        symbol: '£',
        name: 'Isle of Man Pound',
        alphaCode: 'IMP',
        flagEmoji: '🇮🇲'
    },
    {
        symbol: 'Rs',
        name: 'Indian Rupee',
        alphaCode: 'INR',
        flagEmoji: '🇮🇳'
    },
    {
        symbol: 'IQD',
        name: 'Iraqi Dinar',
        alphaCode: 'IQD',
        flagEmoji: '🇮🇶'
    },
    {
        symbol: 'IRR',
        name: 'Iranian Rial',
        alphaCode: 'IRR',
        flagEmoji: '🇮🇷'
    },
    {
        symbol: 'Ikr',
        name: 'Icelandic Króna',
        alphaCode: 'ISK',
        flagEmoji: '🇮🇸'
    },
    {
        symbol: 'J$',
        name: 'Jamaican Dollar',
        alphaCode: 'JMD',
        flagEmoji: '🇯🇲'
    },
    {
        symbol: 'JD',
        name: 'Jordanian Dinar',
        alphaCode: 'JOD',
        flagEmoji: '🇯🇴'
    },
    {
        symbol: '¥',
        name: 'Japanese Yen',
        alphaCode: 'JPY',
        flagEmoji: '🇯🇵'
    },
    {
        symbol: 'с',
        name: 'Kyrgyzstani som',
        alphaCode: 'KGS',
        flagEmoji: '🇰🇬'
    },
    {
        symbol: 'KHR',
        name: 'Cambodian Riel',
        alphaCode: 'KHR',
        flagEmoji: '🇰🇭'
    },
    {
        symbol: 'CF',
        name: 'Comorian Franc',
        alphaCode: 'KMF',
        flagEmoji: '🇰🇲'
    },
    {
        symbol: '₩',
        name: 'North Korean Won',
        alphaCode: 'KPW',
        flagEmoji: '🇰🇵'
    },
    {
        symbol: '₩',
        name: 'South Korean Won',
        alphaCode: 'KRW',
        flagEmoji: '🇰🇷'
    },
    {
        symbol: 'KD',
        name: 'Kuwaiti Dinar',
        alphaCode: 'KWD',
        flagEmoji: '🇰🇼'
    },
    {
        symbol: '$',
        name: 'Cayman Islands dollar',
        alphaCode: 'KYD',
        flagEmoji: '🇰🇾'
    },
    {
        symbol: 'KZT',
        name: 'Kazakhstani Tenge',
        alphaCode: 'KZT',
        flagEmoji: '🇰🇿'
    },
    {
        symbol: 'Ksh',
        name: 'Kenyan Shilling',
        alphaCode: 'KES',
        flagEmoji: '🇰🇪'
    },
    {
        symbol: '₭',
        name: 'Lao kip',
        alphaCode: 'LAK',
        flagEmoji: '🇱🇦'
    },
    {
        symbol: 'LB£',
        name: 'Lebanese Pound',
        alphaCode: 'LBP',
        flagEmoji: '🇱🇧'
    },
    {
        symbol: 'SLRs',
        name: 'Sri Lankan Rupee',
        alphaCode: 'LKR',
        flagEmoji: '🇱🇰'
    },
    {
        symbol: '$',
        name: 'Liberian Dollar',
        alphaCode: 'LRD',
        flagEmoji: '🇱🇷'
    },
    {
        symbol: 'Lt',
        name: 'Lithuanian Litas',
        alphaCode: 'LTL',
        flagEmoji: '🇱🇹'
    },
    {
        symbol: 'L',
        name: 'Basotho Loti',
        alphaCode: 'LSL',
        flagEmoji: '🇱🇸'
    },
    {
        symbol: 'Ls',
        name: 'Latvian Lats',
        alphaCode: 'LVL',
        flagEmoji: '🇱🇻'
    },
    {
        symbol: 'LD',
        name: 'Libyan Dinar',
        alphaCode: 'LYD',
        flagEmoji: '🇱🇾'
    },
    {
        symbol: 'MAD',
        name: 'Moroccan Dirham',
        alphaCode: 'MAD',
        flagEmoji: '🇲🇦'
    },
    {
        symbol: 'MDL',
        name: 'Moldovan Leu',
        alphaCode: 'MDL',
        flagEmoji: '🇲🇩'
    },
    {
        symbol: 'MGA',
        name: 'Malagasy Ariary',
        alphaCode: 'MGA',
        flagEmoji: '🇲🇬'
    },
    {
        symbol: 'MKD',
        name: 'Macedonian Denar',
        alphaCode: 'MKD',
        flagEmoji: '🇲🇰'
    },
    {
        symbol: 'MMK',
        name: 'Myanma Kyat',
        alphaCode: 'MMK',
        flagEmoji: '🇲🇲'
    },
    {
        symbol: 'MOP$',
        name: 'Macanese Pataca',
        alphaCode: 'MOP',
        flagEmoji: '🇲🇴'
    },
    {
        symbol: 'MURs',
        name: 'Mauritian Rupee',
        alphaCode: 'MUR',
        flagEmoji: '🇲🇺'
    },
    {
        symbol: 'MK',
        name: 'Malawian Kwacha',
        alphaCode: 'MWK',
        flagEmoji: '🇲🇼'
    },
    {
        symbol: 'MVR',
        name: 'Maldivian Rufiyaa',
        alphaCode: 'MVR',
        flagEmoji: '🇲🇻'
    },
    {
        symbol: 'MX$',
        name: 'Mexican Peso',
        alphaCode: 'MXN',
        flagEmoji: '🇲🇽'
    },
    {
        symbol: 'RM',
        name: 'Malaysian Ringgit',
        alphaCode: 'MYR',
        flagEmoji: '🇲🇾'
    },
    {
        symbol: 'MTn',
        name: 'Mozambican Metical',
        alphaCode: 'MZN',
        flagEmoji: '🇲🇿'
    },
    {
        symbol: 'N$',
        name: 'Namibian Dollar',
        alphaCode: 'NAD',
        flagEmoji: '🇳🇦'
    },
    {
        symbol: '₦',
        name: 'Nigerian Naira',
        alphaCode: 'NGN',
        flagEmoji: '🇳🇬'
    },
    {
        symbol: 'C$',
        name: 'Nicaraguan Córdoba',
        alphaCode: 'NIO',
        flagEmoji: '🇳🇮'
    },
    {
        symbol: 'Nkr',
        name: 'Norwegian Krone',
        alphaCode: 'NOK',
        flagEmoji: '🇳🇴'
    },
    {
        symbol: 'NPRs',
        name: 'Nepalese Rupee',
        alphaCode: 'NPR',
        flagEmoji: '🇳🇵'
    },
    {
        symbol: 'NZ$',
        name: 'New Zealand Dollar',
        alphaCode: 'NZD',
        flagEmoji: '🇳🇿'
    },
    {
        symbol: 'OMR',
        name: 'Omani Rial',
        alphaCode: 'OMR',
        flagEmoji: '🇴🇲'
    },
    {
        symbol: 'B/.',
        name: 'Panamanian Balboa',
        alphaCode: 'PAB',
        flagEmoji: '🇵🇦'
    },
    {
        symbol: 'S/.',
        name: 'Peruvian Nuevo Sol',
        alphaCode: 'PEN',
        flagEmoji: '🇵🇪'
    },
    {
        symbol: '₱',
        name: 'Philippine Peso',
        alphaCode: 'PHP',
        flagEmoji: '🇵🇭'
    },
    {
        symbol: 'PKRs',
        name: 'Pakistani Rupee',
        alphaCode: 'PKR',
        flagEmoji: '🇵🇰'
    },
    {
        symbol: 'K',
        name: 'Papua New Guinean Kina',
        alphaCode: 'PGK',
        flagEmoji: '🇵🇬'
    },
    {
        symbol: 'zł',
        name: 'Polish Zloty',
        alphaCode: 'PLN',
        flagEmoji: '🇵🇱'
    },
    {
        symbol: '₲',
        name: 'Paraguayan Guarani',
        alphaCode: 'PYG',
        flagEmoji: '🇵🇾'
    },
    {
        symbol: 'QR',
        name: 'Qatari Rial',
        alphaCode: 'QAR',
        flagEmoji: '🇶🇦'
    },
    {
        symbol: 'RON',
        name: 'Romanian Leu',
        alphaCode: 'RON',
        flagEmoji: '🇷🇴'
    },
    {
        symbol: 'din.',
        name: 'Serbian Dinar',
        alphaCode: 'RSD',
        flagEmoji: '🇷🇸'
    },
    {
        symbol: 'RUB',
        name: 'Russian Ruble',
        alphaCode: 'RUB',
        flagEmoji: '🇷🇺'
    },
    {
        symbol: 'RWF',
        name: 'Rwandan Franc',
        alphaCode: 'RWF',
        flagEmoji: '🇷🇼'
    },
    {
        symbol: 'SR',
        name: 'Saudi Riyal',
        alphaCode: 'SAR',
        flagEmoji: '🇸🇦'
    },
    {
        symbol: '₨',
        name: 'Seychellois Rupee',
        alphaCode: 'SCR',
        flagEmoji: '🇸🇨'
    },
    {
        symbol: 'WS$',
        name: 'Samoan Tala',
        alphaCode: 'WST',
        flagEmoji: '🇼🇸'
    },
    {
        symbol: '$',
        name: 'Solomon Islander Dollar',
        alphaCode: 'SBD',
        flagEmoji: '🇸🇧'
    },
    {
        symbol: '₡',
        name: 'Salvadoran Colon',
        alphaCode: 'SVC',
        flagEmoji: '🇸🇻'
    },
    {
        symbol: 'SDG',
        name: 'Sudanese Pound',
        alphaCode: 'SDG',
        flagEmoji: '🇸🇩'
    },
    {
        symbol: 'Sr$',
        name: 'Surinamese Dollar',
        alphaCode: 'SRD',
        flagEmoji: '🇸🇷'
    },
    {
        symbol: 'Skr',
        name: 'Swedish Krona',
        alphaCode: 'SEK',
        flagEmoji: '🇸🇪'
    },
    {
        symbol: 'S$',
        name: 'Singapore Dollar',
        alphaCode: 'SGD',
        flagEmoji: '🇸🇬'
    },
    {
        symbol: 'Le',
        name: 'Sierra Leonean Leone',
        alphaCode: 'SLL',
        flagEmoji: '🇸🇱'
    },
    {
        symbol: 'Ssh',
        name: 'Somali Shilling',
        alphaCode: 'SOS',
        flagEmoji: '🇸🇴'
    },
    {
        symbol: '£',
        name: 'South Sudanese pound',
        alphaCode: 'SSP',
        flagEmoji: '🇸🇸'
    },
    {
        symbol: 'Db',
        name: 'Sao Tomean Dobra',
        alphaCode: 'STN',
        flagEmoji: '🇸🇹'
    },
    {
        symbol: '£',
        name: 'Saint Helenian Pound',
        alphaCode: 'SHP',
        flagEmoji: '🇸🇭'
    },
    {
        symbol: 'SY£',
        name: 'Syrian Pound',
        alphaCode: 'SYP',
        flagEmoji: '🇸🇾'
    },
    {
        symbol: 'L',
        name: 'Swazi Lilangeni',
        alphaCode: 'SZL',
        flagEmoji: '🇸🇿'
    },
    {
        symbol: '฿',
        name: 'Thai Baht',
        alphaCode: 'THB',
        flagEmoji: '🇹🇭'
    },
    {
        symbol: 'ЅМ',
        name: 'Tajikistani Somoni',
        alphaCode: 'TJS',
        flagEmoji: '🇹🇭'
    },
    {
        symbol: 'DT',
        name: 'Tunisian Dinar',
        alphaCode: 'TND',
        flagEmoji: '🇹🇳'
    },
    {
        symbol: 'T$',
        name: 'Tongan Paʻanga',
        alphaCode: 'TOP',
        flagEmoji: '🇹🇴'
    },
    {
        symbol: 'TL',
        name: 'Turkish Lira',
        alphaCode: 'TRY',
        flagEmoji: '🇹🇷'
    },
    {
        symbol: 'm',
        name: 'Turkmenistani Manat',
        alphaCode: 'TMT',
        flagEmoji: '🇹🇲'
    },
    {
        symbol: 'TT$',
        name: 'Trinidad and Tobago Dollar',
        alphaCode: 'TTD',
        flagEmoji: '🇹🇹'
    },
    {
        symbol: 'NT$',
        name: 'New Taiwan Dollar',
        alphaCode: 'TWD',
        flagEmoji: '🇹🇼'
    },
    {
        symbol: '£',
        name: 'Jersey pound',
        alphaCode: 'JEP',
        flagEmoji: '🇯🇪'
    },
    {
        symbol: 'TSh',
        name: 'Tanzanian Shilling',
        alphaCode: 'TZS',
        flagEmoji: '🇹🇿'
    },
    {
        symbol: '₴',
        name: 'Ukrainian Hryvnia',
        alphaCode: 'UAH',
        flagEmoji: '🇺🇦'
    },
    {
        symbol: 'USh',
        name: 'Ugandan Shilling',
        alphaCode: 'UGX',
        flagEmoji: '🇺🇬'
    },
    {
        symbol: 'UM',
        name: 'Mauritanian Ouguiya',
        alphaCode: 'MRU',
        flagEmoji: '🇲🇷'
    },
    {
        symbol: '₮',
        name: 'Mongolian Tughrik',
        alphaCode: 'MNT',
        flagEmoji: '🇲🇳'
    },
    {
        symbol: '$U',
        name: 'Uruguayan Peso',
        alphaCode: 'UYU',
        flagEmoji: '🇺🇾'
    },
    {
        symbol: 'UZS',
        name: 'Uzbekistan Som',
        alphaCode: 'UZS',
        flagEmoji: '🇺🇿'
    },
    {
        symbol: 'Bs.F.',
        name: 'Venezuelan Bolívar',
        alphaCode: 'VEF',
        flagEmoji: '🇻🇪'
    },
    {
        symbol: '₫',
        name: 'Vietnamese Dong',
        alphaCode: 'VND',
        flagEmoji: '🇻🇳'
    },
    {
        symbol: 'Vt',
        name: 'Ni-Vanuatu Vatu',
        alphaCode: 'VUV',
        flagEmoji: '🇻🇺'
    },
    {
        symbol: 'FCFA',
        name: 'CFA Franc BEAC',
        alphaCode: 'XAF',
        flagEmoji: '🇨🇫'
    },
    {
        symbol: '$',
        name: 'East Caribbean Dollar',
        alphaCode: 'XCD',
        flagEmoji: '🇦🇬'
    },
    {
        symbol: 'CFA',
        name: 'CFA Franc BCEAO',
        alphaCode: 'XOF',
        flagEmoji: '🇨🇮'
    },
    {
        symbol: 'Fr',
        name: 'CFP franc',
        alphaCode: 'XPF',
        flagEmoji: '🇵🇫'
    },
    {
        symbol: 'YR',
        name: 'Yemeni Rial',
        alphaCode: 'YER',
        flagEmoji: '🇾🇪'
    },
    {
        symbol: 'R',
        name: 'South African Rand',
        alphaCode: 'ZAR',
        flagEmoji: '🇿🇦'
    },
    {
        symbol: 'ZK',
        name: 'Zambian Kwacha',
        alphaCode: 'ZMK',
        flagEmoji: '🇿🇲'
    },
    {
        symbol: 'ZiG',
        name: 'Zimbabwe Gold',
        alphaCode: 'ZWG',
        flagEmoji: '🇿🇼'
    }
];
//# sourceMappingURL=currencies.js.map