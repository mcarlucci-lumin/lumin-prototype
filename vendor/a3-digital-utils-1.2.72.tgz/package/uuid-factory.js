import { v4 as uuidv4 } from 'uuid';
export class UuidFactory {
    create() {
        return uuidv4();
    }
}
//# sourceMappingURL=uuid-factory.js.map