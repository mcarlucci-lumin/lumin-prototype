export class NumberList {
    constructor(data) {
        this.data = {};
        if (data) {
            this.data = data;
        }
    }
    includes(num) {
        return this.data[num] === true;
    }
    add(num) {
        this.data[num] = true;
    }
    toArray() {
        return Object.keys(this.data).map(x => Number(x));
    }
}
//# sourceMappingURL=number-list.js.map