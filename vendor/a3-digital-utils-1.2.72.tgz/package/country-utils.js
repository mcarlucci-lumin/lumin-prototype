import { COUNTRIES, DOMESTIC_DIAL_CODE, US_ALPHA2_CODE } from './countries.js';
import { Currency } from './currency.js';
import { PhoneParts } from './phone-parts.js';
import { StringUtils } from './string-utils.js';
export class CountryUtils {
    static { this.UNITED_STATES = COUNTRIES.find(c => c.alpha2 === US_ALPHA2_CODE); }
    static { this.COUNTRIES_WITH_DIAL_CODES = COUNTRIES.filter(x => x.dialCode); }
    static { this.SORTED_DIAL_CODES = this.COUNTRIES_WITH_DIAL_CODES.map(x => x.dialCode).sort((a, b) => b.length - a.length); }
    static getCountriesFromPhoneNumber(value) {
        let matches = [];
        if (value) {
            const [dialCode, phoneNumber] = this.getInternationalPhoneParts(value);
            if (dialCode) {
                matches = COUNTRIES.filter(c => c.dialCode === dialCode);
                // If there are multiple countries, try to match on the phone number area code
                if (matches.length > 1 && phoneNumber) {
                    const areaCodeMatches = matches.filter(c => c.areaCodes?.some(areaCode => phoneNumber.startsWith(areaCode)));
                    if (areaCodeMatches.length > 0) {
                        matches = areaCodeMatches;
                    }
                }
            }
        }
        return matches;
    }
    // Note: this doesn't validate the phone number, just tries to standardize the data.
    // Domestic numbers should be returned as a 10 digit string.
    // International numbers should be returned as +, 1-3 digits, space, up to 13 digits (no formatting beyond space).
    // Ex: +XX XXXXX or +XXX XXXXXXX
    static sanitizePhoneNumber(value, allowInternational = false) {
        if (!value) {
            return '';
        }
        const [dialCode, phoneNumber] = this.getInternationalPhoneParts(value);
        if (dialCode === DOMESTIC_DIAL_CODE) {
            // Phone number starts with "+1 " so remove the first three characters
            return this.sanitizeDomesticPhoneNumber(value.substring(3));
        }
        else if (allowInternational && value.startsWith('+') && dialCode) {
            return `+${dialCode} ${phoneNumber}`.trim();
        }
        // Return a sanitized domestic number (10 numeric digits)
        return this.sanitizeDomesticPhoneNumber(value);
    }
    // TODO: This is confusing with sanitizePhoneNumber. sanitizePhoneNumber should become sanitizeInternationalPhoneNumber.
    // Tech debt ticket is DEV-52746
    static sanitizeDomesticPhoneNumber(value) {
        if (!value) {
            return '';
        }
        // Remove all formatting, then remove leading 0s and 1s.
        const digitsOnly = StringUtils.stripNonNumeric(value);
        const noLeadingOnesOrZeroes = digitsOnly.replace(/^[01]+/, '');
        // Return up to 10 digits
        return noLeadingOnesOrZeroes.substring(0, 10);
    }
    static isForeignPhoneNumber(value) {
        const sanitizedNumber = this.sanitizePhoneNumber(value, true);
        // If it still has a + after being sanitized, it's foreign.
        // No guarantees it's valid.
        return sanitizedNumber.startsWith('+');
    }
    static getInternationalPhoneParts(value) {
        // International phone numbers must begin with a + and have a whitespace after the country code.
        // If they don't, we don't have enough data to parse it.
        if (value.startsWith('+') && value.includes(' ')) {
            const digitsAndSpacesOnly = value.replace(/[^0-9\s]/g, '').trim();
            // Split on whitespace. The country code should be the first value.
            const parts = digitsAndSpacesOnly.split(/\s+/);
            let dialCode = StringUtils.stripNonNumeric(parts[0]);
            // Join all the parts (minus the first one) back together for the phone number.
            let phoneNumber = StringUtils.stripNonNumeric(parts.slice(1).join(''));
            // Dial code can be 1-3 digits
            if (dialCode.length > 3) {
                const extraDigits = dialCode.substring(3);
                dialCode = dialCode.substring(0, 3);
                phoneNumber = extraDigits + phoneNumber;
            }
            // Phone number can be 13 digits long
            phoneNumber = phoneNumber.substring(0, 13);
            return [dialCode || '', phoneNumber || ''];
        }
        else if (value.startsWith('+')) {
            const dialCode = StringUtils.stripNonNumeric(value);
            return [dialCode || '', ''];
        }
        return ['', ''];
    }
    static parsePhoneParts(phone, isPartialPhoneNumber = false) {
        const result = new PhoneParts();
        result.raw = phone || '';
        if (!phone) {
            return result;
        }
        result.fullNumber = StringUtils.trimLeadingZeros(StringUtils.stripNonNumeric(phone));
        let dialCode = null;
        for (let code of this.SORTED_DIAL_CODES) {
            if (result.fullNumber.startsWith(code)) {
                dialCode = code;
                break;
            }
        }
        if (!dialCode) {
            if (isPartialPhoneNumber && result.fullNumber) {
                // Useful for UI trying to match on partially typed country codes.
                // Match on up to the first 3 digits.
                result.partialCountryMatches = this.COUNTRIES_WITH_DIAL_CODES.filter(c => c.dialCode.startsWith(result.fullNumber.substring(0, 3)));
            }
            return result;
        }
        result.dialCode = dialCode;
        result.number = result.fullNumber.slice(dialCode.length);
        const matchingCountries = COUNTRIES.filter(x => x.dialCode === dialCode);
        if (matchingCountries.length === 0) {
            return result;
        }
        if (matchingCountries.length === 1) {
            result.country = matchingCountries[0];
            return result;
        }
        let defaultCountry = null;
        for (let country of matchingCountries) {
            if (country.areaCodes && country.areaCodes.length) {
                for (let areaCode of country.areaCodes) {
                    if (result.number.startsWith(areaCode)) {
                        result.country = country;
                        return result;
                    }
                }
            }
            else {
                defaultCountry = country;
            }
        }
        if (defaultCountry) {
            result.country = defaultCountry;
            return result;
        }
        else {
            result.country = matchingCountries[0];
            return result;
        }
    }
    static sanitizePhoneParts(phoneParts, allowInternational = false) {
        if (!phoneParts) {
            return '';
        }
        return this.sanitizePhoneNumber(`+${phoneParts.dialCode} ${phoneParts.number}`, allowInternational);
    }
    // This method is primarily for parsing phone numbers coming from a third party, such as a vendor integration in a microservice.
    static parseAndSanitizePhoneParts(phone, allowInternational = false) {
        const parts = this.parsePhoneParts(phone);
        return this.sanitizePhoneParts(parts, allowInternational);
    }
    static getUniqueCurrenciesFromCountries(countries) {
        const currencies = [];
        if (!countries) {
            return currencies;
        }
        for (const country of countries) {
            const hasCurrency = currencies.map(c => c.alphaCode).includes(country.currencyAlphaCode);
            if (country.currencyAlphaCode && !hasCurrency) {
                const currency = new Currency();
                currency.alphaCode = country.currencyAlphaCode;
                currency.name = country.currencyName;
                currency.numericCode = country.currencyNumericCode;
                currencies.push(currency);
            }
        }
        return currencies;
    }
    static formattedCurrencyName(currency) {
        if (!currency) {
            return '';
        }
        return `${currency.name || ''} (${currency.alphaCode || ''})`;
    }
    static convertAlpha2ToAlpha3(alpha2) {
        const country = COUNTRIES.find(c => c.alpha2 === alpha2);
        return country ? country.alpha3 : '';
    }
    static convertAlpha3ToAlpha2(alpha3) {
        const country = COUNTRIES.find(c => c.alpha3 === alpha3);
        return country ? country.alpha2 : '';
    }
    static getFlagEmojiForPhoneNumber(phoneNumber) {
        if (phoneNumber === null || phoneNumber === undefined || phoneNumber.trim() === '') {
            return '';
        }
        if (CountryUtils.isForeignPhoneNumber(phoneNumber)) {
            const internationalPhoneParts = CountryUtils.parsePhoneParts(phoneNumber);
            return internationalPhoneParts?.country?.flagEmoji ?? '';
        }
        // For North American phone numbers, we need to add +1
        const domesticNumber = `+1${phoneNumber}`;
        const domesticPhoneParts = CountryUtils.parsePhoneParts(domesticNumber);
        return domesticPhoneParts?.country?.flagEmoji ?? CountryUtils.UNITED_STATES.flagEmoji;
    }
}
//# sourceMappingURL=country-utils.js.map