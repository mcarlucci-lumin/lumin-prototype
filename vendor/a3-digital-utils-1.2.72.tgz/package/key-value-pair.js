export class KeyValuePair {
}
//# sourceMappingURL=key-value-pair.js.map