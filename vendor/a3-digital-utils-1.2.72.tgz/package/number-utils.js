import { NumberList } from './number-list.js';
export class NumberUtils {
    static { this.numberFormatter = new Intl.NumberFormat('en-US'); }
    static { this.numberFormatterNoDecimals = new Intl.NumberFormat('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 }); }
    static currencyAmountsEqual(amount1, amount2) {
        return Math.round(amount1 * 100) === Math.round(amount2 * 100);
    }
    static formatNumber(value, noDecimals = false) {
        if (value === undefined || value === null || Number.isNaN(Number(value))) {
            return '';
        }
        const formatter = noDecimals ? this.numberFormatterNoDecimals : this.numberFormatter;
        return formatter.format(value);
    }
    static formatCurrency(value, noCents = false) {
        return this.formatCurrency2(value, { includeFractionalDigits: !noCents });
    }
    static formatCurrency2(value, options) {
        if (value === undefined || value === null || Number.isNaN(Number(value))) {
            return '';
        }
        // TODO: Some foreign currencies support 0, 2, or 3 digits. Add that designation to CURRENCIES and lookup at this time.
        const fractionalDigits = (options?.includeFractionalDigits ?? true) ? 2 : 0;
        const formatter = new Intl.NumberFormat(options?.locale ?? 'en-US', {
            currency: options?.alphaCode ?? 'USD', style: 'currency', minimumFractionDigits: fractionalDigits, maximumFractionDigits: fractionalDigits
        });
        return formatter.format(value);
    }
    // Display decimal values normally ($12.34), except for .00 (12.00 => $12)
    static formatCurrencyRoundIfNoCents(value) {
        const noCents = value % 1 === 0;
        return this.formatCurrency2(value, { includeFractionalDigits: !noCents });
    }
    static sum(...values) {
        // Prevents precision issues that could arise from adding floating point numbers together.
        // For example, 4.52 + 1.13 evaluates to 5.6499999999999995. This function will return 5.65.
        return Math.round(values.reduce((a, b) => a + b, 0) * 100) / 100;
    }
    /*
    parses commaSeparatedListAndRanges of numbers
    e.g. 1,2,3-9,55,67-70 into an array of all of those numbers
    */
    static parseNumberListAndRanges(listAndRanges) {
        const numberList = new NumberList();
        if (!listAndRanges || !listAndRanges.trim()) {
            return numberList;
        }
        let parts = listAndRanges.split(',');
        for (let part of parts) {
            part = part.trim();
            if (part.indexOf('-') !== -1) {
                let rangeParts = part.split('-');
                let rangeStart = parseInt(rangeParts[0].trim(), 10);
                let rangeEnd = parseInt(rangeParts[1].trim(), 10);
                if (Number.isNaN(rangeStart) || Number.isNaN(rangeEnd)) {
                    throw Error(`${part} is not a number range`);
                }
                for (let i = rangeStart; i <= rangeEnd; i++) {
                    numberList.add(i);
                }
            }
            else {
                const num = parseInt(part, 10);
                if (Number.isNaN(num)) {
                    throw Error(`${part} is not a number`);
                }
                else {
                    numberList.add(num);
                }
            }
        }
        return numberList;
    }
    static getIntWithDefault(value, defaultValue) {
        const num = Number.parseInt(value, 10);
        return Number.isNaN(num) ? defaultValue : num;
    }
}
//# sourceMappingURL=number-utils.js.map