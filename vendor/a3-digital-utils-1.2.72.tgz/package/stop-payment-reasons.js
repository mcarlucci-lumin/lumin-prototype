export const STOP_PAYMENT_REASONS = [
    { value: 'STALE_DATED', description: 'Check stale dated' },
    { value: 'LOST', description: 'Check lost' },
    { value: 'DESTROYED', description: 'Check destroyed' },
    { value: 'NEVER_RECEIVED', description: 'Check never received by payee' },
    { value: 'ISSUED_IN_ERROR', description: 'Check issued in error' },
    { value: 'STOLEN', description: 'Check stolen' },
    { value: 'DISPUTE', description: 'Payment dispute' },
    { value: 'OTHER', description: 'Other' },
    { value: 'WRONG_AMOUNT', description: 'Wrong Amount' },
    { value: 'SUSPECT_FRAUD', description: 'Suspect Fraud' }
];
//# sourceMappingURL=stop-payment-reasons.js.map