export class FieldChange {
}
//# sourceMappingURL=field-change.js.map