export class CachingParser {
    constructor(parseFn) {
        this.parseFn = parseFn;
        this.parsedValues = {};
    }
    parse(text) {
        if (this.parsedValues[text] === undefined) {
            this.parsedValues[text] = this.parseFn(text);
        }
        return this.parsedValues[text];
    }
}
//# sourceMappingURL=caching-parser.js.map