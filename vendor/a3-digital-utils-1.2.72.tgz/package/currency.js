export class Currency {
}
//# sourceMappingURL=currency.js.map