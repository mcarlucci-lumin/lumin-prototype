export class PromiseUtils {
    static wait(milliseconds) {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                resolve();
            }, milliseconds);
        });
    }
}
//# sourceMappingURL=promise-utils.js.map