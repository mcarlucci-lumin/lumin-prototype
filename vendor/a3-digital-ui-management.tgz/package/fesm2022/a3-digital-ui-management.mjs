import * as i2$1 from '@angular/cdk/drag-drop';
import { moveItemInArray, DragDropModule } from '@angular/cdk/drag-drop';
import * as i0 from '@angular/core';
import { EventEmitter, Output, Input, Component, HostBinding, Directive, Optional, ViewChild, ElementRef, ViewChildren, NgModule } from '@angular/core';
import * as i2 from '@angular/forms';
import { UntypedFormControl, Validators, FormGroupDirective, ControlContainer, FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import * as i1 from '@a3-digital/ui-core';
import { BaseTextComponent, HtmlUtils, PageActionItem, SpacingUtils, UuidUtils, ButtonGridItem, InlineAction, UiCoreModule } from '@a3-digital/ui-core';
import * as i5 from '@a3-digital/ui-forms';
import { FormUtils, DEFAULT_MAX_LENGTH, DropdownOption, FormSpacingUtils, MultiSelectDropdownOption, UiFormsModule } from '@a3-digital/ui-forms';
import * as i3 from '@angular/common';
import { CommonModule } from '@angular/common';
import { NumberUtils } from '@a3-digital/utils';
import QuillVideo from 'quill/formats/video';
import { Attributor } from 'parchment';
import Link from 'quill/formats/link';
import Quill from 'quill';
import * as i4 from 'ngx-quill';
import { QuillModule } from 'ngx-quill';
import * as i4$1 from 'ngx-monaco-editor-v2';
import { MonacoEditorModule } from 'ngx-monaco-editor-v2';
import { marked } from 'marked';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

class DragAndDropListItem {
}

class DragAndDropListResult {
    constructor(isValid, listItems = []) {
        this.isValid = isValid;
        this.listItems = listItems;
    }
}

class DragAndDropListComponent extends BaseTextComponent {
    constructor(formBuilder, textService) {
        super(textService, 'ui-management-drag-and-drop-list');
        this.formBuilder = formBuilder;
        /**
        * Required. The array of items (of class DragAndDropListItem) to render in a list.
        **/
        this.listItems = [];
        /**
        * If a dropdown is needed, an array of DropdownOptions must be provided.
        **/
        this.dropdownOptions = [];
        /**
        * The maximum number of items allowed in the list. Once this max is reached, the "Add" button will be disabled.
        **/
        this.maxItemCount = 99;
        /**
        * When enabled, all items will be allowed to be removed.
        **/
        this.allowAllItemRemoval = false;
        /**
        * An optional error message to show if there are no items in the list.
        **/
        this.noItemsErrorMessage = '';
        /**
        * Emits the row's DragAndDropListItem when an action button is clicked, which allows the parent component to handle the action.
        **/
        this.itemActionClicked = new EventEmitter();
        /**
        * Emits the index of the new DragAndDropListItem when the "Add" button is clicked.
        **/
        this.itemAdded = new EventEmitter();
        /**
        * Emits the index of the deleted DragAndDropListItem when the "Remove" button is clicked.
        **/
        this.itemRemoved = new EventEmitter();
        /**
        * Emits an object with a value and index of the changed DragAndDropListItem.
        **/
        this.itemDropdownChanged = new EventEmitter();
        /**
        * Emits the array of DragAndDropListItems after the user drags and drops an item into a different position.
        **/
        this.itemMoved = new EventEmitter();
        this.currentDropdownIndex = 0;
    }
    ngOnInit() {
        this.form = this.formBuilder.group({});
        if (this.dropdownOptions?.length) {
            for (let listItem of this.listItems) {
                const control = new UntypedFormControl(listItem.dropdownValue, Validators.required);
                listItem.dropdownOptions = this.getDropdownOptions(listItem);
                listItem.formControlIndex = this.currentDropdownIndex++;
                this.form.addControl(`dropdown${listItem.formControlIndex}`, control);
            }
        }
        this.setActualMaxItemCount();
    }
    onDropdownChange(value, index) {
        const listItem = this.listItems[index];
        listItem.actionDisabled = value !== 0 && !value;
        listItem.dropdownValue = value;
        this.recalculateDropdowns();
        this.itemDropdownChanged.emit({ value, index });
    }
    addNewListItem() {
        const control = new UntypedFormControl(null, Validators.required);
        this.form.addControl(`dropdown${++this.currentDropdownIndex}`, control);
        const newListItem = new DragAndDropListItem();
        newListItem.actionDisabled = this.actionButtonDisabledForNewItems;
        newListItem.formControlIndex = this.currentDropdownIndex;
        newListItem.dropdownOptions = this.getDropdownOptions(newListItem);
        this.listItems.push(newListItem);
        this.itemAdded.emit(this.listItems.length - 1);
    }
    removeListItem(item, index) {
        this.itemRemoved.emit(index);
        this.listItems.splice(index, 1);
        this.form.removeControl(`dropdown${item.formControlIndex}`);
        this.recalculateDropdowns();
    }
    onListItemAction(item) {
        this.itemActionClicked.emit(item);
    }
    onListItemDrop(event) {
        if (event.previousIndex !== event.currentIndex) {
            moveItemInArray(this.listItems, event.previousIndex, event.currentIndex);
            this.itemMoved.emit(this.listItems);
        }
    }
    validate() {
        if (this.form.invalid) {
            FormUtils.showFormValidation(this.form);
            return new DragAndDropListResult(false);
        }
        return new DragAndDropListResult(true, this.listItems);
    }
    recalculateDropdowns() {
        for (let listItem of this.listItems) {
            listItem.dropdownOptions = this.getUniqueListItemDropdownOptions(listItem);
        }
    }
    getDropdownOptions(item) {
        return this.dropdownOptionsShouldBeUnique ? this.getUniqueListItemDropdownOptions(item) : this.dropdownOptions;
    }
    getUniqueListItemDropdownOptions(item) {
        return this.dropdownOptions.filter(option => option.value === item.dropdownValue || !this.listItems.some(i => i.dropdownValue === option.value));
    }
    setActualMaxItemCount() {
        if (this.dropdownOptionsShouldBeUnique) {
            this.actualMaxItemCount = this.maxItemCount > this.dropdownOptions.length ? this.dropdownOptions.length : this.maxItemCount;
        }
        else {
            this.actualMaxItemCount = this.maxItemCount;
        }
    }
    getDefaultText() {
        return {
            dropdownAriaLabel: 'Dropdown',
            defaultDropdownErrorMessage: 'Required',
            defaultListItemPrefix: 'Item',
            removeButtonLabel: 'Remove'
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: DragAndDropListComponent, deps: [{ token: i2.FormBuilder }, { token: i1.TextService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.17", type: DragAndDropListComponent, isStandalone: false, selector: "ui-management-drag-and-drop-list", inputs: { listItems: "listItems", listItemPrefix: "listItemPrefix", dropdownOptions: "dropdownOptions", dropdownOptionsShouldBeUnique: "dropdownOptionsShouldBeUnique", dropdownErrorMessage: "dropdownErrorMessage", actionButtonDisabledForNewItems: "actionButtonDisabledForNewItems", addButtonLabel: "addButtonLabel", maxItemCount: "maxItemCount", allowAllItemRemoval: "allowAllItemRemoval", noItemsErrorMessage: "noItemsErrorMessage" }, outputs: { itemActionClicked: "itemActionClicked", itemAdded: "itemAdded", itemRemoved: "itemRemoved", itemDropdownChanged: "itemDropdownChanged", itemMoved: "itemMoved" }, usesInheritance: true, ngImport: i0, template: "<form [formGroup]=\"form\" cdkDropList (cdkDropListDropped)=\"onListItemDrop($event)\">\n    <div *ngFor=\"let item of listItems; let i=index; let last=last;\" cdkDrag\n        class=\"drag-and-drop-list-item border-top\" [class.border-bottom]=\"last\">\n        <div class=\"item-prefix-cell mr-3\">\n            {{ listItemPrefix || text.defaultListItemPrefix }} {{ i + 1 }}\n        </div>\n        <div *ngIf=\"dropdownOptions.length === 0\" class=\"d-flex justify-content-center flex-column mr-1\">\n            <div class=\"d-inline-flex align-items-center\">\n                <ui-core-icon *ngIf=\"item.labelIcon\" class=\"mr-1 d-inline-flex align-items-center\"\n                    [icon]=\"item.labelIcon\">\n                </ui-core-icon>\n                <span class=\"text-semibold\">{{ item.label }}</span>\n            </div>\n            <div *ngIf=\"item.message\" class=\"text-clamp-2 text-caption mt-1\">\n                {{ item.message }}\n            </div>\n        </div>\n        <div *ngIf=\"dropdownOptions.length\" class=\"dropdown-container\">\n            <ui-forms-dropdown\n                class=\"my-2 form-control-validation-m-0\"\n                [errorMessage]=\"dropdownErrorMessage || text.defaultDropdownErrorMessage\"\n                [formControlName]=\"'dropdown' + item.formControlIndex\" \n                [hideLabel]=\"true\" \n                [label]=\"text.defaultListItemPrefix + ' ' + (i + 1) + ' ' + text.dropdownAriaLabel\"\n                [options]=\"item.dropdownOptions\" \n                (change)=\"onDropdownChange($event, i)\">\n            </ui-forms-dropdown>\n        </div>\n        <div class=\"buttons-container mr-2\">\n            <ui-core-badge *ngIf=\"item.badgeLabel\" \n                class=\"mr-7\" \n                [message]=\"item.badgeLabel\" \n                theme=\"success\">\n            </ui-core-badge>\n            <ui-core-button *ngIf=\"!item.hideRemoveButton\"\n                buttonClass=\"mr-3\"\n                [disabled]=\"listItems.length === 1 && !allowAllItemRemoval\"\n                icon=\"remove_circle\"\n                [message]=\"text.removeButtonLabel\"\n                (click)=\"removeListItem(item, i)\">\n            </ui-core-button>\n            <ui-core-button *ngIf=\"item.actionButtonLabel\"\n                buttonClass=\"mr-3\"\n                [disabled]=\"item.actionDisabled\"\n                [icon]=\"item.actionButtonIcon\"\n                [message]=\"item.actionButtonLabel\"\n                (click)=\"onListItemAction(item)\">\n            </ui-core-button>\n            <ui-core-icon class=\"drag-icon\" icon=\"drag_indicator\" size=\"xl\">\n            </ui-core-icon>\n        </div>\n    </div>\n    <ui-core-in-line-notification *ngIf=\"listItems.length === 0 && noItemsErrorMessage\"\n        theme=\"error\" [message]=\"noItemsErrorMessage\">\n    </ui-core-in-line-notification>\n    <div *ngIf=\"addButtonLabel\" class=\"mt-2\">\n        <ui-core-button \n            [disabled]=\"listItems?.length >= actualMaxItemCount\" \n            icon=\"add_circle\" \n            [message]=\"addButtonLabel\" \n            (click)=\"addNewListItem()\">\n        </ui-core-button>\n    </div>\n</form>", styles: [".drag-and-drop-list-item{background:var(--color-default);display:flex;min-height:5rem}.drag-and-drop-list-item:hover{cursor:grab}.drag-and-drop-list-item:active{cursor:grabbing}.item-prefix-cell{background-color:var(--color-gray-100);font-weight:var(--type-weight-semibold);display:flex;align-items:center;justify-content:center;min-width:5.563rem}.dropdown-container{flex:1 1 auto;max-width:25rem}.buttons-container{display:flex;align-items:center;margin-left:auto}.drag-icon{margin-top:10px}.cdk-drag-placeholder{opacity:var(--opacity-300);border-bottom:1px solid var(--color-stroke-2);border-left:none;border-right:none;border-top:none}.cdk-drag-preview{border-bottom:1px solid var(--color-stroke-2);opacity:var(--opacity-600)}\n"], dependencies: [{ kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2$1.CdkDropList, selector: "[cdkDropList], cdk-drop-list", inputs: ["cdkDropListConnectedTo", "cdkDropListData", "cdkDropListOrientation", "id", "cdkDropListLockAxis", "cdkDropListDisabled", "cdkDropListSortingDisabled", "cdkDropListEnterPredicate", "cdkDropListSortPredicate", "cdkDropListAutoScrollDisabled", "cdkDropListAutoScrollStep", "cdkDropListElementContainer", "cdkDropListHasAnchor"], outputs: ["cdkDropListDropped", "cdkDropListEntered", "cdkDropListExited", "cdkDropListSorted"], exportAs: ["cdkDropList"] }, { kind: "directive", type: i2$1.CdkDrag, selector: "[cdkDrag]", inputs: ["cdkDragData", "cdkDragLockAxis", "cdkDragRootElement", "cdkDragBoundary", "cdkDragStartDelay", "cdkDragFreeDragPosition", "cdkDragDisabled", "cdkDragConstrainPosition", "cdkDragPreviewClass", "cdkDragPreviewContainer", "cdkDragScale"], outputs: ["cdkDragStarted", "cdkDragReleased", "cdkDragEnded", "cdkDragEntered", "cdkDragExited", "cdkDragDropped", "cdkDragMoved"], exportAs: ["cdkDrag"] }, { kind: "directive", type: i2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i1.BadgeComponent, selector: "ui-core-badge", inputs: ["message", "framed", "theme", "type", "centered", "icon", "iconPosition"] }, { kind: "component", type: i1.ButtonComponent, selector: "ui-core-button", inputs: ["themeGroup", "theme", "message", "icon", "iconPosition", "disabled", "disabledMessage", "showSpinner", "buttonClass", "width", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "ariaLabel", "isFormValid", "e2e", "buttonId"] }, { kind: "component", type: i1.IconComponent, selector: "ui-core-icon", inputs: ["icon", "size", "colorClass", "allowEmojis", "ariaLabel", "alignWithText", "collapseHeight", "scaleWithFonts", "animationPath", "animationData", "animationFreeze", "animationFreezeFrame", "animationLoop", "animationLoopTotal"], outputs: ["animationCompleted"] }, { kind: "component", type: i1.InLineNotificationComponent, selector: "ui-core-in-line-notification", inputs: ["header", "message", "bulletList", "theme", "customIcon", "customAnimationPath", "customAnimationData", "customAnimationFreeze", "customAnimationFreezeFrame", "customAnimationLoop", "customAnimationLoopTotal", "buttons", "showCloseButton"], outputs: ["buttonClicked", "closed"] }, { kind: "component", type: i5.DropdownComponent, selector: "ui-forms-dropdown", inputs: ["iconLeft", "showMenuOptionAsIconLeft", "options", "noOptionsMessage", "actions", "actionButtonIcon", "actionButtonMessage", "actionButtonMessageHidden", "actionButtonDisabled", "actionButtonDisabledSpinner", "menuIconsOnRight", "allowEmojis"], outputs: ["actionButtonClick", "menuSelection"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: DragAndDropListComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-management-drag-and-drop-list', template: "<form [formGroup]=\"form\" cdkDropList (cdkDropListDropped)=\"onListItemDrop($event)\">\n    <div *ngFor=\"let item of listItems; let i=index; let last=last;\" cdkDrag\n        class=\"drag-and-drop-list-item border-top\" [class.border-bottom]=\"last\">\n        <div class=\"item-prefix-cell mr-3\">\n            {{ listItemPrefix || text.defaultListItemPrefix }} {{ i + 1 }}\n        </div>\n        <div *ngIf=\"dropdownOptions.length === 0\" class=\"d-flex justify-content-center flex-column mr-1\">\n            <div class=\"d-inline-flex align-items-center\">\n                <ui-core-icon *ngIf=\"item.labelIcon\" class=\"mr-1 d-inline-flex align-items-center\"\n                    [icon]=\"item.labelIcon\">\n                </ui-core-icon>\n                <span class=\"text-semibold\">{{ item.label }}</span>\n            </div>\n            <div *ngIf=\"item.message\" class=\"text-clamp-2 text-caption mt-1\">\n                {{ item.message }}\n            </div>\n        </div>\n        <div *ngIf=\"dropdownOptions.length\" class=\"dropdown-container\">\n            <ui-forms-dropdown\n                class=\"my-2 form-control-validation-m-0\"\n                [errorMessage]=\"dropdownErrorMessage || text.defaultDropdownErrorMessage\"\n                [formControlName]=\"'dropdown' + item.formControlIndex\" \n                [hideLabel]=\"true\" \n                [label]=\"text.defaultListItemPrefix + ' ' + (i + 1) + ' ' + text.dropdownAriaLabel\"\n                [options]=\"item.dropdownOptions\" \n                (change)=\"onDropdownChange($event, i)\">\n            </ui-forms-dropdown>\n        </div>\n        <div class=\"buttons-container mr-2\">\n            <ui-core-badge *ngIf=\"item.badgeLabel\" \n                class=\"mr-7\" \n                [message]=\"item.badgeLabel\" \n                theme=\"success\">\n            </ui-core-badge>\n            <ui-core-button *ngIf=\"!item.hideRemoveButton\"\n                buttonClass=\"mr-3\"\n                [disabled]=\"listItems.length === 1 && !allowAllItemRemoval\"\n                icon=\"remove_circle\"\n                [message]=\"text.removeButtonLabel\"\n                (click)=\"removeListItem(item, i)\">\n            </ui-core-button>\n            <ui-core-button *ngIf=\"item.actionButtonLabel\"\n                buttonClass=\"mr-3\"\n                [disabled]=\"item.actionDisabled\"\n                [icon]=\"item.actionButtonIcon\"\n                [message]=\"item.actionButtonLabel\"\n                (click)=\"onListItemAction(item)\">\n            </ui-core-button>\n            <ui-core-icon class=\"drag-icon\" icon=\"drag_indicator\" size=\"xl\">\n            </ui-core-icon>\n        </div>\n    </div>\n    <ui-core-in-line-notification *ngIf=\"listItems.length === 0 && noItemsErrorMessage\"\n        theme=\"error\" [message]=\"noItemsErrorMessage\">\n    </ui-core-in-line-notification>\n    <div *ngIf=\"addButtonLabel\" class=\"mt-2\">\n        <ui-core-button \n            [disabled]=\"listItems?.length >= actualMaxItemCount\" \n            icon=\"add_circle\" \n            [message]=\"addButtonLabel\" \n            (click)=\"addNewListItem()\">\n        </ui-core-button>\n    </div>\n</form>", styles: [".drag-and-drop-list-item{background:var(--color-default);display:flex;min-height:5rem}.drag-and-drop-list-item:hover{cursor:grab}.drag-and-drop-list-item:active{cursor:grabbing}.item-prefix-cell{background-color:var(--color-gray-100);font-weight:var(--type-weight-semibold);display:flex;align-items:center;justify-content:center;min-width:5.563rem}.dropdown-container{flex:1 1 auto;max-width:25rem}.buttons-container{display:flex;align-items:center;margin-left:auto}.drag-icon{margin-top:10px}.cdk-drag-placeholder{opacity:var(--opacity-300);border-bottom:1px solid var(--color-stroke-2);border-left:none;border-right:none;border-top:none}.cdk-drag-preview{border-bottom:1px solid var(--color-stroke-2);opacity:var(--opacity-600)}\n"] }]
        }], ctorParameters: () => [{ type: i2.FormBuilder }, { type: i1.TextService }], propDecorators: { listItems: [{
                type: Input
            }], listItemPrefix: [{
                type: Input
            }], dropdownOptions: [{
                type: Input
            }], dropdownOptionsShouldBeUnique: [{
                type: Input
            }], dropdownErrorMessage: [{
                type: Input
            }], actionButtonDisabledForNewItems: [{
                type: Input
            }], addButtonLabel: [{
                type: Input
            }], maxItemCount: [{
                type: Input
            }], allowAllItemRemoval: [{
                type: Input
            }], noItemsErrorMessage: [{
                type: Input
            }], itemActionClicked: [{
                type: Output
            }], itemAdded: [{
                type: Output
            }], itemRemoved: [{
                type: Output
            }], itemDropdownChanged: [{
                type: Output
            }], itemMoved: [{
                type: Output
            }] } });

class HeaderComponent {
    constructor() {
        /**
        * Required. Title text
        **/
        this.title = '';
        /**
        * Optional. Subtitle text that displays in-line, to the right of the title
        **/
        this.subtitle = '';
        /**
        * Optional. Array of badges (max of 5) to be displayed in-line with the title text.
        **/
        this.badges = [];
        /**
        * Optional. Description text that displays below the title.
        * Allows rich text html.
        **/
        this.description = '';
        /**
        * Optional. Array of Page Action Items
        **/
        this.pageActions = [];
        /**
        * Optional. Sets the page actions more menu button icon. Defaults to three vertical dots.
        **/
        this.pageActionsMenuIcon = '';
        /**
        * Optional. Sets the page actions more menu button text. Defaults to 'More'.
        **/
        this.pageActionsMenuText = '';
        /**
        * Optional. When true and there are 3 or more page actions, two of the actions will show outside the More dropdown menu.
        **/
        this.showTwoActionsOutsideMenu = false;
        /**
        * Optional. Array of Breadcrumb Items
        **/
        this.breadcrumbs = [];
        /**
        * Optional. If set, a back button will display instead of breadcrumbs.
        **/
        this.backButtonUrl = '';
        /**
        * Optional. The text to display in the back button. Defaults to empty string.
        **/
        this.backButtonText = '';
        /**
        * Optional. A string corresponding to a Material Icon, a SVG icon, or a single char for the header icon.
        **/
        this.headerIcon = '';
        /**
        * Optional. The background class used to control the color of the header icon.
        **/
        this.headerIconBackgroundClass = 'bg-brand-secondary';
        /**
        * Optional. String to define a border around the header icon.
        **/
        this.headerIconBorderColor = '';
        /**
        * Optional. The class used to control the color of the header icon.
        **/
        this.headerIconColorClass = 'color-white';
        /**
        * Optional. Shape of the header icon.
        **/
        this.headerIconShape = 'circle';
        /**
        * Emitted when the back button is clicked.
        * This is only the case when backButtonUrl is not provided and therefore the back button is a true button.
        **/
        this.backButtonClicked = new EventEmitter();
    }
    onBackButtonClick() {
        this.backButtonClicked.emit(true);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: HeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.17", type: HeaderComponent, isStandalone: false, selector: "ui-management-header", inputs: { title: "title", subtitle: "subtitle", badges: "badges", description: "description", pageActions: "pageActions", pageActionsMenuIcon: "pageActionsMenuIcon", pageActionsMenuText: "pageActionsMenuText", showTwoActionsOutsideMenu: "showTwoActionsOutsideMenu", breadcrumbs: "breadcrumbs", backButtonUrl: "backButtonUrl", backButtonText: "backButtonText", headerIcon: "headerIcon", headerIconBackgroundClass: "headerIconBackgroundClass", headerIconBorderColor: "headerIconBorderColor", headerIconColorClass: "headerIconColorClass", headerIconShape: "headerIconShape" }, outputs: { backButtonClicked: "backButtonClicked" }, ngImport: i0, template: "<div class=\"mb-6\" uiCoreReplayUnmask>\n    @if (breadcrumbs?.length > 0) {\n        <div class=\"mb-2\">\n            <ui-core-breadcrumbs [breadcrumbs]=\"breadcrumbs\"></ui-core-breadcrumbs>\n        </div>\n    } @else if (breadcrumbs?.length === 0 && backButtonText) {\n        <div>\n            <ui-core-back-button\n                e2e=\"header\"\n                [url]=\"backButtonUrl\"\n                [message]=\"backButtonText\"\n                (clicked)=\"onBackButtonClick()\">\n            </ui-core-back-button>\n        </div>\n    }\n    \n    <div class=\"d-flex justify-content-between\">\n        <div class=\"title-container d-flex align-items-center\">\n            @if (headerIcon !== '') {\n                <ui-core-icon-shape\n                    [icon]=\"headerIcon\"\n                    [backgroundClass]=\"headerIconBackgroundClass\"\n                    [borderColor]=\"headerIconBorderColor\"\n                    [colorClass]=\"headerIconColorClass\"\n                    [shape]=\"headerIconShape\">\n                </ui-core-icon-shape>\n            }\n            <h1 class=\"text-color-primary mb-md-0\">\n                <span>{{ title }}</span>\n                @if (subtitle) {\n                    <span class=\"color-gray-700 ml-2\">{{ subtitle }}</span>\n                }\n            </h1>\n            @if (badges?.length > 0) {\n                <ui-core-badge-list\n                    [items]=\"badges\"\n                    [marginTop]=\"false\"\n                    [max]=\"5\">\n                </ui-core-badge-list>\n            }\n        </div>\n\n        @if (pageActions?.length > 0) {\n            <div class=\"pl-2\">\n                <ui-core-page-actions \n                    [actions]=\"pageActions\" \n                    [showTwoOutsideMenu]=\"showTwoActionsOutsideMenu\"\n                    [moreMenuIcon]=\"pageActionsMenuIcon\" \n                    [moreMenuButtonText]=\"pageActionsMenuText\">\n                </ui-core-page-actions>\n            </div>\n        }\n    </div>\n    \n    @if (description) {\n        <ui-core-safe-html\n            containerClass=\"color-gray-800 mt-1\"\n            [content]=\"description\">\n        </ui-core-safe-html>\n    }\n</div>", styles: [".title-container{flex-wrap:wrap;gap:.75rem;min-height:48px}.title-container h1{margin-bottom:0}\n"], dependencies: [{ kind: "component", type: i1.BackButtonComponent, selector: "ui-core-back-button", inputs: ["message", "url", "e2e"], outputs: ["clicked"] }, { kind: "component", type: i1.BadgeListComponent, selector: "ui-core-badge-list", inputs: ["items", "marginTop", "max", "rightAlign"] }, { kind: "component", type: i1.BreadcrumbsComponent, selector: "ui-core-breadcrumbs", inputs: ["breadcrumbs"] }, { kind: "component", type: i1.IconShapeComponent, selector: "ui-core-icon-shape[icon]", inputs: ["icon", "backgroundClass", "borderColor", "colorClass", "size", "shape", "ariaLabel"] }, { kind: "component", type: i1.PageActionsComponent, selector: "ui-core-page-actions", inputs: ["withinModal", "withinNav", "showTwoOutsideMenu", "alignLeft", "moreMenuIcon", "moreMenuButtonText", "actions"] }, { kind: "component", type: i1.SafeHtmlComponent, selector: "ui-core-safe-html", inputs: ["content", "mode", "containerClass"] }, { kind: "directive", type: i1.ReplayUnmaskDirective, selector: "[uiCoreReplayUnmask]" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: HeaderComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-management-header', template: "<div class=\"mb-6\" uiCoreReplayUnmask>\n    @if (breadcrumbs?.length > 0) {\n        <div class=\"mb-2\">\n            <ui-core-breadcrumbs [breadcrumbs]=\"breadcrumbs\"></ui-core-breadcrumbs>\n        </div>\n    } @else if (breadcrumbs?.length === 0 && backButtonText) {\n        <div>\n            <ui-core-back-button\n                e2e=\"header\"\n                [url]=\"backButtonUrl\"\n                [message]=\"backButtonText\"\n                (clicked)=\"onBackButtonClick()\">\n            </ui-core-back-button>\n        </div>\n    }\n    \n    <div class=\"d-flex justify-content-between\">\n        <div class=\"title-container d-flex align-items-center\">\n            @if (headerIcon !== '') {\n                <ui-core-icon-shape\n                    [icon]=\"headerIcon\"\n                    [backgroundClass]=\"headerIconBackgroundClass\"\n                    [borderColor]=\"headerIconBorderColor\"\n                    [colorClass]=\"headerIconColorClass\"\n                    [shape]=\"headerIconShape\">\n                </ui-core-icon-shape>\n            }\n            <h1 class=\"text-color-primary mb-md-0\">\n                <span>{{ title }}</span>\n                @if (subtitle) {\n                    <span class=\"color-gray-700 ml-2\">{{ subtitle }}</span>\n                }\n            </h1>\n            @if (badges?.length > 0) {\n                <ui-core-badge-list\n                    [items]=\"badges\"\n                    [marginTop]=\"false\"\n                    [max]=\"5\">\n                </ui-core-badge-list>\n            }\n        </div>\n\n        @if (pageActions?.length > 0) {\n            <div class=\"pl-2\">\n                <ui-core-page-actions \n                    [actions]=\"pageActions\" \n                    [showTwoOutsideMenu]=\"showTwoActionsOutsideMenu\"\n                    [moreMenuIcon]=\"pageActionsMenuIcon\" \n                    [moreMenuButtonText]=\"pageActionsMenuText\">\n                </ui-core-page-actions>\n            </div>\n        }\n    </div>\n    \n    @if (description) {\n        <ui-core-safe-html\n            containerClass=\"color-gray-800 mt-1\"\n            [content]=\"description\">\n        </ui-core-safe-html>\n    }\n</div>", styles: [".title-container{flex-wrap:wrap;gap:.75rem;min-height:48px}.title-container h1{margin-bottom:0}\n"] }]
        }], propDecorators: { title: [{
                type: Input
            }], subtitle: [{
                type: Input
            }], badges: [{
                type: Input
            }], description: [{
                type: Input
            }], pageActions: [{
                type: Input
            }], pageActionsMenuIcon: [{
                type: Input
            }], pageActionsMenuText: [{
                type: Input
            }], showTwoActionsOutsideMenu: [{
                type: Input
            }], breadcrumbs: [{
                type: Input
            }], backButtonUrl: [{
                type: Input
            }], backButtonText: [{
                type: Input
            }], headerIcon: [{
                type: Input
            }], headerIconBackgroundClass: [{
                type: Input
            }], headerIconBorderColor: [{
                type: Input
            }], headerIconColorClass: [{
                type: Input
            }], headerIconShape: [{
                type: Input
            }], backButtonClicked: [{
                type: Output
            }] } });

class HtmlEditorAction {
    constructor() {
        this.showSpinner = false;
        /**
         * If true, the html-editor will automatically show a loading overlay
         * when this action is triggered. The overlay will hide when the Promise resolves/rejects.
         * Note: Only works with Promise-based actions. Synchronous actions are ignored to avoid flicker.
         */
        this.showLoadingOverlay = false;
    }
}

const DEFAULT_LOCKED_MESSAGE = 'DEFAULT_LOCKED_MESSAGE';
class BaseEditorComponent extends BaseTextComponent {
    get lockedMessage() {
        return this.locked ? this.getLockedMessage() : undefined;
    }
    /**
    * Displays when the field is locked
    *  - has a default value that always displays for locked fields
    *  - accepts strings or boolean false - if you don't want any message displayed for a locked field, set this to false - `field.lockedMessage: false`
    **/
    set lockedMessage(value) {
        this._lockedMessage = value;
    }
    get control() {
        if (this.controlContainer && this.controlName && !this._control) {
            // Editors wrap a reactive form control, so the control container is actually the parent
            // form group directive.
            this._control = this.controlContainer.form?.get(this.controlName) || null;
        }
        return this._control;
    }
    get value() {
        return this.control?.value;
    }
    get showControlInvalid() {
        return this.controlTouched && !this.control?.valid;
    }
    get required() {
        return this.control?.hasValidator(Validators.required);
    }
    constructor(textService, textConfigKey, controlContainer) {
        super(textService, textConfigKey);
        this.controlContainer = controlContainer;
        // These are not ideal, but it lets us reuse the global form styles.
        // Under the covers, there is a reactive form control from a third-party library that we are wrapping.
        // Our ui cares about touched and invalid states, so need to pull those from the form control
        // and then re-apply them here.
        this.mimicFormField = true;
        this.managementEditor = true;
        this.controlTouched = false;
        this.controlInvalid = false;
        this.controlValid = false;
        /**
        * Displays a success themed message
        **/
        this.successMessage = '';
        /**
        * Displays an info themed message
        **/
        this.infoMessage = '';
        /**
        * Displays a warning themed message
        **/
        this.warningMessage = '';
        /**
        * Displays when the field is invalid
        **/
        this.errorMessage = '';
        /**
        * Required. The label for the form field
        **/
        this.label = '';
        /**
        * Can be used to visually hide the label. Label should always be provided, and hidden if undesired
        **/
        this.hideLabel = false;
        /**
        * Allows for a custom e2e prefix instead of using the form control name.
        **/
        this.e2e = '';
        /**
        * Specifies whether or not the field should be read-only. Locked fields cannot be modified by the user.
        **/
        this.locked = false;
        /**
        * Content to display in the tooltip popover
        **/
        this.tooltip = '';
        /**
        * Direction to place the tooltip popover.
        * "auto" (default) will attempt to place the popover where it can be seen (based on container/window bounds)
        * See ng-bootstrap documentation for details - type: Placement
        **/
        this.tooltipPlacement = 'auto';
        /**
        * Emits the new value when the value changes.
        **/
        this.change = new EventEmitter();
        this._control = null;
        this.baseText = {};
        // Used for e2e hooks. e2e hooks should be the prefix, plus a short but descriptive hook for the element.
        this.e2ePrefix = '';
        this.e2eField = '';
        // Used to apply custom validators and corresponding error messages.
        this.appliedValidators = [];
        this.hasBeenInitialized = false;
        this.customErrorMessage = '';
        this.errorMessageMap = new Map();
        if (textService) {
            textService.getText$('ui-management-base-editor', this.getDefaultBaseText())
                .pipe(this.takeUntilDestroyed())
                .subscribe((x) => {
                if (x) {
                    this.mergeBaseText(x);
                }
            });
        }
        else {
            this.mergeBaseText(this.getDefaultBaseText());
        }
        // FieldId is used to link the form field element to other elements, such as the label.
        this.fieldId = HtmlUtils.generateRandomId();
        this.labelId = this.fieldId + '_label';
    }
    ngOnInit() {
        this.setE2EPrefix();
        if (this.control) {
            this.updateValidators('onInit');
            this.control.statusChanges
                .pipe(this.takeUntilDestroyed())
                .subscribe(() => {
                // We normally don't use the dirty state, but the editors tend to be complex/tall.
                // Showing invalid state on change or on touched.
                this.controlTouched = this.control?.touched || this.control?.dirty || false;
                this.controlInvalid = this.control?.invalid || false;
                this.controlValid = this.control?.valid || false;
                if (this.controlInvalid && this.control.errors && this.errorMessageMap.size > 0) {
                    this.customErrorMessage = '';
                    for (let customError of this.errorMessageMap) {
                        if (this.control.errors[customError[0]]) {
                            this.customErrorMessage = customError[1];
                        }
                    }
                }
            });
            // Note: when this emits, the value has not actually been written to the control yet.
            // this.control.value will be different!!
            this.control.valueChanges
                .pipe(this.takeUntilDestroyed())
                .subscribe((value) => {
                this.onValueChange(value);
                this.change.emit(value);
            });
        }
    }
    ngOnDestroy() {
        super.ngOnDestroy();
        this.updateValidators('onDestroy');
    }
    updateValidators(source, onChangesUpdate = true) {
        if (!this.control) {
            return;
        }
        switch (source) {
            case 'onInit':
                // onInit should only happen one time.
                // Apply any validators at this time.
                if (!this.hasBeenInitialized) {
                    this.hasBeenInitialized = true;
                    this.setValidators();
                }
                break;
            case 'onChanges':
                if (this.hasBeenInitialized) {
                    // Check to see if any validator has actually been added/removed.
                    const currentValidatorNames = this.appliedValidators.map((x) => x.name);
                    const newValidators = this.getValidators() || [];
                    const newValidatorNames = newValidators.map((x) => x.name);
                    const validatorsChanged = this.validatorsChanged(currentValidatorNames, newValidatorNames);
                    if (validatorsChanged) {
                        this.removeValidators();
                        this.setValidators();
                        if (onChangesUpdate) {
                            this.control.updateValueAndValidity(); // Refresh the control
                        }
                    }
                }
                break;
            case 'onDestroy':
                // Remove any and all validators
                this.removeValidators();
                break;
        }
    }
    setValidators() {
        this.appliedValidators = this.getValidators() || [];
        if (this.appliedValidators.length > 0) {
            this.control.addValidators(this.appliedValidators);
        }
    }
    removeValidators() {
        if (this.appliedValidators.length > 0) {
            this.control.removeValidators(this.appliedValidators);
            this.appliedValidators = [];
        }
    }
    validatorsChanged(oldNames, newNames) {
        // If the lengths are different, they are different.
        if (oldNames.length !== newNames.length) {
            return true;
        }
        // If the lengths are the same, but the names are different, they are different.
        return oldNames.some((x) => !newNames.includes(x));
    }
    setE2EPrefix() {
        this.e2ePrefix = HtmlUtils.formatE2EPrefix(this.e2e || this.controlName);
        this.e2eField = this.e2ePrefix + 'field';
    }
    mergeBaseText(baseText) {
        this.text = Object.assign(this.text, baseText);
    }
    getLockedMessage() {
        if (this._lockedMessage === false) {
            return '';
        }
        if (this._lockedMessage === DEFAULT_LOCKED_MESSAGE || !this._lockedMessage) {
            return this.text.defaultLockedMessage;
        }
        return this._lockedMessage;
    }
    onValueChange(value) {
        // Optional, can be overridden by implementations.
        // This is useful for non-validation related changes, such as extra messaging or state management.
    }
    getValidators() {
        // Optional, can be overridden by implementations.
        // Validators must not have a dependency on "this". Custom error messages can be wired by returning
        // an error key and providing a matching error message in the map.
        return [];
    }
    getDefaultBaseText() {
        return {
            defaultLockedMessage: 'This field can\’t be changed',
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: BaseEditorComponent, deps: "invalid", target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.17", type: BaseEditorComponent, isStandalone: true, inputs: { successMessage: "successMessage", infoMessage: "infoMessage", warningMessage: "warningMessage", errorMessage: "errorMessage", lockedMessage: "lockedMessage", label: "label", hideLabel: "hideLabel", controlName: "controlName", e2e: "e2e", locked: "locked", tooltip: "tooltip", tooltipPlacement: "tooltipPlacement" }, outputs: { change: "change" }, host: { properties: { "class.ui-form-control": "this.mimicFormField", "class.ui-management-editor": "this.managementEditor", "class.ng-touched": "this.controlTouched", "class.ng-invalid": "this.controlInvalid", "class.ng-valid": "this.controlValid", "attr.data-control-name": "this.controlName", "class.form-locked": "this.locked", "attr.data-e2e": "this.e2eField" } }, usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: BaseEditorComponent, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: i1.TextService }, { type: undefined }, { type: i2.ControlContainer }], propDecorators: { mimicFormField: [{
                type: HostBinding,
                args: ['class.ui-form-control']
            }], managementEditor: [{
                type: HostBinding,
                args: ['class.ui-management-editor']
            }], controlTouched: [{
                type: HostBinding,
                args: ['class.ng-touched']
            }], controlInvalid: [{
                type: HostBinding,
                args: ['class.ng-invalid']
            }], controlValid: [{
                type: HostBinding,
                args: ['class.ng-valid']
            }], successMessage: [{
                type: Input
            }], infoMessage: [{
                type: Input
            }], warningMessage: [{
                type: Input
            }], errorMessage: [{
                type: Input
            }], lockedMessage: [{
                type: Input
            }], label: [{
                type: Input
            }], hideLabel: [{
                type: Input
            }], controlName: [{
                type: HostBinding,
                args: ['attr.data-control-name']
            }, {
                type: Input
            }], e2e: [{
                type: Input
            }], locked: [{
                type: Input
            }, {
                type: HostBinding,
                args: ['class.form-locked']
            }], tooltip: [{
                type: Input
            }], tooltipPlacement: [{
                type: Input
            }], change: [{
                type: Output
            }], e2eField: [{
                type: HostBinding,
                args: ['attr.data-e2e']
            }] } });

// Override Quill video embed handling that returns href instead of video iframe to content
// https://github.com/slab/quill/issues/4186
// Out of the box, Quill will strip out non-whitelisted attributes such as referrerpolicy.
// Create the Attributor per these docs: https://github.com/slab/parchment/blob/main/README.md#attributor
const ReferrerPolicyAttributor = new Attributor('referrerpolicy', 'referrerpolicy');
class IFrameVideo extends QuillVideo {
    html() {
        if (this.attributes) {
            this.attributes.attribute(ReferrerPolicyAttributor, 'strict-origin-when-cross-origin');
        }
        const { video } = this.value();
        return `<iframe class="ql-video" frameborder="0" allowfullscreen="true" src="${video}"></iframe>`;
    }
}

// Override Quill link handling to prevent local URLs from being targeted to new windows
class LocalLink extends Link {
    static create(value) {
        // catch newly created links
        const node = Link.create(value);
        value = Link.sanitize(value);
        node.setAttribute('href', value);
        if (HtmlUtils.isRouterUrl(value)) {
            node.removeAttribute('target');
        }
        return node;
    }
    format(name, value) {
        // catch existing links on edit
        super.format(name, value);
        if (HtmlUtils.isRouterUrl(value)) {
            this['domNode'].removeAttribute('target');
        }
    }
}

function linkUrlsAreValid(control) {
    const value = control?.value || '';
    // Should return matches like: href="sample"
    const hrefInstances = value.match(/href="[^"]*"/g);
    const hrefUrls = hrefInstances?.map(href => href.replace(/"/g, '').replace('href=', '')) || [];
    if (hrefUrls.some(url => !HtmlUtils.isRouterUrl(url) && !HtmlUtils.isExternalUrl(url))) {
        return { invalidHref: true };
    }
    return null;
}

// Register customizations to Quill
Quill.register(LocalLink, true);
Quill.register(IFrameVideo, true);
class HtmlEditorComponent extends BaseEditorComponent {
    constructor(textService, controlContainer) {
        super(textService, 'ui-management-html-editor', controlContainer);
        this.textService = textService;
        /**
        * If enabled, a button will be displayed to allow the user to insert videos.
        **/
        this.allowVideos = false;
        /**
        * By default, run the DOM sanitizer on html content. If you trust the content, you can disable this.
        **/
        this.sanitize = true;
        /**
        * If true, this takes over the 'info', 'success' and 'warning' messages,
        * so don't enable this if you need any of those messages to display.
        **/
        this.showCharactersRemaining = false;
        /**
        * The maximum amount of character input allowed in the text field.
        **/
        this.maxLength = FormUtils.defaultMaxLength;
        /**
        * Optional. Actions to render in the toolbar.
        **/
        this.actions = [];
        /**
        * Optional. A custom template to render in the footer of the editor in place of the actions.
        * When provided, this template takes precedence over the actions input.
        **/
        this.footerTemplate = null;
        /**
        * Optional. Sets the page actions more menu button icon. Defaults to three vertical dots.
        **/
        this.pageActionsMenuIcon = '';
        /**
        * Optional. The message to display in the loading overlay. 40 character limit for messages.
        **/
        this.loadingOverlayMessage = 'Loading...';
        /**
        * Optional. The size of the spinner in the loading overlay.
        **/
        this.loadingOverlaySpinnerSize = 'sm';
        /**
        * Optional. Sets the page actions more menu button text. Defaults to 'More'.
        **/
        this.pageActionsMenuText = '';
        /**
        * Optional. Toggle the loading overlay externally. When using the actions input with
        * showLoadingOverlay=true, this is also set automatically by the editor.
        **/
        this.isLoading = false;
        /**
         * Optional. Event that emits the currently selected text in the editor whenever the selection changes.
         * Emits an object containing both the plain text and the HTML content of the selection.
         */
        this.textSelection = new EventEmitter();
        /**
         * (Internal use only - Form Renderer uses this to listen for selection events, all other use-cases should use the textSelection output)
         * Accepts a function that is called with the currently selected text in the editor whenever the selection changes.
         * Emits both the plain text and the HTML content of the selection.
         */
        this._textSelected = null;
        this.hasActions = false;
        this.pageActions = [];
        // Set up custom error messages for validators
        this.setMaxLengthErrorMessage();
        this.errorMessageMap.set('invalidHref', this.text.invalidLinkErrorMessage);
    }
    ngOnChanges(changes) {
        if (changes.maxLength && this.control) {
            this.setMaxLengthErrorMessage();
            this.updateValidators('onChanges');
        }
        if (changes.actions) {
            this.hasActions = this.actions && this.actions.length > 0;
            this.pageActions = this.actions.map(action => {
                const item = new PageActionItem();
                item.text = action.text;
                item.action = this.wrapActionWithLoadingOverlay(action);
                item.icon = action.icon;
                item.id = action.id;
                item.e2e = action.e2e;
                item.disabled = action.disabled;
                item.disabledMessage = action.disabledMessage;
                item.showSpinner = action.showSpinner;
                return item;
            });
        }
    }
    setMaxLengthErrorMessage() {
        if (this.value) {
            const excessCount = NumberUtils.formatNumber(this.value.length - this.maxLength);
            const msg = `${excessCount} ${this.text.charactersRemainingErrorMessage}`;
            // maxlength is a built-in validator
            this.errorMessageMap.set('maxlength', msg);
        }
    }
    wrapActionWithLoadingOverlay(action) {
        if (!action.showLoadingOverlay) {
            return action.action;
        }
        return () => {
            const result = action.action();
            // Only show overlay for Promise-based actions to avoid flicker
            if (result instanceof Promise) {
                this.isLoading = true;
                result
                    .then(() => {
                    this.isLoading = false;
                })
                    .catch(() => {
                    this.isLoading = false;
                });
            }
            // Synchronous actions are ignored - overlay would just flicker
        };
    }
    onBlur() {
        if (this.control) {
            this.control.markAsTouched();
            this.control.updateValueAndValidity();
        }
    }
    onSelectionChanged(event) {
        if (event.range) {
            // text selected, or unselected, if range exists a selection event has occurred
            // Claude is suggesting a check of oldRange, or guard with range.length === 0, to detect un-selection, but that clears too eagerly & blanks-out any selected text as the user clicks an action button
            // we're intentionally not emitting too quickly to accommodate actions inside menus (allowing that outside click without emitting a selection reset)
            const text = event.editor.getText(event.range.index, event.range.length);
            const html = text.length > 0 ? event.editor.getSemanticHTML(event.range.index, event.range.length) : '';
            const selectionEvent = {
                text,
                html,
                index: event.range.index,
                length: event.range.length
            };
            this.textSelection.emit(selectionEvent);
            if (this._textSelected) {
                this._textSelected(selectionEvent);
            }
        }
    }
    onEditorCreated(editor) {
        const Delta = Quill.import('delta');
        editor.clipboard.addMatcher('IMG', () => new Delta());
        editor.clipboard.addMatcher('PICTURE', () => new Delta());
        editor.root.addEventListener('drop', (event) => {
            const types = event.dataTransfer?.types || [];
            const hasFiles = Array.from(types).includes('Files');
            if (hasFiles) {
                event.preventDefault();
                event.stopPropagation();
            }
        }, true);
    }
    onValueChange(value) {
        if (this.showCharactersRemaining) {
            this.updateCharactersRemaining(value);
        }
        this.setMaxLengthErrorMessage();
    }
    updateCharactersRemaining(value) {
        this.successMessage = '';
        this.warningMessage = '';
        this.infoMessage = '';
        const currentLength = value ? value.length : 0;
        // Show the appropriate icon and message depending on how many characters are left.
        // If they went negative, the custom validation will show the error message.
        if (currentLength < this.maxLength) {
            const remainingCount = NumberUtils.formatNumber(this.maxLength - currentLength);
            this.infoMessage = `${remainingCount} ${this.text.defaultCharactersRemaining}`;
        }
        else if (currentLength === this.maxLength) {
            this.warningMessage = `0 ${this.text.defaultCharactersRemaining}`;
        }
    }
    getValidators() {
        return [
            Validators.maxLength(this.maxLength),
            linkUrlsAreValid
        ];
    }
    getDefaultText() {
        return {
            defaultCharactersRemaining: 'character(s) remaining',
            charactersRemainingErrorMessage: 'character(s) over the limit',
            invalidLinkErrorMessage: 'Invalid link url(s). External link urls must begin with a valid protocol (http://, https://, etc.). Internal links must begin with a forward slash (/example).',
            // Placeholder matches default from quill
            placeholder: 'Insert text here...',
            // Toolbar button titles
            boldTitle: 'Bold',
            italicTitle: 'Italic',
            underlineTitle: 'Underline',
            decreaseIndentTitle: 'Decrease Indent',
            increaseIndentTitle: 'Increase Indent',
            leftAlignTitle: 'Left Align',
            centerAlignTitle: 'Center Align',
            rightAlignTitle: 'Right Align',
            justifyTitle: 'Justify',
            bulletedListTitle: 'Bulleted List',
            numberedListTitle: 'Numbered List',
            linkTitle: 'Insert Link',
            videoTitle: 'Embed Video',
            clearFormattingTitle: 'Clear Formatting',
            // Custom Actions
            actionTitle: 'Actions'
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: HtmlEditorComponent, deps: [{ token: i1.TextService }, { token: i2.ControlContainer, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.17", type: HtmlEditorComponent, isStandalone: false, selector: "ui-management-html-editor", inputs: { allowVideos: "allowVideos", sanitize: "sanitize", showCharactersRemaining: "showCharactersRemaining", maxLength: "maxLength", actions: "actions", footerTemplate: "footerTemplate", pageActionsMenuIcon: "pageActionsMenuIcon", loadingOverlayMessage: "loadingOverlayMessage", loadingOverlaySpinnerSize: "loadingOverlaySpinnerSize", pageActionsMenuText: "pageActionsMenuText", isLoading: "isLoading", _textSelected: "_textSelected" }, outputs: { textSelection: "textSelection" }, usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div class=\"label-container\">\n    @if (!hideLabel) {\n        <label\n            uiCoreReplayUnmask\n            [for]=\"fieldId\"\n            [id]=\"labelId\">\n            {{ label }}\n            <ui-forms-label-tooltips\n                [label]=\"label\"\n                [locked]=\"locked\"\n                [lockedMessage]=\"lockedMessage\"\n                [tooltip]=\"tooltip\"\n                [tooltipPlacement]=\"tooltipPlacement\"\n                [e2e]=\"e2ePrefix\">\n            </ui-forms-label-tooltips>\n        </label>\n    }\n</div>\n\n<div\n    class=\"container-form\"\n    data-form-focus=\"focus-editable-content\"\n    [uiLoadingOverlay]=\"isLoading\"\n    [loadingMessage]=\"loadingOverlayMessage\"\n    [loadingSpinnerSize]=\"loadingOverlaySpinnerSize\">\n    <quill-editor\n        bounds=\"self\"\n        [readOnly]=\"locked\"\n        [sanitize]=\"sanitize\"\n        [placeholder]=\"text.placeholder\"\n        [formControlName]=\"controlName\"\n        [required]=\"required\"\n        (onBlur)=\"onBlur()\"\n        (onSelectionChanged)=\"onSelectionChanged($event)\"\n        (onEditorCreated)=\"onEditorCreated($event)\">\n        <div\n            quill-editor-toolbar\n            uiCoreReplayUnmask>\n            <span class=\"ql-formats\">\n                <button\n                    class=\"ql-bold\"\n                    [title]=\"text.boldTitle\"></button>\n                <button\n                    class=\"ql-italic\"\n                    [title]=\"text.italicTitle\"></button>\n                <button\n                    class=\"ql-underline\"\n                    [title]=\"text.underlineTitle\"></button>\n            </span>\n            <span class=\"ql-formats\">\n                <select class=\"ql-header\">\n                    <option value=\"1\"></option>\n                    <option value=\"2\"></option>\n                    <option value=\"3\"></option>\n                    <option value=\"4\"></option>\n                    <option value=\"5\"></option>\n                    <option value=\"6\"></option>\n                    <option selected=\"selected\"></option>\n                </select>\n            </span>\n            <span class=\"ql-formats\">\n                <button\n                    class=\"ql-indent\"\n                    value=\"-1\"\n                    [title]=\"text.decreaseIndentTitle\"></button>\n                <button\n                    class=\"ql-indent\"\n                    value=\"+1\"\n                    [title]=\"text.increaseIndentTitle\"></button>\n            </span>\n            <span class=\"ql-formats\">\n                <button\n                    class=\"ql-align\"\n                    value=\"\"\n                    [title]=\"text.leftAlignTitle\"></button>\n                <button\n                    class=\"ql-align\"\n                    value=\"center\"\n                    [title]=\"text.centerAlignTitle\"></button>\n                <button\n                    class=\"ql-align\"\n                    value=\"right\"\n                    [title]=\"text.rightAlignTitle\"></button>\n                <button\n                    class=\"ql-align\"\n                    value=\"justify\"\n                    [title]=\"text.justifyTitle\"></button>\n            </span>\n            <span class=\"ql-formats\">\n                <button\n                    class=\"ql-list\"\n                    value=\"bullet\"\n                    [title]=\"text.bulletedListTitle\"></button>\n                <button\n                    class=\"ql-list\"\n                    value=\"ordered\"\n                    [title]=\"text.numberedListTitle\"></button>\n            </span>\n            <span class=\"ql-formats\">\n                <button\n                    class=\"ql-link\"\n                    [title]=\"text.linkTitle\"></button>\n\n                @if (allowVideos) {\n                    <button\n                        class=\"ql-video\"\n                        [title]=\"text.videoTitle\"></button>\n                }\n\n                <button\n                    class=\"ql-clean\"\n                    [title]=\"text.clearFormattingTitle\"></button>\n            </span>\n        </div>\n    </quill-editor>\n\n    @if (footerTemplate) {\n        <div class=\"html-editor-footer\">\n            <ng-container *ngTemplateOutlet=\"footerTemplate\"></ng-container>\n        </div>\n    } @else if (hasActions) {\n        <div class=\"html-editor-actions\">\n            <ui-core-page-actions\n                [actions]=\"pageActions\"\n                [alignLeft]=\"true\"\n                [showTwoOutsideMenu]=\"true\"\n                [withinModal]=\"true\"\n                [moreMenuIcon]=\"pageActionsMenuIcon\"\n                [moreMenuButtonText]=\"pageActionsMenuText\">\n            </ui-core-page-actions>\n        </div>\n    }\n</div>\n\n@if (controlName) {\n    <ui-forms-field-validation\n        [ariaInputName]=\"label\"\n        [errorMessage]=\"customErrorMessage || errorMessage\"\n        [infoMessage]=\"infoMessage\"\n        [successMessage]=\"successMessage\"\n        [warningMessage]=\"warningMessage\"\n        [fieldId]=\"fieldId\"\n        [locked]=\"locked\">\n    </ui-forms-field-validation>\n}\n", styles: [".container-form{display:flex;flex-direction:column;height:290px;min-height:100px;overflow:hidden;padding:0;resize:vertical}.container-form:has(.html-editor-actions),.container-form:has(.html-editor-footer){min-height:150px}.container-form quill-editor{display:flex!important;flex-direction:column;flex-grow:1;min-height:0}.container-form .html-editor-actions{padding:0 14px}.container-form .html-editor-footer{padding:8px 14px;cursor:default}\n"], dependencies: [{ kind: "directive", type: i3.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i2.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "component", type: i4.QuillEditorComponent, selector: "quill-editor" }, { kind: "directive", type: i2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i1.PageActionsComponent, selector: "ui-core-page-actions", inputs: ["withinModal", "withinNav", "showTwoOutsideMenu", "alignLeft", "moreMenuIcon", "moreMenuButtonText", "actions"] }, { kind: "directive", type: i1.LoadingOverlayDirective, selector: "[uiLoadingOverlay]", inputs: ["uiLoadingOverlay", "loadingMessage", "loadingSpinnerSize"] }, { kind: "directive", type: i1.ReplayUnmaskDirective, selector: "[uiCoreReplayUnmask]" }, { kind: "component", type: i5.FieldValidationComponent, selector: "ui-forms-field-validation", inputs: ["fieldId", "locked", "errorMessage", "infoMessage", "successMessage", "warningMessage", "ariaInputName", "criteria", "criteriaDescription"] }, { kind: "component", type: i5.LabelTooltipsComponent, selector: "ui-forms-label-tooltips", inputs: ["label", "locked", "lockedMessage", "tooltip", "tooltipPlacement", "e2e", "tooltipClass"] }], viewProviders: [
            {
                provide: ControlContainer,
                useExisting: FormGroupDirective
            }
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: HtmlEditorComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-management-html-editor', viewProviders: [
                        {
                            provide: ControlContainer,
                            useExisting: FormGroupDirective
                        }
                    ], template: "<div class=\"label-container\">\n    @if (!hideLabel) {\n        <label\n            uiCoreReplayUnmask\n            [for]=\"fieldId\"\n            [id]=\"labelId\">\n            {{ label }}\n            <ui-forms-label-tooltips\n                [label]=\"label\"\n                [locked]=\"locked\"\n                [lockedMessage]=\"lockedMessage\"\n                [tooltip]=\"tooltip\"\n                [tooltipPlacement]=\"tooltipPlacement\"\n                [e2e]=\"e2ePrefix\">\n            </ui-forms-label-tooltips>\n        </label>\n    }\n</div>\n\n<div\n    class=\"container-form\"\n    data-form-focus=\"focus-editable-content\"\n    [uiLoadingOverlay]=\"isLoading\"\n    [loadingMessage]=\"loadingOverlayMessage\"\n    [loadingSpinnerSize]=\"loadingOverlaySpinnerSize\">\n    <quill-editor\n        bounds=\"self\"\n        [readOnly]=\"locked\"\n        [sanitize]=\"sanitize\"\n        [placeholder]=\"text.placeholder\"\n        [formControlName]=\"controlName\"\n        [required]=\"required\"\n        (onBlur)=\"onBlur()\"\n        (onSelectionChanged)=\"onSelectionChanged($event)\"\n        (onEditorCreated)=\"onEditorCreated($event)\">\n        <div\n            quill-editor-toolbar\n            uiCoreReplayUnmask>\n            <span class=\"ql-formats\">\n                <button\n                    class=\"ql-bold\"\n                    [title]=\"text.boldTitle\"></button>\n                <button\n                    class=\"ql-italic\"\n                    [title]=\"text.italicTitle\"></button>\n                <button\n                    class=\"ql-underline\"\n                    [title]=\"text.underlineTitle\"></button>\n            </span>\n            <span class=\"ql-formats\">\n                <select class=\"ql-header\">\n                    <option value=\"1\"></option>\n                    <option value=\"2\"></option>\n                    <option value=\"3\"></option>\n                    <option value=\"4\"></option>\n                    <option value=\"5\"></option>\n                    <option value=\"6\"></option>\n                    <option selected=\"selected\"></option>\n                </select>\n            </span>\n            <span class=\"ql-formats\">\n                <button\n                    class=\"ql-indent\"\n                    value=\"-1\"\n                    [title]=\"text.decreaseIndentTitle\"></button>\n                <button\n                    class=\"ql-indent\"\n                    value=\"+1\"\n                    [title]=\"text.increaseIndentTitle\"></button>\n            </span>\n            <span class=\"ql-formats\">\n                <button\n                    class=\"ql-align\"\n                    value=\"\"\n                    [title]=\"text.leftAlignTitle\"></button>\n                <button\n                    class=\"ql-align\"\n                    value=\"center\"\n                    [title]=\"text.centerAlignTitle\"></button>\n                <button\n                    class=\"ql-align\"\n                    value=\"right\"\n                    [title]=\"text.rightAlignTitle\"></button>\n                <button\n                    class=\"ql-align\"\n                    value=\"justify\"\n                    [title]=\"text.justifyTitle\"></button>\n            </span>\n            <span class=\"ql-formats\">\n                <button\n                    class=\"ql-list\"\n                    value=\"bullet\"\n                    [title]=\"text.bulletedListTitle\"></button>\n                <button\n                    class=\"ql-list\"\n                    value=\"ordered\"\n                    [title]=\"text.numberedListTitle\"></button>\n            </span>\n            <span class=\"ql-formats\">\n                <button\n                    class=\"ql-link\"\n                    [title]=\"text.linkTitle\"></button>\n\n                @if (allowVideos) {\n                    <button\n                        class=\"ql-video\"\n                        [title]=\"text.videoTitle\"></button>\n                }\n\n                <button\n                    class=\"ql-clean\"\n                    [title]=\"text.clearFormattingTitle\"></button>\n            </span>\n        </div>\n    </quill-editor>\n\n    @if (footerTemplate) {\n        <div class=\"html-editor-footer\">\n            <ng-container *ngTemplateOutlet=\"footerTemplate\"></ng-container>\n        </div>\n    } @else if (hasActions) {\n        <div class=\"html-editor-actions\">\n            <ui-core-page-actions\n                [actions]=\"pageActions\"\n                [alignLeft]=\"true\"\n                [showTwoOutsideMenu]=\"true\"\n                [withinModal]=\"true\"\n                [moreMenuIcon]=\"pageActionsMenuIcon\"\n                [moreMenuButtonText]=\"pageActionsMenuText\">\n            </ui-core-page-actions>\n        </div>\n    }\n</div>\n\n@if (controlName) {\n    <ui-forms-field-validation\n        [ariaInputName]=\"label\"\n        [errorMessage]=\"customErrorMessage || errorMessage\"\n        [infoMessage]=\"infoMessage\"\n        [successMessage]=\"successMessage\"\n        [warningMessage]=\"warningMessage\"\n        [fieldId]=\"fieldId\"\n        [locked]=\"locked\">\n    </ui-forms-field-validation>\n}\n", styles: [".container-form{display:flex;flex-direction:column;height:290px;min-height:100px;overflow:hidden;padding:0;resize:vertical}.container-form:has(.html-editor-actions),.container-form:has(.html-editor-footer){min-height:150px}.container-form quill-editor{display:flex!important;flex-direction:column;flex-grow:1;min-height:0}.container-form .html-editor-actions{padding:0 14px}.container-form .html-editor-footer{padding:8px 14px;cursor:default}\n"] }]
        }], ctorParameters: () => [{ type: i1.TextService }, { type: i2.ControlContainer, decorators: [{
                    type: Optional
                }] }], propDecorators: { allowVideos: [{
                type: Input
            }], sanitize: [{
                type: Input
            }], showCharactersRemaining: [{
                type: Input
            }], maxLength: [{
                type: Input
            }], actions: [{
                type: Input
            }], footerTemplate: [{
                type: Input
            }], pageActionsMenuIcon: [{
                type: Input
            }], loadingOverlayMessage: [{
                type: Input
            }], loadingOverlaySpinnerSize: [{
                type: Input
            }], pageActionsMenuText: [{
                type: Input
            }], isLoading: [{
                type: Input
            }], textSelection: [{
                type: Output
            }], _textSelected: [{
                type: Input
            }] } });

class JsonDiffComponent extends BaseTextComponent {
    constructor(textService) {
        super(textService, 'ui-management-json-diff');
        /**
        * String label of previous/first/left diff pane
        **/
        this.previousDiffTitle = '';
        /**
        * String label of current/second/right diff pane
        **/
        this.currentDiffTitle = '';
        /**
        * Height of diff-view - requires a fixed height for the editor to measure & size-to, minimum 200
        **/
        this.height = 200;
        this.diffOptions = {
            automaticLayout: true,
            folding: true,
            language: 'json',
            readOnly: true,
            scrollBeyondLastLine: false
        };
    }
    ngOnChanges() {
        this.previousDiffData = this.buildMonacoDiffModel(this.previousData);
        this.currentDiffData = this.buildMonacoDiffModel(this.currentData);
    }
    buildMonacoDiffModel(value) {
        return {
            language: 'application/json',
            code: JSON.stringify(value, null, 4)
        };
    }
    getDefaultText() {
        return {
            previousDiffTitle: 'Previous:',
            currentDiffTitle: 'Selected:'
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: JsonDiffComponent, deps: [{ token: i1.TextService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.17", type: JsonDiffComponent, isStandalone: false, selector: "ui-management-json-diff", inputs: { previousData: "previousData", currentData: "currentData", previousDiffTitle: "previousDiffTitle", currentDiffTitle: "currentDiffTitle", height: "height" }, usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div class=\"json-header\">\n  <h5>{{ previousDiffTitle || text.previousDiffTitle }}</h5>\n  <h5>{{ currentDiffTitle || text.currentDiffTitle }}</h5>\n</div>\n<div class=\"json-wrapper\" [ngStyle]=\"{ 'height': height + 'px' }\">\n  <ngx-monaco-diff-editor [options]=\"diffOptions\" [originalModel]=\"previousDiffData\" [modifiedModel]=\"currentDiffData\" class=\"h-100\"></ngx-monaco-diff-editor>\n</div>\n", styles: [".json-header{display:flex;margin-top:8px}.json-header h5{margin-bottom:0;text-align:center;width:50%}.json-wrapper{margin-top:8px;overflow:auto;resize:vertical}\n"], dependencies: [{ kind: "directive", type: i3.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "component", type: i4$1.DiffEditorComponent, selector: "ngx-monaco-diff-editor", inputs: ["options", "originalModel", "modifiedModel"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: JsonDiffComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-management-json-diff', template: "<div class=\"json-header\">\n  <h5>{{ previousDiffTitle || text.previousDiffTitle }}</h5>\n  <h5>{{ currentDiffTitle || text.currentDiffTitle }}</h5>\n</div>\n<div class=\"json-wrapper\" [ngStyle]=\"{ 'height': height + 'px' }\">\n  <ngx-monaco-diff-editor [options]=\"diffOptions\" [originalModel]=\"previousDiffData\" [modifiedModel]=\"currentDiffData\" class=\"h-100\"></ngx-monaco-diff-editor>\n</div>\n", styles: [".json-header{display:flex;margin-top:8px}.json-header h5{margin-bottom:0;text-align:center;width:50%}.json-wrapper{margin-top:8px;overflow:auto;resize:vertical}\n"] }]
        }], ctorParameters: () => [{ type: i1.TextService }], propDecorators: { previousData: [{
                type: Input
            }], currentData: [{
                type: Input
            }], previousDiffTitle: [{
                type: Input
            }], currentDiffTitle: [{
                type: Input
            }], height: [{
                type: Input
            }] } });

function isValidJSON(control) {
    const value = control?.value || '';
    if (value) {
        try {
            JSON.parse(value);
        }
        catch (e) {
            // An error means this is invalid JSON.
            return { invalidJSON: true };
        }
    }
    return null;
}
function isValidArrayOfStrings(control) {
    const value = control?.value || '';
    let jsonObject = null;
    if (value) {
        try {
            jsonObject = JSON.parse(control.value);
        }
        catch (e) {
            // An error means this is invalid JSON.
            return { invalidJSON: true };
        }
    }
    if (!jsonObject || !Array.isArray(jsonObject)) {
        return { invalidArray: true };
    }
    if (jsonObject.some((v) => typeof v !== 'string')) {
        return { invalidArrayOfStrings: true };
    }
    return null;
}

const MIN_HEIGHT$1 = 100;
const INITIAL_HEIGHT$1 = 200;
class JsonEditorComponent extends BaseEditorComponent {
    constructor(textService, controlContainer) {
        super(textService, 'ui-management-json-editor', controlContainer);
        /**
        * Height of editor - requires a fixed height for the editor to measure & size-to, minimum 100
        **/
        this.height = INITIAL_HEIGHT$1;
        /**
        * Display editor as read-only initially, but allow edit on button click
        **/
        this.showEditToggle = false;
        /**
        * When used as part of a form, this will enforce the JSON value is an array of strings
        **/
        this.stringArrayOnly = false;
        this.editorOptions = {
            automaticLayout: true,
            folding: true,
            language: 'json',
            readOnly: false,
            scrollBeyondLastLine: false,
        };
        this.readOnly = false;
        this.readOnlyValue = '';
        this.heightStyles = {};
        this.initialHeight = '';
        this.minHeight = MIN_HEIGHT$1 + 'px';
        this.valueBeforeEdit = null;
        this.monacoEditor = null;
        this.contentChangeDisposable = null;
        this.hasMountedEditor = false;
        this.setInitialHeight(INITIAL_HEIGHT$1);
        // Set up custom error messages for validators
        this.errorMessageMap.set('invalidJSON', this.text.invalidJSONErrorMessage);
        this.errorMessageMap.set('invalidArray', this.text.invalidArrayErrorMessage);
        this.errorMessageMap.set('invalidArrayOfStrings', this.text.invalidStringArrayErrorMessage);
    }
    ngOnChanges(changes) {
        this.setReadonlyValue();
        this.locked = this.locked || !this.controlName;
        const newReadOnlyValue = this.showEditToggle || this.locked;
        // Do not set height here, as it will be set in ngAfterViewInit
        const updateValidation = this.setReadonlyFlag(newReadOnlyValue, false);
        if (changes.stringArrayOnly || updateValidation) {
            this.updateValidators('onChanges');
        }
    }
    ngAfterViewInit() {
        if (this.readOnly && !this.readOnlyValue) {
            this.readOnlyValue = this.value;
        }
        // The default height is set once by the constructor.
        // Wait for content to load, then set the height from the input.
        // Note: since we are letting the user resize content, not going to respect the height input
        // via ngOnChanges.
        this.setInitialHeight(this.height);
    }
    setInitialHeight(height) {
        const heightInPx = (!height || height < MIN_HEIGHT$1 ? MIN_HEIGHT$1 : height) + 'px';
        if (heightInPx === this.initialHeight) {
            return;
        }
        // Used by the scrollbox
        this.initialHeight = heightInPx;
        // Used by the editor
        this.heightStyles = {
            height: this.initialHeight,
            minHeight: this.minHeight
        };
    }
    edit() {
        this.valueBeforeEdit = this.value;
        this.hasMountedEditor = true;
        const updateValidation = this.setReadonlyFlag(false, true);
        if (updateValidation) {
            // Technically not onChanges, but we want to look for any changed validators and re-apply them,
            // which is what onChanges does. But in this instance, we don't need to call updateValueAndValidity.
            // This is because the monaco component will load in, and wire up the form controls, which runs validation.
            // Calling updateValueAndValidity causes expensive json validation to run excessively.
            this.updateValidators('onChanges', false);
        }
    }
    cancel() {
        const previousValue = this.valueBeforeEdit ?? '';
        this.valueBeforeEdit = null;
        // Reset monaco's editor text directly. Monaco preserves its model across our
        // *ngIf swap, and its CVA writeValue is unreliable (deferred via setTimeout
        // and races with disposal). Setting on the editor directly is authoritative.
        if (this.monacoEditor && typeof this.monacoEditor.setValue === 'function') {
            this.monacoEditor.setValue(previousValue);
        }
        this.readOnlyValue = previousValue;
        this.setReadonlyFlag(true, true);
        if (this.control) {
            if (this.control.value !== previousValue) {
                this.control.setValue(previousValue);
            }
            this.control.markAsPristine();
            this.control.markAsUntouched();
        }
    }
    onMonacoInit(editor) {
        this.monacoEditor = editor;
        // Dispose any prior listener in case the editor is re-mounted via *ngIf.
        this.contentChangeDisposable?.dispose();
        // Monaco's bundled CVA propagateChange has been observed to not deliver typed
        // values to the form control. Wire a direct listener so user edits always reach
        // the control.
        this.contentChangeDisposable = editor.onDidChangeModelContent(() => {
            const value = editor.getValue();
            if (this.control && this.control.value !== value) {
                this.control.setValue(value);
                this.control.markAsDirty();
                this.control.markAsTouched();
            }
        });
    }
    ngOnDestroy() {
        this.contentChangeDisposable?.dispose();
        this.contentChangeDisposable = null;
        super.ngOnDestroy();
    }
    setReadonlyFlag(newValue, setHeight) {
        const readOnlyStateChanged = newValue !== this.readOnly;
        if (readOnlyStateChanged) {
            this.readOnly = newValue;
            this.editorOptions.readOnly = newValue;
            if (this.monacoEditor && typeof this.monacoEditor.updateOptions === 'function') {
                this.monacoEditor.updateOptions({ readOnly: newValue });
            }
            // Grab the current height of the container, and use it as the initial height.
            // This will keep the two modes in sync with one another (scrollbox vs editor).
            if (setHeight && this.resizeContainer?.nativeElement) {
                const actualHeight = this.resizeContainer.nativeElement.clientHeight;
                this.setInitialHeight(actualHeight);
            }
        }
        // When the component is in readonly state, we do not apply validators (parsing json can be expensive).
        // If readonly stage changed, and we are no longer readonly, we need to apply validators.
        return readOnlyStateChanged && !this.readOnly;
    }
    setReadonlyValue() {
        if (this.controlName) {
            this.readOnlyValue = this.value || '';
        }
        else if (this.data) {
            this.readOnlyValue = JSON.stringify(this.data, null, 2) || '';
        }
        else {
            this.readOnlyValue = '';
        }
    }
    onValueChange(value) {
        this.readOnlyValue = value;
    }
    getValidators() {
        if (this.readOnly) {
            return [];
        }
        // To avoid parsing JSON strings in multiple validators, apply only one or the other at a time.
        if (this.stringArrayOnly) {
            return [isValidArrayOfStrings];
        }
        return [isValidJSON];
    }
    getDefaultText() {
        return {
            editButtonLabel: 'Edit',
            cancelButtonLabel: 'Cancel',
            invalidJSONErrorMessage: 'Must be valid JSON',
            invalidArrayErrorMessage: 'Must be a valid JSON array',
            invalidStringArrayErrorMessage: 'Array may only contain string values'
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: JsonEditorComponent, deps: [{ token: i1.TextService }, { token: i2.ControlContainer, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.17", type: JsonEditorComponent, isStandalone: false, selector: "ui-management-json-editor", inputs: { data: "data", height: "height", showEditToggle: "showEditToggle", stringArrayOnly: "stringArrayOnly" }, viewQueries: [{ propertyName: "resizeContainer", first: true, predicate: ["resizeContainer"], descendants: true }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div class=\"label-container\"\n  [class.justify-content-between]=\"showEditToggle && !locked && !hideLabel\"\n  [class.justify-content-end]=\"showEditToggle && !locked && hideLabel\">\n  <label *ngIf=\"!hideLabel\" uiCoreReplayUnmask [for]=\"fieldId\" [id]=\"labelId\">\n    {{ label }}\n    <ui-forms-label-tooltips\n        [label]=\"label\"\n        [locked]=\"locked\"\n        [lockedMessage]=\"lockedMessage\"\n        [tooltip]=\"tooltip\"\n        [tooltipPlacement]=\"tooltipPlacement\"\n        [e2e]=\"e2ePrefix\"\n    ></ui-forms-label-tooltips>\n  </label>\n  <div *ngIf=\"showEditToggle && !locked\">\n    <ui-core-button *ngIf=\"readOnly\" (click)=\"edit()\" [message]=\"text.editButtonLabel\" icon=\"edit\" buttonClass=\"py-0\"></ui-core-button>\n    <ui-core-button *ngIf=\"!readOnly\" (click)=\"cancel()\" [message]=\"text.cancelButtonLabel\" icon=\"close\" buttonClass=\"py-0\"></ui-core-button>\n  </div>\n</div>\n\n<div [class.mt-1]=\"(showEditToggle && !locked) || (label && !hideLabel)\" #resizeContainer>\n    <ui-core-scrollbox *ngIf=\"readOnly\" [content]=\"readOnlyValue\" [codeView]=\"true\" [locked]=\"locked\"\n        [height]=\"initialHeight\" [minHeight]=\"minHeight\">\n    </ui-core-scrollbox>\n    <div *ngIf=\"!readOnly || hasMountedEditor\" [hidden]=\"readOnly\" class=\"json-wrapper-resize\" [ngStyle]=\"heightStyles\">\n        <div class=\"h-100 container-form\">\n            <ngx-monaco-editor [formControlName]=\"controlName\" [options]=\"editorOptions\" (onInit)=\"onMonacoInit($event)\" class=\"h-100\"></ngx-monaco-editor>\n        </div>\n    </div>\n</div>\n\n<ui-forms-field-validation *ngIf=\"controlName && !readOnly && !locked\"\n  [ariaInputName]=\"label\"\n  [errorMessage]=\"customErrorMessage || errorMessage\"\n  [infoMessage]=\"infoMessage\"\n  [successMessage]=\"successMessage\"\n  [warningMessage]=\"warningMessage\"\n  [fieldId]=\"fieldId\"\n  [locked]=\"locked\">\n</ui-forms-field-validation>\n", styles: [".json-wrapper-resize{overflow:auto;resize:vertical}.container-form{padding:12px 0}\n"], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i3.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "component", type: i4$1.EditorComponent, selector: "ngx-monaco-editor", inputs: ["options", "model"] }, { kind: "directive", type: i2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i1.ButtonComponent, selector: "ui-core-button", inputs: ["themeGroup", "theme", "message", "icon", "iconPosition", "disabled", "disabledMessage", "showSpinner", "buttonClass", "width", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "ariaLabel", "isFormValid", "e2e", "buttonId"] }, { kind: "component", type: i1.ScrollboxComponent, selector: "ui-core-scrollbox", inputs: ["content", "emitScroll", "message", "ariaLabel", "codeView", "locked", "e2e", "height", "minHeight"], outputs: ["scrolled"] }, { kind: "directive", type: i1.ReplayUnmaskDirective, selector: "[uiCoreReplayUnmask]" }, { kind: "component", type: i5.FieldValidationComponent, selector: "ui-forms-field-validation", inputs: ["fieldId", "locked", "errorMessage", "infoMessage", "successMessage", "warningMessage", "ariaInputName", "criteria", "criteriaDescription"] }, { kind: "component", type: i5.LabelTooltipsComponent, selector: "ui-forms-label-tooltips", inputs: ["label", "locked", "lockedMessage", "tooltip", "tooltipPlacement", "e2e", "tooltipClass"] }], viewProviders: [
            {
                provide: ControlContainer,
                useExisting: FormGroupDirective
            }
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: JsonEditorComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-management-json-editor', viewProviders: [
                        {
                            provide: ControlContainer,
                            useExisting: FormGroupDirective
                        }
                    ], template: "<div class=\"label-container\"\n  [class.justify-content-between]=\"showEditToggle && !locked && !hideLabel\"\n  [class.justify-content-end]=\"showEditToggle && !locked && hideLabel\">\n  <label *ngIf=\"!hideLabel\" uiCoreReplayUnmask [for]=\"fieldId\" [id]=\"labelId\">\n    {{ label }}\n    <ui-forms-label-tooltips\n        [label]=\"label\"\n        [locked]=\"locked\"\n        [lockedMessage]=\"lockedMessage\"\n        [tooltip]=\"tooltip\"\n        [tooltipPlacement]=\"tooltipPlacement\"\n        [e2e]=\"e2ePrefix\"\n    ></ui-forms-label-tooltips>\n  </label>\n  <div *ngIf=\"showEditToggle && !locked\">\n    <ui-core-button *ngIf=\"readOnly\" (click)=\"edit()\" [message]=\"text.editButtonLabel\" icon=\"edit\" buttonClass=\"py-0\"></ui-core-button>\n    <ui-core-button *ngIf=\"!readOnly\" (click)=\"cancel()\" [message]=\"text.cancelButtonLabel\" icon=\"close\" buttonClass=\"py-0\"></ui-core-button>\n  </div>\n</div>\n\n<div [class.mt-1]=\"(showEditToggle && !locked) || (label && !hideLabel)\" #resizeContainer>\n    <ui-core-scrollbox *ngIf=\"readOnly\" [content]=\"readOnlyValue\" [codeView]=\"true\" [locked]=\"locked\"\n        [height]=\"initialHeight\" [minHeight]=\"minHeight\">\n    </ui-core-scrollbox>\n    <div *ngIf=\"!readOnly || hasMountedEditor\" [hidden]=\"readOnly\" class=\"json-wrapper-resize\" [ngStyle]=\"heightStyles\">\n        <div class=\"h-100 container-form\">\n            <ngx-monaco-editor [formControlName]=\"controlName\" [options]=\"editorOptions\" (onInit)=\"onMonacoInit($event)\" class=\"h-100\"></ngx-monaco-editor>\n        </div>\n    </div>\n</div>\n\n<ui-forms-field-validation *ngIf=\"controlName && !readOnly && !locked\"\n  [ariaInputName]=\"label\"\n  [errorMessage]=\"customErrorMessage || errorMessage\"\n  [infoMessage]=\"infoMessage\"\n  [successMessage]=\"successMessage\"\n  [warningMessage]=\"warningMessage\"\n  [fieldId]=\"fieldId\"\n  [locked]=\"locked\">\n</ui-forms-field-validation>\n", styles: [".json-wrapper-resize{overflow:auto;resize:vertical}.container-form{padding:12px 0}\n"] }]
        }], ctorParameters: () => [{ type: i1.TextService }, { type: i2.ControlContainer, decorators: [{
                    type: Optional
                }] }], propDecorators: { resizeContainer: [{
                type: ViewChild,
                args: ['resizeContainer']
            }], data: [{
                type: Input
            }], height: [{
                type: Input
            }], showEditToggle: [{
                type: Input
            }], stringArrayOnly: [{
                type: Input
            }] } });

const MIN_HEIGHT = 100;
const INITIAL_HEIGHT = 200;
class MarkdownEditorComponent extends BaseEditorComponent {
    constructor(textService, controlContainer) {
        super(textService, 'ui-management-markdown-editor', controlContainer);
        this.textService = textService;
        /**
        * Height of editor - requires a fixed height for the editor to measure & size-to, minimum 100
        **/
        this.height = INITIAL_HEIGHT;
        /**
        * Display editor as read-only initially, but allow edit on button click
        **/
        this.showEditToggle = false;
        this.editorOptions = {
            automaticLayout: true,
            folding: true,
            language: 'markdown',
            readOnly: false,
            scrollBeyondLastLine: false,
        };
        this.readOnly = false;
        this.readOnlyValue = '';
        this.heightStyles = {};
        this.initialHeight = '';
        this.minHeight = MIN_HEIGHT + 'px';
        this.setInitialHeight(INITIAL_HEIGHT);
    }
    ngOnChanges(changes) {
        this.setReadonlyValue(this.value);
        this.locked = this.locked || !this.controlName;
        const newReadOnlyValue = this.showEditToggle || this.locked;
        // Do not set height here, as it will be set in ngAfterViewInit
        this.setReadonlyFlag(newReadOnlyValue, false);
    }
    ngAfterViewInit() {
        if (this.readOnly && !this.readOnlyValue) {
            this.readOnlyValue = this.value;
            this.setReadonlyValue(this.value);
        }
        // The default height is set once by the constructor.
        // Wait for content to load, then set the height from the input.
        // Note: since we are letting the user resize content, not going to respect the height input
        // via ngOnChanges.
        this.setInitialHeight(this.height);
    }
    setInitialHeight(height) {
        const heightInPx = (!height || height < MIN_HEIGHT ? MIN_HEIGHT : height) + 'px';
        if (heightInPx === this.initialHeight) {
            return;
        }
        // Used by the scrollbox
        this.initialHeight = heightInPx;
        // Used by the editor
        this.heightStyles = {
            height: this.initialHeight,
            minHeight: this.minHeight
        };
    }
    edit() {
        this.setReadonlyFlag(false, true);
    }
    setReadonlyFlag(newValue, setHeight) {
        const readOnlyStateChanged = newValue !== this.readOnly;
        if (readOnlyStateChanged) {
            this.readOnly = newValue;
            this.editorOptions.readOnly = newValue;
            // Grab the current height of the container, and use it as the initial height.
            // This will keep the two modes in sync with one another (scrollbox vs editor).
            if (setHeight && this.resizeContainer?.nativeElement) {
                const actualHeight = this.resizeContainer.nativeElement.clientHeight;
                this.setInitialHeight(actualHeight);
            }
        }
    }
    setReadonlyValue(incomingValue) {
        const parsedValue = marked.parse(incomingValue || '');
        this.readOnlyValue = parsedValue;
    }
    onValueChange(value) {
        this.setReadonlyValue(value);
    }
    getValidators() {
        // The base class returns an empty array, but using this as a placeholder for a comment.
        // The reality is that markdown isn't something that can be validated easily, since any
        // text is valid markdown. Previewing is the best way to validate markdown.
        return [];
    }
    getDefaultText() {
        return {
            editButtonLabel: 'Edit'
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: MarkdownEditorComponent, deps: [{ token: i1.TextService }, { token: i2.ControlContainer, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.17", type: MarkdownEditorComponent, isStandalone: false, selector: "ui-management-markdown-editor", inputs: { height: "height", showEditToggle: "showEditToggle" }, viewQueries: [{ propertyName: "resizeContainer", first: true, predicate: ["resizeContainer"], descendants: true }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div class=\"label-container\"\n  [class.justify-content-between]=\"showEditToggle && !locked && !hideLabel\"\n  [class.justify-content-end]=\"showEditToggle && !locked && hideLabel\">\n  <label *ngIf=\"!hideLabel\" uiCoreReplayUnmask [for]=\"fieldId\" [id]=\"labelId\">\n    {{ label }}\n    <ui-forms-label-tooltips\n        [label]=\"label\"\n        [locked]=\"locked\"\n        [lockedMessage]=\"lockedMessage\"\n        [tooltip]=\"tooltip\"\n        [tooltipPlacement]=\"tooltipPlacement\"\n        [e2e]=\"e2ePrefix\"\n    ></ui-forms-label-tooltips>\n  </label>\n  <div *ngIf=\"showEditToggle && !locked\">\n    <ui-core-button (click)=\"edit()\" [message]=\"text.editButtonLabel\" icon=\"edit\" [class.invisible]=\"!readOnly\" buttonClass=\"py-0\"></ui-core-button>\n  </div>\n</div>\n\n<div [class.mt-1]=\"(showEditToggle && !locked) || (label && !hideLabel)\" #resizeContainer>\n    <ui-core-scrollbox *ngIf=\"readOnly\" [content]=\"readOnlyValue\" [locked]=\"locked\"\n        [height]=\"initialHeight\" [minHeight]=\"minHeight\">\n    </ui-core-scrollbox>\n    <div *ngIf=\"!readOnly\" class=\"markdown-wrapper-resize\" [ngStyle]=\"heightStyles\">\n        <div class=\"h-100 container-form\" >\n            <ngx-monaco-editor [formControlName]=\"controlName\" [options]=\"editorOptions\" class=\"h-100\"></ngx-monaco-editor>\n        </div>\n    </div>\n</div>\n\n<ui-forms-field-validation *ngIf=\"controlName && !readOnly && !locked\"\n  [ariaInputName]=\"label\"\n  [errorMessage]=\"customErrorMessage || errorMessage\"\n  [infoMessage]=\"infoMessage\"\n  [successMessage]=\"successMessage\"\n  [warningMessage]=\"warningMessage\"\n  [fieldId]=\"fieldId\"\n  [locked]=\"locked\">\n</ui-forms-field-validation>\n", styles: [".markdown-wrapper-resize{overflow:auto;resize:vertical}.container-form{padding:12px 0}\n"], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i3.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "component", type: i4$1.EditorComponent, selector: "ngx-monaco-editor", inputs: ["options", "model"] }, { kind: "directive", type: i2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i1.ButtonComponent, selector: "ui-core-button", inputs: ["themeGroup", "theme", "message", "icon", "iconPosition", "disabled", "disabledMessage", "showSpinner", "buttonClass", "width", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "ariaLabel", "isFormValid", "e2e", "buttonId"] }, { kind: "component", type: i1.ScrollboxComponent, selector: "ui-core-scrollbox", inputs: ["content", "emitScroll", "message", "ariaLabel", "codeView", "locked", "e2e", "height", "minHeight"], outputs: ["scrolled"] }, { kind: "directive", type: i1.ReplayUnmaskDirective, selector: "[uiCoreReplayUnmask]" }, { kind: "component", type: i5.FieldValidationComponent, selector: "ui-forms-field-validation", inputs: ["fieldId", "locked", "errorMessage", "infoMessage", "successMessage", "warningMessage", "ariaInputName", "criteria", "criteriaDescription"] }, { kind: "component", type: i5.LabelTooltipsComponent, selector: "ui-forms-label-tooltips", inputs: ["label", "locked", "lockedMessage", "tooltip", "tooltipPlacement", "e2e", "tooltipClass"] }], viewProviders: [
            {
                provide: ControlContainer,
                useExisting: FormGroupDirective
            }
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: MarkdownEditorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-management-markdown-editor', viewProviders: [
                        {
                            provide: ControlContainer,
                            useExisting: FormGroupDirective
                        }
                    ], standalone: false, template: "<div class=\"label-container\"\n  [class.justify-content-between]=\"showEditToggle && !locked && !hideLabel\"\n  [class.justify-content-end]=\"showEditToggle && !locked && hideLabel\">\n  <label *ngIf=\"!hideLabel\" uiCoreReplayUnmask [for]=\"fieldId\" [id]=\"labelId\">\n    {{ label }}\n    <ui-forms-label-tooltips\n        [label]=\"label\"\n        [locked]=\"locked\"\n        [lockedMessage]=\"lockedMessage\"\n        [tooltip]=\"tooltip\"\n        [tooltipPlacement]=\"tooltipPlacement\"\n        [e2e]=\"e2ePrefix\"\n    ></ui-forms-label-tooltips>\n  </label>\n  <div *ngIf=\"showEditToggle && !locked\">\n    <ui-core-button (click)=\"edit()\" [message]=\"text.editButtonLabel\" icon=\"edit\" [class.invisible]=\"!readOnly\" buttonClass=\"py-0\"></ui-core-button>\n  </div>\n</div>\n\n<div [class.mt-1]=\"(showEditToggle && !locked) || (label && !hideLabel)\" #resizeContainer>\n    <ui-core-scrollbox *ngIf=\"readOnly\" [content]=\"readOnlyValue\" [locked]=\"locked\"\n        [height]=\"initialHeight\" [minHeight]=\"minHeight\">\n    </ui-core-scrollbox>\n    <div *ngIf=\"!readOnly\" class=\"markdown-wrapper-resize\" [ngStyle]=\"heightStyles\">\n        <div class=\"h-100 container-form\" >\n            <ngx-monaco-editor [formControlName]=\"controlName\" [options]=\"editorOptions\" class=\"h-100\"></ngx-monaco-editor>\n        </div>\n    </div>\n</div>\n\n<ui-forms-field-validation *ngIf=\"controlName && !readOnly && !locked\"\n  [ariaInputName]=\"label\"\n  [errorMessage]=\"customErrorMessage || errorMessage\"\n  [infoMessage]=\"infoMessage\"\n  [successMessage]=\"successMessage\"\n  [warningMessage]=\"warningMessage\"\n  [fieldId]=\"fieldId\"\n  [locked]=\"locked\">\n</ui-forms-field-validation>\n", styles: [".markdown-wrapper-resize{overflow:auto;resize:vertical}.container-form{padding:12px 0}\n"] }]
        }], ctorParameters: () => [{ type: i1.TextService }, { type: i2.ControlContainer, decorators: [{
                    type: Optional
                }] }], propDecorators: { resizeContainer: [{
                type: ViewChild,
                args: ['resizeContainer']
            }], height: [{
                type: Input
            }], showEditToggle: [{
                type: Input
            }] } });

class PanelListComponent {
    constructor() {
        /**
        * Header at the top of the list.
        **/
        this.header = '';
        /**
        * Optional. When provided, an icon button will be rendered in the top right corner of the card.
        **/
        this.headerIcon = '';
        /**
        * Required if headerIcon is provided. The label for the header icon button.
        **/
        this.headerIconLabel = '';
        /**
        * Subheader at the top of the list.
        **/
        this.subheader = '';
        /**
        * Each item shown in the panel.
        **/
        this.items = [];
        /**
        * Emits when the header icon is clicked.
        **/
        this.headerIconClicked = new EventEmitter();
        // TODO
        this.e2ePrefix = '';
    }
    onHeaderIconClick() {
        this.headerIconClicked.emit();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: PanelListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.17", type: PanelListComponent, isStandalone: false, selector: "ui-management-panel-list", inputs: { header: "header", headerIcon: "headerIcon", headerIconLabel: "headerIconLabel", subheader: "subheader", items: "items", itemTemplate: "itemTemplate" }, outputs: { headerIconClicked: "headerIconClicked" }, ngImport: i0, template: "<div class=\"container-bordered p-0 mb-5\" *ngIf=\"items.length > 0\">\n    <div *ngIf=\"header\" class=\"bg-gray-100 border-radius-top p-5\">\n        <div class=\"d-flex align-items-center justify-content-between\">\n            <h2 class=\"text-semibold m-0\">{{ header }}</h2>\n            <ui-core-icon-button *ngIf=\"headerIcon && headerIconLabel\"\n                [message]=\"headerIconLabel\"\n                [icon]=\"headerIcon\"\n                size=\"md\"\n                [e2e]=\"e2ePrefix + 'header-icon'\"\n                (click)=\"onHeaderIconClick()\"\n            ></ui-core-icon-button>\n        </div>\n        <div *ngIf=\"subheader\" class=\"mt-1\">{{ subheader }}</div>\n    </div>\n    <div class=\"panel-list\">\n        <ng-container *ngFor=\"let item of items; let i=index; let isLast=last\">\n            <div [attr.data-e2e]=\"'panel-list-item-' + i\" class=\"m-5\">\n                <ng-container [ngTemplateOutlet]=\"itemTemplate\" [ngTemplateOutletContext]=\"{item: item, index: i}\">\n                </ng-container>\n            </div>\n            <hr *ngIf=\"!isLast\" class=\"my-0 mx-5\"/>\n        </ng-container>\n    </div>\n</div>", dependencies: [{ kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i3.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: i1.IconButtonComponent, selector: "ui-core-icon-button", inputs: ["message", "icon", "size", "disabled", "buttonClass", "ariaPressed", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "e2e", "theme", "usesGlassHoverState", "buttonId"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: PanelListComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-management-panel-list', template: "<div class=\"container-bordered p-0 mb-5\" *ngIf=\"items.length > 0\">\n    <div *ngIf=\"header\" class=\"bg-gray-100 border-radius-top p-5\">\n        <div class=\"d-flex align-items-center justify-content-between\">\n            <h2 class=\"text-semibold m-0\">{{ header }}</h2>\n            <ui-core-icon-button *ngIf=\"headerIcon && headerIconLabel\"\n                [message]=\"headerIconLabel\"\n                [icon]=\"headerIcon\"\n                size=\"md\"\n                [e2e]=\"e2ePrefix + 'header-icon'\"\n                (click)=\"onHeaderIconClick()\"\n            ></ui-core-icon-button>\n        </div>\n        <div *ngIf=\"subheader\" class=\"mt-1\">{{ subheader }}</div>\n    </div>\n    <div class=\"panel-list\">\n        <ng-container *ngFor=\"let item of items; let i=index; let isLast=last\">\n            <div [attr.data-e2e]=\"'panel-list-item-' + i\" class=\"m-5\">\n                <ng-container [ngTemplateOutlet]=\"itemTemplate\" [ngTemplateOutletContext]=\"{item: item, index: i}\">\n                </ng-container>\n            </div>\n            <hr *ngIf=\"!isLast\" class=\"my-0 mx-5\"/>\n        </ng-container>\n    </div>\n</div>" }]
        }], propDecorators: { header: [{
                type: Input
            }], headerIcon: [{
                type: Input
            }], headerIconLabel: [{
                type: Input
            }], subheader: [{
                type: Input
            }], items: [{
                type: Input
            }], itemTemplate: [{
                type: Input
            }], headerIconClicked: [{
                type: Output
            }] } });

class PanelListItem {
    constructor(data) {
        this.data = data;
        this.id = '';
    }
    static fromObject(data) {
        if (data.data) {
            const item = new PanelListItem(data.data);
            item.id = data.id || '';
            return item;
        }
        return null;
    }
}

class SearchBarComponent extends BaseTextComponent {
    constructor(textService) {
        super(textService, 'ui-management-search-bar');
        /**
        * Set the value externally.
        **/
        this.value = '';
        /**
        * The maximum amount of character input allowed.
        **/
        this.maxLength = DEFAULT_MAX_LENGTH;
        /**
        * Custom placeholder text that appears when no value is entered.
        * Default placeholder text is "Search"
        **/
        this.placeholder = this.text.placeholder;
        /**
        * Set to true to automatically focus the search input after the component is initialized. Defaults to false.
        **/
        this.autoFocus = false;
        /**
        * Customizable text for Search button
        **/
        this.searchButtonText = this.text.searchButtonText;
        /**
        * Customizable label for the searchByText
        **/
        this.searchByLabel = this.text.searchByLabel;
        /**
        * Customizable text to display next to the "Search By:" label
        **/
        this.searchByText = '';
        /**
        * Set to true to set the loading state (if true, component is readonly & shows a spinner)
        **/
        this.loading = false;
        /**
        * Customizable input id
        **/
        this.inputId = HtmlUtils.generateRandomId();
        /**
        * Emits when the search button is clicked
        **/
        this.searchSubmitted = new EventEmitter();
    }
    search() {
        if (this.value) {
            this.searchSubmitted.emit(this.value);
        }
    }
    getDefaultText() {
        return {
            placeholder: 'Search',
            searchByLabel: 'Search by:',
            searchButtonText: 'Search'
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: SearchBarComponent, deps: [{ token: i1.TextService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.17", type: SearchBarComponent, isStandalone: false, selector: "ui-management-search-bar", inputs: { value: "value", maxLength: "maxLength", placeholder: "placeholder", autoFocus: "autoFocus", searchButtonText: "searchButtonText", searchByLabel: "searchByLabel", searchByText: "searchByText", loading: "loading", inputId: "inputId" }, outputs: { searchSubmitted: "searchSubmitted" }, usesInheritance: true, ngImport: i0, template: "<label *ngIf=\"searchByText\" class=\"search-label text-caption form-px\" [for]=\"inputId\">\n  <span class=\"text-strong\">{{ searchByLabel }}</span>\n  {{ searchByText }}\n</label>\n<div class=\"d-flex\">\n  <div class=\"d-flex flex-grow-1\">\n    <ui-forms-search-input\n      [autoFocus]=\"autoFocus\"\n      class=\"w-100\"\n      [class.form-locked]=\"loading\"\n      [inputId]=\"inputId\"\n      [isSearchBar]=\"true\"\n      [locked]=\"loading\"\n      [maxLength]=\"maxLength\"\n      [placeholder]=\"placeholder\"\n      size=\"lg\"\n      [value]=\"value\"\n      (change)=\"value = $event\"\n      (keyup.enter)=\"search()\" />\n  </div>\n  <div>\n    <ui-core-button\n      [message]=\"searchButtonText\"\n      icon=\"search\"\n      theme=\"primary\"\n      buttonClass=\"border-left-flat pl-5 h-100\"\n      [disabled]=\"loading\"\n      [showSpinner]=\"true\"\n      (click)=\"search()\" />\n  </div>\n</div>\n", dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i1.ButtonComponent, selector: "ui-core-button", inputs: ["themeGroup", "theme", "message", "icon", "iconPosition", "disabled", "disabledMessage", "showSpinner", "buttonClass", "width", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "ariaLabel", "isFormValid", "e2e", "buttonId"] }, { kind: "component", type: i5.SearchInputComponent, selector: "ui-forms-search-input", inputs: ["value", "maxLength", "placeholder", "size", "autoFocus", "locked", "inputId", "clearButtonId", "isSearchBar"], outputs: ["inputHasFocus"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: SearchBarComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-management-search-bar', template: "<label *ngIf=\"searchByText\" class=\"search-label text-caption form-px\" [for]=\"inputId\">\n  <span class=\"text-strong\">{{ searchByLabel }}</span>\n  {{ searchByText }}\n</label>\n<div class=\"d-flex\">\n  <div class=\"d-flex flex-grow-1\">\n    <ui-forms-search-input\n      [autoFocus]=\"autoFocus\"\n      class=\"w-100\"\n      [class.form-locked]=\"loading\"\n      [inputId]=\"inputId\"\n      [isSearchBar]=\"true\"\n      [locked]=\"loading\"\n      [maxLength]=\"maxLength\"\n      [placeholder]=\"placeholder\"\n      size=\"lg\"\n      [value]=\"value\"\n      (change)=\"value = $event\"\n      (keyup.enter)=\"search()\" />\n  </div>\n  <div>\n    <ui-core-button\n      [message]=\"searchButtonText\"\n      icon=\"search\"\n      theme=\"primary\"\n      buttonClass=\"border-left-flat pl-5 h-100\"\n      [disabled]=\"loading\"\n      [showSpinner]=\"true\"\n      (click)=\"search()\" />\n  </div>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i1.TextService }], propDecorators: { value: [{
                type: Input
            }], maxLength: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], autoFocus: [{
                type: Input
            }], searchButtonText: [{
                type: Input
            }], searchByLabel: [{
                type: Input
            }], searchByText: [{
                type: Input
            }], loading: [{
                type: Input
            }], inputId: [{
                type: Input
            }], searchSubmitted: [{
                type: Output
            }] } });

class TargetConditionGroup {
}
var TargetGroupOperator;
(function (TargetGroupOperator) {
    TargetGroupOperator["AND"] = "AND";
    TargetGroupOperator["OR"] = "OR";
})(TargetGroupOperator || (TargetGroupOperator = {}));

class TargetingUtils {
    static toDropdownOptions(options) {
        const dropdownOptions = [];
        options.forEach(option => {
            const dOption = typeof option === 'string' ? [option, option] : [option.label, option.value];
            dropdownOptions.push(new DropdownOption(...dOption));
        });
        return dropdownOptions;
    }
}

class TargetCondition {
}
var ConditionOperator;
(function (ConditionOperator) {
    ConditionOperator["IS"] = "IS";
    ConditionOperator["IS_NOT"] = "IS_NOT";
    ConditionOperator["OVER"] = "OVER";
    ConditionOperator["UNDER"] = "UNDER";
    ConditionOperator["INCLUDES"] = "INCLUDES";
    ConditionOperator["DOES_NOT_INCLUDE"] = "DOES_NOT_INCLUDE";
})(ConditionOperator || (ConditionOperator = {}));

class TargetOperatorOption {
}

class TargetWorkflowOptions {
}
var ConditionValueType;
(function (ConditionValueType) {
    ConditionValueType["NONE"] = "none";
    ConditionValueType["NUMBER"] = "number";
    ConditionValueType["SELECT"] = "select";
    ConditionValueType["MULTISELECT"] = "multiselect";
    ConditionValueType["STRING"] = "string";
    ConditionValueType["DATE"] = "date";
    ConditionValueType["CURRENCY"] = "currency";
})(ConditionValueType || (ConditionValueType = {}));

class TargetResult {
    constructor(isValid, conditionGroup) {
        this.isValid = isValid;
        this.conditionGroup = conditionGroup;
    }
}

class TargetConditionComponent extends BaseTextComponent {
    constructor(textService, changeDetector, fb, ngZone, windowService) {
        super(textService, 'ui-management-target-condition');
        this.textService = textService;
        this.changeDetector = changeDetector;
        this.fb = fb;
        this.ngZone = ngZone;
        this.windowService = windowService;
        this.groupId = '';
        this.subjectDropdownOptions = [];
        this.targetingOptions = [];
        this.locked = false;
        this.groupConditionDeleted = new EventEmitter();
        this.groupConditionUpdated = new EventEmitter();
        this.isMobile = false;
        this.isMultiValueRule = false;
        this.operatorDropdownOptions = [];
        this.valueLabel = '';
        this.valueHelpText = '';
        this.valueDropdownOptions = [];
        this.valueMultiSelectOptions = [];
        this.ConditionValueType = ConditionValueType;
        this.multiValueOperators = [ConditionOperator.DOES_NOT_INCLUDE, ConditionOperator.INCLUDES];
        this.windowService.windowSize$.pipe(this.takeUntilDestroyed()).subscribe(windowSize => {
            this.isMobile = windowSize.isMobile;
        });
    }
    ngOnInit() {
        this.form = this.fb.group({
            subject: [this.condition.leftOperand, Validators.required],
            rule: [this.condition.operator, Validators.required],
        });
        this.form.get('subject').valueChanges.subscribe(subject => this.onSubjectChanged(subject));
        this.form.get('rule').valueChanges.subscribe(rule => this.onRuleChanged(rule));
        if (this.condition.leftOperand) {
            this.onSubjectChanged(this.condition.leftOperand);
        }
    }
    ngOnChanges(changes) {
        if (changes.condition && this.form?.get('subject')) {
            this.form.get('subject').setValue(this.condition.leftOperand);
        }
    }
    ngAfterViewInit() {
        // AfterViewInit run may be before CSS renders completely, resulting in spacing errors, this adds a delay cycle
        this.ngZone.runOutsideAngular(() => setTimeout(() => this.ngZone.run(() => this.setSpacing())));
    }
    isValid() {
        return this.form.valid;
    }
    validate() {
        if (!this.isValid()) {
            FormUtils.showFormValidation(this.form);
            return new TargetResult(false, this.condition);
        }
        return new TargetResult(true, this.condition);
    }
    setSpacing() {
        const elements = this.getFormSpacingElements();
        if (elements.length > 1) {
            SpacingUtils.setSpacingPerRow(elements);
        }
    }
    getFormSpacingElements() {
        const elements = [];
        if (!this.isMobile) {
            elements.push(this.subjectDropdown.nativeElement);
        }
        if (this.ruleDropdown?.nativeElement) {
            elements.push(this.ruleDropdown.nativeElement);
        }
        if (this.valueType !== ConditionValueType.NONE && this.valueInput?.nativeElement) {
            elements.push(this.valueInput.nativeElement);
        }
        elements.push(this.deleteDiv.nativeElement);
        return [...elements].map(element => ({
            element,
            ...FormSpacingUtils.getSpacingConfig(element)
        }));
    }
    onSubjectChanged(subject) {
        if (!subject) {
            return; // empty init
        }
        const updated = this.condition.leftOperand !== subject;
        this.condition.leftOperand = subject;
        this.operatorDropdownOptions = TargetingUtils.toDropdownOptions(this.getOperatorOptions());
        this.changeDetector.detectChanges();
        if (updated) {
            this.condition.operator = null;
            this.form.get('rule').setValue(null);
            this.condition.rightOperand = null;
            this.form.get('value')?.setValue(null);
            this.onConditionUpdated();
        }
        else if (this.condition.operator) {
            this.onRuleChanged(this.condition.operator);
        }
    }
    onRuleChanged(rule) {
        const updated = this.condition.operator !== rule;
        this.condition.operator = rule;
        this.setupValueField();
        if (updated) {
            this.onConditionUpdated();
        }
    }
    onValueChanged(value) {
        const strValue = Array.isArray(value) ? value.join(',') : (value || value === 0) && value.toString() || '';
        const updated = this.condition.rightOperand !== strValue;
        this.condition.rightOperand = strValue;
        if (updated) {
            this.onConditionUpdated();
        }
    }
    onDeleteCondition() {
        this.groupConditionDeleted.emit({ condition: this.condition, groupId: this.groupId });
    }
    onConditionUpdated() {
        this.groupConditionUpdated.emit({ condition: this.condition, groupId: this.groupId });
        this.setSpacing();
    }
    getTargetWorkflowOption(subject) {
        return this.targetingOptions.find(option => option.subject === subject);
    }
    getOperatorOptions() {
        if (!this.condition.leftOperand) {
            return [];
        }
        const operators = this.getTargetWorkflowOption(this.condition.leftOperand).operators;
        const operatorOptions = operators.map(op => {
            if (op instanceof TargetOperatorOption) {
                return op;
            }
            else {
                return {
                    label: op['label'] || this.text['operatorLabel' + op] || op,
                    value: op['value'] || op
                };
            }
        });
        return operatorOptions;
    }
    setupValueField() {
        if (!this.condition.leftOperand || !this.condition.operator) {
            this.valueLabel = '';
            this.valueHelpText = '';
            this.valueType = ConditionValueType.NONE;
            this.setSpacing();
            return;
        }
        const isMultiValueRule = this.multiValueOperators.includes(this.condition.operator);
        const workflowOption = this.getTargetWorkflowOption(this.condition.leftOperand);
        this.valueLabel = workflowOption.valueLabel || '';
        this.valueDropdownOptions = workflowOption.valueDropdownOptions;
        if (isMultiValueRule && workflowOption.valueOptions?.length) {
            this.valueType = ConditionValueType.MULTISELECT;
            this.valueHelpText = '';
            this.valueMultiSelectOptions = this.toMultiSelectOptions(workflowOption.valueOptions);
        }
        else if (isMultiValueRule) {
            this.valueType = ConditionValueType.STRING;
            this.valueHelpText = this.text.multipleValuesHelpText;
        }
        else if (workflowOption.valueDropdownOptions) {
            this.valueType = ConditionValueType.SELECT;
            this.valueHelpText = '';
        }
        else {
            this.valueType = workflowOption.valueType ?? ConditionValueType.NONE;
            this.valueHelpText = '';
        }
        if (this.valueType !== ConditionValueType.NONE) {
            // rightOperand is always stored as a string. The amount input treats an incoming string as cents (legacy back-compat) but a number as dollars.
            // We coerce currency values to a number to avoid a 2000 --> 20.00 display error.
            let initialValue;
            if (this.valueType === ConditionValueType.CURRENCY && this.condition.rightOperand) {
                initialValue = Number(this.condition.rightOperand);
            }
            else if (this.valueType === ConditionValueType.MULTISELECT) {
                initialValue = this.condition.rightOperand
                    ? this.condition.rightOperand.split(',').map(v => v.trim()).filter(Boolean)
                    : [];
            }
            else {
                initialValue = this.condition.rightOperand;
            }
            this.form.addControl('value', new FormControl(initialValue, Validators.required));
            this.form.get('value')?.valueChanges.subscribe(value => this.onValueChanged(value));
        }
        else {
            this.form.removeControl('value');
        }
        this.changeDetector.detectChanges();
        this.setSpacing();
    }
    toMultiSelectOptions(valueOptions) {
        return (valueOptions || []).map(opt => typeof opt === 'string'
            ? new MultiSelectDropdownOption(opt, opt)
            : new MultiSelectDropdownOption(opt.label, opt.value));
    }
    getDefaultText() {
        return {
            conditionLabel: 'Condition',
            multipleValuesHelpText: 'Enter Values Separated by Commas',
            operatorLabelDOES_NOT_INCLUDE: 'Is Not One Of',
            operatorLabelINCLUDES: 'Is One Of',
            operatorLabelIS_NOT: 'Is Not',
            operatorLabelIS: 'Is',
            operatorLabelOVER: 'Over or Equal To',
            operatorLabelUNDER: 'Under',
            removeConditionButtonAria: 'Remove Condition',
            ruleLabel: 'Rule',
            conditionErrorMessage: 'Select a Condition',
            ruleErrorMessage: 'Select a Rule',
            valueErrorMessage: 'Enter a Value'
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TargetConditionComponent, deps: [{ token: i1.TextService }, { token: i0.ChangeDetectorRef }, { token: i2.UntypedFormBuilder }, { token: i0.NgZone }, { token: i1.WindowService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.17", type: TargetConditionComponent, isStandalone: false, selector: "ui-management-target-condition", inputs: { condition: "condition", groupId: "groupId", subjectDropdownOptions: "subjectDropdownOptions", targetingOptions: "targetingOptions", locked: "locked" }, outputs: { groupConditionDeleted: "groupConditionDeleted", groupConditionUpdated: "groupConditionUpdated" }, viewQueries: [{ propertyName: "subjectDropdown", first: true, predicate: ["subjectDropdown"], descendants: true, read: ElementRef }, { propertyName: "ruleDropdown", first: true, predicate: ["ruleDropdown"], descendants: true, read: ElementRef }, { propertyName: "valueInput", first: true, predicate: ["valueInput"], descendants: true, read: ElementRef }, { propertyName: "deleteDiv", first: true, predicate: ["deleteDiv"], descendants: true }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div class=\"row pt-2 py-half bg-brand\" [formGroup]=\"form\">\n  <div class=\"col-md\">\n    <ui-forms-dropdown\n      #subjectDropdown\n      formControlName=\"subject\"\n      class=\"form-control-validation-m-0\"\n      [label]=\"text.conditionLabel\"\n      [options]=\"subjectDropdownOptions\"\n      [locked]=\"locked\"\n      [errorMessage]=\"text.conditionErrorMessage\" />\n  </div>\n\n  <div class=\"col-md col-sm-5 pl-md-2 pl-4 pr-0 pr-md-2\">\n    @if (condition.leftOperand) {\n      <ui-forms-dropdown\n        #ruleDropdown\n        formControlName=\"rule\"\n        class=\"form-control-validation-m-0\"\n        [label]=\"text.ruleLabel\"\n        [options]=\"operatorDropdownOptions\"\n        [locked]=\"locked\"\n        [errorMessage]=\"text.ruleErrorMessage\" />\n    }\n  </div>\n\n  <div class=\"col-md col-sm-5 pr-sm-0\">\n    @if (valueType === ConditionValueType.SELECT) {\n      <ui-forms-dropdown\n        #valueInput\n        formControlName=\"value\"\n        class=\"form-control-validation-m-0\"\n        [label]=\"valueLabel\"\n        [options]=\"valueDropdownOptions\"\n        [locked]=\"locked\"\n        [errorMessage]=\"text.valueErrorMessage\" />\n    } @else if (valueType === ConditionValueType.MULTISELECT) {\n      <ui-forms-multi-select-dropdown\n        #valueInput\n        formControlName=\"value\"\n        class=\"form-control-validation-m-0\"\n        [label]=\"valueLabel\"\n        [options]=\"valueMultiSelectOptions\"\n        [locked]=\"locked\"\n        [errorMessage]=\"text.valueErrorMessage\" />\n    } @else if (valueType === ConditionValueType.NUMBER) {\n      <ui-forms-number-input\n        #valueInput\n        formControlName=\"value\"\n        class=\"form-control-validation-m-0\"\n        [label]=\"valueLabel\"\n        [locked]=\"locked\"\n        [errorMessage]=\"text.valueErrorMessage\" />\n    } @else if (valueType === ConditionValueType.STRING) {\n      <ui-forms-text-input\n        #valueInput\n        formControlName=\"value\"\n        class=\"form-control-validation-m-0\"\n        [label]=\"valueLabel\"\n        [tooltip]=\"valueHelpText\"\n        [locked]=\"locked\"\n        [errorMessage]=\"text.valueErrorMessage\" />\n    } @else if (valueType === ConditionValueType.DATE) {\n      <ui-forms-datepicker\n        #valueInput\n        formControlName=\"value\"\n        class=\"form-control-validation-m-0\"\n        [label]=\"valueLabel\"\n        [allowToday]=\"true\"\n        [locked]=\"locked\"\n        [errorMessage]=\"text.valueErrorMessage\" />\n    } @else if (valueType === ConditionValueType.CURRENCY) {\n      <ui-forms-amount-input\n        #valueInput\n        formControlName=\"value\"\n        class=\"form-control-validation-m-0\"\n        [label]=\"valueLabel\"\n        [tooltip]=\"valueHelpText\"\n        [locked]=\"locked\"\n        [errorMessage]=\"text.valueErrorMessage\" />\n    }\n  </div>\n\n  <div class=\"col-sm-2 col-md-1 pb-4\">\n    <div #deleteDiv class=\"d-flex form-content-centered justify-content-end\">\n      <ui-core-icon-button\n        icon=\"delete\"\n        class=\"form-content-container\"\n        [message]=\"text.removeConditionButtonAria\"\n        [disabled]=\"locked\"\n        (click)=\"onDeleteCondition()\" />\n    </div>\n  </div>\n</div>\n", dependencies: [{ kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i1.IconButtonComponent, selector: "ui-core-icon-button", inputs: ["message", "icon", "size", "disabled", "buttonClass", "ariaPressed", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "e2e", "theme", "usesGlassHoverState", "buttonId"] }, { kind: "component", type: i5.AmountInputComponent, selector: "ui-forms-amount-input", inputs: ["decimalPlaces", "min", "hideIcon", "allowEmptyField"] }, { kind: "component", type: i5.DatepickerComponent, selector: "ui-forms-datepicker", inputs: ["actionButtonIcon", "actionButtonLabel", "afterDateText", "allowToday", "daysAfter", "daysPrior", "disableAllExceptFirstDayOfMonth", "disableAllExceptLastDayOfMonth", "disableAllExceptFifteenthAndLastDay", "disabledDaysOfMonth", "disabledDaysText", "disableFutureDates", "disableHolidays", "disablePastDates", "disableWeekends", "hideCalendar", "holidays", "iconLeft", "markedDate", "markedDateText", "maxDate", "minDate", "mobileDoneButtonLabel", "placeholder", "priorDateText", "selectedDateText"], outputs: ["actionButtonClick"] }, { kind: "component", type: i5.DropdownComponent, selector: "ui-forms-dropdown", inputs: ["iconLeft", "showMenuOptionAsIconLeft", "options", "noOptionsMessage", "actions", "actionButtonIcon", "actionButtonMessage", "actionButtonMessageHidden", "actionButtonDisabled", "actionButtonDisabledSpinner", "menuIconsOnRight", "allowEmojis"], outputs: ["actionButtonClick", "menuSelection"] }, { kind: "component", type: i5.MultiSelectDropdownComponent, selector: "ui-forms-multi-select-dropdown", inputs: ["iconLeft", "options", "actions", "actionButtonIcon", "actionButtonMessage", "actionButtonMessageHidden", "actionButtonDisabled", "actionButtonDisabledSpinner", "menuIconsOnRight"], outputs: ["menuSelection", "actionButtonClick"] }, { kind: "component", type: i5.NumberInputComponent, selector: "ui-forms-number-input", inputs: ["min", "max", "dayOfMonthPicker", "disabledPickerDays", "markedDay", "markedDayLabel", "selectedDayLabel", "disabledDaysText", "decimalPlaces"] }, { kind: "component", type: i5.TextInputComponent, selector: "ui-forms-text-input", inputs: ["maxLength", "fieldType", "actionButtonIcon", "actionButtonMessage", "actionButtonDisabled", "actionButtonDisabledSpinner", "copyToClipboard", "criteria", "criteriaDescription", "options", "typeaheadFactory", "autocomplete", "postalCodeCountryAlpha2", "postalCodeRequired", "customMasking"], outputs: ["actionButtonClick", "copied", "menuSelection"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TargetConditionComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-management-target-condition', template: "<div class=\"row pt-2 py-half bg-brand\" [formGroup]=\"form\">\n  <div class=\"col-md\">\n    <ui-forms-dropdown\n      #subjectDropdown\n      formControlName=\"subject\"\n      class=\"form-control-validation-m-0\"\n      [label]=\"text.conditionLabel\"\n      [options]=\"subjectDropdownOptions\"\n      [locked]=\"locked\"\n      [errorMessage]=\"text.conditionErrorMessage\" />\n  </div>\n\n  <div class=\"col-md col-sm-5 pl-md-2 pl-4 pr-0 pr-md-2\">\n    @if (condition.leftOperand) {\n      <ui-forms-dropdown\n        #ruleDropdown\n        formControlName=\"rule\"\n        class=\"form-control-validation-m-0\"\n        [label]=\"text.ruleLabel\"\n        [options]=\"operatorDropdownOptions\"\n        [locked]=\"locked\"\n        [errorMessage]=\"text.ruleErrorMessage\" />\n    }\n  </div>\n\n  <div class=\"col-md col-sm-5 pr-sm-0\">\n    @if (valueType === ConditionValueType.SELECT) {\n      <ui-forms-dropdown\n        #valueInput\n        formControlName=\"value\"\n        class=\"form-control-validation-m-0\"\n        [label]=\"valueLabel\"\n        [options]=\"valueDropdownOptions\"\n        [locked]=\"locked\"\n        [errorMessage]=\"text.valueErrorMessage\" />\n    } @else if (valueType === ConditionValueType.MULTISELECT) {\n      <ui-forms-multi-select-dropdown\n        #valueInput\n        formControlName=\"value\"\n        class=\"form-control-validation-m-0\"\n        [label]=\"valueLabel\"\n        [options]=\"valueMultiSelectOptions\"\n        [locked]=\"locked\"\n        [errorMessage]=\"text.valueErrorMessage\" />\n    } @else if (valueType === ConditionValueType.NUMBER) {\n      <ui-forms-number-input\n        #valueInput\n        formControlName=\"value\"\n        class=\"form-control-validation-m-0\"\n        [label]=\"valueLabel\"\n        [locked]=\"locked\"\n        [errorMessage]=\"text.valueErrorMessage\" />\n    } @else if (valueType === ConditionValueType.STRING) {\n      <ui-forms-text-input\n        #valueInput\n        formControlName=\"value\"\n        class=\"form-control-validation-m-0\"\n        [label]=\"valueLabel\"\n        [tooltip]=\"valueHelpText\"\n        [locked]=\"locked\"\n        [errorMessage]=\"text.valueErrorMessage\" />\n    } @else if (valueType === ConditionValueType.DATE) {\n      <ui-forms-datepicker\n        #valueInput\n        formControlName=\"value\"\n        class=\"form-control-validation-m-0\"\n        [label]=\"valueLabel\"\n        [allowToday]=\"true\"\n        [locked]=\"locked\"\n        [errorMessage]=\"text.valueErrorMessage\" />\n    } @else if (valueType === ConditionValueType.CURRENCY) {\n      <ui-forms-amount-input\n        #valueInput\n        formControlName=\"value\"\n        class=\"form-control-validation-m-0\"\n        [label]=\"valueLabel\"\n        [tooltip]=\"valueHelpText\"\n        [locked]=\"locked\"\n        [errorMessage]=\"text.valueErrorMessage\" />\n    }\n  </div>\n\n  <div class=\"col-sm-2 col-md-1 pb-4\">\n    <div #deleteDiv class=\"d-flex form-content-centered justify-content-end\">\n      <ui-core-icon-button\n        icon=\"delete\"\n        class=\"form-content-container\"\n        [message]=\"text.removeConditionButtonAria\"\n        [disabled]=\"locked\"\n        (click)=\"onDeleteCondition()\" />\n    </div>\n  </div>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i1.TextService }, { type: i0.ChangeDetectorRef }, { type: i2.UntypedFormBuilder }, { type: i0.NgZone }, { type: i1.WindowService }], propDecorators: { subjectDropdown: [{
                type: ViewChild,
                args: ['subjectDropdown', { read: ElementRef }]
            }], ruleDropdown: [{
                type: ViewChild,
                args: ['ruleDropdown', { read: ElementRef }]
            }], valueInput: [{
                type: ViewChild,
                args: ['valueInput', { read: ElementRef }]
            }], deleteDiv: [{
                type: ViewChild,
                args: ['deleteDiv']
            }], condition: [{
                type: Input
            }], groupId: [{
                type: Input
            }], subjectDropdownOptions: [{
                type: Input
            }], targetingOptions: [{
                type: Input
            }], locked: [{
                type: Input
            }], groupConditionDeleted: [{
                type: Output
            }], groupConditionUpdated: [{
                type: Output
            }] } });

class TargetOperatorComponent {
    constructor() {
        this.disabled = false;
        this.locked = false;
        this.andLabel = 'AND';
        this.orLabel = 'OR';
        this.value = TargetGroupOperator.AND;
        this.valueChange = new EventEmitter();
        this.controlId = '';
        this.andValue = TargetGroupOperator.AND;
        this.orValue = TargetGroupOperator.OR;
        this.controlId = HtmlUtils.generateRandomId();
    }
    changeValue(value) {
        this.valueChange.emit(value);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TargetOperatorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.17", type: TargetOperatorComponent, isStandalone: false, selector: "ui-management-target-operator", inputs: { disabled: "disabled", locked: "locked", andLabel: "andLabel", orLabel: "orLabel", value: "value" }, outputs: { valueChange: "valueChange" }, ngImport: i0, template: `
        <div class="text-nowrap">
            <fieldset role="radiogroup" [attr.aria-disabled]="disabled || locked" [attr.aria-labelledby]="controlId + '-legend'">
                <legend class="sr-only" [id]="controlId + '-legend'">Group Operator</legend>
                <input
                    type="radio"
                    [checked]="value === andValue"
                    class="sr-only"
                    [class.locked]="locked && !disabled"
                    [disabled]="disabled || locked"
                    [id]="controlId + 'a'"
                    [name]="controlId"
                    [value]="andValue"
                    (change)="changeValue($event.target.value)"
                />
                <label [for]="controlId + 'a'">{{ andLabel }}</label>
                <input
                    type="radio"
                    [checked]="value === orValue"
                    class="sr-only"
                    [class.locked]="locked && !disabled"
                    [disabled]="disabled || locked"
                    [id]="controlId + 'o'"
                    [name]="controlId"
                    [value]="orValue"
                    (change)="changeValue($event.target.value)"
                />
                <label [for]="controlId + 'o'">{{ orLabel }}</label>
            </fieldset>
      </div>
    `, isInline: true, styles: ["label{background-color:var(--color-default);border:1px solid var(--color-gray-600);border-radius:4px 0 0 4px;color:var(--color-gray-600);font-size:16px;font-weight:var(--type-weight-bold);line-height:1.5;margin:0;padding:1px 8px;position:relative;transition-property:color,background-color,border-color;transition-duration:var(--transition-duration);transition-timing-function:var(--transition-timing)}label~label{margin-left:-1px;border-radius:0 4px 4px 0}label:hover{border-color:var(--color-primary);color:var(--color-primary);position:relative;z-index:1;cursor:pointer}input:focus:not(:checked)+label{border-color:var(--color-primary);color:var(--color-primary);position:relative;z-index:1}input:checked+label,input:checked+label:hover{background-color:var(--color-primary-900);border-color:var(--color-primary-900);color:var(--color-content-neutral);cursor:default}input:checked.locked+label{background-color:var(--button-color-primary-disabled);border-color:var(--button-color-primary-border-disabled);color:var(--button-color-primary-disabled-on)}input:disabled+label{background-color:var(--color-default);border-color:var(--color-gray-300);color:var(--color-gray-300)}input:disabled+label,input.locked+label{pointer-events:none}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TargetOperatorComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-management-target-operator', template: `
        <div class="text-nowrap">
            <fieldset role="radiogroup" [attr.aria-disabled]="disabled || locked" [attr.aria-labelledby]="controlId + '-legend'">
                <legend class="sr-only" [id]="controlId + '-legend'">Group Operator</legend>
                <input
                    type="radio"
                    [checked]="value === andValue"
                    class="sr-only"
                    [class.locked]="locked && !disabled"
                    [disabled]="disabled || locked"
                    [id]="controlId + 'a'"
                    [name]="controlId"
                    [value]="andValue"
                    (change)="changeValue($event.target.value)"
                />
                <label [for]="controlId + 'a'">{{ andLabel }}</label>
                <input
                    type="radio"
                    [checked]="value === orValue"
                    class="sr-only"
                    [class.locked]="locked && !disabled"
                    [disabled]="disabled || locked"
                    [id]="controlId + 'o'"
                    [name]="controlId"
                    [value]="orValue"
                    (change)="changeValue($event.target.value)"
                />
                <label [for]="controlId + 'o'">{{ orLabel }}</label>
            </fieldset>
      </div>
    `, styles: ["label{background-color:var(--color-default);border:1px solid var(--color-gray-600);border-radius:4px 0 0 4px;color:var(--color-gray-600);font-size:16px;font-weight:var(--type-weight-bold);line-height:1.5;margin:0;padding:1px 8px;position:relative;transition-property:color,background-color,border-color;transition-duration:var(--transition-duration);transition-timing-function:var(--transition-timing)}label~label{margin-left:-1px;border-radius:0 4px 4px 0}label:hover{border-color:var(--color-primary);color:var(--color-primary);position:relative;z-index:1;cursor:pointer}input:focus:not(:checked)+label{border-color:var(--color-primary);color:var(--color-primary);position:relative;z-index:1}input:checked+label,input:checked+label:hover{background-color:var(--color-primary-900);border-color:var(--color-primary-900);color:var(--color-content-neutral);cursor:default}input:checked.locked+label{background-color:var(--button-color-primary-disabled);border-color:var(--button-color-primary-border-disabled);color:var(--button-color-primary-disabled-on)}input:disabled+label{background-color:var(--color-default);border-color:var(--color-gray-300);color:var(--color-gray-300)}input:disabled+label,input.locked+label{pointer-events:none}\n"] }]
        }], ctorParameters: () => [], propDecorators: { disabled: [{
                type: Input
            }], locked: [{
                type: Input
            }], andLabel: [{
                type: Input
            }], orLabel: [{
                type: Input
            }], value: [{
                type: Input
            }], valueChange: [{
                type: Output
            }] } });

class TargetRuleComponent {
    constructor() {
        /**
        * Boolean - true if this is the first rule of a child group
        **/
        this.isSubGroup = false;
        /**
        * Text to display for the current active operator
        **/
        this.operator = '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TargetRuleComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.17", type: TargetRuleComponent, isStandalone: false, selector: "ui-management-target-rule", inputs: { isFirst: "isFirst", isSubGroup: "isSubGroup", operator: "operator" }, ngImport: i0, template: `
        <div class="label-rule-wrapper" [class.nested]="isSubGroup">
          <div class="cell-1" [class.mt-2]="isFirst && !isSubGroup">
            <span *ngIf="operator && !isFirst" class="operator-label">{{ operator }}</span>
          </div>
        </div>
    `, isInline: true, styles: [".label-rule-wrapper{display:grid;height:100%;width:36px;border-left:2px solid var(--color-stroke-1);margin-left:15px;margin-top:-1px}.label-rule-wrapper .cell-1{height:3.65rem;border-bottom:2px solid var(--color-stroke-1)}.label-rule-wrapper .cell-1 .operator-label{position:relative;top:2.65rem;background-color:#fff;color:var(--color-gray-400);font-size:10px;font-weight:var(--type-weight-bold);margin-left:4px;padding:0 2px;text-transform:uppercase}@media (min-width: 768px){.label-rule-wrapper.nested{width:52px}}.label-rule-wrapper.nested .cell-1{height:2.3rem}.label-rule-wrapper.nested .cell-1 .operator-label{top:1.3rem}\n"], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TargetRuleComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-management-target-rule', template: `
        <div class="label-rule-wrapper" [class.nested]="isSubGroup">
          <div class="cell-1" [class.mt-2]="isFirst && !isSubGroup">
            <span *ngIf="operator && !isFirst" class="operator-label">{{ operator }}</span>
          </div>
        </div>
    `, styles: [".label-rule-wrapper{display:grid;height:100%;width:36px;border-left:2px solid var(--color-stroke-1);margin-left:15px;margin-top:-1px}.label-rule-wrapper .cell-1{height:3.65rem;border-bottom:2px solid var(--color-stroke-1)}.label-rule-wrapper .cell-1 .operator-label{position:relative;top:2.65rem;background-color:#fff;color:var(--color-gray-400);font-size:10px;font-weight:var(--type-weight-bold);margin-left:4px;padding:0 2px;text-transform:uppercase}@media (min-width: 768px){.label-rule-wrapper.nested{width:52px}}.label-rule-wrapper.nested .cell-1{height:2.3rem}.label-rule-wrapper.nested .cell-1 .operator-label{top:1.3rem}\n"] }]
        }], propDecorators: { isFirst: [{
                type: Input
            }], isSubGroup: [{
                type: Input
            }], operator: [{
                type: Input
            }] } });

class TargetingComponent extends BaseTextComponent {
    constructor(textService, changeDetector) {
        super(textService, 'ui-management-targeting');
        this.textService = textService;
        this.changeDetector = changeDetector;
        /**
        * Array of TargetWorkflowOptions to define available conditions & rules, text & options
        */
        this.targetingOptions = [];
        /**
        * Specifies whether or not the component should be read-only. Locked fields cannot be modified by the user.
        **/
        this.locked = false;
        /**
        * emits full conditionGroup object on any change
        **/
        this.conditionGroupChange = new EventEmitter();
        /**
        * internal Inputs & Outputs
        **/
        // used to determine if component is inside a parent group
        this._isSubGroup = false;
        // used to pass options recursively
        this._subjectDropdownOptions = [];
        // used to emit updates to the parent group
        this.groupDeleted = new EventEmitter();
        this.groupConditionDeleted = new EventEmitter();
        this.groupConditionUpdated = new EventEmitter();
        this.id = '';
    }
    ngOnChanges(changes) {
        if (changes.conditionGroup && this.conditionGroup) {
            this.id = this.conditionGroup.id;
            if (this.conditionGroup.conditions?.length > 0) {
                if (this.groupOperator) {
                    this.groupOperator.value = this.conditionGroup.groupOperator;
                }
            }
        }
        if (changes.targetingOptions) {
            const subjectOptions = [];
            this.targetingOptions.forEach(option => {
                subjectOptions.push({ label: option.label, value: option.subject });
                if (option.valueOptions) {
                    option.valueDropdownOptions = TargetingUtils.toDropdownOptions(option.valueOptions);
                }
            });
            this._subjectDropdownOptions = TargetingUtils.toDropdownOptions(subjectOptions);
        }
    }
    ngAfterViewInit() {
        if (this.conditionGroup) {
            // trigger update to parent form to validate pre-filled data & allow submit
            this.updateGroupOperator(this.conditionGroup.groupOperator);
            if (!this._isSubGroup) { // run validate only on the top-level group
                this.validate();
                this.changeDetector.detectChanges();
            }
        }
    }
    validate() {
        let foundError = false;
        const conditions = [...this.targetConditions];
        if (this.targetSubgroups) {
            this.targetSubgroups.forEach(group => {
                conditions.push(...group.targetConditions);
            });
        }
        conditions.forEach(condition => {
            const result = condition.validate();
            if (!result.isValid) {
                foundError = true;
            }
        });
        return new TargetResult(!foundError, this.conditionGroup);
    }
    createConditionGroup() {
        const group = new TargetConditionGroup();
        group.id = UuidUtils.create();
        group.groupOperator = TargetGroupOperator.AND;
        group.conditions = [];
        this.conditionGroup = group;
        this.id = group.id;
        this.addCondition(group.id);
    }
    addCondition(groupId) {
        const group = this.getConditionGroup(groupId);
        group.conditions.push({
            id: UuidUtils.create(),
            operator: undefined,
            leftOperand: undefined,
            rightOperand: undefined
        });
        this.conditionGroupChange.emit(this.conditionGroup);
    }
    addGroup() {
        const id = UuidUtils.create();
        this.conditionGroup.conditions.push({
            id,
            groupOperator: TargetGroupOperator.OR,
            conditions: []
        });
        this.addCondition(id);
    }
    deleteGroup(groupId) {
        if (this._isSubGroup) {
            this.groupDeleted.emit(groupId);
            return;
        }
        this.conditionGroup.conditions = this.conditionGroup.conditions.filter(condition => condition.id !== groupId);
        if (this.conditionGroup.conditions.length === 0) {
            this.conditionGroup = null;
        }
        this.conditionGroupChange.emit(this.conditionGroup);
    }
    deleteGroupCondition(cData) {
        if (this._isSubGroup) {
            this.groupConditionDeleted.emit(cData);
            return;
        }
        let group = this.getConditionGroup(cData.condition.id, true);
        group.conditions = group.conditions.filter(condition => condition.id !== cData.condition.id);
        if (group.conditions.length === 0) {
            this.deleteGroup(group.id);
            return;
        }
        this.conditionGroupChange.emit(this.conditionGroup);
    }
    updateGroupCondition(cData) {
        if (this._isSubGroup) {
            this.groupConditionUpdated.emit(cData);
            return;
        }
        let group = this.getConditionGroup(cData.condition.id, true);
        const index = group.conditions.findIndex(value => value.id === cData.condition.id);
        if (index >= 0) {
            group.conditions.splice(index, 1, cData.condition);
        }
        this.conditionGroupChange.emit(this.conditionGroup);
    }
    updateGroupOperator(operator) {
        this.conditionGroup.groupOperator = operator;
        this.conditionGroupChange.emit(this.conditionGroup);
    }
    getConditionGroup(id, getParent = false) {
        let group;
        if (this.conditionGroup.id === id) {
            group = this.conditionGroup;
        }
        this.conditionGroup.conditions.forEach(condition => {
            if (condition.id === id) {
                group = getParent ? this.conditionGroup : condition;
            }
            else {
                condition.conditions?.forEach(subCondition => {
                    if (subCondition.id === id) {
                        group = condition;
                    }
                });
            }
        });
        return group;
    }
    getDefaultText() {
        return {
            addConditionButtonLabel: 'Add Rule',
            addGroupButtonLabel: 'Add Group',
            deleteGroupButtonLabel: 'Delete Group',
            operatorAndLabel: 'AND',
            operatorOrLabel: 'OR'
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TargetingComponent, deps: [{ token: i1.TextService }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.17", type: TargetingComponent, isStandalone: false, selector: "ui-management-targeting", inputs: { targetingOptions: "targetingOptions", conditionGroup: "conditionGroup", locked: "locked", _isSubGroup: "_isSubGroup", _subjectDropdownOptions: "_subjectDropdownOptions" }, outputs: { conditionGroupChange: "conditionGroupChange", groupDeleted: "groupDeleted", groupConditionDeleted: "groupConditionDeleted", groupConditionUpdated: "groupConditionUpdated" }, viewQueries: [{ propertyName: "groupOperator", first: true, predicate: ["groupOperator"], descendants: true }, { propertyName: "targetConditions", predicate: TargetConditionComponent, descendants: true }, { propertyName: "targetSubgroups", predicate: ["targetSubgroup"], descendants: true }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div class=\"condition-group w-100 mt-3\">\n  <ng-container *ngIf=\"conditionGroup\">\n    <ui-management-target-operator *ngIf=\"conditionGroup.conditions?.length > 0\"\n      #groupOperator\n      [disabled]=\"conditionGroup.conditions.length <= 1\"\n      [andLabel]=\"text.operatorAndLabel\"\n      [orLabel]=\"text.operatorOrLabel\"\n      class=\"d-flex mt-half\"\n      [value]=\"conditionGroup.groupOperator\"\n      [locked]=\"locked\"\n      (valueChange)=\"updateGroupOperator($event)\" />\n    <div *ngFor=\"let condition of conditionGroup.conditions; let first = first; let last = last\" class=\"conditions d-flex w-100\">\n      <ui-management-target-rule \n        [operator]=\"conditionGroup.conditions.length > 1 && conditionGroup.groupOperator\" \n        [isFirst]=\"first\" \n        [isSubGroup]=\"condition.conditions\">\n      </ui-management-target-rule>\n      <ui-management-target-condition *ngIf=\"!condition.conditions\"\n        [condition]=\"condition\"\n        [subjectDropdownOptions]=\"_subjectDropdownOptions\"\n        [targetingOptions]=\"targetingOptions\"\n        [groupId]=\"id\"\n        [locked]=\"locked\"\n        class=\"container ml-0 px-0 px-lg-2 mb-half\"\n        [class.pt-2]=\"first\"\n        [class.pb-2]=\"last\"\n        [class.mb-1]=\"last\"\n        (groupConditionDeleted)=\"deleteGroupCondition($event)\"\n        (groupConditionUpdated)=\"updateGroupCondition($event)\">\n      </ui-management-target-condition>\n      <ui-management-targeting *ngIf=\"condition.conditions\"\n        #targetSubgroup\n        [conditionGroup]=\"condition\"\n        [_isSubGroup]=\"true\"\n        [_subjectDropdownOptions]=\"_subjectDropdownOptions\"\n        [targetingOptions]=\"targetingOptions\"\n        [locked]=\"locked\"\n        class=\"d-flex w-100\"\n        (groupDeleted)=\"deleteGroup($event)\"\n        (groupConditionDeleted)=\"deleteGroupCondition($event)\"\n        (groupConditionUpdated)=\"updateGroupCondition($event)\"\n        (conditionGroupChange)=\"conditionGroupChange.emit(conditionGroup)\" />\n    </div>\n  </ng-container>\n  <ui-core-button-group\n    [primaryButtonText]=\"conditionGroup ? text.addConditionButtonLabel : null\"\n    (primaryButtonClicked)=\"addCondition(id)\"\n    [secondaryButtonText]=\"!conditionGroup ? text.addConditionButtonLabel : null\"\n    (secondaryButtonClicked)=\"createConditionGroup()\"\n    [tertiaryButtonText]=\"!conditionGroup ? null : _isSubGroup ? text.deleteGroupButtonLabel : text.addGroupButtonLabel\"\n    [tertiaryButtonIcon]=\"_isSubGroup ? 'delete' : 'library_add'\"\n    (tertiaryButtonClicked)=\"_isSubGroup ? deleteGroup(id) : addGroup()\"\n    [disableButtons]=\"locked\"\n    [showPrimarySpinner]=\"false\"\n    [showSecondarySpinner]=\"false\"\n    [marginTop]=\"false\"\n    [marginBottom]=\"_isSubGroup\" />\n</div>\n", styles: [".condition-group{max-width:1200px}\n"], dependencies: [{ kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i1.ButtonGroupComponent, selector: "ui-core-button-group", inputs: ["disableButtons", "primaryButtonText", "primaryButtonDisabledText", "primaryButtonIcon", "primaryButtonIconPosition", "showPrimarySpinner", "primaryButtonUrl", "primaryButtonUrlParams", "primaryButtonUsesExternalUrlNewTab", "secondaryButtonText", "secondaryButtonIcon", "secondaryButtonIconPosition", "showSecondarySpinner", "secondaryButtonTheme", "secondaryButtonUrl", "secondaryButtonUrlParams", "secondaryButtonUsesExternalUrlNewTab", "tertiaryButtonText", "tertiaryButtonIcon", "tertiaryButtonIconPosition", "showTertiarySpinner", "tertiaryButtonTheme", "tertiaryButtonUrl", "tertiaryButtonUrlParams", "tertiaryButtonUsesExternalUrlNewTab", "isFormValid", "withinFormRenderer", "errorMessages", "e2e", "marginBottom", "marginTop", "stacked"], outputs: ["primaryButtonClicked", "secondaryButtonClicked", "tertiaryButtonClicked"] }, { kind: "component", type: TargetConditionComponent, selector: "ui-management-target-condition", inputs: ["condition", "groupId", "subjectDropdownOptions", "targetingOptions", "locked"], outputs: ["groupConditionDeleted", "groupConditionUpdated"] }, { kind: "component", type: TargetingComponent, selector: "ui-management-targeting", inputs: ["targetingOptions", "conditionGroup", "locked", "_isSubGroup", "_subjectDropdownOptions"], outputs: ["conditionGroupChange", "groupDeleted", "groupConditionDeleted", "groupConditionUpdated"] }, { kind: "component", type: TargetOperatorComponent, selector: "ui-management-target-operator", inputs: ["disabled", "locked", "andLabel", "orLabel", "value"], outputs: ["valueChange"] }, { kind: "component", type: TargetRuleComponent, selector: "ui-management-target-rule", inputs: ["isFirst", "isSubGroup", "operator"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TargetingComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-management-targeting', template: "<div class=\"condition-group w-100 mt-3\">\n  <ng-container *ngIf=\"conditionGroup\">\n    <ui-management-target-operator *ngIf=\"conditionGroup.conditions?.length > 0\"\n      #groupOperator\n      [disabled]=\"conditionGroup.conditions.length <= 1\"\n      [andLabel]=\"text.operatorAndLabel\"\n      [orLabel]=\"text.operatorOrLabel\"\n      class=\"d-flex mt-half\"\n      [value]=\"conditionGroup.groupOperator\"\n      [locked]=\"locked\"\n      (valueChange)=\"updateGroupOperator($event)\" />\n    <div *ngFor=\"let condition of conditionGroup.conditions; let first = first; let last = last\" class=\"conditions d-flex w-100\">\n      <ui-management-target-rule \n        [operator]=\"conditionGroup.conditions.length > 1 && conditionGroup.groupOperator\" \n        [isFirst]=\"first\" \n        [isSubGroup]=\"condition.conditions\">\n      </ui-management-target-rule>\n      <ui-management-target-condition *ngIf=\"!condition.conditions\"\n        [condition]=\"condition\"\n        [subjectDropdownOptions]=\"_subjectDropdownOptions\"\n        [targetingOptions]=\"targetingOptions\"\n        [groupId]=\"id\"\n        [locked]=\"locked\"\n        class=\"container ml-0 px-0 px-lg-2 mb-half\"\n        [class.pt-2]=\"first\"\n        [class.pb-2]=\"last\"\n        [class.mb-1]=\"last\"\n        (groupConditionDeleted)=\"deleteGroupCondition($event)\"\n        (groupConditionUpdated)=\"updateGroupCondition($event)\">\n      </ui-management-target-condition>\n      <ui-management-targeting *ngIf=\"condition.conditions\"\n        #targetSubgroup\n        [conditionGroup]=\"condition\"\n        [_isSubGroup]=\"true\"\n        [_subjectDropdownOptions]=\"_subjectDropdownOptions\"\n        [targetingOptions]=\"targetingOptions\"\n        [locked]=\"locked\"\n        class=\"d-flex w-100\"\n        (groupDeleted)=\"deleteGroup($event)\"\n        (groupConditionDeleted)=\"deleteGroupCondition($event)\"\n        (groupConditionUpdated)=\"updateGroupCondition($event)\"\n        (conditionGroupChange)=\"conditionGroupChange.emit(conditionGroup)\" />\n    </div>\n  </ng-container>\n  <ui-core-button-group\n    [primaryButtonText]=\"conditionGroup ? text.addConditionButtonLabel : null\"\n    (primaryButtonClicked)=\"addCondition(id)\"\n    [secondaryButtonText]=\"!conditionGroup ? text.addConditionButtonLabel : null\"\n    (secondaryButtonClicked)=\"createConditionGroup()\"\n    [tertiaryButtonText]=\"!conditionGroup ? null : _isSubGroup ? text.deleteGroupButtonLabel : text.addGroupButtonLabel\"\n    [tertiaryButtonIcon]=\"_isSubGroup ? 'delete' : 'library_add'\"\n    (tertiaryButtonClicked)=\"_isSubGroup ? deleteGroup(id) : addGroup()\"\n    [disableButtons]=\"locked\"\n    [showPrimarySpinner]=\"false\"\n    [showSecondarySpinner]=\"false\"\n    [marginTop]=\"false\"\n    [marginBottom]=\"_isSubGroup\" />\n</div>\n", styles: [".condition-group{max-width:1200px}\n"] }]
        }], ctorParameters: () => [{ type: i1.TextService }, { type: i0.ChangeDetectorRef }], propDecorators: { groupOperator: [{
                type: ViewChild,
                args: ['groupOperator', { static: false }]
            }], targetConditions: [{
                type: ViewChildren,
                args: [TargetConditionComponent]
            }], targetSubgroups: [{
                type: ViewChildren,
                args: ['targetSubgroup']
            }], targetingOptions: [{
                type: Input
            }], conditionGroup: [{
                type: Input
            }], locked: [{
                type: Input
            }], conditionGroupChange: [{
                type: Output
            }], _isSubGroup: [{
                type: Input
            }], _subjectDropdownOptions: [{
                type: Input
            }], groupDeleted: [{
                type: Output
            }], groupConditionDeleted: [{
                type: Output
            }], groupConditionUpdated: [{
                type: Output
            }] } });

class TargetGroupData {
}

class TargetOption {
}

class SidePanelComponent extends BaseTextComponent {
    constructor(textService) {
        super(textService, 'ui-management-side-panel');
        /**
         * Required: Title Text
         */
        this.headerTitle = '';
        /**
         * Optional: Show edit button next to title. Will emit an event when clicked.
         */
        this.showHeaderEditButton = false;
        /**
         * Optional: Description text shown below the title. Can be left blank if not needed.
         */
        this.headerDescription = '';
        /**
         * Required: Date last updated
         */
        this.headerLastUpdated = null;
        /**
         * Optional: Array of header action buttons to display.
         */
        this.headerActions = [];
        /**
         * Optional: Array of badges to display in the header.
         */
        this.headerBadges = [];
        /**
         * Optional: Array of footer action buttons to display. Max 2 buttons.
         */
        this.footerActions = [];
        this.editHeaderButtonClick = new EventEmitter();
        this.headerActionsClick = new EventEmitter();
        this.footerActionsClick = new EventEmitter();
    }
    onEditHeaderButtonClick() {
        this.editHeaderButtonClick.emit();
    }
    onHeaderActionsClick(value) {
        this.headerActionsClick.emit(value);
    }
    onFooterActionsClick(value) {
        this.footerActionsClick.emit(value);
    }
    getDefaultText() {
        return {
            editButtonText: 'Edit Title',
            lastUpdatedMessage: 'Last Updated',
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: SidePanelComponent, deps: [{ token: i1.TextService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.17", type: SidePanelComponent, isStandalone: false, selector: "ui-management-side-panel", inputs: { headerTitle: "headerTitle", showHeaderEditButton: "showHeaderEditButton", headerDescription: "headerDescription", headerLastUpdated: "headerLastUpdated", headerActions: "headerActions", headerBadges: "headerBadges", footerActions: "footerActions" }, outputs: { editHeaderButtonClick: "editHeaderButtonClick", headerActionsClick: "headerActionsClick", footerActionsClick: "footerActionsClick" }, usesInheritance: true, ngImport: i0, template: "<div class=\"side-panel-container\">\n    @if (headerTitle || headerDescription || headerLastUpdated) {\n        <div class=\"side-panel-header mt-3 mx-3\">\n            @if (headerTitle) {\n                <div class=\"title\">\n                    <div class=\"text-heading1 font-weight-normal\">\n                        {{ headerTitle }} \n                    </div>\n                    @if (showHeaderEditButton) {\n                        <ui-core-icon-button\n                            [message]=\"text.editButtonText\"\n                            icon=\"edit\"\n                            (click)=\"onEditHeaderButtonClick()\">\n                        </ui-core-icon-button>\n                    }\n                </div>\n            }\n            @if (headerDescription) {\n                <div class=\"description text-color-tertiary\">\n                    {{ headerDescription }}\n                </div>\n            }\n            @if (headerLastUpdated) {\n                <div class=\"last-updated text-color-tertiary text-italic\">\n                    {{text.lastUpdatedMessage}} {{ headerLastUpdated | date:'medium' }}\n                </div>\n            }\n            @if (headerActions.length > 0) {\n                <div class=\"actions\">\n                    @for (action of headerActions; track action) {\n                        <ui-core-button theme=\"tertiary\" [message]=\"action.text\" [icon]=\"action.icon\" [e2e]=\"action.e2e\" (click)=\"onHeaderActionsClick(action.value)\"></ui-core-button>\n                    }\n                </div>\n            }\n            @if (headerBadges.length > 0) {\n                <div class=\"badges\">\n                    @for (badge of headerBadges; track badge) {\n                        <ui-core-badge [message]=\"badge.message\" [theme]=\"badge.theme\"></ui-core-badge>\n                    }\n                </div>\n            }\n        </div>\n    }\n    <div class=\"side-panel-body\">\n        <ng-content></ng-content>\n    </div>\n    @if (footerActions.length > 0) {\n        <div class=\"side-panel-footer mr-3\">\n            <ui-core-button-grid display=\"column\" [items]=\"footerActions\" (itemClicked)=\"onFooterActionsClick($event.value)\"></ui-core-button-grid>\n        </div>\n    }\n</div>\n", styles: [".side-panel-container,.side-panel-header,.title,.actions,.badges{display:flex}.side-panel-container,.side-panel-container .side-panel-header{flex-direction:column;gap:var(--spacing-150)}.side-panel-container .title{align-items:center;gap:var(--spacing-150)}.side-panel-container .actions{gap:var(--spacing-150)}.side-panel-container .badges{gap:var(--spacing-50)}\n"], dependencies: [{ kind: "component", type: i1.BadgeComponent, selector: "ui-core-badge", inputs: ["message", "framed", "theme", "type", "centered", "icon", "iconPosition"] }, { kind: "component", type: i1.ButtonComponent, selector: "ui-core-button", inputs: ["themeGroup", "theme", "message", "icon", "iconPosition", "disabled", "disabledMessage", "showSpinner", "buttonClass", "width", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "ariaLabel", "isFormValid", "e2e", "buttonId"] }, { kind: "component", type: i1.ButtonGridComponent, selector: "ui-core-button-grid", inputs: ["items", "iconAboveMessage", "display", "rowLabel", "emptyLabel"], outputs: ["itemClicked"] }, { kind: "component", type: i1.IconButtonComponent, selector: "ui-core-icon-button", inputs: ["message", "icon", "size", "disabled", "buttonClass", "ariaPressed", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "e2e", "theme", "usesGlassHoverState", "buttonId"] }, { kind: "pipe", type: i3.DatePipe, name: "date" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: SidePanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-management-side-panel', standalone: false, template: "<div class=\"side-panel-container\">\n    @if (headerTitle || headerDescription || headerLastUpdated) {\n        <div class=\"side-panel-header mt-3 mx-3\">\n            @if (headerTitle) {\n                <div class=\"title\">\n                    <div class=\"text-heading1 font-weight-normal\">\n                        {{ headerTitle }} \n                    </div>\n                    @if (showHeaderEditButton) {\n                        <ui-core-icon-button\n                            [message]=\"text.editButtonText\"\n                            icon=\"edit\"\n                            (click)=\"onEditHeaderButtonClick()\">\n                        </ui-core-icon-button>\n                    }\n                </div>\n            }\n            @if (headerDescription) {\n                <div class=\"description text-color-tertiary\">\n                    {{ headerDescription }}\n                </div>\n            }\n            @if (headerLastUpdated) {\n                <div class=\"last-updated text-color-tertiary text-italic\">\n                    {{text.lastUpdatedMessage}} {{ headerLastUpdated | date:'medium' }}\n                </div>\n            }\n            @if (headerActions.length > 0) {\n                <div class=\"actions\">\n                    @for (action of headerActions; track action) {\n                        <ui-core-button theme=\"tertiary\" [message]=\"action.text\" [icon]=\"action.icon\" [e2e]=\"action.e2e\" (click)=\"onHeaderActionsClick(action.value)\"></ui-core-button>\n                    }\n                </div>\n            }\n            @if (headerBadges.length > 0) {\n                <div class=\"badges\">\n                    @for (badge of headerBadges; track badge) {\n                        <ui-core-badge [message]=\"badge.message\" [theme]=\"badge.theme\"></ui-core-badge>\n                    }\n                </div>\n            }\n        </div>\n    }\n    <div class=\"side-panel-body\">\n        <ng-content></ng-content>\n    </div>\n    @if (footerActions.length > 0) {\n        <div class=\"side-panel-footer mr-3\">\n            <ui-core-button-grid display=\"column\" [items]=\"footerActions\" (itemClicked)=\"onFooterActionsClick($event.value)\"></ui-core-button-grid>\n        </div>\n    }\n</div>\n", styles: [".side-panel-container,.side-panel-header,.title,.actions,.badges{display:flex}.side-panel-container,.side-panel-container .side-panel-header{flex-direction:column;gap:var(--spacing-150)}.side-panel-container .title{align-items:center;gap:var(--spacing-150)}.side-panel-container .actions{gap:var(--spacing-150)}.side-panel-container .badges{gap:var(--spacing-50)}\n"] }]
        }], ctorParameters: () => [{ type: i1.TextService }], propDecorators: { headerTitle: [{
                type: Input
            }], showHeaderEditButton: [{
                type: Input
            }], headerDescription: [{
                type: Input
            }], headerLastUpdated: [{
                type: Input
            }], headerActions: [{
                type: Input
            }], headerBadges: [{
                type: Input
            }], footerActions: [{
                type: Input
            }], editHeaderButtonClick: [{
                type: Output
            }], headerActionsClick: [{
                type: Output
            }], footerActionsClick: [{
                type: Output
            }] } });

class SidePanelAction extends ButtonGridItem {
    constructor(value, text, icon, e2e) {
        super(value, text, icon, e2e);
        this.value = value;
        this.text = text;
        this.icon = icon;
        this.e2e = e2e;
    }
}

// ─── Enums ─────────────────────────────────────────────────────────
var StageStatus;
(function (StageStatus) {
    StageStatus["Completed"] = "completed";
    StageStatus["Active"] = "active";
    StageStatus["Locked"] = "locked";
})(StageStatus || (StageStatus = {}));
// ─── Constants ─────────────────────────────────────────────────────
const STATUS_ICON_NAMES = {
    locked: 'lock',
    completed: 'check',
    pending: 'access_time',
    warning: 'warning',
    error: 'dangerous',
    info: 'info'
};
const ICON_STYLES = {
    locked: {
        stage: { background: 'bg-brand', color: 'color-gray-800' },
        step: { background: 'bg-brand', color: 'color-gray-800' },
        notification: { background: 'bg-brand', color: 'color-gray-800' }
    },
    completed: {
        stage: { background: 'bg-success-light', color: 'color-success' },
        step: { background: 'bg-success-light', color: 'color-success' },
        notification: { background: 'bg-success-light', color: 'color-success' }
    },
    pending: {
        stage: { background: 'bg-gray-800', color: 'color-white' },
        step: { background: 'bg-brand', color: 'color-gray-800' },
        notification: { background: 'bg-brand', color: 'color-gray-800' },
    },
    warning: {
        stage: { background: 'bg-warning', color: 'color-white' },
        step: { background: 'bg-warning-light', color: 'color-gray-800' },
        notification: { background: 'bg-brand', color: 'color-warning' },
    },
    error: {
        stage: { background: 'bg-danger', color: 'color-white' },
        step: { background: 'bg-danger-light', color: 'color-danger' },
        notification: { background: 'bg-danger-light', color: 'color-danger' },
    },
    info: {
        stage: { background: 'bg-brand', color: 'color-gray-800' },
        step: { background: 'bg-brand', color: 'color-gray-800' },
        notification: { background: 'bg-brand', color: 'color-info' },
    },
};
// ─── Helpers ───────────────────────────────────────────────────────
function getIconStyle(status, context) {
    return ICON_STYLES[status][context];
}
function getIconName(status) {
    return STATUS_ICON_NAMES[status];
}

class StatusTrackerStepsComponent {
    constructor() {
        /**
         * Required. Steps should be passed in from status tracker parent component. Determines the step data to display.
         **/
        this.steps = [];
        /**
         * Required. Should be passed in from status tracker parent component. Determines the state of each step.
         **/
        this.status = StageStatus.Locked;
        /**
         * Emits when action button/link is clicked. Includes the stage and step clicked.
         **/
        this.actionClicked = new EventEmitter();
        this.stepViewModels = [];
    }
    ngOnChanges() {
        this.stepViewModels = this.buildStepViewModels();
    }
    buildStepViewModels() {
        return this.steps.map((step, index) => ({
            ...step,
            trackId: `${step.title}-${index}`,
            computedIcon: this.computeStepIcon(step),
            notificationIcon: this.computeNotificationIcon(step),
            isActive: this.status !== StageStatus.Locked && step.status !== 'locked' && step.status !== 'completed',
        }));
    }
    computeStepIcon(step) {
        const status = (this.status === StageStatus.Locked || step.status === 'locked')
            ? 'locked'
            : step.status;
        if (!status) {
            return step.icon ? this.buildIconAttributes('pending', 'step', step.icon) : null;
        }
        const overrideIcon = (status === 'completed' || status === 'locked') ? undefined : step.icon;
        return this.buildIconAttributes(status, 'step', overrideIcon);
    }
    buildIconAttributes(status, context, overrideIcon) {
        const style = getIconStyle(status, context);
        return {
            icon: overrideIcon ?? getIconName(status),
            ariaLabel: `${status.charAt(0).toUpperCase() + status.slice(1)} Icon`,
            backgroundClass: style.background,
            colorClass: style.color,
        };
    }
    computeNotificationIcon(step) {
        const status = (step.status ?? 'info');
        return {
            icon: getIconName(status),
            color: getIconStyle(status, 'notification')?.color
        };
    }
    actionClick(step) {
        this.actionClicked.emit(step);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: StatusTrackerStepsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.17", type: StatusTrackerStepsComponent, isStandalone: false, selector: "ui-management-status-tracker-steps", inputs: { steps: "steps", status: "status" }, outputs: { actionClicked: "actionClicked" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"status-tracker-steps-card bg-white\" [class]=\"status\">\n    @for (step of stepViewModels; track step.trackId) {\n        <div class=\"status-tracker-steps-step\">\n            <div class=\"status-tracker-steps-step-main\">\n\n                @if(step.computedIcon) {\n                    <div class=\"status-tracker-steps-step-main-tile\" [class]=\"step.status ?? ''\">\n                        <ui-core-icon-shape\n                            [icon]=\"step.computedIcon.icon\"\n                            [ariaLabel]=\"step.computedIcon.ariaLabel\"\n                            [backgroundClass]=\"step.computedIcon.backgroundClass\"\n                            [colorClass]=\"step.computedIcon.colorClass\"\n                            shape=\"rounded\"\n                            size=\"sm\"\n                        >\n                        </ui-core-icon-shape>\n                    </div>\n                }\n\n                <div class=\"status-tracker-steps-step-main-body\">\n                    <span class=\"text-bold\">{{ step.title }}</span>\n                    @if (step.statusMessage) {\n                        <p class=\"text-second mb-0\">{{ step.statusMessage }}</p>\n                    }\n\n                    @if (step.isActive && step.notificationMessage) {               \n                        <div class=\"d-flex status-tracker-steps-notification\">\n                            <ui-core-icon \n                                [icon]=\"step.notificationIcon.icon\"\n                                size=\"sm\"\n                                [colorClass]=\"step.notificationIcon.color\"\n                                collapseHeight=\"true\">\n                            </ui-core-icon>\n                            <p class=\"text-caption mb-0\">{{ step.notificationMessage }}</p>\n                        </div>\n                    }\n                </div>\n            </div>\n            @if (step.isActive && step.action) {\n                @if (step.action.url) {\n                    <ui-core-link\n                        [link]=\"step.action.url\"\n                        [message]=\"step.action.message\"\n                        [openLinkInNewTab]=\"step.action.target === '_blank'\"\n                        theme=\"secondary\"\n                        themeGroup=\"neutral\"\n                        width=\"full\"\n                        class=\"mt-1\"\n                        (click)=\"actionClick(step)\"\n                    >\n                    </ui-core-link>\n                }\n                @else {\n                    <ui-core-button \n                        [message]=\"step.action.message\"\n                        theme=\"secondary\"\n                        themeGroup=\"neutral\"\n                        width=\"full\"\n                        class=\"mt-1\"\n                        (click)=\"actionClick(step)\"\n                    >\n                    </ui-core-button>\n                }\n            }\n        </div>\n    }\n</div>", styles: [".status-tracker{position:relative}.status-tracker details[open] .status-tracker-summary{border-bottom-right-radius:0;border-bottom-left-radius:0}.status-tracker details[open] .status-tracker-expand-icon{transform:rotate(180deg);transition:transform .18s}.status-tracker-scroll-container{overflow-x:auto;padding-bottom:16px;scrollbar-width:thin;scrollbar-color:var(--color-gray-100) transparent}.status-tracker-line{width:100%;min-width:20px;height:1px;background:var(--color-gray-200)}.status-tracker-line.completed{background:var(--color-success)}.status-tracker-summary{list-style:none;flex:none;gap:8px;padding:12px;margin-bottom:1px;white-space:nowrap;background:var(--color-default);border:1px solid transparent;border-radius:12px;font-family:var(--font-family-base)}.locked .status-tracker-summary{border:1px solid var(--color-gray-200)}.active .status-tracker-summary,.locked[open] .status-tracker-summary{border:0;box-shadow:var(--elevation-2)}.status-tracker-steps-card{border-radius:0 12px 12px;box-shadow:var(--elevation-3);padding:16px;width:350px;position:absolute;z-index:100;max-height:min(420px,100vh - 160px);overflow-y:auto}.status-tracker-steps-card.is-fixed{position:fixed;top:var(--status-tracker-card-top);left:var(--status-tracker-card-left)}:host(.is-last) .status-tracker-steps-card{right:0}.status-tracker-steps-step{display:flex;flex-direction:column;gap:6px;padding:16px 0;border-bottom:1px solid var(--color-gray-100)}.status-tracker-steps-step:last-child{border-bottom:0}.status-tracker-steps-step-main{display:flex;gap:16px;align-items:flex-start}.locked .status-tracker-steps-step-main{color:var(--color-gray-700)}.status-tracker-steps-notification{display:flex;align-items:center;gap:4px;margin-top:8px}\n"], dependencies: [{ kind: "component", type: i1.ButtonComponent, selector: "ui-core-button", inputs: ["themeGroup", "theme", "message", "icon", "iconPosition", "disabled", "disabledMessage", "showSpinner", "buttonClass", "width", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "ariaLabel", "isFormValid", "e2e", "buttonId"] }, { kind: "component", type: i1.IconComponent, selector: "ui-core-icon", inputs: ["icon", "size", "colorClass", "allowEmojis", "ariaLabel", "alignWithText", "collapseHeight", "scaleWithFonts", "animationPath", "animationData", "animationFreeze", "animationFreezeFrame", "animationLoop", "animationLoopTotal"], outputs: ["animationCompleted"] }, { kind: "component", type: i1.IconShapeComponent, selector: "ui-core-icon-shape[icon]", inputs: ["icon", "backgroundClass", "borderColor", "colorClass", "size", "shape", "ariaLabel"] }, { kind: "component", type: i1.LinkComponent, selector: "ui-core-link", inputs: ["themeGroup", "theme", "size", "link", "openLinkInNewTab", "message", "icon", "iconPosition", "disabled", "linkClass", "width", "ariaLabel", "e2e", "urlParams"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: StatusTrackerStepsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-management-status-tracker-steps', standalone: false, template: "<div class=\"status-tracker-steps-card bg-white\" [class]=\"status\">\n    @for (step of stepViewModels; track step.trackId) {\n        <div class=\"status-tracker-steps-step\">\n            <div class=\"status-tracker-steps-step-main\">\n\n                @if(step.computedIcon) {\n                    <div class=\"status-tracker-steps-step-main-tile\" [class]=\"step.status ?? ''\">\n                        <ui-core-icon-shape\n                            [icon]=\"step.computedIcon.icon\"\n                            [ariaLabel]=\"step.computedIcon.ariaLabel\"\n                            [backgroundClass]=\"step.computedIcon.backgroundClass\"\n                            [colorClass]=\"step.computedIcon.colorClass\"\n                            shape=\"rounded\"\n                            size=\"sm\"\n                        >\n                        </ui-core-icon-shape>\n                    </div>\n                }\n\n                <div class=\"status-tracker-steps-step-main-body\">\n                    <span class=\"text-bold\">{{ step.title }}</span>\n                    @if (step.statusMessage) {\n                        <p class=\"text-second mb-0\">{{ step.statusMessage }}</p>\n                    }\n\n                    @if (step.isActive && step.notificationMessage) {               \n                        <div class=\"d-flex status-tracker-steps-notification\">\n                            <ui-core-icon \n                                [icon]=\"step.notificationIcon.icon\"\n                                size=\"sm\"\n                                [colorClass]=\"step.notificationIcon.color\"\n                                collapseHeight=\"true\">\n                            </ui-core-icon>\n                            <p class=\"text-caption mb-0\">{{ step.notificationMessage }}</p>\n                        </div>\n                    }\n                </div>\n            </div>\n            @if (step.isActive && step.action) {\n                @if (step.action.url) {\n                    <ui-core-link\n                        [link]=\"step.action.url\"\n                        [message]=\"step.action.message\"\n                        [openLinkInNewTab]=\"step.action.target === '_blank'\"\n                        theme=\"secondary\"\n                        themeGroup=\"neutral\"\n                        width=\"full\"\n                        class=\"mt-1\"\n                        (click)=\"actionClick(step)\"\n                    >\n                    </ui-core-link>\n                }\n                @else {\n                    <ui-core-button \n                        [message]=\"step.action.message\"\n                        theme=\"secondary\"\n                        themeGroup=\"neutral\"\n                        width=\"full\"\n                        class=\"mt-1\"\n                        (click)=\"actionClick(step)\"\n                    >\n                    </ui-core-button>\n                }\n            }\n        </div>\n    }\n</div>", styles: [".status-tracker{position:relative}.status-tracker details[open] .status-tracker-summary{border-bottom-right-radius:0;border-bottom-left-radius:0}.status-tracker details[open] .status-tracker-expand-icon{transform:rotate(180deg);transition:transform .18s}.status-tracker-scroll-container{overflow-x:auto;padding-bottom:16px;scrollbar-width:thin;scrollbar-color:var(--color-gray-100) transparent}.status-tracker-line{width:100%;min-width:20px;height:1px;background:var(--color-gray-200)}.status-tracker-line.completed{background:var(--color-success)}.status-tracker-summary{list-style:none;flex:none;gap:8px;padding:12px;margin-bottom:1px;white-space:nowrap;background:var(--color-default);border:1px solid transparent;border-radius:12px;font-family:var(--font-family-base)}.locked .status-tracker-summary{border:1px solid var(--color-gray-200)}.active .status-tracker-summary,.locked[open] .status-tracker-summary{border:0;box-shadow:var(--elevation-2)}.status-tracker-steps-card{border-radius:0 12px 12px;box-shadow:var(--elevation-3);padding:16px;width:350px;position:absolute;z-index:100;max-height:min(420px,100vh - 160px);overflow-y:auto}.status-tracker-steps-card.is-fixed{position:fixed;top:var(--status-tracker-card-top);left:var(--status-tracker-card-left)}:host(.is-last) .status-tracker-steps-card{right:0}.status-tracker-steps-step{display:flex;flex-direction:column;gap:6px;padding:16px 0;border-bottom:1px solid var(--color-gray-100)}.status-tracker-steps-step:last-child{border-bottom:0}.status-tracker-steps-step-main{display:flex;gap:16px;align-items:flex-start}.locked .status-tracker-steps-step-main{color:var(--color-gray-700)}.status-tracker-steps-notification{display:flex;align-items:center;gap:4px;margin-top:8px}\n"] }]
        }], propDecorators: { steps: [{
                type: Input
            }], status: [{
                type: Input
            }], actionClicked: [{
                type: Output
            }] } });

class StatusTrackerComponent {
    constructor(el) {
        this.el = el;
        /**
        * Required. Stages to render in the tracker. Maximum of 6 — extras are excluded.
        **/
        this.stages = [];
        /**
        * Required. This determines which stage will be active, and therefore which will be completed and locked.
        **/
        this.activeStageIndex = 0;
        /**
        * Emits when action button/link is clicked. Includes the stage and step clicked.
        **/
        this.actionClicked = new EventEmitter();
        this.stageViewModels = [];
        // ── Global listener management ────────────────────────────────────────────
        // When a card is fixed-positioned, page scroll or window resize would cause
        // it to drift away from its anchor. The simplest robust solution is to close
        // all open details when either occurs, consistent with how the internal
        // scroll container already behaves.
        this.boundCloseAll = () => this.closeAllDetails();
        this.globalListenersActive = false;
    }
    // ── Lifecycle ─────────────────────────────────────────────────────────────
    ngOnChanges() {
        this.stageViewModels = this.buildViewModels();
    }
    ngOnDestroy() {
        this.removeGlobalListeners();
    }
    // ── View model construction ───────────────────────────────────────────────
    buildViewModels() {
        // Enforcing maximum of 6 stages
        this.stages = this.stages.slice(0, 6);
        return this.stages.map((stage, i) => {
            const status = this.computeStatus(i);
            const icon = this.computeIcon(stage, status);
            return {
                ...stage,
                trackId: `${stage.title}-${i}`,
                status,
                icon,
                stageIcon: {
                    icon: getIconName(icon),
                    ariaLabel: `Status: ${status}`,
                    backgroundClass: getIconStyle(icon, 'stage').background,
                    colorClass: getIconStyle(icon, 'stage').color
                },
                hasDetails: status !== StageStatus.Completed && !!stage.steps?.length,
                isLast: i + 1 === this.stages.length,
            };
        });
    }
    computeStatus(index) {
        if (index < this.activeStageIndex) {
            return StageStatus.Completed;
        }
        if (index === this.activeStageIndex) {
            return StageStatus.Active;
        }
        return StageStatus.Locked;
    }
    computeIcon(stage, status) {
        if (status === StageStatus.Locked) {
            return StageStatus.Locked;
        }
        if (status === StageStatus.Completed) {
            return StageStatus.Completed;
        }
        const stepStatuses = stage.steps?.map(step => step.status);
        if (stepStatuses?.includes('error')) {
            return 'error';
        }
        if (stepStatuses?.includes('warning')) {
            return 'warning';
        }
        return 'pending';
    }
    addGlobalListeners() {
        if (this.globalListenersActive) {
            return;
        }
        window.addEventListener('resize', this.boundCloseAll, { passive: true });
        this.globalListenersActive = true;
    }
    removeGlobalListeners() {
        window.removeEventListener('resize', this.boundCloseAll);
        this.globalListenersActive = false;
    }
    closeAllDetails() {
        this.el.nativeElement.querySelectorAll('details[open]').forEach(d => {
            d.removeAttribute('open');
        });
        this.removeGlobalListeners();
    }
    // ── Stage summary click ───────────────────────────────────────────────────
    stageSummaryClick(event) {
        const summary = event.currentTarget;
        const details = summary.closest('details');
        if (!details) {
            return;
        }
        this.el.nativeElement
            .querySelectorAll('details[open]')
            .forEach(openDetails => {
            if (openDetails !== details) {
                openDetails.removeAttribute('open');
            }
        });
        const card = details.querySelector('.status-tracker-steps-card');
        const scroller = this.el.nativeElement.querySelector('.status-tracker-scroll-container');
        if (!card || !scroller) {
            return;
        }
        const hasHorizontalOverflow = scroller.scrollWidth > scroller.clientWidth;
        if (!hasHorizontalOverflow) {
            card.classList.remove('is-fixed');
            card.style.removeProperty('--status-tracker-card-top');
            card.style.removeProperty('--status-tracker-card-left');
            return;
        }
        const rect = summary.getBoundingClientRect();
        const cardWidth = 350;
        const cardHeight = 420;
        const gap = 1;
        const viewportPadding = 16;
        card.classList.add('is-fixed');
        const spaceBelow = window.innerHeight - rect.bottom - gap - viewportPadding;
        const spaceAbove = rect.top - gap - viewportPadding;
        const wouldOverflowBottom = spaceBelow < cardHeight && spaceAbove > spaceBelow;
        card.style.setProperty('--status-tracker-card-top', wouldOverflowBottom
            ? `${rect.top - gap - cardHeight}px`
            : `${rect.bottom + gap}px`);
        const wouldOverflowRight = rect.left + cardWidth > window.innerWidth - viewportPadding;
        if (wouldOverflowRight) {
            card.style.setProperty('--status-tracker-card-left', `${rect.right - cardWidth}px`);
        }
        else {
            const leftPos = Math.max(viewportPadding, rect.left);
            card.style.setProperty('--status-tracker-card-left', `${leftPos}px`);
        }
        this.addGlobalListeners();
    }
    // ── Scroll / action handlers ──────────────────────────────────────────────
    statusTrackerScroll() {
        this.closeAllDetails();
    }
    stepActionClick(step, stage) {
        this.actionClicked.emit({ step, stage });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: StatusTrackerComponent, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.17", type: StatusTrackerComponent, isStandalone: false, selector: "ui-management-status-tracker", inputs: { stages: "stages", activeStageIndex: "activeStageIndex" }, outputs: { actionClicked: "actionClicked" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"status-tracker\">\n    <div class=\"status-tracker-scroll-container d-flex align-items-center\" (scroll)=\"statusTrackerScroll()\">       \n        @for (stage of stageViewModels; track stage.trackId; let i = $index) {\n\n            <ng-template #stageContent let-stage=\"stage\">\n                <span class=\"status-tracker-status-icon d-flex align-items-center justify-content-center\"\n                    [class]=\"stage.icon\">\n                    <ui-core-icon-shape\n                        [icon]=\"stage.stageIcon.icon\"\n                        [ariaLabel]=\"stage.stageIcon.ariaLabel\"\n                        [backgroundClass]=\"stage.stageIcon.backgroundClass\"\n                        [colorClass]=\"stage.stageIcon.colorClass\"\n                        shape=\"circle\"\n                        size=\"sm\">\n                    </ui-core-icon-shape>\n                </span>\n                <p class=\"mb-0 text-compact\" [class]=\"stage.status === 'active' ? 'text-bold' : ''\">\n                    {{ stage.title }}\n                </p>\n            </ng-template>\n\n            @if (stage.hasDetails) {\n                <details class=\"status-tracker-stage\" [class]=\"stage.status\">\n                    <summary class=\"status-tracker-summary d-flex align-items-center\" (click)=\"stageSummaryClick($event)\">\n                        \n                        <ng-container *ngTemplateOutlet=\"stageContent; context: { stage: stage }\"></ng-container>\n                        \n                        <ui-core-icon \n                            icon=\"expand_more\"\n                            size=\"md\"\n                            collapseHeight=\"true\"\n                            class=\"status-tracker-expand-icon\"\n                        >\n                        </ui-core-icon>\n                    </summary>\n                    <div>\n                        <ui-management-status-tracker-steps \n                            [steps]=\"stage.steps\"\n                            [status]=\"stage.status\"\n                            [class]=\"stage.isLast ? 'is-last' : ''\"\n                            (actionClicked)=\"stepActionClick($event, stage)\"\n                        >\n                        </ui-management-status-tracker-steps>\n                    </div>\n                </details>\n            }\n            @else {\n                <div class=\"status-tracker-stage\" [class]=\"stage.status\">\n                    <div class=\"status-tracker-summary d-flex align-items-center\">\n                        <ng-container *ngTemplateOutlet=\"stageContent; context: { stage: stage }\"></ng-container>\n                    </div>\n                </div>\n            }\n\n            @if (i + 1 < stages.length) {\n                <span class=\"status-tracker-line\" [class]=\"stage.status\"></span>\n            }\n        }\n    </div>\n</div>", styles: [".status-tracker{position:relative}.status-tracker details[open] .status-tracker-summary{border-bottom-right-radius:0;border-bottom-left-radius:0}.status-tracker details[open] .status-tracker-expand-icon{transform:rotate(180deg);transition:transform .18s}.status-tracker-scroll-container{overflow-x:auto;padding-bottom:16px;scrollbar-width:thin;scrollbar-color:var(--color-gray-100) transparent}.status-tracker-line{width:100%;min-width:20px;height:1px;background:var(--color-gray-200)}.status-tracker-line.completed{background:var(--color-success)}.status-tracker-summary{list-style:none;flex:none;gap:8px;padding:12px;margin-bottom:1px;white-space:nowrap;background:var(--color-default);border:1px solid transparent;border-radius:12px;font-family:var(--font-family-base)}.locked .status-tracker-summary{border:1px solid var(--color-gray-200)}.active .status-tracker-summary,.locked[open] .status-tracker-summary{border:0;box-shadow:var(--elevation-2)}.status-tracker-steps-card{border-radius:0 12px 12px;box-shadow:var(--elevation-3);padding:16px;width:350px;position:absolute;z-index:100;max-height:min(420px,100vh - 160px);overflow-y:auto}.status-tracker-steps-card.is-fixed{position:fixed;top:var(--status-tracker-card-top);left:var(--status-tracker-card-left)}:host(.is-last) .status-tracker-steps-card{right:0}.status-tracker-steps-step{display:flex;flex-direction:column;gap:6px;padding:16px 0;border-bottom:1px solid var(--color-gray-100)}.status-tracker-steps-step:last-child{border-bottom:0}.status-tracker-steps-step-main{display:flex;gap:16px;align-items:flex-start}.locked .status-tracker-steps-step-main{color:var(--color-gray-700)}.status-tracker-steps-notification{display:flex;align-items:center;gap:4px;margin-top:8px}\n"], dependencies: [{ kind: "directive", type: i3.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: i1.IconComponent, selector: "ui-core-icon", inputs: ["icon", "size", "colorClass", "allowEmojis", "ariaLabel", "alignWithText", "collapseHeight", "scaleWithFonts", "animationPath", "animationData", "animationFreeze", "animationFreezeFrame", "animationLoop", "animationLoopTotal"], outputs: ["animationCompleted"] }, { kind: "component", type: i1.IconShapeComponent, selector: "ui-core-icon-shape[icon]", inputs: ["icon", "backgroundClass", "borderColor", "colorClass", "size", "shape", "ariaLabel"] }, { kind: "component", type: StatusTrackerStepsComponent, selector: "ui-management-status-tracker-steps", inputs: ["steps", "status"], outputs: ["actionClicked"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: StatusTrackerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-management-status-tracker', standalone: false, template: "<div class=\"status-tracker\">\n    <div class=\"status-tracker-scroll-container d-flex align-items-center\" (scroll)=\"statusTrackerScroll()\">       \n        @for (stage of stageViewModels; track stage.trackId; let i = $index) {\n\n            <ng-template #stageContent let-stage=\"stage\">\n                <span class=\"status-tracker-status-icon d-flex align-items-center justify-content-center\"\n                    [class]=\"stage.icon\">\n                    <ui-core-icon-shape\n                        [icon]=\"stage.stageIcon.icon\"\n                        [ariaLabel]=\"stage.stageIcon.ariaLabel\"\n                        [backgroundClass]=\"stage.stageIcon.backgroundClass\"\n                        [colorClass]=\"stage.stageIcon.colorClass\"\n                        shape=\"circle\"\n                        size=\"sm\">\n                    </ui-core-icon-shape>\n                </span>\n                <p class=\"mb-0 text-compact\" [class]=\"stage.status === 'active' ? 'text-bold' : ''\">\n                    {{ stage.title }}\n                </p>\n            </ng-template>\n\n            @if (stage.hasDetails) {\n                <details class=\"status-tracker-stage\" [class]=\"stage.status\">\n                    <summary class=\"status-tracker-summary d-flex align-items-center\" (click)=\"stageSummaryClick($event)\">\n                        \n                        <ng-container *ngTemplateOutlet=\"stageContent; context: { stage: stage }\"></ng-container>\n                        \n                        <ui-core-icon \n                            icon=\"expand_more\"\n                            size=\"md\"\n                            collapseHeight=\"true\"\n                            class=\"status-tracker-expand-icon\"\n                        >\n                        </ui-core-icon>\n                    </summary>\n                    <div>\n                        <ui-management-status-tracker-steps \n                            [steps]=\"stage.steps\"\n                            [status]=\"stage.status\"\n                            [class]=\"stage.isLast ? 'is-last' : ''\"\n                            (actionClicked)=\"stepActionClick($event, stage)\"\n                        >\n                        </ui-management-status-tracker-steps>\n                    </div>\n                </details>\n            }\n            @else {\n                <div class=\"status-tracker-stage\" [class]=\"stage.status\">\n                    <div class=\"status-tracker-summary d-flex align-items-center\">\n                        <ng-container *ngTemplateOutlet=\"stageContent; context: { stage: stage }\"></ng-container>\n                    </div>\n                </div>\n            }\n\n            @if (i + 1 < stages.length) {\n                <span class=\"status-tracker-line\" [class]=\"stage.status\"></span>\n            }\n        }\n    </div>\n</div>", styles: [".status-tracker{position:relative}.status-tracker details[open] .status-tracker-summary{border-bottom-right-radius:0;border-bottom-left-radius:0}.status-tracker details[open] .status-tracker-expand-icon{transform:rotate(180deg);transition:transform .18s}.status-tracker-scroll-container{overflow-x:auto;padding-bottom:16px;scrollbar-width:thin;scrollbar-color:var(--color-gray-100) transparent}.status-tracker-line{width:100%;min-width:20px;height:1px;background:var(--color-gray-200)}.status-tracker-line.completed{background:var(--color-success)}.status-tracker-summary{list-style:none;flex:none;gap:8px;padding:12px;margin-bottom:1px;white-space:nowrap;background:var(--color-default);border:1px solid transparent;border-radius:12px;font-family:var(--font-family-base)}.locked .status-tracker-summary{border:1px solid var(--color-gray-200)}.active .status-tracker-summary,.locked[open] .status-tracker-summary{border:0;box-shadow:var(--elevation-2)}.status-tracker-steps-card{border-radius:0 12px 12px;box-shadow:var(--elevation-3);padding:16px;width:350px;position:absolute;z-index:100;max-height:min(420px,100vh - 160px);overflow-y:auto}.status-tracker-steps-card.is-fixed{position:fixed;top:var(--status-tracker-card-top);left:var(--status-tracker-card-left)}:host(.is-last) .status-tracker-steps-card{right:0}.status-tracker-steps-step{display:flex;flex-direction:column;gap:6px;padding:16px 0;border-bottom:1px solid var(--color-gray-100)}.status-tracker-steps-step:last-child{border-bottom:0}.status-tracker-steps-step-main{display:flex;gap:16px;align-items:flex-start}.locked .status-tracker-steps-step-main{color:var(--color-gray-700)}.status-tracker-steps-notification{display:flex;align-items:center;gap:4px;margin-top:8px}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { stages: [{
                type: Input
            }], activeStageIndex: [{
                type: Input
            }], actionClicked: [{
                type: Output
            }] } });

class TreeViewComponent {
    constructor() {
        /**
         * Maximum number of levels permitted in the tree. Root items are level 1.
         */
        this.levelLimit = 3;
        /**
         * Accessible name for the tree, announced by screen readers. Set this to
         * something meaningful for the context the tree is used in.
         */
        this.ariaLabel = 'Tree view';
        /**
         * Emits whenever the tree structure changes.
         */
        this.listItemsChange = new EventEmitter();
        this.branches = [];
        this.dragging = false;
        this.dropActionTodo = null;
        /**
         * The branch currently being dragged. Rendered as a copy in the cross-group
         * drop slot so the destination previews the actual row, matching CDK's
         * native placeholder within a group.
         */
        this.draggedBranch = null;
        this.addAction = new InlineAction('Add Child', 'add', true);
        this.editAction = new InlineAction('Edit', 'edit', true);
        this.deleteAction = new InlineAction('Delete', 'delete', true);
        this.actions = [
            this.addAction,
            this.editAction,
            this.deleteAction,
        ];
        this.actionsWithoutAdd = [
            this.editAction,
            this.deleteAction,
        ];
        this.sourceListId = null;
        this.dropWasHandled = false;
        this.canEnter = (_drag, dropList) => {
            return (this.sourceListId === null ||
                dropList.id === this.sourceListId);
        };
    }
    /**
     * Required. The tree items to display.
     */
    set listItems(value) {
        this.branches = value ?? [];
        this.setLevels(this.branches);
    }
    startDrag(listId, branch) {
        this.dragging = true;
        this.dropWasHandled = false;
        this.sourceListId = listId;
        this.draggedBranch = branch;
        this.dropActionTodo = null;
    }
    dragMoved(moved) {
        if (!this.dragging) {
            return;
        }
        const target = this.findBranchAtPoint(moved.pointerPosition.x, moved.pointerPosition.y, moved.source.data.id);
        if (!target) {
            this.dropActionTodo = null;
            return;
        }
        const targetId = target.branchElement.getAttribute('data-id');
        const targetListId = target.listElement.getAttribute('data-list-id');
        if (!targetId || !targetListId || targetId === moved.source.data.id) {
            return;
        }
        /*
         * Reordering within the source list is handled natively by CDK, which
         * renders its own placeholder slot. Only surface the manual slot when
         * the pointer is over a different list.
         */
        if (targetListId === this.sourceListId) {
            this.dropActionTodo = null;
            return;
        }
        const bounds = target.rowElement.getBoundingClientRect();
        const alreadyOpenForTarget = this.dropActionTodo?.targetId === targetId &&
            this.dropActionTodo?.targetListId === targetListId;
        /*
         * Only open a cross-group slot when the pointer is genuinely over the
         * target row. Reordering to the last position of the source group moves
         * the pointer into the gap below the final row, which belongs to an
         * adjacent branch in a parent list — without this check that gap
         * would be treated as a cross-group drop and pop the branch up a level.
         *
         * Once a slot is already open the pointer sits over the ghost (outside
         * the row), so keep it stable in that case to avoid flicker.
         */
        const withinRow = moved.pointerPosition.y >= bounds.top &&
            moved.pointerPosition.y <= bounds.bottom;
        if (!withinRow && !alreadyOpenForTarget) {
            this.dropActionTodo = null;
            return;
        }
        const action = moved.pointerPosition.y < bounds.top + bounds.height / 2
            ? 'before'
            : 'after';
        /*
         * Skip redundant updates. Re-emitting the same target every frame would
         * thrash layout and make the slot flicker.
         */
        if (alreadyOpenForTarget && this.dropActionTodo?.action === action) {
            return;
        }
        this.dropActionTodo = { targetId, targetListId, action };
    }
    drop(event) {
        this.dropWasHandled = true;
        const sourceListId = this.sourceListId;
        const draggedItem = event.item.data;
        if (!sourceListId) {
            this.finishDrop();
            return;
        }
        const sourceChildren = this.getChildrenForList(sourceListId);
        if (!sourceChildren) {
            this.finishDrop();
            return;
        }
        const sourceIndex = sourceChildren.findIndex(item => item.id === draggedItem.id);
        if (sourceIndex === -1) {
            this.finishDrop();
            return;
        }
        const dropInfo = this.dropActionTodo;
        if (!dropInfo || dropInfo.targetListId === sourceListId) {
            if (sourceIndex !== event.currentIndex) {
                moveItemInArray(sourceChildren, sourceIndex, event.currentIndex);
            }
            this.setLevels(this.branches);
            this.listItemsChange.emit(this.branches);
            this.finishDrop();
            return;
        }
        const targetChildren = this.getChildrenForList(dropInfo.targetListId);
        const targetBranch = this.findBranchById(dropInfo.targetId, this.branches);
        if (!targetChildren || !targetBranch) {
            this.finishDrop();
            return;
        }
        if (!this.canDropBesideTarget(draggedItem, targetBranch)) {
            this.finishDrop();
            return;
        }
        /*
         * Prevent moving a parent into one of its own descendant
         * lists.
         */
        if (dropInfo.targetListId !== 'root' &&
            draggedItem.children &&
            this.containsBranch(draggedItem.children, dropInfo.targetListId)) {
            this.finishDrop();
            return;
        }
        const targetIndex = targetChildren.findIndex(item => item.id === dropInfo.targetId);
        if (targetIndex === -1) {
            this.finishDrop();
            return;
        }
        const [movedItem] = sourceChildren.splice(sourceIndex, 1);
        /*
         * Recalculate after removal in case sourceChildren and
         * targetChildren refer to the same array.
         */
        const updatedTargetIndex = targetChildren.findIndex(item => item.id === dropInfo.targetId);
        if (updatedTargetIndex === -1) {
            sourceChildren.splice(sourceIndex, 0, movedItem);
            this.finishDrop();
            return;
        }
        const insertionIndex = dropInfo.action === 'before' ? updatedTargetIndex : updatedTargetIndex + 1;
        targetChildren.splice(insertionIndex, 0, movedItem);
        this.setLevels(this.branches);
        this.listItemsChange.emit(this.branches);
        this.finishDrop();
    }
    endDrag() {
        this.dragging = false;
        /*
         * cdkDragEnded also fires after a successful drop.
         * Give drop() an opportunity to complete first.
         */
        setTimeout(() => {
            if (!this.dropWasHandled) {
                this.resetDragState();
            }
        });
    }
    expand(branch) {
        if ((branch.level ?? 1) >= this.levelLimit) {
            return;
        }
        branch.isExpanded = !branch.isExpanded;
    }
    setLevels(items, level = 1) {
        for (const item of items) {
            item.level = level;
            if (item.children) {
                this.setLevels(item.children, level + 1);
            }
        }
    }
    canDropBesideTarget(draggedItem, targetBranch) {
        const targetLevel = targetBranch.level ?? 1;
        const draggedChildDepth = this.getChildDepth(draggedItem);
        return (targetLevel + draggedChildDepth <= this.levelLimit);
    }
    /**
     * Returns the number of descendant levels beneath an item.
     *
     * A leaf has child depth 0.
     * A branch with leaf children has child depth 1.
     */
    getChildDepth(item) {
        if (!item.children || item.children.length === 0) {
            return 0;
        }
        return 1 + Math.max(...item.children.map(child => this.getChildDepth(child)));
    }
    findBranchAtPoint(x, y, draggedBranchId) {
        const elements = document.elementsFromPoint(x, y);
        for (const element of elements) {
            if (!(element instanceof HTMLElement)) {
                continue;
            }
            if (element.closest('.cdk-drag-preview') || element.closest('.cdk-drag-placeholder')) {
                continue;
            }
            /*
             * Resolve the branch first, not the row. Once the drop slot is
             * open, the cursor is over the slot (which belongs to the branch,
             * not the row); keying off the branch keeps the resolved target
             * stable instead of falling through to whatever sits behind the
             * slot.
             */
            const branchElement = element.closest('.tree-branch');
            if (!branchElement) {
                continue;
            }
            const targetId = branchElement.getAttribute('data-id');
            if (!targetId || targetId === draggedBranchId) {
                continue;
            }
            /* The branch's own row, never a nested descendant's row. */
            const rowElement = branchElement.querySelector(':scope > .tree-view-list-item-container .tree-branch-row');
            if (!rowElement) {
                continue;
            }
            const listElement = branchElement.closest('.cdk-drop-list');
            if (!listElement) {
                continue;
            }
            return {
                branchElement,
                rowElement,
                listElement,
            };
        }
        return null;
    }
    getChildrenForList(listId) {
        if (listId === 'root') {
            return this.branches;
        }
        const parent = this.findBranchById(listId, this.branches);
        return parent?.children ?? null;
    }
    findBranchById(id, branches) {
        for (const branch of branches) {
            if (branch.id === id) {
                return branch;
            }
            if (!branch.children) {
                continue;
            }
            const found = this.findBranchById(id, branch.children);
            if (found) {
                return found;
            }
        }
        return null;
    }
    containsBranch(branches, targetId) {
        for (const branch of branches) {
            if (branch.id === targetId) {
                return true;
            }
            if (branch.children && this.containsBranch(branch.children, targetId)) {
                return true;
            }
        }
        return false;
    }
    finishDrop() {
        this.resetDragState();
    }
    resetDragState() {
        this.dragging = false;
        this.dropWasHandled = false;
        this.sourceListId = null;
        this.dropActionTodo = null;
        this.draggedBranch = null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TreeViewComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.17", type: TreeViewComponent, isStandalone: false, selector: "ui-management-tree-view", inputs: { listItems: "listItems", levelLimit: "levelLimit", ariaLabel: "ariaLabel" }, outputs: { listItemsChange: "listItemsChange" }, ngImport: i0, template: "<ng-template\n    #tmplChildren\n    let-tmpBranches=\"tmpBranches\"\n    let-isRoot=\"isRoot\"\n    let-listId=\"listId\"\n>\n    <div\n        class=\"tree-branch-list\"\n        [class.tree-branch-children]=\"!isRoot\"\n        [attr.role]=\"isRoot ? 'tree' : 'group'\"\n        [attr.aria-label]=\"isRoot ? ariaLabel : null\"\n        cdkDropList\n        [id]=\"listId\"\n        [cdkDropListData]=\"tmpBranches\"\n        [cdkDropListEnterPredicate]=\"canEnter\"\n        [attr.data-list-id]=\"listId\"\n        (cdkDropListDropped)=\"drop($event)\"\n    >\n        @for (branch of tmpBranches; track branch.id) {\n            <div\n                class=\"tree-branch\"\n                role=\"treeitem\"\n                [attr.data-id]=\"branch.id\"\n                [attr.aria-label]=\"branch.title\"\n                [attr.aria-level]=\"branch.level\"\n                [attr.aria-setsize]=\"tmpBranches.length\"\n                [attr.aria-posinset]=\"$index + 1\"\n                [attr.aria-expanded]=\"branch.children?.length ? !!branch.isExpanded : null\"\n            >\n                @if (dropActionTodo?.targetId === branch.id && dropActionTodo?.action === 'before') {\n                    <div class=\"tree-branch-ghost\" aria-hidden=\"true\">\n                        <ng-container\n                            *ngTemplateOutlet=\"tmplBranch; context: { branch: draggedBranch }\"\n                        >\n                        </ng-container>\n                    </div>\n                }\n\n                <div\n                    class=\"tree-view-list-item-container\"\n                    cdkDrag\n                    [cdkDragData]=\"branch\"\n                    (cdkDragMoved)=\"dragMoved($event)\"\n                    (cdkDragStarted)=\"startDrag(listId, branch)\"\n                    (cdkDragEnded)=\"endDrag()\"\n                >\n                    <ng-container\n                        *ngTemplateOutlet=\"tmplBranch; context: { branch: branch }\"\n                    >\n                    </ng-container>\n                </div>\n\n                @if (branch?.isExpanded && branch?.children && branch.children.length) {\n                    <ng-container\n                        *ngTemplateOutlet=\"\n                            tmplChildren;\n                            context: {\n                                tmpBranches: branch.children,\n                                isRoot: false,\n                                listId: branch.id\n                            }\n                        \"\n                    >\n                    </ng-container>\n                }\n\n                @if (dropActionTodo?.targetId === branch.id && dropActionTodo?.action === 'after') {\n                    <div class=\"tree-branch-ghost\" aria-hidden=\"true\">\n                        <ng-container\n                            *ngTemplateOutlet=\"tmplBranch; context: { branch: draggedBranch }\"\n                        >\n                        </ng-container>\n                    </div>\n                }\n            </div>\n        }\n    </div>\n</ng-template>\n\n<ng-template #tmplBranch let-branch=\"branch\">\n    <div\n        class=\"tree-branch-row tree-view-list-item d-flex justify-content-between p-2\"\n        [class.is-expanded]=\"branch?.isExpanded\"\n    >\n        <div class=\"d-flex align-items-center tree-view-list-item-truncate-helper\">\n            @if (branch.level === levelLimit) {\n                <ui-core-icon\n                    icon=\"remove\"\n                    size=\"sm\"\n                    colorClass=\"color-gray-400\"\n                    collapseHeight=\"true\"\n                    class=\"mr-1\"\n                    aria-hidden=\"true\"\n                >\n                </ui-core-icon>\n            } @else {\n                <ui-core-icon-button\n                    icon=\"chevron_right\"\n                    class=\"tree-view-list-item-toggle\"\n                    [message]=\"(branch.isExpanded ? 'Collapse ' : 'Expand ') + branch.title\"\n                    (click)=\"expand(branch)\"\n                    [disabled]=\"!branch.children?.length\"\n                >\n                </ui-core-icon-button>\n            }\n\n            @if (branch.icon) {\n                <ui-core-icon\n                    [icon]=\"branch.icon\"\n                    size=\"xl\"\n                    colorClass=\"color-gray-700\"\n                    collapseHeight=\"true\"\n                    class=\"mr-1\"\n                    aria-hidden=\"true\"\n                >\n                </ui-core-icon>\n            }\n\n            <div class=\"tree-view-list-item-truncate-helper\">\n                <p class=\"text-second text-semibold mb-0 text-truncate\">\n                    {{ branch.title }}\n                </p>\n            </div>\n\n            @if (branch.badge) {\n                <ui-core-badge\n                    [message]=\"branch.badge.message\"\n                    [theme]=\"branch.badge.theme\"\n                    [framed]=\"branch.badge.framed ?? false\"\n                    class=\"ml-2\"\n                >\n                </ui-core-badge>\n            }\n        </div>\n\n        <div class=\"d-flex align-items-center\">\n            <ui-core-inline-actions-bar\n                [inlineActions]=\"branch.level === levelLimit ? actionsWithoutAdd : actions\"\n                class=\"tree-view-list-item-hover-icon\">\n            </ui-core-inline-actions-bar>\n\n            <ui-core-icon\n                class=\"drag-icon ml-1\"\n                icon=\"drag_indicator\"\n                size=\"xxxl\"\n                alignWithText=\"true\"\n                colorClass=\"color-gray-300\"\n                aria-label=\"Drag to reorder\"\n                cdkDragHandle\n            >\n            </ui-core-icon>\n        </div>\n    </div>\n</ng-template>\n\n<div\n    class=\"sidebar tree-view-list\"\n    [class.dragging]=\"dragging\"\n    [class.cross-group-active]=\"!!dropActionTodo\"\n    cdkDropListGroup\n>\n    <ng-container\n        *ngTemplateOutlet=\"\n            tmplChildren;\n            context: {\n                tmpBranches: branches,\n                isRoot: true,\n                listId: 'root'\n            }\n        \"\n    >\n    </ng-container>\n</div>\n", styles: [".tree-view-list{padding:0;list-style:none;justify-content:space-between;align-items:center;align-self:stretch;border-top:1px solid var(--color-gray-200)}.tree-view-list-item{background:var(--color-default);border:1px solid var(--color-gray-200);border-top:none}.tree-view-list-item.is-expanded .tree-view-list-item-toggle{transform:rotate(90deg)}.tree-view-list-item .drag-icon:hover{cursor:grab}.tree-view-list-item-truncate-helper{min-width:0}.tree-view-list-item-hover-icon{opacity:0;transition:opacity .15s ease}.tree-view-list-item:hover,.tree-view-list-item:focus-within{background:var(--hover-color)}.tree-view-list-item:hover .tree-view-list-item-hover-icon,.tree-view-list-item:focus-within .tree-view-list-item-hover-icon{opacity:1}.tree-branch-row{background:var(--color-default);border:1px solid var(--color-gray-200);border-top:none}.tree-branch-ghost{pointer-events:none;background-color:color-mix(in srgb,var(--color-primary),transparent 90%);border:1px solid var(--color-primary);border-radius:var(--containers-shape)}.cross-group-active .cdk-drag-placeholder{display:none}.cross-group-active .tree-view-list-item-container{transform:none!important}.tree-branch-children{position:relative;transition:height .2s;padding-left:68px;background:var(--color-gray-100)}\n"], dependencies: [{ kind: "directive", type: i3.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i2$1.CdkDropList, selector: "[cdkDropList], cdk-drop-list", inputs: ["cdkDropListConnectedTo", "cdkDropListData", "cdkDropListOrientation", "id", "cdkDropListLockAxis", "cdkDropListDisabled", "cdkDropListSortingDisabled", "cdkDropListEnterPredicate", "cdkDropListSortPredicate", "cdkDropListAutoScrollDisabled", "cdkDropListAutoScrollStep", "cdkDropListElementContainer", "cdkDropListHasAnchor"], outputs: ["cdkDropListDropped", "cdkDropListEntered", "cdkDropListExited", "cdkDropListSorted"], exportAs: ["cdkDropList"] }, { kind: "directive", type: i2$1.CdkDropListGroup, selector: "[cdkDropListGroup]", inputs: ["cdkDropListGroupDisabled"], exportAs: ["cdkDropListGroup"] }, { kind: "directive", type: i2$1.CdkDrag, selector: "[cdkDrag]", inputs: ["cdkDragData", "cdkDragLockAxis", "cdkDragRootElement", "cdkDragBoundary", "cdkDragStartDelay", "cdkDragFreeDragPosition", "cdkDragDisabled", "cdkDragConstrainPosition", "cdkDragPreviewClass", "cdkDragPreviewContainer", "cdkDragScale"], outputs: ["cdkDragStarted", "cdkDragReleased", "cdkDragEnded", "cdkDragEntered", "cdkDragExited", "cdkDragDropped", "cdkDragMoved"], exportAs: ["cdkDrag"] }, { kind: "directive", type: i2$1.CdkDragHandle, selector: "[cdkDragHandle]", inputs: ["cdkDragHandleDisabled"] }, { kind: "component", type: i1.BadgeComponent, selector: "ui-core-badge", inputs: ["message", "framed", "theme", "type", "centered", "icon", "iconPosition"] }, { kind: "component", type: i1.IconComponent, selector: "ui-core-icon", inputs: ["icon", "size", "colorClass", "allowEmojis", "ariaLabel", "alignWithText", "collapseHeight", "scaleWithFonts", "animationPath", "animationData", "animationFreeze", "animationFreezeFrame", "animationLoop", "animationLoopTotal"], outputs: ["animationCompleted"] }, { kind: "component", type: i1.IconButtonComponent, selector: "ui-core-icon-button", inputs: ["message", "icon", "size", "disabled", "buttonClass", "ariaPressed", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "e2e", "theme", "usesGlassHoverState", "buttonId"] }, { kind: "component", type: i1.InlineActionsBarComponent, selector: "ui-core-inline-actions-bar", inputs: ["message", "inlineActions", "maxActions"], outputs: ["actionClicked"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TreeViewComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-management-tree-view', template: "<ng-template\n    #tmplChildren\n    let-tmpBranches=\"tmpBranches\"\n    let-isRoot=\"isRoot\"\n    let-listId=\"listId\"\n>\n    <div\n        class=\"tree-branch-list\"\n        [class.tree-branch-children]=\"!isRoot\"\n        [attr.role]=\"isRoot ? 'tree' : 'group'\"\n        [attr.aria-label]=\"isRoot ? ariaLabel : null\"\n        cdkDropList\n        [id]=\"listId\"\n        [cdkDropListData]=\"tmpBranches\"\n        [cdkDropListEnterPredicate]=\"canEnter\"\n        [attr.data-list-id]=\"listId\"\n        (cdkDropListDropped)=\"drop($event)\"\n    >\n        @for (branch of tmpBranches; track branch.id) {\n            <div\n                class=\"tree-branch\"\n                role=\"treeitem\"\n                [attr.data-id]=\"branch.id\"\n                [attr.aria-label]=\"branch.title\"\n                [attr.aria-level]=\"branch.level\"\n                [attr.aria-setsize]=\"tmpBranches.length\"\n                [attr.aria-posinset]=\"$index + 1\"\n                [attr.aria-expanded]=\"branch.children?.length ? !!branch.isExpanded : null\"\n            >\n                @if (dropActionTodo?.targetId === branch.id && dropActionTodo?.action === 'before') {\n                    <div class=\"tree-branch-ghost\" aria-hidden=\"true\">\n                        <ng-container\n                            *ngTemplateOutlet=\"tmplBranch; context: { branch: draggedBranch }\"\n                        >\n                        </ng-container>\n                    </div>\n                }\n\n                <div\n                    class=\"tree-view-list-item-container\"\n                    cdkDrag\n                    [cdkDragData]=\"branch\"\n                    (cdkDragMoved)=\"dragMoved($event)\"\n                    (cdkDragStarted)=\"startDrag(listId, branch)\"\n                    (cdkDragEnded)=\"endDrag()\"\n                >\n                    <ng-container\n                        *ngTemplateOutlet=\"tmplBranch; context: { branch: branch }\"\n                    >\n                    </ng-container>\n                </div>\n\n                @if (branch?.isExpanded && branch?.children && branch.children.length) {\n                    <ng-container\n                        *ngTemplateOutlet=\"\n                            tmplChildren;\n                            context: {\n                                tmpBranches: branch.children,\n                                isRoot: false,\n                                listId: branch.id\n                            }\n                        \"\n                    >\n                    </ng-container>\n                }\n\n                @if (dropActionTodo?.targetId === branch.id && dropActionTodo?.action === 'after') {\n                    <div class=\"tree-branch-ghost\" aria-hidden=\"true\">\n                        <ng-container\n                            *ngTemplateOutlet=\"tmplBranch; context: { branch: draggedBranch }\"\n                        >\n                        </ng-container>\n                    </div>\n                }\n            </div>\n        }\n    </div>\n</ng-template>\n\n<ng-template #tmplBranch let-branch=\"branch\">\n    <div\n        class=\"tree-branch-row tree-view-list-item d-flex justify-content-between p-2\"\n        [class.is-expanded]=\"branch?.isExpanded\"\n    >\n        <div class=\"d-flex align-items-center tree-view-list-item-truncate-helper\">\n            @if (branch.level === levelLimit) {\n                <ui-core-icon\n                    icon=\"remove\"\n                    size=\"sm\"\n                    colorClass=\"color-gray-400\"\n                    collapseHeight=\"true\"\n                    class=\"mr-1\"\n                    aria-hidden=\"true\"\n                >\n                </ui-core-icon>\n            } @else {\n                <ui-core-icon-button\n                    icon=\"chevron_right\"\n                    class=\"tree-view-list-item-toggle\"\n                    [message]=\"(branch.isExpanded ? 'Collapse ' : 'Expand ') + branch.title\"\n                    (click)=\"expand(branch)\"\n                    [disabled]=\"!branch.children?.length\"\n                >\n                </ui-core-icon-button>\n            }\n\n            @if (branch.icon) {\n                <ui-core-icon\n                    [icon]=\"branch.icon\"\n                    size=\"xl\"\n                    colorClass=\"color-gray-700\"\n                    collapseHeight=\"true\"\n                    class=\"mr-1\"\n                    aria-hidden=\"true\"\n                >\n                </ui-core-icon>\n            }\n\n            <div class=\"tree-view-list-item-truncate-helper\">\n                <p class=\"text-second text-semibold mb-0 text-truncate\">\n                    {{ branch.title }}\n                </p>\n            </div>\n\n            @if (branch.badge) {\n                <ui-core-badge\n                    [message]=\"branch.badge.message\"\n                    [theme]=\"branch.badge.theme\"\n                    [framed]=\"branch.badge.framed ?? false\"\n                    class=\"ml-2\"\n                >\n                </ui-core-badge>\n            }\n        </div>\n\n        <div class=\"d-flex align-items-center\">\n            <ui-core-inline-actions-bar\n                [inlineActions]=\"branch.level === levelLimit ? actionsWithoutAdd : actions\"\n                class=\"tree-view-list-item-hover-icon\">\n            </ui-core-inline-actions-bar>\n\n            <ui-core-icon\n                class=\"drag-icon ml-1\"\n                icon=\"drag_indicator\"\n                size=\"xxxl\"\n                alignWithText=\"true\"\n                colorClass=\"color-gray-300\"\n                aria-label=\"Drag to reorder\"\n                cdkDragHandle\n            >\n            </ui-core-icon>\n        </div>\n    </div>\n</ng-template>\n\n<div\n    class=\"sidebar tree-view-list\"\n    [class.dragging]=\"dragging\"\n    [class.cross-group-active]=\"!!dropActionTodo\"\n    cdkDropListGroup\n>\n    <ng-container\n        *ngTemplateOutlet=\"\n            tmplChildren;\n            context: {\n                tmpBranches: branches,\n                isRoot: true,\n                listId: 'root'\n            }\n        \"\n    >\n    </ng-container>\n</div>\n", styles: [".tree-view-list{padding:0;list-style:none;justify-content:space-between;align-items:center;align-self:stretch;border-top:1px solid var(--color-gray-200)}.tree-view-list-item{background:var(--color-default);border:1px solid var(--color-gray-200);border-top:none}.tree-view-list-item.is-expanded .tree-view-list-item-toggle{transform:rotate(90deg)}.tree-view-list-item .drag-icon:hover{cursor:grab}.tree-view-list-item-truncate-helper{min-width:0}.tree-view-list-item-hover-icon{opacity:0;transition:opacity .15s ease}.tree-view-list-item:hover,.tree-view-list-item:focus-within{background:var(--hover-color)}.tree-view-list-item:hover .tree-view-list-item-hover-icon,.tree-view-list-item:focus-within .tree-view-list-item-hover-icon{opacity:1}.tree-branch-row{background:var(--color-default);border:1px solid var(--color-gray-200);border-top:none}.tree-branch-ghost{pointer-events:none;background-color:color-mix(in srgb,var(--color-primary),transparent 90%);border:1px solid var(--color-primary);border-radius:var(--containers-shape)}.cross-group-active .cdk-drag-placeholder{display:none}.cross-group-active .tree-view-list-item-container{transform:none!important}.tree-branch-children{position:relative;transition:height .2s;padding-left:68px;background:var(--color-gray-100)}\n"] }]
        }], propDecorators: { listItems: [{
                type: Input
            }], levelLimit: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }], listItemsChange: [{
                type: Output
            }] } });

class UiManagementModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: UiManagementModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.17", ngImport: i0, type: UiManagementModule, declarations: [DragAndDropListComponent,
            HeaderComponent,
            HtmlEditorComponent,
            JsonDiffComponent,
            JsonEditorComponent,
            MarkdownEditorComponent,
            PanelListComponent,
            SearchBarComponent,
            TargetConditionComponent,
            TargetingComponent,
            TargetOperatorComponent,
            TargetRuleComponent,
            TreeViewComponent,
            SidePanelComponent,
            StatusTrackerComponent,
            StatusTrackerStepsComponent], imports: [CommonModule,
            DragDropModule,
            FormsModule, i4$1.MonacoEditorModule, NgbModule, i4.QuillModule, ReactiveFormsModule,
            UiCoreModule,
            UiFormsModule], exports: [DragAndDropListComponent,
            HeaderComponent,
            HtmlEditorComponent,
            JsonDiffComponent,
            JsonEditorComponent,
            MarkdownEditorComponent,
            PanelListComponent,
            SearchBarComponent,
            TargetingComponent,
            TreeViewComponent,
            SidePanelComponent,
            StatusTrackerComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: UiManagementModule, imports: [CommonModule,
            DragDropModule,
            FormsModule,
            MonacoEditorModule.forRoot(),
            NgbModule,
            QuillModule.forRoot(),
            ReactiveFormsModule,
            UiCoreModule,
            UiFormsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: UiManagementModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        DragAndDropListComponent,
                        HeaderComponent,
                        HtmlEditorComponent,
                        JsonDiffComponent,
                        JsonEditorComponent,
                        MarkdownEditorComponent,
                        PanelListComponent,
                        SearchBarComponent,
                        TargetConditionComponent,
                        TargetingComponent,
                        TargetOperatorComponent,
                        TargetRuleComponent,
                        TreeViewComponent,
                        SidePanelComponent,
                        StatusTrackerComponent,
                        StatusTrackerStepsComponent
                    ],
                    imports: [
                        CommonModule,
                        DragDropModule,
                        FormsModule,
                        MonacoEditorModule.forRoot(),
                        NgbModule,
                        QuillModule.forRoot(),
                        ReactiveFormsModule,
                        UiCoreModule,
                        UiFormsModule
                    ],
                    exports: [
                        DragAndDropListComponent,
                        HeaderComponent,
                        HtmlEditorComponent,
                        JsonDiffComponent,
                        JsonEditorComponent,
                        MarkdownEditorComponent,
                        PanelListComponent,
                        SearchBarComponent,
                        TargetingComponent,
                        TreeViewComponent,
                        SidePanelComponent,
                        StatusTrackerComponent
                    ]
                }]
        }] });

/*
 * Public API Surface of ui-management
 */
// Components

/**
 * Generated bundle index. Do not edit.
 */

export { ConditionOperator, ConditionValueType, DragAndDropListComponent, DragAndDropListItem, DragAndDropListResult, HeaderComponent, HtmlEditorAction, HtmlEditorComponent, JsonDiffComponent, JsonEditorComponent, MarkdownEditorComponent, PanelListComponent, PanelListItem, SearchBarComponent, SidePanelAction, SidePanelComponent, StatusTrackerComponent, TargetCondition, TargetConditionGroup, TargetGroupData, TargetGroupOperator, TargetOperatorOption, TargetOption, TargetResult, TargetWorkflowOptions, TargetingComponent, TreeViewComponent, UiManagementModule };
//# sourceMappingURL=a3-digital-ui-management.mjs.map
