import * as i0 from '@angular/core';
import { EventEmitter, Output, Input, ViewChild, Component, HostBinding, ChangeDetectionStrategy, Injectable, Injector, NgModule } from '@angular/core';
import { format } from '@a3-digital/formatter';
import * as i2 from '@a3-digital/ui-core';
import { BaseTextComponent, UnsavedChangesModalComponent, ButtonCardItem, HtmlUtils, AnimationUtils, fadeInEffect, expandEffect, slideDownEffect, fadeOutEffect, collapseEffect, BadgeTheme, TransitionStateChange, NotificationTheme, EventUtils, ChipListItem, GridItem, ContainerTheme, HtmlAttributeState, collapseOrSlideState, BaseDestroyComponent, SanitizationUtils, IconComponent, FeatureFlagClass, UiCoreModule } from '@a3-digital/ui-core';
import * as i4 from '@a3-digital/ui-forms';
import { RadioButtonsField, FormRendererRow, FormUtils, TextAreaField, TextInputField, FormRendererComponent, TextAreaIconButton, WorkflowInputOption, WorkflowInputComponent, PickerOption, MultiSelectPickerOption, formValidator, SearchInputComponent, DEFAULT_MAX_NUMBER, WorkflowButtonSummary, DropdownOption, TemplateDropdownField, ContentTemplateData, TemplateDropdownOption, TemplateGroup, DropdownField, DatepickerField, NumberInputField, FormRendererGroup, RadioButtonOption, UiFormsModule } from '@a3-digital/ui-forms';
import { NativeVariableUtils } from '@a3-digital/ui-styles';
import * as i1 from '@angular/forms';
import { UntypedFormControl, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import * as i3 from '@angular/router';
import * as i4$1 from '@angular/cdk/drag-drop';
import { DragDropModule } from '@angular/cdk/drag-drop';
import * as i2$1 from '@angular/common';
import { CommonModule } from '@angular/common';
import { take, catchError, of, BehaviorSubject } from 'rxjs';
import * as i1$1 from '@a3-digital/date-utils';
import { DateUtils, CalendarDate } from '@a3-digital/date-utils';
import { LANGUAGES, NumberUtils, ArrayUtils } from '@a3-digital/utils';
import { optional, required, positiveAmount } from '@a3-digital/validation';
import { globalSettings } from '@a3-digital/configurability';
import * as i5 from '@ng-bootstrap/ng-bootstrap';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

class AddressVerificationModalComponent extends BaseTextComponent {
    constructor(modalService, textService) {
        super(textService, 'ui-workflows-address-verification-modal');
        this.modalService = modalService;
        this.textService = textService;
        /**
        * Optional. Information to display near the top of the modal.
        * Defaults to: 'The United States Postal Service suggests using the Recommended Address below.'
        **/
        this.infoText = this.text.addressVerificationDescription;
        /**
        * Optional. Set to true to prevent the modal from closing when the scrim (backdrop) is clicked or when
        * the ESC key is pressed. The modal can only be dismissed via its close, cancel, or submit
        * buttons, or programmatically (e.g. modalService.dismissAll()).
        **/
        this.lockScrim = false;
        /**
        * Emits the selected address value.
        **/
        this.primaryButtonClick = new EventEmitter();
        this.formRows = [];
    }
    /**
    * Opens the modal. `recommended` is the USPS-corrected address and is pre-selected on open.
    * `entered` is the address the user originally typed. The option labels are owned by this
    * component — only `value` and `subtextLines` need to be set by the caller.
    **/
    showAddressOptions(recommended, entered) {
        recommended.label = this.text.recommendedAddressLabel;
        entered.label = this.text.enteredAddressLabel;
        const label = this.infoText || this.text.addressVerificationDescription;
        const radioButtonField = new RadioButtonsField('addresses', label, recommended.value, true);
        radioButtonField.options = [recommended, entered];
        radioButtonField.errorMessage = this.text.requiredError;
        radioButtonField.vertical = true;
        radioButtonField.fullWidth = true;
        radioButtonField.hideLabel = !label;
        this.formRows = [new FormRendererRow([radioButtonField])];
        this.modalService.openNormalModal(this.addressModal);
    }
    selectAddress(form) {
        if (form.invalid) {
            return;
        }
        const selectedValue = form.get('addresses')?.value;
        this.modalService.closeMostRecentModal();
        this.primaryButtonClick.emit(selectedValue);
    }
    getDefaultText() {
        return {
            addressVerificationModalTitle: 'Address Verification',
            addressVerificationButtonText: 'Use Selected Address',
            addressVerificationDescription: 'The United States Postal Service suggests using the Recommended Address below.',
            recommendedAddressLabel: 'Recommended Address',
            enteredAddressLabel: 'Entered Address',
            requiredError: 'Required'
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: AddressVerificationModalComponent, deps: [{ token: i2.ModalService }, { token: i2.TextService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.17", type: AddressVerificationModalComponent, isStandalone: false, selector: "ui-workflows-address-verification-modal", inputs: { infoText: "infoText", lockScrim: "lockScrim" }, outputs: { primaryButtonClick: "primaryButtonClick" }, viewQueries: [{ propertyName: "addressModal", first: true, predicate: ["addressModal"], descendants: true }], usesInheritance: true, ngImport: i0, template: "<ng-template #addressModal>\n    <ui-core-modal [title]=\"text.addressVerificationModalTitle\"\n        [lockScrim]=\"lockScrim\"\n        [useFormRendererButtons]=\"true\"\n        e2e=\"address-verification\">\n        <ui-forms-form-renderer [rows]=\"formRows\"\n            [primaryButtonText]=\"text.addressVerificationButtonText\"\n            (primaryButtonClicked)=\"selectAddress($event)\">\n        </ui-forms-form-renderer>\n    </ui-core-modal>\n</ng-template>\n", dependencies: [{ kind: "component", type: i2.ModalComponent, selector: "ui-core-modal", inputs: ["headerTemplate", "footerTemplate", "noBodyPadding", "noHeaderBorder", "useFormRendererButtons", "useFooterButtons", "showPrimarySpinner", "useGlassBackground"] }, { kind: "component", type: i4.FormRendererComponent, selector: "ui-forms-form-renderer", inputs: ["rows", "disableButtons", "primaryButtonText", "primaryButtonDisabledText", "primaryButtonIcon", "primaryButtonIconPosition", "secondaryButtonText", "secondaryButtonClearsForm", "secondaryButtonUrl", "secondaryButtonUrlParams", "secondaryButtonUsesExternalUrlNewTab", "secondaryButtonIcon", "secondaryButtonIconPosition", "tertiaryButtonText", "tertiaryButtonIcon", "tertiaryButtonIconPosition", "tertiaryButtonUrl", "tertiaryButtonUrlParams", "tertiaryButtonUsesExternalUrlNewTab", "locked", "loading", "loadingMessage", "storeValuesOnSubmit", "storeValuesOnDestroy", "checkEditedValues", "e2e", "showNextField", "errorMessages", "autoFocus", "marginTop", "marginBottom", "enableBotDetection"], outputs: ["primaryButtonClicked", "secondaryButtonClicked", "tertiaryButtonClicked", "inputChange", "selection", "groupCategoryChange"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: AddressVerificationModalComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-workflows-address-verification-modal', template: "<ng-template #addressModal>\n    <ui-core-modal [title]=\"text.addressVerificationModalTitle\"\n        [lockScrim]=\"lockScrim\"\n        [useFormRendererButtons]=\"true\"\n        e2e=\"address-verification\">\n        <ui-forms-form-renderer [rows]=\"formRows\"\n            [primaryButtonText]=\"text.addressVerificationButtonText\"\n            (primaryButtonClicked)=\"selectAddress($event)\">\n        </ui-forms-form-renderer>\n    </ui-core-modal>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i2.ModalService }, { type: i2.TextService }], propDecorators: { addressModal: [{
                type: ViewChild,
                args: ['addressModal', { static: false }]
            }], infoText: [{
                type: Input
            }], lockScrim: [{
                type: Input
            }], primaryButtonClick: [{
                type: Output
            }] } });

class ConfirmationModalEvent {
    constructor(confirm = false, dontShowAgain = false) {
        this.confirm = confirm;
        this.dontShowAgain = dontShowAgain;
    }
}

class ConfirmationModalComponent extends BaseTextComponent {
    constructor(modalService, textService) {
        super(textService, 'ui-workflows-confirmation-modal');
        this.modalService = modalService;
        this.textService = textService;
        /**
        * Optional modal title. Default is "Are you sure?"
        **/
        this.title = '';
        /**
        * Required. The message inside the modal body.
        **/
        this.message = '';
        /**
        * Optional. Extra message inside the modal body.
        **/
        this.additionalMessage = '';
        /**
        * Optional. Bullet list label that displays under the messages if bullet list items are provided.
        **/
        this.bulletListLabel = '';
        /**
        * Optional. CSS classes to apply to the bullet list label.
        **/
        this.bulletListLabelClasses = '';
        /**
        * Optional. Bullet list items that displays under the messages
        **/
        this.bulletListItems = [];
        /**
        * Optional. Whether or not the "Don't show again" checkbox is displayed
        **/
        this.showDontShowAgainCheckbox = false;
        /**
        * Optional. Whether or not the primary button should dismiss all modals.
        **/
        this.primaryButtonDismissesAllModals = false;
        /**
        * Optional primary button text. Default is "Accept and Continue"
        **/
        this.primaryButtonText = '';
        /**
        * Optional secondary button text. Default is "Cancel"
        **/
        this.secondaryButtonText = '';
        /**
        * Set to true to prevent the modal from closing when the scrim (backdrop) is clicked or when
        * the ESC key is pressed. The modal can only be dismissed via its close, cancel, or submit
        * buttons, or programmatically (e.g. modalService.dismissAll()).
        **/
        this.lockScrim = false;
        /**
        * Emits when Cancel or Confirm buttons are clicked. Includes button and checkbox values.
        **/
        this.clicked = new EventEmitter();
        this.modalTitle = '';
        this.confirmButtonText = '';
        this.cancelButtonText = '';
        this.valueEmitted = false;
        this.dontShowAgain = false;
    }
    show() {
        // Reset flags and text
        this.valueEmitted = false;
        this.dontShowAgain = false;
        this.modalTitle = this.title || this.text.modalTitle;
        this.confirmButtonText = this.primaryButtonText || this.text.confirmButtonText;
        this.cancelButtonText = this.secondaryButtonText || this.text.cancelButtonText;
        if (this.modalService.hasEnhancedModalOnTop()) {
            this.modalService.openEnhancedModal(this.confirmationModal);
        }
        else {
            this.modalService.openNormalModal(this.confirmationModal);
        }
    }
    modalClosed() {
        // There are ways of closing the modal without interacting with the primary/secondary buttons.
        // If one of them was used, treat that as a cancelation.
        if (!this.valueEmitted) {
            this.clicked.emit(new ConfirmationModalEvent());
        }
    }
    closeModal(confirmed) {
        // There is a slight animation delay when closing the modal,
        // so emit values now instead of waiting for the close event.
        if (confirmed) {
            this.clicked.emit(new ConfirmationModalEvent(true, this.dontShowAgain));
        }
        else {
            this.clicked.emit(new ConfirmationModalEvent());
        }
        this.valueEmitted = true;
        if (confirmed && this.primaryButtonDismissesAllModals) {
            this.modalService.dismissAll();
        }
        else {
            this.modalService.closeMostRecentModal();
        }
    }
    getDefaultText() {
        return {
            modalTitle: 'Are you sure?',
            confirmButtonText: 'Accept and Continue',
            cancelButtonText: 'Cancel',
            checkboxLabelText: `Don't show again`,
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: ConfirmationModalComponent, deps: [{ token: i2.ModalService }, { token: i2.TextService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.17", type: ConfirmationModalComponent, isStandalone: false, selector: "ui-workflows-confirmation-modal", inputs: { title: "title", message: "message", additionalMessage: "additionalMessage", bulletListLabel: "bulletListLabel", bulletListLabelClasses: "bulletListLabelClasses", bulletListItems: "bulletListItems", showDontShowAgainCheckbox: "showDontShowAgainCheckbox", primaryButtonDismissesAllModals: "primaryButtonDismissesAllModals", primaryButtonText: "primaryButtonText", secondaryButtonText: "secondaryButtonText", lockScrim: "lockScrim" }, outputs: { clicked: "clicked" }, viewQueries: [{ propertyName: "confirmationModal", first: true, predicate: ["confirmationModal"], descendants: true, static: true }], usesInheritance: true, ngImport: i0, template: "<ng-template #confirmationModal>\n    <ui-core-modal [title]=\"modalTitle\"\n        e2e=\"confirmation\"\n        [lockScrim]=\"lockScrim\"\n        [primaryButtonText]=\"confirmButtonText\"\n        [secondaryButtonText]=\"cancelButtonText\"\n        (primaryButtonClicked)=\"closeModal(true)\"\n        (secondaryButtonClicked)=\"closeModal(false)\"\n        (closed)=\"modalClosed()\">\n\n        <div class=\"mb-5\">\n            {{ message }}\n            @if (additionalMessage) {\n                <div class=\"mt-2\">{{ additionalMessage }}</div>\n            }\n            @if (bulletListItems.length > 0) {\n                <div class=\"mt-2\">\n                    <ui-core-bullet-list\n                        [label]=\"bulletListLabel\"\n                        [labelClasses]=\"bulletListLabelClasses\"\n                        [items]=\"bulletListItems\">\n                    </ui-core-bullet-list>\n                </div>\n            }\n            @if (showDontShowAgainCheckbox) {\n                <div class=\"mt-5\">\n                    <ui-forms-checkbox\n                        [label]=\"text.checkboxLabelText\"\n                        e2e=\"dont-show-again\"\n                        (change)=\"dontShowAgain=$event\">\n                    </ui-forms-checkbox>\n                </div>\n            }\n        </div>\n\n    </ui-core-modal>\n</ng-template>\n", dependencies: [{ kind: "component", type: i2.BulletListComponent, selector: "ui-core-bullet-list", inputs: ["items", "label", "labelClasses", "markerStyle", "leftAligned", "marginBottom"] }, { kind: "component", type: i2.ModalComponent, selector: "ui-core-modal", inputs: ["headerTemplate", "footerTemplate", "noBodyPadding", "noHeaderBorder", "useFormRendererButtons", "useFooterButtons", "showPrimarySpinner", "useGlassBackground"] }, { kind: "component", type: i4.CheckboxComponent, selector: "ui-forms-checkbox", inputs: ["indeterminate", "isChild", "secondaryLabel", "subtextLines", "ariaLabel"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: ConfirmationModalComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-workflows-confirmation-modal', template: "<ng-template #confirmationModal>\n    <ui-core-modal [title]=\"modalTitle\"\n        e2e=\"confirmation\"\n        [lockScrim]=\"lockScrim\"\n        [primaryButtonText]=\"confirmButtonText\"\n        [secondaryButtonText]=\"cancelButtonText\"\n        (primaryButtonClicked)=\"closeModal(true)\"\n        (secondaryButtonClicked)=\"closeModal(false)\"\n        (closed)=\"modalClosed()\">\n\n        <div class=\"mb-5\">\n            {{ message }}\n            @if (additionalMessage) {\n                <div class=\"mt-2\">{{ additionalMessage }}</div>\n            }\n            @if (bulletListItems.length > 0) {\n                <div class=\"mt-2\">\n                    <ui-core-bullet-list\n                        [label]=\"bulletListLabel\"\n                        [labelClasses]=\"bulletListLabelClasses\"\n                        [items]=\"bulletListItems\">\n                    </ui-core-bullet-list>\n                </div>\n            }\n            @if (showDontShowAgainCheckbox) {\n                <div class=\"mt-5\">\n                    <ui-forms-checkbox\n                        [label]=\"text.checkboxLabelText\"\n                        e2e=\"dont-show-again\"\n                        (change)=\"dontShowAgain=$event\">\n                    </ui-forms-checkbox>\n                </div>\n            }\n        </div>\n\n    </ui-core-modal>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i2.ModalService }, { type: i2.TextService }], propDecorators: { confirmationModal: [{
                type: ViewChild,
                args: ['confirmationModal', { static: true }]
            }], title: [{
                type: Input
            }], message: [{
                type: Input
            }], additionalMessage: [{
                type: Input
            }], bulletListLabel: [{
                type: Input
            }], bulletListLabelClasses: [{
                type: Input
            }], bulletListItems: [{
                type: Input
            }], showDontShowAgainCheckbox: [{
                type: Input
            }], primaryButtonDismissesAllModals: [{
                type: Input
            }], primaryButtonText: [{
                type: Input
            }], secondaryButtonText: [{
                type: Input
            }], lockScrim: [{
                type: Input
            }], clicked: [{
                type: Output
            }] } });

class EditLabelValueModalComponent extends BaseTextComponent {
    constructor(modalService, textService) {
        super(textService, 'ui-workflows-edit-label-value-modal');
        this.modalService = modalService;
        this.textService = textService;
        /**
        * The label for the label-value. Also used to generate the modal title and form label.
        **/
        this.label = '';
        /**
        * The value for the label-value. If the value is updated successfully, this input must be updated
        * with the new value.
        **/
        this.value = '';
        /**
        * Optional error message to display. Default value is "Required"
        **/
        this.errorMessage = '';
        /**
        * The max length of the form field.
        **/
        this.maxLength = FormUtils.defaultMaxLength;
        /**
        * Optional regex to enforce for validation.
        **/
        this.validationRegex = '';
        /**
        * Optional loading spinner to help long running API calls.
        **/
        this.showSpinner = false;
        /**
        * Show the form field as a text area.
        **/
        this.showTextArea = false;
        /**
        * By default, a value is required in the form field.
        * If this is set to true, the form field can be empty.
        **/
        this.valueIsOptional = false;
        /**
        * Optional label for the edit link, rendered when the value is an empty string.
        * Default is "Edit".
        **/
        this.editLinkText = '';
        /**
        * Optional text override for the submit (primary) button. Defaults to "Update"
        **/
        this.submitButtonText = '';
        /**
        * Allows for a custom e2e prefix. Default is "edit-label-value"
        **/
        this.e2e = 'edit-label-value';
        /**
        * If enabled, edit button is right aligned.
        **/
        this.rightAlignEditButton = false;
        /**
        * Class(es) to apply to outer container of the label-value for spacing.
        **/
        this.elementClass = 'mb-4';
        /**
        * If enabled, shows a border at the bottom of the label-value.
        **/
        this.borderBottom = false;
        /**
        * Set to true to prevent the modal from closing when the scrim (backdrop) is clicked or when
        * the ESC key is pressed. The modal can only be dismissed via its close (X), cancel, or submit
        * buttons, or programmatically (e.g. modalService.dismissAll()).
        *
        * Use this for modals where closing mid-flow is not allowed (e.g. a required step that must complete).
        * For warning about unsaved form changes, use confirmUnsavedChanges instead.
        * Avoid setting both lockScrim and confirmUnsavedChanges to true — they have overlapping but
        * subtly different behavior and are not designed to be used together.
        **/
        this.lockScrim = false;
        /**
        * Set to true to show an unsaved changes confirmation when the user attempts to close the modal
        * via the close (X) button, scrim click, ESC key, or cancel button, and the form is dirty.
        * If the form has not been modified, the modal closes normally without a confirmation.
        *
        * Use this for form modals where the user could lose unsaved work.
        * For modals where closing mid-flow must be completely prevented, use lockScrim instead.
        * Avoid setting both confirmUnsavedChanges and lockScrim to true — they are not designed to be used together.
        **/
        this.confirmUnsavedChanges = false;
        this.checkUnsavedChangesHandler = this.checkUnsavedChanges.bind(this);
        /**
        * Emits if the user cancels the action (with the "Cancel" button or by closing the modal)
        **/
        this.cancelled = new EventEmitter();
        /**
        * Emits the new value if it is valid, and different from the original value.
        **/
        this.updated = new EventEmitter();
        this.formRows = [];
        this.modalTitle = '';
        // Edit button changes between iconRight (has value) and valueIsLink (no value)
        this.iconRight = '';
        this.actualValue = '';
        this.valueIsLink = false;
    }
    ngOnChanges(changes) {
        if (changes.value) {
            if (this.value) {
                this.iconRight = 'edit';
                this.actualValue = this.value;
                this.valueIsLink = false;
            }
            else {
                this.iconRight = '';
                this.actualValue = this.editLinkText || this.text.editButtonText;
                this.valueIsLink = true;
            }
        }
    }
    editClicked() {
        this.createForm();
        this.launchModal();
    }
    createForm() {
        const required = !this.valueIsOptional;
        const label = this.label + (required ? '' : ` ${this.text.optionalLabel}`);
        const textField = this.showTextArea
            ? new TextAreaField('editField', label, this.value, required)
            : new TextInputField('editField', label, this.value, required);
        const defaultErrorMessage = required ? this.text.requiredError : '';
        textField.errorMessage = this.errorMessage || defaultErrorMessage;
        textField.maxLength = this.maxLength;
        textField.fullWidth = true;
        textField.pattern = this.validationRegex;
        this.formRows = [new FormRendererRow([textField])];
    }
    launchModal() {
        this.modalTitle = format(this.text.modalTitle, { label: this.label });
        this.modalService.openNormalModal(this.editModal);
    }
    // Handles clicks of the submit button.
    submitForm() {
        if (this.formRenderer.form.invalid) {
            FormUtils.showFormValidation(this.formRenderer.form);
            return;
        }
        const newValue = this.formRenderer.form.value.editField;
        if (newValue !== this.value) {
            this.updated.emit(newValue);
        }
        this.closeModal();
    }
    // Handles clicks of the cancel button.
    async cancelEdit() {
        if (this.confirmUnsavedChanges && this.formRenderer?.form?.dirty) {
            const shouldClose = await this.unsavedChangesModal.showUnsavedChangesModal();
            if (!shouldClose) {
                return;
            }
        }
        this.cancelled.emit();
        this.closeModal();
    }
    // beforeClose callback — invoked by the modal service on X button, scrim click, or ESC key.
    // Returns true (allow close) immediately if the form is clean; otherwise defers to the unsaved-changes modal.
    async checkUnsavedChanges() {
        if (!this.formRenderer?.form?.dirty) {
            return true;
        }
        return this.unsavedChangesModal.showUnsavedChangesModal();
    }
    // Closes the modal, signaling to the modal service that this was an intentional button-driven close.
    closeModal() {
        this.modalService.closeMostRecentModal();
    }
    getDefaultText() {
        return {
            modalTitle: 'Edit {{ label }}',
            submitButtonText: 'Update',
            cancelButtonText: 'Cancel',
            editButtonText: 'Edit',
            requiredError: 'Required',
            optionalLabel: '(optional)',
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: EditLabelValueModalComponent, deps: [{ token: i2.ModalService }, { token: i2.TextService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.17", type: EditLabelValueModalComponent, isStandalone: false, selector: "ui-workflows-edit-label-value-modal", inputs: { label: "label", value: "value", errorMessage: "errorMessage", maxLength: "maxLength", validationRegex: "validationRegex", showSpinner: "showSpinner", showTextArea: "showTextArea", valueIsOptional: "valueIsOptional", editLinkText: "editLinkText", submitButtonText: "submitButtonText", e2e: "e2e", rightAlignEditButton: "rightAlignEditButton", elementClass: "elementClass", borderBottom: "borderBottom", lockScrim: "lockScrim", confirmUnsavedChanges: "confirmUnsavedChanges" }, outputs: { cancelled: "cancelled", updated: "updated" }, viewQueries: [{ propertyName: "editModal", first: true, predicate: ["editModal"], descendants: true, static: true }, { propertyName: "formRenderer", first: true, predicate: FormRendererComponent, descendants: true }, { propertyName: "unsavedChangesModal", first: true, predicate: UnsavedChangesModalComponent, descendants: true, static: true }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<ui-core-unsaved-changes-modal></ui-core-unsaved-changes-modal>\n\n<ng-template #editModal>\n    <ui-core-modal [title]=\"modalTitle\" [e2e]=\"e2e\"\n        [lockScrim]=\"lockScrim\"\n        [beforeClose]=\"confirmUnsavedChanges ? checkUnsavedChangesHandler : null\"\n        [useFormRendererButtons]=\"true\">\n        <ui-forms-form-renderer [rows]=\"formRows\" [e2e]=\"e2e\"\n            [primaryButtonText]=\"submitButtonText || text.submitButtonText\"\n            [secondaryButtonText]=\"text.cancelButtonText\"\n            (primaryButtonClicked)=\"submitForm()\"\n            (secondaryButtonClicked)=\"cancelEdit()\">\n        </ui-forms-form-renderer>\n    </ui-core-modal>\n</ng-template>\n\n<ui-core-label-value [class.d-block]=\"borderBottom\" [iconRight]=\"iconRight\" [iconRightAriaLabel]=\"text.editButtonText\"\n    [label]=\"label\" [value]=\"actualValue\" [valueIsLink]=\"valueIsLink\" [showSpinner]=\"showSpinner\" [e2e]=\"e2e\"\n    [rightAlignIconButtons]=\"rightAlignEditButton\" [elementClass]=\"elementClass\" [borderBottom]=\"borderBottom\"\n    (iconRightClicked)=\"editClicked()\" (linkClicked)=\"editClicked()\">\n</ui-core-label-value>\n", dependencies: [{ kind: "component", type: i2.LabelValueComponent, selector: "ui-core-label-value", inputs: ["label", "value", "values", "labelIcon", "tooltipContent", "tooltipPlacement", "iconLeft", "iconRight", "iconRightAriaLabel", "iconLeftColorClass", "iconLeftAllowEmojis", "masked", "maskedValues", "showCopyToClipboard", "rightAlignIconButtons", "elementClass", "borderBottom", "valueClass", "valueIsLink", "valueSubLinkText", "url", "externalUrlNewTab", "showSpinner", "e2e", "valueIsUnselectable", "notificationMessage", "notificationTheme", "notificationIcon"], outputs: ["iconRightClicked", "linkClicked", "maskToggleClicked", "copied"] }, { kind: "component", type: i2.ModalComponent, selector: "ui-core-modal", inputs: ["headerTemplate", "footerTemplate", "noBodyPadding", "noHeaderBorder", "useFormRendererButtons", "useFooterButtons", "showPrimarySpinner", "useGlassBackground"] }, { kind: "component", type: i2.UnsavedChangesModalComponent, selector: "ui-core-unsaved-changes-modal", inputs: ["title", "header", "message", "primaryButtonText", "secondaryButtonText", "lockScrim"] }, { kind: "component", type: i4.FormRendererComponent, selector: "ui-forms-form-renderer", inputs: ["rows", "disableButtons", "primaryButtonText", "primaryButtonDisabledText", "primaryButtonIcon", "primaryButtonIconPosition", "secondaryButtonText", "secondaryButtonClearsForm", "secondaryButtonUrl", "secondaryButtonUrlParams", "secondaryButtonUsesExternalUrlNewTab", "secondaryButtonIcon", "secondaryButtonIconPosition", "tertiaryButtonText", "tertiaryButtonIcon", "tertiaryButtonIconPosition", "tertiaryButtonUrl", "tertiaryButtonUrlParams", "tertiaryButtonUsesExternalUrlNewTab", "locked", "loading", "loadingMessage", "storeValuesOnSubmit", "storeValuesOnDestroy", "checkEditedValues", "e2e", "showNextField", "errorMessages", "autoFocus", "marginTop", "marginBottom", "enableBotDetection"], outputs: ["primaryButtonClicked", "secondaryButtonClicked", "tertiaryButtonClicked", "inputChange", "selection", "groupCategoryChange"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: EditLabelValueModalComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-workflows-edit-label-value-modal', template: "<ui-core-unsaved-changes-modal></ui-core-unsaved-changes-modal>\n\n<ng-template #editModal>\n    <ui-core-modal [title]=\"modalTitle\" [e2e]=\"e2e\"\n        [lockScrim]=\"lockScrim\"\n        [beforeClose]=\"confirmUnsavedChanges ? checkUnsavedChangesHandler : null\"\n        [useFormRendererButtons]=\"true\">\n        <ui-forms-form-renderer [rows]=\"formRows\" [e2e]=\"e2e\"\n            [primaryButtonText]=\"submitButtonText || text.submitButtonText\"\n            [secondaryButtonText]=\"text.cancelButtonText\"\n            (primaryButtonClicked)=\"submitForm()\"\n            (secondaryButtonClicked)=\"cancelEdit()\">\n        </ui-forms-form-renderer>\n    </ui-core-modal>\n</ng-template>\n\n<ui-core-label-value [class.d-block]=\"borderBottom\" [iconRight]=\"iconRight\" [iconRightAriaLabel]=\"text.editButtonText\"\n    [label]=\"label\" [value]=\"actualValue\" [valueIsLink]=\"valueIsLink\" [showSpinner]=\"showSpinner\" [e2e]=\"e2e\"\n    [rightAlignIconButtons]=\"rightAlignEditButton\" [elementClass]=\"elementClass\" [borderBottom]=\"borderBottom\"\n    (iconRightClicked)=\"editClicked()\" (linkClicked)=\"editClicked()\">\n</ui-core-label-value>\n" }]
        }], ctorParameters: () => [{ type: i2.ModalService }, { type: i2.TextService }], propDecorators: { editModal: [{
                type: ViewChild,
                args: ['editModal', { static: true }]
            }], formRenderer: [{
                type: ViewChild,
                args: [FormRendererComponent, { static: false }]
            }], unsavedChangesModal: [{
                type: ViewChild,
                args: [UnsavedChangesModalComponent, { static: true }]
            }], label: [{
                type: Input
            }], value: [{
                type: Input
            }], errorMessage: [{
                type: Input
            }], maxLength: [{
                type: Input
            }], validationRegex: [{
                type: Input
            }], showSpinner: [{
                type: Input
            }], showTextArea: [{
                type: Input
            }], valueIsOptional: [{
                type: Input
            }], editLinkText: [{
                type: Input
            }], submitButtonText: [{
                type: Input
            }], e2e: [{
                type: Input
            }], rightAlignEditButton: [{
                type: Input
            }], elementClass: [{
                type: Input
            }], borderBottom: [{
                type: Input
            }], lockScrim: [{
                type: Input
            }], confirmUnsavedChanges: [{
                type: Input
            }], cancelled: [{
                type: Output
            }], updated: [{
                type: Output
            }] } });

class ReasonModalEvent {
    constructor(submitted = false, reason = '') {
        this.submitted = submitted;
        this.reason = reason;
    }
}

class ReasonModalComponent extends BaseTextComponent {
    constructor(modalService, textService) {
        super(textService, 'ui-workflows-reason-modal');
        this.modalService = modalService;
        this.textService = textService;
        /**
        * Optional modal title. Default is "Provide Reason"
        **/
        this.title = '';
        /**
        * Optional description text.
        **/
        this.description = '';
        /**
        * Optional label for the textarea field. Default is "Please provide a reason:"
        **/
        this.label = '';
        /**
        * Optional. Max number of characters in the textarea. Default is 500.
        **/
        this.reasonMaxLength = FormUtils.defaultMaxLength;
        /**
        * Optional. Whether or not the primary button should dismiss all modals.
        **/
        this.primaryButtonDismissesAllModals = false;
        /**
        * Optional primary button text. Default is "Submit"
        **/
        this.primaryButtonText = '';
        /**
        * Optional secondary button text. Default is "Cancel"
        **/
        this.secondaryButtonText = '';
        /**
        * Optional. Whether or not submitting a reason in the textarea is required. Defaults to true
        **/
        this.isRequired = true;
        /**
        * Set to true to prevent the modal from closing when the scrim (backdrop) is clicked or when
        * the ESC key is pressed. The modal can only be dismissed via its close (X), cancel, or submit
        * buttons, or programmatically (e.g. modalService.dismissAll()).
        *
        * Use this for modals where closing mid-flow is not allowed (e.g. a required step that must complete).
        * For warning about unsaved form changes, use confirmUnsavedChanges instead.
        * Avoid setting both lockScrim and confirmUnsavedChanges to true — they have overlapping but
        * subtly different behavior and are not designed to be used together.
        **/
        this.lockScrim = false;
        /**
        * Set to true to show an unsaved changes confirmation when the user attempts to close the modal
        * via the close (X) button, scrim click, ESC key, or cancel button, and the form is dirty.
        * If the form has not been modified, the modal closes normally without a confirmation.
        *
        * Use this for form modals where the user could lose unsaved work.
        * For modals where closing mid-flow must be completely prevented, use lockScrim instead.
        * Avoid setting both confirmUnsavedChanges and lockScrim to true — they are not designed to be used together.
        **/
        this.confirmUnsavedChanges = false;
        this.checkUnsavedChangesHandler = this.checkUnsavedChanges.bind(this);
        /**
        * Emits when Cancel or Confirm buttons are clicked. Includes textarea value.
        **/
        this.clicked = new EventEmitter();
        this.valueEmitted = false;
        this.modalTitle = '';
        this.textareaLabel = '';
        this.submitButtonText = '';
        this.cancelButtonText = '';
        this.formRows = [];
    }
    show() {
        this.valueEmitted = false;
        this.modalTitle = this.title || this.text.modalTitle;
        this.textareaLabel = this.label || this.text.label;
        this.submitButtonText = this.primaryButtonText || this.text.submitButtonText;
        this.cancelButtonText = this.secondaryButtonText || this.text.cancelButtonText;
        const reasonField = new TextAreaField('reason', this.textareaLabel, '', this.isRequired);
        reasonField.collapsable = false;
        reasonField.fullWidth = true;
        reasonField.maxLength = this.reasonMaxLength;
        reasonField.errorMessage = this.text.requiredError;
        this.formRows = [new FormRendererRow([reasonField])];
        this.modalService.openNormalModal(this.reasonModal);
    }
    // Invoked by the modal's (onClose) event after the modal has closed.
    // Emits a cancellation if the modal was closed by X button, scrim click, or ESC key.
    modalClosed() {
        // There are ways of closing the modal without interacting with the primary/secondary buttons.
        // If one of them was used, treat that as a cancelation.
        if (!this.valueEmitted) {
            this.clicked.emit(new ReasonModalEvent(false));
        }
    }
    // beforeClose callback — invoked by the modal service on X button, scrim click, or ESC key.
    // Returns true (allow close) immediately if the form is clean; otherwise defers to the unsaved-changes modal.
    async checkUnsavedChanges() {
        if (!this.formRenderer?.form?.dirty) {
            return true;
        }
        return this.unsavedChangesModal.showUnsavedChangesModal();
    }
    // Handles clicks of the primary and secondary buttons.
    async onButtonClick(submitting, form) {
        if (form?.invalid) {
            return;
        }
        // If the form is dirty and confirmUnsavedChanges is true, show the unsaved changes confirmation modal. 
        // If the user chooses to cancel, do not proceed with closing the modal or emitting values.
        if (!submitting && this.confirmUnsavedChanges && this.formRenderer?.form?.dirty) {
            const shouldClose = await this.unsavedChangesModal.showUnsavedChangesModal();
            if (!shouldClose) {
                return;
            }
        }
        // There is a slight animation delay when closing the modal,
        // so emit values now instead of waiting for the close event.
        if (submitting) {
            const reasonValue = form.get('reason').value;
            this.clicked.emit(new ReasonModalEvent(true, reasonValue));
        }
        else {
            this.clicked.emit(new ReasonModalEvent(false));
        }
        this.valueEmitted = true;
        if (submitting && this.primaryButtonDismissesAllModals) {
            this.modalService.dismissAll();
        }
        else {
            this.modalService.closeMostRecentModal();
        }
    }
    getDefaultText() {
        return {
            modalTitle: 'Provide Reason',
            label: 'Please provide a reason:',
            submitButtonText: 'Submit',
            cancelButtonText: 'Cancel',
            requiredError: 'Required'
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: ReasonModalComponent, deps: [{ token: i2.ModalService }, { token: i2.TextService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.17", type: ReasonModalComponent, isStandalone: false, selector: "ui-workflows-reason-modal", inputs: { title: "title", description: "description", label: "label", reasonMaxLength: "reasonMaxLength", primaryButtonDismissesAllModals: "primaryButtonDismissesAllModals", primaryButtonText: "primaryButtonText", secondaryButtonText: "secondaryButtonText", isRequired: "isRequired", lockScrim: "lockScrim", confirmUnsavedChanges: "confirmUnsavedChanges" }, outputs: { clicked: "clicked" }, viewQueries: [{ propertyName: "reasonModal", first: true, predicate: ["reasonModal"], descendants: true, static: true }, { propertyName: "formRenderer", first: true, predicate: FormRendererComponent, descendants: true }, { propertyName: "unsavedChangesModal", first: true, predicate: UnsavedChangesModalComponent, descendants: true, static: true }], usesInheritance: true, ngImport: i0, template: "<ui-core-unsaved-changes-modal></ui-core-unsaved-changes-modal>\n\n<ng-template #reasonModal>\n    <ui-core-modal [title]=\"modalTitle\" e2e=\"reason\"\n        [lockScrim]=\"lockScrim\"\n        [beforeClose]=\"confirmUnsavedChanges ? checkUnsavedChangesHandler : null\"\n        [useFormRendererButtons]=\"true\"\n        (closed)=\"modalClosed()\">\n\n        @if (description) {\n            <div class=\"mb-5\">{{ description }}</div>\n        }\n\n        <ui-forms-form-renderer\n            [rows]=\"formRows\"\n            [primaryButtonText]=\"submitButtonText\"\n            [secondaryButtonText]=\"cancelButtonText\"\n            (primaryButtonClicked)=\"onButtonClick(true, $event)\"\n            (secondaryButtonClicked)=\"onButtonClick(false)\">\n        </ui-forms-form-renderer>\n    </ui-core-modal>\n</ng-template>\n", dependencies: [{ kind: "component", type: i2.ModalComponent, selector: "ui-core-modal", inputs: ["headerTemplate", "footerTemplate", "noBodyPadding", "noHeaderBorder", "useFormRendererButtons", "useFooterButtons", "showPrimarySpinner", "useGlassBackground"] }, { kind: "component", type: i2.UnsavedChangesModalComponent, selector: "ui-core-unsaved-changes-modal", inputs: ["title", "header", "message", "primaryButtonText", "secondaryButtonText", "lockScrim"] }, { kind: "component", type: i4.FormRendererComponent, selector: "ui-forms-form-renderer", inputs: ["rows", "disableButtons", "primaryButtonText", "primaryButtonDisabledText", "primaryButtonIcon", "primaryButtonIconPosition", "secondaryButtonText", "secondaryButtonClearsForm", "secondaryButtonUrl", "secondaryButtonUrlParams", "secondaryButtonUsesExternalUrlNewTab", "secondaryButtonIcon", "secondaryButtonIconPosition", "tertiaryButtonText", "tertiaryButtonIcon", "tertiaryButtonIconPosition", "tertiaryButtonUrl", "tertiaryButtonUrlParams", "tertiaryButtonUsesExternalUrlNewTab", "locked", "loading", "loadingMessage", "storeValuesOnSubmit", "storeValuesOnDestroy", "checkEditedValues", "e2e", "showNextField", "errorMessages", "autoFocus", "marginTop", "marginBottom", "enableBotDetection"], outputs: ["primaryButtonClicked", "secondaryButtonClicked", "tertiaryButtonClicked", "inputChange", "selection", "groupCategoryChange"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: ReasonModalComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-workflows-reason-modal', template: "<ui-core-unsaved-changes-modal></ui-core-unsaved-changes-modal>\n\n<ng-template #reasonModal>\n    <ui-core-modal [title]=\"modalTitle\" e2e=\"reason\"\n        [lockScrim]=\"lockScrim\"\n        [beforeClose]=\"confirmUnsavedChanges ? checkUnsavedChangesHandler : null\"\n        [useFormRendererButtons]=\"true\"\n        (closed)=\"modalClosed()\">\n\n        @if (description) {\n            <div class=\"mb-5\">{{ description }}</div>\n        }\n\n        <ui-forms-form-renderer\n            [rows]=\"formRows\"\n            [primaryButtonText]=\"submitButtonText\"\n            [secondaryButtonText]=\"cancelButtonText\"\n            (primaryButtonClicked)=\"onButtonClick(true, $event)\"\n            (secondaryButtonClicked)=\"onButtonClick(false)\">\n        </ui-forms-form-renderer>\n    </ui-core-modal>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i2.ModalService }, { type: i2.TextService }], propDecorators: { reasonModal: [{
                type: ViewChild,
                args: ['reasonModal', { static: true }]
            }], formRenderer: [{
                type: ViewChild,
                args: [FormRendererComponent, { static: false }]
            }], unsavedChangesModal: [{
                type: ViewChild,
                args: [UnsavedChangesModalComponent, { static: true }]
            }], title: [{
                type: Input
            }], description: [{
                type: Input
            }], label: [{
                type: Input
            }], reasonMaxLength: [{
                type: Input
            }], primaryButtonDismissesAllModals: [{
                type: Input
            }], primaryButtonText: [{
                type: Input
            }], secondaryButtonText: [{
                type: Input
            }], isRequired: [{
                type: Input
            }], lockScrim: [{
                type: Input
            }], confirmUnsavedChanges: [{
                type: Input
            }], clicked: [{
                type: Output
            }] } });

// Relative to whichever persona is viewing the conversation - not text/layout direction.
var ChatMessageDirection;
(function (ChatMessageDirection) {
    ChatMessageDirection["INCOMING"] = "INCOMING";
    ChatMessageDirection["OUTGOING"] = "OUTGOING";
})(ChatMessageDirection || (ChatMessageDirection = {}));

var ChatMessageSenderType;
(function (ChatMessageSenderType) {
    ChatMessageSenderType["ASSISTANT"] = "ASSISTANT";
    ChatMessageSenderType["MEMBER"] = "MEMBER";
    ChatMessageSenderType["ADMIN"] = "ADMIN";
    ChatMessageSenderType["SYSTEM"] = "SYSTEM";
})(ChatMessageSenderType || (ChatMessageSenderType = {}));

class ChatMessage {
    constructor() {
        this.message = '';
        this.senderName = '';
        this.senderType = ChatMessageSenderType.MEMBER;
        // Explicit, sender-agnostic positioning signal set by the consuming app based on its own persona.
        // Not derived from senderType so an admin surface and a member surface can each decide "who am I" independently.
        this.direction = ChatMessageDirection.INCOMING;
        this.navMatches = [];
        this.actions = [];
        this.hasClickedAction = false;
        this.sendActionErrorMessage = '';
    }
    get isFromMember() {
        return this.senderType === ChatMessageSenderType.MEMBER;
    }
    get isFromAssistant() {
        return this.senderType === ChatMessageSenderType.ASSISTANT;
    }
    get isFromAdmin() {
        return this.senderType === ChatMessageSenderType.ADMIN;
    }
    get isFromSystem() {
        return this.senderType === ChatMessageSenderType.SYSTEM;
    }
    get isOutgoing() {
        return this.direction === ChatMessageDirection.OUTGOING;
    }
    get isIncoming() {
        return this.direction === ChatMessageDirection.INCOMING;
    }
    // ASSISTANT/ADMIN always map to the same icon/bubble class regardless of which app is rendering them;
    // only the member bubble class varies per surface (e.g. chat-page's configurable member bubble colors),
    // so callers supply that one value rather than duplicating the whole mapping.
    static iconFor(message) {
        return message.senderType === ChatMessageSenderType.ASSISTANT ? 'auto_awesome' : 'person';
    }
    static cssClassFor(message, memberCssClass) {
        switch (message.senderType) {
            case ChatMessageSenderType.ASSISTANT:
                return 'assistant-message';
            case ChatMessageSenderType.ADMIN:
                return 'admin-message';
            default:
                return memberCssClass;
        }
    }
    static fromObject(data) {
        const chatMessage = new ChatMessage();
        chatMessage.message = data.message || '';
        chatMessage.messageId = data.messageId || undefined;
        chatMessage.senderType = data.senderType || ChatMessageSenderType.MEMBER;
        chatMessage.senderName = data.senderName || '';
        chatMessage.direction = data.direction || ChatMessageDirection.INCOMING;
        chatMessage.navMatches = data.navMatches || [];
        chatMessage.actions = data.actions || [];
        chatMessage.hasClickedAction = data.hasClickedAction || false;
        chatMessage.sendActionErrorMessage = data.sendActionErrorMessage || '';
        chatMessage.sentAt = data.sentAt || undefined;
        chatMessage.timestampText = data.timestampText || undefined;
        return chatMessage;
    }
}

var ChatMessageActionType;
(function (ChatMessageActionType) {
    ChatMessageActionType["REPLY"] = "REPLY";
    ChatMessageActionType["NAVIGATION"] = "NAVIGATION";
})(ChatMessageActionType || (ChatMessageActionType = {}));
var ChatMessageReplyActionRole;
(function (ChatMessageReplyActionRole) {
    ChatMessageReplyActionRole["CONFIRM"] = "CONFIRM";
    ChatMessageReplyActionRole["CANCEL"] = "CANCEL";
})(ChatMessageReplyActionRole || (ChatMessageReplyActionRole = {}));
class ChatMessageAction {
}

var ChatWindowMode;
(function (ChatWindowMode) {
    ChatWindowMode["CHAT"] = "CHAT";
    ChatWindowMode["HISTORY_LIST"] = "HISTORY_LIST";
    ChatWindowMode["HISTORY_DETAIL"] = "HISTORY_DETAIL";
})(ChatWindowMode || (ChatWindowMode = {}));

class ChatMessageBodyComponent {
    constructor() {
        /**
        * Optional. Whether or not a response is pending from the chat service; disables action buttons.
        **/
        this.pendingResponse = false;
        /**
        * Optional. The action most recently clicked, used to show a spinner on the matching button.
        **/
        this.clickedChatMessageAction = null;
        /**
        * Optional. Label shown before a single navigation match link.
        **/
        this.searchLinkMessage = '';
        /**
        * Optional. Label shown above multiple navigation match links.
        **/
        this.searchLinksMessage = '';
        /**
        * Emits the message and action when a reply/navigation action button is clicked.
        **/
        this.actionClicked = new EventEmitter();
        this.ChatMessageActionType = ChatMessageActionType;
        this.ChatMessageReplyActionRole = ChatMessageReplyActionRole;
    }
    onActionClick(action) {
        this.actionClicked.emit({ message: this.message, action });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: ChatMessageBodyComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.17", type: ChatMessageBodyComponent, isStandalone: false, selector: "ui-workflows-chat-message-body", inputs: { message: "message", pendingResponse: "pendingResponse", clickedChatMessageAction: "clickedChatMessageAction", searchLinkMessage: "searchLinkMessage", searchLinksMessage: "searchLinksMessage" }, outputs: { actionClicked: "actionClicked" }, ngImport: i0, template: "<div [innerHtml]=\"message.message\">\n</div>\n@if (message.timestampText) {\n    <div class=\"message-timestamp text-caption\" [class.text-color-secondary]=\"!message.isFromMember\" [class.color-white]=\"message.isFromMember\">{{ message.timestampText }}</div>\n}\n@if (message.navMatches?.length === 1) {\n    <div class=\"py-2\">\n        <span class=\"text-second\">{{ searchLinkMessage }}&nbsp;</span>\n        @for (match of message.navMatches; track match.url) {\n            <ui-core-link theme=\"link\" [link]=\"match.url\" [message]=\"match.title\">\n            </ui-core-link>\n        }\n    </div>\n}\n@if (message.navMatches?.length > 2) {\n    <div class=\"py-2 text-second\">\n        {{ searchLinksMessage }}\n    </div>\n    <ul>\n        @for (match of message.navMatches; track match.url) {\n            <li>\n                <ui-core-link theme=\"link\" [link]=\"match.url\" [message]=\"match.title\">\n                </ui-core-link>\n            </li>\n        }\n    </ul>\n}\n@if (message.actions?.length && message.actions?.length <= 2) {\n    <div class=\"assistant-message-actions pt-2\">\n        @for (action of message.actions; track action) {\n            <ui-core-button\n                [message]=\"action.text\"\n                themeGroup=\"neutral\"\n                [theme]=\"message.actions.length === 1 || action.role !== ChatMessageReplyActionRole.CANCEL ? 'secondary' : 'tertiary'\"\n                width=\"full\"\n                [icon]=\"action.clicked && !message.sendActionErrorMessage ? 'check' : ''\"\n                [attr.aria-disabled]=\"message.hasClickedAction && !message.sendActionErrorMessage ? 'true' : null\"\n                [disabled]=\"pendingResponse || (message.hasClickedAction && !message.sendActionErrorMessage)\"\n                [showSpinner]=\"action === clickedChatMessageAction && action.type === ChatMessageActionType.REPLY && pendingResponse\"\n                (click)=\"onActionClick(action)\">\n            </ui-core-button>\n        }\n    </div>\n    @if (message.sendActionErrorMessage) {\n        <ui-core-micro-notification class=\"pt-2\" [message]=\"message.sendActionErrorMessage\" theme=\"error\"></ui-core-micro-notification>\n    }\n}\n", styles: [":host{display:block}.assistant-message-actions{display:flex;flex-flow:column;gap:var(--spacing-50)}.message-timestamp{margin-top:var(--spacing-50)}\n"], dependencies: [{ kind: "component", type: i2.ButtonComponent, selector: "ui-core-button", inputs: ["themeGroup", "theme", "message", "icon", "iconPosition", "disabled", "disabledMessage", "showSpinner", "buttonClass", "width", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "ariaLabel", "isFormValid", "e2e", "buttonId"] }, { kind: "component", type: i2.LinkComponent, selector: "ui-core-link", inputs: ["themeGroup", "theme", "size", "link", "openLinkInNewTab", "message", "icon", "iconPosition", "disabled", "linkClass", "width", "ariaLabel", "e2e", "urlParams"] }, { kind: "component", type: i2.MicroNotificationComponent, selector: "ui-core-micro-notification", inputs: ["message", "boldText", "theme", "containerTheme", "icon", "animationPath", "animationData", "animationFreeze", "animationFreezeFrame", "animationLoop", "animationLoopTotal", "ariaPrefix"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: ChatMessageBodyComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-workflows-chat-message-body', standalone: false, template: "<div [innerHtml]=\"message.message\">\n</div>\n@if (message.timestampText) {\n    <div class=\"message-timestamp text-caption\" [class.text-color-secondary]=\"!message.isFromMember\" [class.color-white]=\"message.isFromMember\">{{ message.timestampText }}</div>\n}\n@if (message.navMatches?.length === 1) {\n    <div class=\"py-2\">\n        <span class=\"text-second\">{{ searchLinkMessage }}&nbsp;</span>\n        @for (match of message.navMatches; track match.url) {\n            <ui-core-link theme=\"link\" [link]=\"match.url\" [message]=\"match.title\">\n            </ui-core-link>\n        }\n    </div>\n}\n@if (message.navMatches?.length > 2) {\n    <div class=\"py-2 text-second\">\n        {{ searchLinksMessage }}\n    </div>\n    <ul>\n        @for (match of message.navMatches; track match.url) {\n            <li>\n                <ui-core-link theme=\"link\" [link]=\"match.url\" [message]=\"match.title\">\n                </ui-core-link>\n            </li>\n        }\n    </ul>\n}\n@if (message.actions?.length && message.actions?.length <= 2) {\n    <div class=\"assistant-message-actions pt-2\">\n        @for (action of message.actions; track action) {\n            <ui-core-button\n                [message]=\"action.text\"\n                themeGroup=\"neutral\"\n                [theme]=\"message.actions.length === 1 || action.role !== ChatMessageReplyActionRole.CANCEL ? 'secondary' : 'tertiary'\"\n                width=\"full\"\n                [icon]=\"action.clicked && !message.sendActionErrorMessage ? 'check' : ''\"\n                [attr.aria-disabled]=\"message.hasClickedAction && !message.sendActionErrorMessage ? 'true' : null\"\n                [disabled]=\"pendingResponse || (message.hasClickedAction && !message.sendActionErrorMessage)\"\n                [showSpinner]=\"action === clickedChatMessageAction && action.type === ChatMessageActionType.REPLY && pendingResponse\"\n                (click)=\"onActionClick(action)\">\n            </ui-core-button>\n        }\n    </div>\n    @if (message.sendActionErrorMessage) {\n        <ui-core-micro-notification class=\"pt-2\" [message]=\"message.sendActionErrorMessage\" theme=\"error\"></ui-core-micro-notification>\n    }\n}\n", styles: [":host{display:block}.assistant-message-actions{display:flex;flex-flow:column;gap:var(--spacing-50)}.message-timestamp{margin-top:var(--spacing-50)}\n"] }]
        }], propDecorators: { message: [{
                type: Input
            }], pendingResponse: [{
                type: Input
            }], clickedChatMessageAction: [{
                type: Input
            }], searchLinkMessage: [{
                type: Input
            }], searchLinksMessage: [{
                type: Input
            }], actionClicked: [{
                type: Output
            }] } });

class ChatMessageComponent {
    constructor() {
        /**
        * Avatar icon shown in the message header. Ignored for SYSTEM messages.
        **/
        this.icon = '';
        /**
        * Label shown next to the avatar in the message header. Ignored for SYSTEM messages.
        **/
        this.label = '';
        /**
        * Bubble background/text CSS class(es), e.g. 'assistant-message'. Ignored for SYSTEM messages.
        **/
        this.cssClass = '';
        /**
        * Optional. Whether or not a response is pending from the chat service; disables action buttons.
        **/
        this.pendingResponse = false;
        /**
        * Optional. The action most recently clicked, used to show a spinner on the matching button.
        **/
        this.clickedChatMessageAction = null;
        /**
        * Optional. Label shown before a single navigation match link.
        **/
        this.searchLinkMessage = '';
        /**
        * Optional. Label shown above multiple navigation match links.
        **/
        this.searchLinksMessage = '';
        /**
        * Emits the message and action when a reply/navigation action button is clicked.
        **/
        this.actionClicked = new EventEmitter();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: ChatMessageComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.17", type: ChatMessageComponent, isStandalone: false, selector: "ui-workflows-chat-message", inputs: { message: "message", icon: "icon", label: "label", cssClass: "cssClass", pendingResponse: "pendingResponse", clickedChatMessageAction: "clickedChatMessageAction", searchLinkMessage: "searchLinkMessage", searchLinksMessage: "searchLinksMessage" }, outputs: { actionClicked: "actionClicked" }, ngImport: i0, template: "@if (message.isFromSystem) {\n    <div class=\"d-flex justify-content-center mb-2\">\n        <ui-core-badge\n            [message]=\"message.message\"\n            theme=\"neutral\"\n            [framed]=\"true\">\n        </ui-core-badge>\n    </div>\n} @else {\n    <div class=\"d-flex mb-2\" [class.justify-content-end]=\"message.isOutgoing\">\n        <div [ngClass]=\"cssClass\" [class.mr-7]=\"message.isIncoming\" [class.ml-7]=\"message.isOutgoing\">\n            <div class=\"d-flex mb-1\" [class.justify-content-end]=\"message.isOutgoing\">\n                <ui-core-avatar backgroundClass=\"bg-brand-secondary\" [icon]=\"icon\" size=\"xs\">\n                </ui-core-avatar>\n                <span class=\"text-caption text-strong ml-1\">{{ label }}</span>\n            </div>\n            <ui-workflows-chat-message-body\n                [message]=\"message\"\n                [pendingResponse]=\"pendingResponse\"\n                [clickedChatMessageAction]=\"clickedChatMessageAction\"\n                [searchLinkMessage]=\"searchLinkMessage\"\n                [searchLinksMessage]=\"searchLinksMessage\"\n                (actionClicked)=\"actionClicked.emit($event)\">\n            </ui-workflows-chat-message-body>\n        </div>\n    </div>\n}\n", styles: [":host{display:block}.assistant-message,.admin-message,.user-message{width:fit-content;border:1px solid var(--color-stroke-1);border-radius:14px;font-size:var(--type-body2-size);padding:12px;overflow-wrap:break-word;word-break:break-word}.assistant-message{background-color:var(--color-sunken)}.admin-message{background-color:var(--color-gray-100)}.user-message{color:var(--color-content-neutral)}\n"], dependencies: [{ kind: "directive", type: i2$1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: i2.AvatarComponent, selector: "ui-core-avatar", inputs: ["ariaLabel", "backgroundClass", "colorClass", "completed", "disabled", "icon", "imageRotationClass", "imageUrl", "shape", "size", "progressValue", "progressMax", "progressAnimationStart"] }, { kind: "component", type: i2.BadgeComponent, selector: "ui-core-badge", inputs: ["message", "framed", "theme", "type", "centered", "icon", "iconPosition"] }, { kind: "component", type: ChatMessageBodyComponent, selector: "ui-workflows-chat-message-body", inputs: ["message", "pendingResponse", "clickedChatMessageAction", "searchLinkMessage", "searchLinksMessage"], outputs: ["actionClicked"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: ChatMessageComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-workflows-chat-message', standalone: false, template: "@if (message.isFromSystem) {\n    <div class=\"d-flex justify-content-center mb-2\">\n        <ui-core-badge\n            [message]=\"message.message\"\n            theme=\"neutral\"\n            [framed]=\"true\">\n        </ui-core-badge>\n    </div>\n} @else {\n    <div class=\"d-flex mb-2\" [class.justify-content-end]=\"message.isOutgoing\">\n        <div [ngClass]=\"cssClass\" [class.mr-7]=\"message.isIncoming\" [class.ml-7]=\"message.isOutgoing\">\n            <div class=\"d-flex mb-1\" [class.justify-content-end]=\"message.isOutgoing\">\n                <ui-core-avatar backgroundClass=\"bg-brand-secondary\" [icon]=\"icon\" size=\"xs\">\n                </ui-core-avatar>\n                <span class=\"text-caption text-strong ml-1\">{{ label }}</span>\n            </div>\n            <ui-workflows-chat-message-body\n                [message]=\"message\"\n                [pendingResponse]=\"pendingResponse\"\n                [clickedChatMessageAction]=\"clickedChatMessageAction\"\n                [searchLinkMessage]=\"searchLinkMessage\"\n                [searchLinksMessage]=\"searchLinksMessage\"\n                (actionClicked)=\"actionClicked.emit($event)\">\n            </ui-workflows-chat-message-body>\n        </div>\n    </div>\n}\n", styles: [":host{display:block}.assistant-message,.admin-message,.user-message{width:fit-content;border:1px solid var(--color-stroke-1);border-radius:14px;font-size:var(--type-body2-size);padding:12px;overflow-wrap:break-word;word-break:break-word}.assistant-message{background-color:var(--color-sunken)}.admin-message{background-color:var(--color-gray-100)}.user-message{color:var(--color-content-neutral)}\n"] }]
        }], propDecorators: { message: [{
                type: Input
            }], icon: [{
                type: Input
            }], label: [{
                type: Input
            }], cssClass: [{
                type: Input
            }], pendingResponse: [{
                type: Input
            }], clickedChatMessageAction: [{
                type: Input
            }], searchLinkMessage: [{
                type: Input
            }], searchLinksMessage: [{
                type: Input
            }], actionClicked: [{
                type: Output
            }] } });

class ChatWindowComponent extends BaseTextComponent {
    get unreadCountDisplay() {
        return Math.min(this.unreadCount, 99).toString();
    }
    get historyButtonCardItems() {
        return this.chatHistorySessions.map(session => {
            const item = new ButtonCardItem(session.title, session.sessionId);
            item.leftTitleSize = 'caption';
            return item;
        });
    }
    constructor(formBuilder, textService, windowService, router) {
        super(textService, 'ui-workflows-chat-window');
        this.formBuilder = formBuilder;
        this.textService = textService;
        this.windowService = windowService;
        this.router = router;
        /**
        * Optional title for the chat window.
        **/
        this.title = '';
        /**
        * Optional. The message to show if loading the chat fails.
        **/
        this.failedToLoadMessage = '';
        /**
        * Optional. The message to show if sending an action fails.
        **/
        this.failedToSendActionMessage = '';
        /**
        * Optional. Whether or not the chat window is visible.
        **/
        this.isVisible = true;
        /**
        * Optional. Whether or not to anchor the chat button to the bottom right of the screen.
        **/
        this.anchorChatButton = true;
        /**
        * Optional. Whether or not the chat component is loading.
        **/
        this.loading = false;
        /**
        * Optional. Whether or not a response is pending from the chat service.
        **/
        this.pendingResponse = false;
        /**
        * Optional. The messages to show in the chat.
        **/
        this.messages = [];
        /**
        * Optional. The unread message count to show as a badge on the floating chat button while minimized.
        * A value of 0 (the default) hides the badge. Values over 99 display as 99.
        **/
        this.unreadCount = 0;
        /**
        * Optional. Previous chat sessions to show on the Chat History screen.
        **/
        this.chatHistorySessions = [];
        /**
        * Emits the attach file event when the attach file button is clicked.
        **/
        this.attachFileClicked = new EventEmitter();
        /**
        * Emits when the chat window is closed.
        **/
        this.closed = new EventEmitter();
        /**
        * Emits the search value when the Search button is clicked.
        **/
        this.searched = new EventEmitter();
        /**
        * Emits the voice input event when the voice input button is clicked.
        **/
        this.voiceClicked = new EventEmitter();
        /**
        * Emits the action object when a chat message action is clicked.
        **/
        this.action = new EventEmitter();
        this.chatIconButtons = [];
        this.dragPosition = { x: 0, y: 0 };
        this.isMinimized = true;
        this.isMobile = false;
        this.mode = ChatWindowMode.CHAT;
        this.selectedHistorySession = null;
        this.ChatWindowMode = ChatWindowMode;
        this.searchFormId = HtmlUtils.generateRandomId();
        this.searchForm = null;
        this.clickedChatMessageAction = null;
        this.attachFileIcon = 'attach_file';
        this.micIcon = 'mic';
        this.sendMessageIcon = 'arrow_forward';
        this.lastMessageContent = '';
        this.lastTrackedMessage = null;
        this.windowService.windowSize$.pipe(this.takeUntilDestroyed()).subscribe(windowSize => {
            this.isMobile = windowSize.isMobile;
            if (!this.isMobile) {
                this.resetChatWindowPosition();
            }
        });
    }
    ngOnInit() {
        this.chatTitle = this.title || this.text.chatTitle;
        this.chatButtonAriaLabel = format(this.text.chatButtonAriaLabel, { title: this.chatTitle });
        this.chatIconButtons = [
            new TextAreaIconButton(this.attachFileIcon, this.text.attachFileAriaLabel, 'left'),
            new TextAreaIconButton(this.micIcon, this.text.voiceInputAriaLabel, 'left'),
            new TextAreaIconButton(this.sendMessageIcon, this.text.sendMessageAriaLabel, 'right'),
        ];
        this.resetChatWindowPosition();
        this.searchForm = this.formBuilder.group({
            search: this.formBuilder.control('')
        });
    }
    ngOnChanges(changes) {
        if (changes.messages && this.messages?.length) {
            // Track the last incoming (non-member) message so streamed replies from either the
            // assistant or a live agent auto-scroll the chat body as their content grows.
            const lastIncomingMessage = this.messages.filter(m => !m.isFromMember).at(-1);
            this.lastTrackedMessage = lastIncomingMessage ?? null;
            this.lastMessageContent = lastIncomingMessage?.message ?? '';
        }
        if (!this.isMinimized && (changes.messages && this.messages?.length || changes.pendingResponse && this.pendingResponse)) {
            this.scrollFooterIntoView();
        }
        if (changes.failedToSendActionMessage && this.failedToSendActionMessage && this.clickedChatMessageAction) {
            const clickedAction = this.clickedChatMessageAction;
            const owningMessage = this.messages.find(m => m.actions?.includes(clickedAction));
            if (owningMessage) {
                owningMessage.sendActionErrorMessage = this.failedToSendActionMessage;
            }
        }
        if (changes.pendingResponse && !this.pendingResponse) {
            this.clickedChatMessageAction = null;
        }
    }
    ngDoCheck() {
        // Streaming replies mutate the message object in place, so ngOnChanges never fires for them.
        // Compare length (O(1)) against the baseline set by ngOnChanges to detect growth and scroll.
        const currentContent = this.lastTrackedMessage?.message ?? '';
        if (!this.isMinimized && currentContent.length > this.lastMessageContent.length) {
            this.lastMessageContent = currentContent;
            this.scrollFooterIntoView();
        }
    }
    toggleChatWindow() {
        this.isMinimized = !this.isMinimized;
        this.resetChatWindowPosition();
        if (!this.isMinimized) {
            this.focusSearchField();
        }
    }
    openChatHistory() {
        this.mode = ChatWindowMode.HISTORY_LIST;
    }
    selectChatHistorySession(sessionId) {
        this.selectedHistorySession = this.chatHistorySessions.find(session => session.sessionId === sessionId) ?? null;
        this.mode = ChatWindowMode.HISTORY_DETAIL;
    }
    backToChat() {
        this.mode = ChatWindowMode.CHAT;
    }
    backToChatHistory() {
        this.selectedHistorySession = null;
        this.openChatHistory();
    }
    submitSearch() {
        const message = this.searchForm?.get('search')?.value || '';
        if (message) {
            this.searched.emit(message);
            this.searchForm?.reset();
        }
    }
    onIconButtonClick(button) {
        if (button.icon === this.sendMessageIcon) {
            this.submitSearch();
        }
        if (button.icon === this.attachFileIcon) {
            this.attachFileClicked.emit(); // TODO: actual file handling
        }
        if (button.icon === this.micIcon) {
            this.voiceClicked.emit(); // TODO: actual voice input handling
        }
    }
    onChatMessageActionClick(message, action) {
        // Reset prior failure state so a retry click starts clean.
        message.sendActionErrorMessage = '';
        message.actions.forEach(a => a.clicked = false);
        // Mark the chosen action, then dispatch: REPLY emits to the parent; NAVIGATION routes inline.
        action.clicked = true;
        message.hasClickedAction = true;
        this.clickedChatMessageAction = action;
        switch (action.type) {
            case ChatMessageActionType.REPLY:
                this.action.emit(action);
                break;
            case ChatMessageActionType.NAVIGATION:
                HtmlUtils.handleAction(action, this.router);
                break;
        }
    }
    messageIcon(message) {
        return ChatMessage.iconFor(message);
    }
    messageLabel(message) {
        switch (message.senderType) {
            case ChatMessageSenderType.ASSISTANT:
                return message.senderName || this.chatTitle;
            case ChatMessageSenderType.ADMIN:
                return message.senderName;
            default:
                return message.senderName || this.text.memberLabel;
        }
    }
    messageCssClass(message) {
        return ChatMessage.cssClassFor(message, 'user-message bg-brand-primary color-white');
    }
    closeChatWindow() {
        this.confirmationModal.show();
    }
    onConfirmationModalClick(event) {
        if (event.confirm) {
            this.isVisible = false;
            this.closed.emit();
        }
    }
    resetChatWindowPosition() {
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;
        // On mobile, full-screen when expanded; on desktop, bottom-right corner
        if (this.isMobile && !this.isMinimized || !this.anchorChatButton) {
            // Full-screen on mobile
            this.dragPosition = { x: 0, y: 0 };
        }
        else {
            // Bottom-right corner (desktop or minimized)
            const windowWidth = this.isMinimized ? 64 : 400;
            const windowHeight = this.isMinimized ? 64 : 600;
            const margin = 20;
            let bottomOffset = margin;
            if (this.isMobile && this.isMinimized) {
                bottomOffset += parseFloat(NativeVariableUtils.getCustomValue('--nav-footer-height')) || 0;
            }
            this.dragPosition = {
                x: viewportWidth - windowWidth - margin,
                y: viewportHeight - windowHeight - bottomOffset
            };
        }
    }
    focusSearchField() {
        setTimeout(() => {
            const formContainer = document.getElementById(this.searchFormId);
            if (formContainer) {
                FormUtils.focusSpecificField(formContainer, 'search');
            }
        }, 10);
    }
    scrollFooterIntoView() {
        setTimeout(() => {
            if (this.chatBody) {
                const el = this.chatBody.nativeElement;
                el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' });
            }
        }, 10);
    }
    getDefaultText() {
        return {
            chatTitle: 'Chat',
            chatButtonAriaLabel: 'Open {{ title }}',
            backButtonAriaLabel: 'Back',
            minimizeButtonAriaLabel: 'Minimize Chat',
            closeButtonAriaLabel: 'Close Chat',
            chatHistoryButtonAriaLabel: 'Chat History',
            chatHistoryTitle: 'Chat History',
            backToChatMessage: 'Back to Chat',
            backToChatHistoryMessage: 'Back to Chat History',
            noChatHistoryMessage: 'You have no previous chats.',
            endChatConfirmationModalTitle: 'End Chat',
            endChatConfirmationModalMessage: 'Are you sure you want to end this chat?',
            endChatConfirmationModalPrimaryButtonText: 'End Chat',
            endChatConfirmationModalSecondaryButtonText: 'Cancel',
            loadingMessage: 'Loading...',
            searchLinkMessage: 'For more information, check out this link:',
            searchLinksMessage: 'For more information, check out these links:',
            memberLabel: 'You',
            chatInputPlaceholder: 'Type a message...',
            attachFileAriaLabel: 'Attach file',
            voiceInputAriaLabel: 'Voice input',
            sendMessageAriaLabel: 'Send message',
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: ChatWindowComponent, deps: [{ token: i1.UntypedFormBuilder }, { token: i2.TextService }, { token: i2.WindowService }, { token: i3.Router }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.17", type: ChatWindowComponent, isStandalone: false, selector: "ui-workflows-chat-window", inputs: { title: "title", headerBadge: "headerBadge", failedToLoadMessage: "failedToLoadMessage", failedToSendActionMessage: "failedToSendActionMessage", isVisible: "isVisible", anchorChatButton: "anchorChatButton", loading: "loading", pendingResponse: "pendingResponse", messages: "messages", unreadCount: "unreadCount", chatHistorySessions: "chatHistorySessions" }, outputs: { attachFileClicked: "attachFileClicked", closed: "closed", searched: "searched", voiceClicked: "voiceClicked", action: "action" }, viewQueries: [{ propertyName: "chatBody", first: true, predicate: ["chatBody"], descendants: true }, { propertyName: "confirmationModal", first: true, predicate: ConfirmationModalComponent, descendants: true, static: true }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "@if (isVisible) {\n    <div class=\"chat-window-container\" id=\"chatWindowContainer\"\n        cdkDrag\n        [cdkDragDisabled]=\"isMinimized || isMobile\"\n        [cdkDragFreeDragPosition]=\"dragPosition\"\n        [class.minimized]=\"isMinimized\"\n        [class.mobile-fullscreen]=\"isMobile && !isMinimized\">\n\n        @if (isMinimized) {\n            <button class=\"chat-floating-button\" type=\"button\"\n                aria-controls=\"chatWindowContainer\"\n                [attr.aria-expanded]=\"!isMinimized\"\n                [attr.aria-label]=\"chatButtonAriaLabel\"\n                (click)=\"toggleChatWindow()\">\n                <ui-core-icon colorClass=\"color-white\" icon=\"svg_support_hub\" size=\"xxxl\">\n                </ui-core-icon>\n                @if (unreadCount > 0) {\n                    <ui-core-badge\n                        class=\"chat-floating-button-badge\"\n                        type=\"badge\"\n                        theme=\"error\"\n                        [message]=\"unreadCountDisplay\">\n                    </ui-core-badge>\n                }\n            </button>\n        } @else {\n            @switch (mode) {\n                @case (ChatWindowMode.HISTORY_LIST) {\n                    <div class=\"chat-window-header chat-window-header-compact\" [class.cursor-grab]=\"!isMinimized\" cdkDragHandle>\n                        <div class=\"chat-window-title\">\n                            <ui-core-back-button [message]=\"text.backToChatMessage\" (clicked)=\"backToChat()\">\n                            </ui-core-back-button>\n                        </div>\n                    </div>\n\n                    <div class=\"chat-window-body\">\n                        <div class=\"text-caption text-semibold text-color-secondary chat-history-title\">{{ text.chatHistoryTitle }}</div>\n                        @if (chatHistorySessions.length) {\n                            <ui-core-button-cards\n                                [items]=\"historyButtonCardItems\"\n                                [compactSpacing]=\"true\"\n                                [desktopColumns]=\"1\"\n                                [tabletColumns]=\"1\"\n                                [ariaLabel]=\"text.chatHistoryTitle\"\n                                (itemClicked)=\"selectChatHistorySession($event)\">\n                            </ui-core-button-cards>\n                        } @else {\n                            <p class=\"text-second\">{{ text.noChatHistoryMessage }}</p>\n                        }\n                    </div>\n                }\n                @case (ChatWindowMode.HISTORY_DETAIL) {\n                    <div class=\"chat-window-header chat-window-header-compact\" [class.cursor-grab]=\"!isMinimized\" cdkDragHandle>\n                        <div class=\"chat-window-title\">\n                            <ui-core-back-button [message]=\"text.backToChatHistoryMessage\" (clicked)=\"backToChatHistory()\">\n                            </ui-core-back-button>\n                        </div>\n                    </div>\n\n                    <div class=\"chat-window-body\">\n                        @if (selectedHistorySession) {\n                            <div class=\"search-messages-container mb-4\">\n                                @for (message of selectedHistorySession.messages; track $index) {\n                                    <ui-workflows-chat-message\n                                        [message]=\"message\"\n                                        [icon]=\"messageIcon(message)\"\n                                        [label]=\"messageLabel(message)\"\n                                        [cssClass]=\"messageCssClass(message)\"\n                                        [searchLinkMessage]=\"text.searchLinkMessage\"\n                                        [searchLinksMessage]=\"text.searchLinksMessage\">\n                                    </ui-workflows-chat-message>\n                                }\n                            </div>\n                        }\n                    </div>\n                }\n                @default {\n                    <div class=\"chat-window-header\" [class.cursor-grab]=\"!isMinimized\" cdkDragHandle>\n                        <div class=\"chat-window-title\">\n                            <ui-core-icon-button icon=\"arrow_back\" [message]=\"text.backButtonAriaLabel\" size=\"lg\"\n                                (click)=\"toggleChatWindow()\">\n                            </ui-core-icon-button>\n                            <h4 class=\"text-strong mb-0\">{{ chatTitle }}</h4>\n                            @if (headerBadge) {\n                                <ui-core-badge\n                                    [message]=\"headerBadge.message\"\n                                    [icon]=\"headerBadge.icon\"\n                                    [theme]=\"headerBadge.theme\"\n                                    [framed]=\"true\">\n                                </ui-core-badge>\n                            }\n                        </div>\n                        <div class=\"chat-window-actions\">\n                            <ui-core-icon-button icon=\"history\" [message]=\"text.chatHistoryButtonAriaLabel\" size=\"lg\"\n                                (click)=\"openChatHistory()\">\n                            </ui-core-icon-button>\n                            <ui-core-icon-button icon=\"minimize\" [message]=\"text.minimizeButtonAriaLabel\" size=\"lg\" class=\"mt-n3\"\n                                (click)=\"toggleChatWindow()\">\n                            </ui-core-icon-button>\n                            <ui-core-icon-button icon=\"close\" [message]=\"text.closeButtonAriaLabel\" size=\"lg\"\n                                (click)=\"closeChatWindow()\">\n                            </ui-core-icon-button>\n                        </div>\n                    </div>\n\n                    <div #chatBody class=\"chat-window-body\">\n                        @if (loading) {\n                            <div class=\"mt-5\">\n                                <ui-core-spinner [centered]=\"true\" [message]=\"text.loadingMessage\" size=\"h2\">\n                                </ui-core-spinner>\n                            </div>\n                        }\n                        @if (failedToLoadMessage) {\n                            <ui-core-in-line-notification [header]=\"failedToLoadMessage\" theme=\"error\">\n                            </ui-core-in-line-notification>\n                        }\n                        @if (!loading && messages.length) {\n                            <div class=\"search-messages-container mb-4\">\n                                @for (message of messages; track $index) {\n                                    <ui-workflows-chat-message\n                                        [message]=\"message\"\n                                        [icon]=\"messageIcon(message)\"\n                                        [label]=\"messageLabel(message)\"\n                                        [cssClass]=\"messageCssClass(message)\"\n                                        [pendingResponse]=\"pendingResponse\"\n                                        [clickedChatMessageAction]=\"clickedChatMessageAction\"\n                                        [searchLinkMessage]=\"text.searchLinkMessage\"\n                                        [searchLinksMessage]=\"text.searchLinksMessage\"\n                                        (actionClicked)=\"onChatMessageActionClick($event.message, $event.action)\">\n                                    </ui-workflows-chat-message>\n                                }\n                                @if (pendingResponse) {\n                                    <div class=\"d-flex\">\n                                        <div class=\"assistant-message pending-response mr-7 mb-2\">\n                                            <div class=\"d-flex mb-1\">\n                                                <ui-core-avatar backgroundClass=\"bg-brand-secondary\" icon=\"auto_awesome\" size=\"xs\">\n                                                </ui-core-avatar>\n                                                <span class=\"text-caption text-strong ml-1\">{{ chatTitle }}</span>\n                                            </div>\n                                            <ui-core-spinner size=\"sm\"></ui-core-spinner>\n                                        </div>\n                                    </div>\n                                }\n                            </div>\n                        }\n                    </div>\n\n                    <form [formGroup]=\"searchForm\" class=\"search-form\" [id]=\"searchFormId\">\n                        @if (!failedToLoadMessage) {\n                            <ui-forms-text-area\n                                [iconButtons]=\"chatIconButtons\"\n                                [rows]=\"1\"\n                                [maxRows]=\"5\"\n                                formControlName=\"search\"\n                                [hideLabel]=\"true\"\n                                [placeholder]=\"text.chatInputPlaceholder\"\n                                [preventNewLines]=\"true\"\n                                (keyup.enter)=\"submitSearch()\"\n                                (iconButtonClicked)=\"onIconButtonClick($event)\">\n                            </ui-forms-text-area>\n                        }\n                    </form>\n                }\n            }\n        }\n    </div>\n}\n\n<ui-workflows-confirmation-modal\n    [title]=\"text.endChatConfirmationModalTitle\"\n    [message]=\"text.endChatConfirmationModalMessage\"\n    [primaryButtonText]=\"text.endChatConfirmationModalPrimaryButtonText\"\n    [secondaryButtonText]=\"text.endChatConfirmationModalSecondaryButtonText\"\n    (clicked)=\"onConfirmationModalClick($event)\">\n</ui-workflows-confirmation-modal>\n", styles: [".chat-window-container{position:fixed;top:0;left:0;width:400px;height:600px;background:var(--color-default);border-radius:14px;box-shadow:var(--elevation-4);display:flex;flex-direction:column;z-index:var(--z-index-fixed)}.chat-window-container.minimized{width:48px;height:48px;border-radius:var(--containers-shape);background:transparent;box-shadow:none}.chat-window-container:not(.minimized){padding:0 20px}.chat-window-container.mobile-fullscreen{width:100vw;height:100vh;border-radius:0;max-height:100vh}.chat-floating-button{position:relative;width:48px;height:48px;border-radius:var(--containers-shape);background:var(--color-primary);border:none;display:flex;align-items:center;justify-content:center;cursor:pointer;box-shadow:var(--elevation-2);transition:transform .2s ease,box-shadow .2s ease;padding:0}.chat-floating-button:hover{transform:scale(1.05);box-shadow:var(--elevation-4)}.chat-floating-button:active{transform:scale(.95)}.chat-floating-button-badge{position:absolute;top:0;right:0;transform:translate(50%,-50%);box-shadow:var(--elevation-1)}.chat-window-header{display:flex;justify-content:space-between;align-items:center;margin:20px 0;-webkit-user-select:none;user-select:none}.chat-window-header.chat-window-header-compact{margin-bottom:0}.chat-history-title{margin-bottom:var(--spacing-150)}.chat-window-body{flex:1;overflow-y:auto;margin-top:20px}.chat-window-container.mobile-fullscreen .chat-window-body{height:100%}.chat-window-title{display:flex;align-items:center;gap:8px}.chat-window-actions{display:flex;align-items:center;gap:12px}.assistant-message{width:fit-content;border:1px solid var(--color-stroke-1);border-radius:14px;font-size:var(--type-body2-size);padding:12px;overflow-wrap:break-word;word-break:break-word;background-color:var(--color-sunken)}\n"], dependencies: [{ kind: "directive", type: i4$1.CdkDrag, selector: "[cdkDrag]", inputs: ["cdkDragData", "cdkDragLockAxis", "cdkDragRootElement", "cdkDragBoundary", "cdkDragStartDelay", "cdkDragFreeDragPosition", "cdkDragDisabled", "cdkDragConstrainPosition", "cdkDragPreviewClass", "cdkDragPreviewContainer", "cdkDragScale"], outputs: ["cdkDragStarted", "cdkDragReleased", "cdkDragEnded", "cdkDragEntered", "cdkDragExited", "cdkDragDropped", "cdkDragMoved"], exportAs: ["cdkDrag"] }, { kind: "directive", type: i4$1.CdkDragHandle, selector: "[cdkDragHandle]", inputs: ["cdkDragHandleDisabled"] }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i2.AvatarComponent, selector: "ui-core-avatar", inputs: ["ariaLabel", "backgroundClass", "colorClass", "completed", "disabled", "icon", "imageRotationClass", "imageUrl", "shape", "size", "progressValue", "progressMax", "progressAnimationStart"] }, { kind: "component", type: i2.BackButtonComponent, selector: "ui-core-back-button", inputs: ["message", "url", "e2e"], outputs: ["clicked"] }, { kind: "component", type: i2.BadgeComponent, selector: "ui-core-badge", inputs: ["message", "framed", "theme", "type", "centered", "icon", "iconPosition"] }, { kind: "component", type: i2.ButtonCardsComponent, selector: "ui-core-button-cards", inputs: ["header", "subheader", "items", "mobileColumns", "tabletColumns", "desktopColumns", "compactSpacing", "horizontalScroll", "cardShadow", "centerIcon", "iconSize", "ariaLabel"], outputs: ["itemClicked"] }, { kind: "component", type: i2.IconComponent, selector: "ui-core-icon", inputs: ["icon", "size", "colorClass", "allowEmojis", "ariaLabel", "alignWithText", "collapseHeight", "scaleWithFonts", "animationPath", "animationData", "animationFreeze", "animationFreezeFrame", "animationLoop", "animationLoopTotal"], outputs: ["animationCompleted"] }, { kind: "component", type: i2.IconButtonComponent, selector: "ui-core-icon-button", inputs: ["message", "icon", "size", "disabled", "buttonClass", "ariaPressed", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "e2e", "theme", "usesGlassHoverState", "buttonId"] }, { kind: "component", type: i2.InLineNotificationComponent, selector: "ui-core-in-line-notification", inputs: ["header", "message", "bulletList", "theme", "customIcon", "customAnimationPath", "customAnimationData", "customAnimationFreeze", "customAnimationFreezeFrame", "customAnimationLoop", "customAnimationLoopTotal", "buttons", "showCloseButton"], outputs: ["buttonClicked", "closed"] }, { kind: "component", type: i2.SpinnerComponent, selector: "ui-core-spinner", inputs: ["message", "size", "buttonIcon", "hideSpinner", "centered", "delayMs", "buttonSpinner"] }, { kind: "component", type: i4.TextAreaComponent, selector: "ui-forms-text-area", inputs: ["collapsable", "maxLength", "maxRows", "placeholder", "preventNewLines", "rows", "showCharactersRemaining", "iconButtons"], outputs: ["iconButtonClicked"] }, { kind: "component", type: ChatMessageComponent, selector: "ui-workflows-chat-message", inputs: ["message", "icon", "label", "cssClass", "pendingResponse", "clickedChatMessageAction", "searchLinkMessage", "searchLinksMessage"], outputs: ["actionClicked"] }, { kind: "component", type: ConfirmationModalComponent, selector: "ui-workflows-confirmation-modal", inputs: ["title", "message", "additionalMessage", "bulletListLabel", "bulletListLabelClasses", "bulletListItems", "showDontShowAgainCheckbox", "primaryButtonDismissesAllModals", "primaryButtonText", "secondaryButtonText", "lockScrim"], outputs: ["clicked"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: ChatWindowComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-workflows-chat-window', standalone: false, template: "@if (isVisible) {\n    <div class=\"chat-window-container\" id=\"chatWindowContainer\"\n        cdkDrag\n        [cdkDragDisabled]=\"isMinimized || isMobile\"\n        [cdkDragFreeDragPosition]=\"dragPosition\"\n        [class.minimized]=\"isMinimized\"\n        [class.mobile-fullscreen]=\"isMobile && !isMinimized\">\n\n        @if (isMinimized) {\n            <button class=\"chat-floating-button\" type=\"button\"\n                aria-controls=\"chatWindowContainer\"\n                [attr.aria-expanded]=\"!isMinimized\"\n                [attr.aria-label]=\"chatButtonAriaLabel\"\n                (click)=\"toggleChatWindow()\">\n                <ui-core-icon colorClass=\"color-white\" icon=\"svg_support_hub\" size=\"xxxl\">\n                </ui-core-icon>\n                @if (unreadCount > 0) {\n                    <ui-core-badge\n                        class=\"chat-floating-button-badge\"\n                        type=\"badge\"\n                        theme=\"error\"\n                        [message]=\"unreadCountDisplay\">\n                    </ui-core-badge>\n                }\n            </button>\n        } @else {\n            @switch (mode) {\n                @case (ChatWindowMode.HISTORY_LIST) {\n                    <div class=\"chat-window-header chat-window-header-compact\" [class.cursor-grab]=\"!isMinimized\" cdkDragHandle>\n                        <div class=\"chat-window-title\">\n                            <ui-core-back-button [message]=\"text.backToChatMessage\" (clicked)=\"backToChat()\">\n                            </ui-core-back-button>\n                        </div>\n                    </div>\n\n                    <div class=\"chat-window-body\">\n                        <div class=\"text-caption text-semibold text-color-secondary chat-history-title\">{{ text.chatHistoryTitle }}</div>\n                        @if (chatHistorySessions.length) {\n                            <ui-core-button-cards\n                                [items]=\"historyButtonCardItems\"\n                                [compactSpacing]=\"true\"\n                                [desktopColumns]=\"1\"\n                                [tabletColumns]=\"1\"\n                                [ariaLabel]=\"text.chatHistoryTitle\"\n                                (itemClicked)=\"selectChatHistorySession($event)\">\n                            </ui-core-button-cards>\n                        } @else {\n                            <p class=\"text-second\">{{ text.noChatHistoryMessage }}</p>\n                        }\n                    </div>\n                }\n                @case (ChatWindowMode.HISTORY_DETAIL) {\n                    <div class=\"chat-window-header chat-window-header-compact\" [class.cursor-grab]=\"!isMinimized\" cdkDragHandle>\n                        <div class=\"chat-window-title\">\n                            <ui-core-back-button [message]=\"text.backToChatHistoryMessage\" (clicked)=\"backToChatHistory()\">\n                            </ui-core-back-button>\n                        </div>\n                    </div>\n\n                    <div class=\"chat-window-body\">\n                        @if (selectedHistorySession) {\n                            <div class=\"search-messages-container mb-4\">\n                                @for (message of selectedHistorySession.messages; track $index) {\n                                    <ui-workflows-chat-message\n                                        [message]=\"message\"\n                                        [icon]=\"messageIcon(message)\"\n                                        [label]=\"messageLabel(message)\"\n                                        [cssClass]=\"messageCssClass(message)\"\n                                        [searchLinkMessage]=\"text.searchLinkMessage\"\n                                        [searchLinksMessage]=\"text.searchLinksMessage\">\n                                    </ui-workflows-chat-message>\n                                }\n                            </div>\n                        }\n                    </div>\n                }\n                @default {\n                    <div class=\"chat-window-header\" [class.cursor-grab]=\"!isMinimized\" cdkDragHandle>\n                        <div class=\"chat-window-title\">\n                            <ui-core-icon-button icon=\"arrow_back\" [message]=\"text.backButtonAriaLabel\" size=\"lg\"\n                                (click)=\"toggleChatWindow()\">\n                            </ui-core-icon-button>\n                            <h4 class=\"text-strong mb-0\">{{ chatTitle }}</h4>\n                            @if (headerBadge) {\n                                <ui-core-badge\n                                    [message]=\"headerBadge.message\"\n                                    [icon]=\"headerBadge.icon\"\n                                    [theme]=\"headerBadge.theme\"\n                                    [framed]=\"true\">\n                                </ui-core-badge>\n                            }\n                        </div>\n                        <div class=\"chat-window-actions\">\n                            <ui-core-icon-button icon=\"history\" [message]=\"text.chatHistoryButtonAriaLabel\" size=\"lg\"\n                                (click)=\"openChatHistory()\">\n                            </ui-core-icon-button>\n                            <ui-core-icon-button icon=\"minimize\" [message]=\"text.minimizeButtonAriaLabel\" size=\"lg\" class=\"mt-n3\"\n                                (click)=\"toggleChatWindow()\">\n                            </ui-core-icon-button>\n                            <ui-core-icon-button icon=\"close\" [message]=\"text.closeButtonAriaLabel\" size=\"lg\"\n                                (click)=\"closeChatWindow()\">\n                            </ui-core-icon-button>\n                        </div>\n                    </div>\n\n                    <div #chatBody class=\"chat-window-body\">\n                        @if (loading) {\n                            <div class=\"mt-5\">\n                                <ui-core-spinner [centered]=\"true\" [message]=\"text.loadingMessage\" size=\"h2\">\n                                </ui-core-spinner>\n                            </div>\n                        }\n                        @if (failedToLoadMessage) {\n                            <ui-core-in-line-notification [header]=\"failedToLoadMessage\" theme=\"error\">\n                            </ui-core-in-line-notification>\n                        }\n                        @if (!loading && messages.length) {\n                            <div class=\"search-messages-container mb-4\">\n                                @for (message of messages; track $index) {\n                                    <ui-workflows-chat-message\n                                        [message]=\"message\"\n                                        [icon]=\"messageIcon(message)\"\n                                        [label]=\"messageLabel(message)\"\n                                        [cssClass]=\"messageCssClass(message)\"\n                                        [pendingResponse]=\"pendingResponse\"\n                                        [clickedChatMessageAction]=\"clickedChatMessageAction\"\n                                        [searchLinkMessage]=\"text.searchLinkMessage\"\n                                        [searchLinksMessage]=\"text.searchLinksMessage\"\n                                        (actionClicked)=\"onChatMessageActionClick($event.message, $event.action)\">\n                                    </ui-workflows-chat-message>\n                                }\n                                @if (pendingResponse) {\n                                    <div class=\"d-flex\">\n                                        <div class=\"assistant-message pending-response mr-7 mb-2\">\n                                            <div class=\"d-flex mb-1\">\n                                                <ui-core-avatar backgroundClass=\"bg-brand-secondary\" icon=\"auto_awesome\" size=\"xs\">\n                                                </ui-core-avatar>\n                                                <span class=\"text-caption text-strong ml-1\">{{ chatTitle }}</span>\n                                            </div>\n                                            <ui-core-spinner size=\"sm\"></ui-core-spinner>\n                                        </div>\n                                    </div>\n                                }\n                            </div>\n                        }\n                    </div>\n\n                    <form [formGroup]=\"searchForm\" class=\"search-form\" [id]=\"searchFormId\">\n                        @if (!failedToLoadMessage) {\n                            <ui-forms-text-area\n                                [iconButtons]=\"chatIconButtons\"\n                                [rows]=\"1\"\n                                [maxRows]=\"5\"\n                                formControlName=\"search\"\n                                [hideLabel]=\"true\"\n                                [placeholder]=\"text.chatInputPlaceholder\"\n                                [preventNewLines]=\"true\"\n                                (keyup.enter)=\"submitSearch()\"\n                                (iconButtonClicked)=\"onIconButtonClick($event)\">\n                            </ui-forms-text-area>\n                        }\n                    </form>\n                }\n            }\n        }\n    </div>\n}\n\n<ui-workflows-confirmation-modal\n    [title]=\"text.endChatConfirmationModalTitle\"\n    [message]=\"text.endChatConfirmationModalMessage\"\n    [primaryButtonText]=\"text.endChatConfirmationModalPrimaryButtonText\"\n    [secondaryButtonText]=\"text.endChatConfirmationModalSecondaryButtonText\"\n    (clicked)=\"onConfirmationModalClick($event)\">\n</ui-workflows-confirmation-modal>\n", styles: [".chat-window-container{position:fixed;top:0;left:0;width:400px;height:600px;background:var(--color-default);border-radius:14px;box-shadow:var(--elevation-4);display:flex;flex-direction:column;z-index:var(--z-index-fixed)}.chat-window-container.minimized{width:48px;height:48px;border-radius:var(--containers-shape);background:transparent;box-shadow:none}.chat-window-container:not(.minimized){padding:0 20px}.chat-window-container.mobile-fullscreen{width:100vw;height:100vh;border-radius:0;max-height:100vh}.chat-floating-button{position:relative;width:48px;height:48px;border-radius:var(--containers-shape);background:var(--color-primary);border:none;display:flex;align-items:center;justify-content:center;cursor:pointer;box-shadow:var(--elevation-2);transition:transform .2s ease,box-shadow .2s ease;padding:0}.chat-floating-button:hover{transform:scale(1.05);box-shadow:var(--elevation-4)}.chat-floating-button:active{transform:scale(.95)}.chat-floating-button-badge{position:absolute;top:0;right:0;transform:translate(50%,-50%);box-shadow:var(--elevation-1)}.chat-window-header{display:flex;justify-content:space-between;align-items:center;margin:20px 0;-webkit-user-select:none;user-select:none}.chat-window-header.chat-window-header-compact{margin-bottom:0}.chat-history-title{margin-bottom:var(--spacing-150)}.chat-window-body{flex:1;overflow-y:auto;margin-top:20px}.chat-window-container.mobile-fullscreen .chat-window-body{height:100%}.chat-window-title{display:flex;align-items:center;gap:8px}.chat-window-actions{display:flex;align-items:center;gap:12px}.assistant-message{width:fit-content;border:1px solid var(--color-stroke-1);border-radius:14px;font-size:var(--type-body2-size);padding:12px;overflow-wrap:break-word;word-break:break-word;background-color:var(--color-sunken)}\n"] }]
        }], ctorParameters: () => [{ type: i1.UntypedFormBuilder }, { type: i2.TextService }, { type: i2.WindowService }, { type: i3.Router }], propDecorators: { chatBody: [{
                type: ViewChild,
                args: ['chatBody']
            }], confirmationModal: [{
                type: ViewChild,
                args: [ConfirmationModalComponent, { static: true }]
            }], title: [{
                type: Input
            }], headerBadge: [{
                type: Input
            }], failedToLoadMessage: [{
                type: Input
            }], failedToSendActionMessage: [{
                type: Input
            }], isVisible: [{
                type: Input
            }], anchorChatButton: [{
                type: Input
            }], loading: [{
                type: Input
            }], pendingResponse: [{
                type: Input
            }], messages: [{
                type: Input
            }], unreadCount: [{
                type: Input
            }], chatHistorySessions: [{
                type: Input
            }], attachFileClicked: [{
                type: Output
            }], closed: [{
                type: Output
            }], searched: [{
                type: Output
            }], voiceClicked: [{
                type: Output
            }], action: [{
                type: Output
            }] } });

class ChatSession {
    constructor() {
        this.sessionId = '';
        this.title = '';
        this.messages = [];
    }
    static fromObject(data) {
        const chatSession = new ChatSession();
        chatSession.sessionId = data.sessionId || '';
        chatSession.title = data.title || '';
        chatSession.startedAt = data.startedAt || undefined;
        chatSession.messages = (data.messages || []).map(ChatMessage.fromObject);
        return chatSession;
    }
}

class ChatPageAction {
    constructor() {
        this.text = '';
    }
}

class ChatPageComponent extends BaseTextComponent {
    /** The rendered actions, capped at 3. */
    get visibleHeaderActions() {
        return this.headerActions.slice(0, 3);
    }
    constructor(formBuilder, textService, router) {
        super(textService, 'ui-workflows-chat-page');
        this.formBuilder = formBuilder;
        this.textService = textService;
        this.router = router;
        /**
        * Optional. Background class applied behind the header icon.
        **/
        this.headerIconBackgroundClass = '';
        /**
        * Optional. Neutral action buttons shown in the top-right. Only the first 3 are rendered.
        **/
        this.headerActions = [];
        /**
        * Optional title for the chat window.
        **/
        this.title = '';
        /**
        * Optional. The message to show if loading the chat fails.
        **/
        this.failedToLoadMessage = '';
        /**
        * Optional. The message to show if sending an action fails.
        **/
        this.failedToSendActionMessage = '';
        /**
        * Optional. Whether or not the chat window is visible.
        **/
        this.isVisible = true;
        /**
        * Optional. Whether or not the chat component is loading.
        **/
        this.loading = false;
        /**
        * Optional. Whether or not a response is pending from the chat service.
        **/
        this.pendingResponse = false;
        /**
        * Optional. The messages to show in the chat.
        **/
        this.messages = [];
        /**
        * Optional. Background color applied to member message bubbles.
        **/
        this.memberBubbleBackgroundClass = 'bg-brand-primary';
        /**
        * Optional. Text color applied to member message bubbles.
        **/
        this.memberBubbleTextClass = 'color-white';
        /**
        * Optional. Whether or not to hide the message input area at the bottom of the chat.
        * Set to true for read-only chats, such as a closed or ended conversation.
        **/
        this.hideMessageInput = false;
        /**
        * Emits the action when one of the header action buttons is clicked.
        **/
        this.headerActionClicked = new EventEmitter();
        /**
        * Emits the attach file event when the attach file button is clicked.
        **/
        this.attachFileClicked = new EventEmitter();
        /**
        * Emits the search value when the Search button is clicked.
        **/
        this.searched = new EventEmitter();
        /**
        * Emits the voice input event when the voice input button is clicked.
        **/
        this.voiceClicked = new EventEmitter();
        /**
        * Emits the action object when a chat message action is clicked.
        **/
        this.chatMessageActionClicked = new EventEmitter();
        this.chatIconButtons = [];
        this.searchFormId = HtmlUtils.generateRandomId();
        this.searchForm = null;
        this.clickedChatMessageAction = null;
        this.attachFileIcon = 'attach_file';
        this.micIcon = 'mic';
        this.sendMessageIcon = 'arrow_forward';
        this.lastMessageContent = '';
        this.lastTrackedMessage = null;
    }
    ngOnInit() {
        this.chatTitle = this.title || this.text.chatTitle;
        this.chatIconButtons = [
            new TextAreaIconButton(this.attachFileIcon, this.text.attachFileAriaLabel, 'left'),
            new TextAreaIconButton(this.micIcon, this.text.voiceInputAriaLabel, 'left'),
            new TextAreaIconButton(this.sendMessageIcon, this.text.sendMessageAriaLabel, 'right'),
        ];
        this.searchForm = this.formBuilder.group({
            search: this.formBuilder.control('')
        });
        this.focusSearchField();
    }
    ngOnChanges(changes) {
        if (changes.messages && this.messages?.length) {
            // Track the last incoming (member) message so streamed replies from member auto-scroll the chat body as their content grows.
            const lastIncomingMessage = this.messages.filter(m => m.isFromMember).at(-1);
            this.lastTrackedMessage = lastIncomingMessage ?? null;
            this.lastMessageContent = lastIncomingMessage?.message ?? '';
        }
        if (changes.messages && this.messages?.length || changes.pendingResponse && this.pendingResponse) {
            this.scrollFooterIntoView();
        }
        if (changes.failedToSendActionMessage && this.failedToSendActionMessage && this.clickedChatMessageAction) {
            const clickedAction = this.clickedChatMessageAction;
            const owningMessage = this.messages.find(m => m.actions?.includes(clickedAction));
            if (owningMessage) {
                owningMessage.sendActionErrorMessage = this.failedToSendActionMessage;
            }
        }
        if (changes.pendingResponse && !this.pendingResponse) {
            this.clickedChatMessageAction = null;
        }
    }
    ngDoCheck() {
        // Streaming replies mutate the message object in place, so ngOnChanges never fires for them.
        // Compare length (O(1)) against the baseline set by ngOnChanges to detect growth and scroll.
        const currentContent = this.lastTrackedMessage?.message ?? '';
        if (currentContent.length > this.lastMessageContent.length) {
            this.lastMessageContent = currentContent;
            this.scrollFooterIntoView();
        }
    }
    submitSearch() {
        const message = this.searchForm?.get('search')?.value || '';
        if (message) {
            this.searched.emit(message);
            this.searchForm?.reset();
        }
    }
    onHeaderActionClick(action) {
        this.headerActionClicked.emit(action);
    }
    onIconButtonClick(button) {
        if (button.icon === this.sendMessageIcon) {
            this.submitSearch();
        }
        if (button.icon === this.attachFileIcon) {
            this.attachFileClicked.emit(); // TODO: actual file handling
        }
        if (button.icon === this.micIcon) {
            this.voiceClicked.emit(); // TODO: actual voice input handling
        }
    }
    messageIcon(message) {
        return ChatMessage.iconFor(message);
    }
    messageLabel(message) {
        switch (message.senderType) {
            case ChatMessageSenderType.ASSISTANT:
                return this.chatTitle;
            case ChatMessageSenderType.ADMIN:
                return message.senderName;
            default:
                return this.headerTitle;
        }
    }
    messageCssClass(message) {
        return ChatMessage.cssClassFor(message, `user-message ${this.memberBubbleBackgroundClass} ${this.memberBubbleTextClass}`);
    }
    onChatMessageActionClick(message, action) {
        // Reset prior failure state so a retry click starts clean.
        message.sendActionErrorMessage = '';
        message.actions.forEach(a => a.clicked = false);
        // Mark the chosen action, then dispatch: REPLY emits to the parent; NAVIGATION routes inline.
        action.clicked = true;
        message.hasClickedAction = true;
        this.clickedChatMessageAction = action;
        switch (action.type) {
            case ChatMessageActionType.REPLY:
                this.chatMessageActionClicked.emit(action);
                break;
            case ChatMessageActionType.NAVIGATION:
                HtmlUtils.handleAction(action, this.router);
                break;
        }
    }
    focusSearchField() {
        setTimeout(() => {
            const formContainer = document.getElementById(this.searchFormId);
            if (formContainer) {
                FormUtils.focusSpecificField(formContainer, 'search');
            }
        }, 10);
    }
    scrollFooterIntoView() {
        setTimeout(() => {
            if (this.chatBody) {
                const el = this.chatBody.nativeElement;
                el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' });
            }
        }, 10);
    }
    getDefaultText() {
        return {
            chatTitle: 'Chat',
            loadingMessage: 'Loading...',
            searchLinkMessage: 'For more information, check out this link:',
            searchLinksMessage: 'For more information, check out these links:',
            chatInputPlaceholder: 'Type a message...',
            attachFileAriaLabel: 'Attach file',
            voiceInputAriaLabel: 'Voice input',
            sendMessageAriaLabel: 'Send message',
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: ChatPageComponent, deps: [{ token: i1.UntypedFormBuilder }, { token: i2.TextService }, { token: i3.Router }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.17", type: ChatPageComponent, isStandalone: false, selector: "ui-workflows-chat-page", inputs: { headerIcon: "headerIcon", headerTitle: "headerTitle", headerSubtitle: "headerSubtitle", headerBadge: "headerBadge", headerIconBackgroundClass: "headerIconBackgroundClass", headerActions: "headerActions", title: "title", failedToLoadMessage: "failedToLoadMessage", failedToSendActionMessage: "failedToSendActionMessage", isVisible: "isVisible", loading: "loading", pendingResponse: "pendingResponse", messages: "messages", memberBubbleBackgroundClass: "memberBubbleBackgroundClass", memberBubbleTextClass: "memberBubbleTextClass", hideMessageInput: "hideMessageInput" }, outputs: { headerActionClicked: "headerActionClicked", attachFileClicked: "attachFileClicked", searched: "searched", voiceClicked: "voiceClicked", chatMessageActionClicked: "chatMessageActionClicked" }, viewQueries: [{ propertyName: "chatBody", first: true, predicate: ["chatBody"], descendants: true }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div class=\"container-bordered h-100\">\n    <div class=\"chat-page-container\" id=\"chatPageContainer\">\n        <div class=\"chat-page-header\">\n            <div class=\"header-left\">\n                <ui-core-micro-summary\n                    [header]=\"headerTitle\"\n                    headerClass=\"text-heading3\"\n                    [subheader]=\"headerSubtitle\"\n                    [icon]=\"headerIcon\"\n                    [iconBackgroundClass]=\"headerIconBackgroundClass || 'bg-brand-secondary'\">\n                </ui-core-micro-summary>\n                @if (headerBadge) {\n                    <ui-core-badge\n                        [message]=\"headerBadge.message\"\n                        [theme]=\"headerBadge.theme\"\n                        [framed]=\"true\">\n                    </ui-core-badge>\n                }\n            </div>\n            <div class=\"header-right\">\n                @for (action of visibleHeaderActions; track action) {\n                    <ui-core-button\n                        [icon]=\"action.icon || ''\"\n                        themeGroup=\"neutral\"\n                        theme=\"secondary\"\n                        [message]=\"action.text\"\n                        (click)=\"onHeaderActionClick(action)\">\n                    </ui-core-button>\n                }\n            </div>\n        </div>\n\n        <div #chatBody class=\"chat-page-body mt-4\">\n            <div class=\"chat-body-content\">\n                @if (loading) {\n                    <div class=\"mt-5\">\n                        <ui-core-spinner [centered]=\"true\" [message]=\"text.loadingMessage\" size=\"h2\">\n                        </ui-core-spinner>\n                    </div>\n                }\n                @if (failedToLoadMessage) {\n                    <ui-core-in-line-notification [header]=\"failedToLoadMessage\" theme=\"error\">\n                    </ui-core-in-line-notification>\n                }\n                @if (!loading && messages.length) {\n                    <div class=\"search-messages-container mb-4\">\n                        @for (message of messages; track $index) {\n                            <ui-workflows-chat-message\n                                [message]=\"message\"\n                                [icon]=\"messageIcon(message)\"\n                                [label]=\"messageLabel(message)\"\n                                [cssClass]=\"messageCssClass(message)\"\n                                [pendingResponse]=\"pendingResponse\"\n                                [clickedChatMessageAction]=\"clickedChatMessageAction\"\n                                [searchLinkMessage]=\"text.searchLinkMessage\"\n                                [searchLinksMessage]=\"text.searchLinksMessage\"\n                                (actionClicked)=\"onChatMessageActionClick($event.message, $event.action)\">\n                            </ui-workflows-chat-message>\n                        }\n                        @if (pendingResponse) {\n                            <div class=\"d-flex justify-content-end\">\n                                <div class=\"assistant-message pending-response ml-7 mb-2\">\n                                    <div class=\"d-flex mb-1\">\n                                        <ui-core-avatar backgroundClass=\"bg-brand-secondary\" icon=\"person\" size=\"xs\">\n                                        </ui-core-avatar>\n                                        <span class=\"text-caption text-strong ml-1\">{{ chatTitle }}</span>\n                                    </div>\n                                    <ui-core-spinner size=\"sm\"></ui-core-spinner>\n                                </div>\n                            </div>\n                        }\n                    </div>\n                }\n            </div>\n        </div>\n\n        <form [formGroup]=\"searchForm\" class=\"search-form\" [id]=\"searchFormId\">\n            @if (!failedToLoadMessage && !hideMessageInput) {\n                <ui-forms-text-area\n                    [iconButtons]=\"chatIconButtons\"\n                    [rows]=\"1\"\n                    [maxRows]=\"5\"\n                    formControlName=\"search\"\n                    [hideLabel]=\"true\"\n                    [placeholder]=\"text.chatInputPlaceholder\"\n                    [preventNewLines]=\"true\"\n                    (keyup.enter)=\"submitSearch()\"\n                    (iconButtonClicked)=\"onIconButtonClick($event)\">\n                </ui-forms-text-area>\n            }\n        </form>\n    </div>\n</div>\n", styles: [".chat-page-container{height:100%;background:var(--color-default);display:flex;flex-direction:column;z-index:var(--z-index-fixed)}.chat-page-container .chat-page-header{display:flex;justify-content:space-between;padding-top:var(--spacing-100)}.chat-page-container .chat-page-header .header-left,.chat-page-container .chat-page-header .header-right{display:flex;column-gap:var(--spacing-100)}.chat-page-container .chat-page-body{position:relative;flex:1 3;overflow-y:auto}.chat-page-container .search-form{margin-top:auto}.assistant-message{width:fit-content;border:1px solid var(--color-stroke-1);border-radius:14px;font-size:var(--type-body2-size);padding:12px;overflow-wrap:break-word;word-break:break-word;background-color:var(--color-sunken)}\n"], dependencies: [{ kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i2.AvatarComponent, selector: "ui-core-avatar", inputs: ["ariaLabel", "backgroundClass", "colorClass", "completed", "disabled", "icon", "imageRotationClass", "imageUrl", "shape", "size", "progressValue", "progressMax", "progressAnimationStart"] }, { kind: "component", type: i2.BadgeComponent, selector: "ui-core-badge", inputs: ["message", "framed", "theme", "type", "centered", "icon", "iconPosition"] }, { kind: "component", type: i2.ButtonComponent, selector: "ui-core-button", inputs: ["themeGroup", "theme", "message", "icon", "iconPosition", "disabled", "disabledMessage", "showSpinner", "buttonClass", "width", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "ariaLabel", "isFormValid", "e2e", "buttonId"] }, { kind: "component", type: i2.InLineNotificationComponent, selector: "ui-core-in-line-notification", inputs: ["header", "message", "bulletList", "theme", "customIcon", "customAnimationPath", "customAnimationData", "customAnimationFreeze", "customAnimationFreezeFrame", "customAnimationLoop", "customAnimationLoopTotal", "buttons", "showCloseButton"], outputs: ["buttonClicked", "closed"] }, { kind: "component", type: i2.MicroSummaryComponent, selector: "ui-core-micro-summary", inputs: ["header", "headerClass", "subheader", "icon", "badges", "iconBackgroundClass"] }, { kind: "component", type: i2.SpinnerComponent, selector: "ui-core-spinner", inputs: ["message", "size", "buttonIcon", "hideSpinner", "centered", "delayMs", "buttonSpinner"] }, { kind: "component", type: i4.TextAreaComponent, selector: "ui-forms-text-area", inputs: ["collapsable", "maxLength", "maxRows", "placeholder", "preventNewLines", "rows", "showCharactersRemaining", "iconButtons"], outputs: ["iconButtonClicked"] }, { kind: "component", type: ChatMessageComponent, selector: "ui-workflows-chat-message", inputs: ["message", "icon", "label", "cssClass", "pendingResponse", "clickedChatMessageAction", "searchLinkMessage", "searchLinksMessage"], outputs: ["actionClicked"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: ChatPageComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-workflows-chat-page', standalone: false, template: "<div class=\"container-bordered h-100\">\n    <div class=\"chat-page-container\" id=\"chatPageContainer\">\n        <div class=\"chat-page-header\">\n            <div class=\"header-left\">\n                <ui-core-micro-summary\n                    [header]=\"headerTitle\"\n                    headerClass=\"text-heading3\"\n                    [subheader]=\"headerSubtitle\"\n                    [icon]=\"headerIcon\"\n                    [iconBackgroundClass]=\"headerIconBackgroundClass || 'bg-brand-secondary'\">\n                </ui-core-micro-summary>\n                @if (headerBadge) {\n                    <ui-core-badge\n                        [message]=\"headerBadge.message\"\n                        [theme]=\"headerBadge.theme\"\n                        [framed]=\"true\">\n                    </ui-core-badge>\n                }\n            </div>\n            <div class=\"header-right\">\n                @for (action of visibleHeaderActions; track action) {\n                    <ui-core-button\n                        [icon]=\"action.icon || ''\"\n                        themeGroup=\"neutral\"\n                        theme=\"secondary\"\n                        [message]=\"action.text\"\n                        (click)=\"onHeaderActionClick(action)\">\n                    </ui-core-button>\n                }\n            </div>\n        </div>\n\n        <div #chatBody class=\"chat-page-body mt-4\">\n            <div class=\"chat-body-content\">\n                @if (loading) {\n                    <div class=\"mt-5\">\n                        <ui-core-spinner [centered]=\"true\" [message]=\"text.loadingMessage\" size=\"h2\">\n                        </ui-core-spinner>\n                    </div>\n                }\n                @if (failedToLoadMessage) {\n                    <ui-core-in-line-notification [header]=\"failedToLoadMessage\" theme=\"error\">\n                    </ui-core-in-line-notification>\n                }\n                @if (!loading && messages.length) {\n                    <div class=\"search-messages-container mb-4\">\n                        @for (message of messages; track $index) {\n                            <ui-workflows-chat-message\n                                [message]=\"message\"\n                                [icon]=\"messageIcon(message)\"\n                                [label]=\"messageLabel(message)\"\n                                [cssClass]=\"messageCssClass(message)\"\n                                [pendingResponse]=\"pendingResponse\"\n                                [clickedChatMessageAction]=\"clickedChatMessageAction\"\n                                [searchLinkMessage]=\"text.searchLinkMessage\"\n                                [searchLinksMessage]=\"text.searchLinksMessage\"\n                                (actionClicked)=\"onChatMessageActionClick($event.message, $event.action)\">\n                            </ui-workflows-chat-message>\n                        }\n                        @if (pendingResponse) {\n                            <div class=\"d-flex justify-content-end\">\n                                <div class=\"assistant-message pending-response ml-7 mb-2\">\n                                    <div class=\"d-flex mb-1\">\n                                        <ui-core-avatar backgroundClass=\"bg-brand-secondary\" icon=\"person\" size=\"xs\">\n                                        </ui-core-avatar>\n                                        <span class=\"text-caption text-strong ml-1\">{{ chatTitle }}</span>\n                                    </div>\n                                    <ui-core-spinner size=\"sm\"></ui-core-spinner>\n                                </div>\n                            </div>\n                        }\n                    </div>\n                }\n            </div>\n        </div>\n\n        <form [formGroup]=\"searchForm\" class=\"search-form\" [id]=\"searchFormId\">\n            @if (!failedToLoadMessage && !hideMessageInput) {\n                <ui-forms-text-area\n                    [iconButtons]=\"chatIconButtons\"\n                    [rows]=\"1\"\n                    [maxRows]=\"5\"\n                    formControlName=\"search\"\n                    [hideLabel]=\"true\"\n                    [placeholder]=\"text.chatInputPlaceholder\"\n                    [preventNewLines]=\"true\"\n                    (keyup.enter)=\"submitSearch()\"\n                    (iconButtonClicked)=\"onIconButtonClick($event)\">\n                </ui-forms-text-area>\n            }\n        </form>\n    </div>\n</div>\n", styles: [".chat-page-container{height:100%;background:var(--color-default);display:flex;flex-direction:column;z-index:var(--z-index-fixed)}.chat-page-container .chat-page-header{display:flex;justify-content:space-between;padding-top:var(--spacing-100)}.chat-page-container .chat-page-header .header-left,.chat-page-container .chat-page-header .header-right{display:flex;column-gap:var(--spacing-100)}.chat-page-container .chat-page-body{position:relative;flex:1 3;overflow-y:auto}.chat-page-container .search-form{margin-top:auto}.assistant-message{width:fit-content;border:1px solid var(--color-stroke-1);border-radius:14px;font-size:var(--type-body2-size);padding:12px;overflow-wrap:break-word;word-break:break-word;background-color:var(--color-sunken)}\n"] }]
        }], ctorParameters: () => [{ type: i1.UntypedFormBuilder }, { type: i2.TextService }, { type: i3.Router }], propDecorators: { chatBody: [{
                type: ViewChild,
                args: ['chatBody']
            }], headerIcon: [{
                type: Input
            }], headerTitle: [{
                type: Input
            }], headerSubtitle: [{
                type: Input
            }], headerBadge: [{
                type: Input
            }], headerIconBackgroundClass: [{
                type: Input
            }], headerActions: [{
                type: Input
            }], title: [{
                type: Input
            }], failedToLoadMessage: [{
                type: Input
            }], failedToSendActionMessage: [{
                type: Input
            }], isVisible: [{
                type: Input
            }], loading: [{
                type: Input
            }], pendingResponse: [{
                type: Input
            }], messages: [{
                type: Input
            }], memberBubbleBackgroundClass: [{
                type: Input
            }], memberBubbleTextClass: [{
                type: Input
            }], hideMessageInput: [{
                type: Input
            }], headerActionClicked: [{
                type: Output
            }], attachFileClicked: [{
                type: Output
            }], searched: [{
                type: Output
            }], voiceClicked: [{
                type: Output
            }], chatMessageActionClicked: [{
                type: Output
            }] } });

class BulkAction {
}

class BulkActionEvent {
}

const animationTiming = AnimationUtils.getTiming(150, 'cubic-bezier(0.4, 0.0, 0.2, 1)');
// The expand/collapse effects are needed to gracefully push existing content out of the way.
const effectsIn = [fadeInEffect, slideDownEffect.getReverseEffect(), expandEffect];
const effectsOut = [fadeOutEffect, slideDownEffect, collapseEffect];
class BulkActionsComponent {
    constructor() {
        this.actions = [];
        this.clearAllLabel = '';
        this.emptyLabel = '';
        this.rowLabel = '';
        this.allCleared = new EventEmitter();
        this.bulkAction = new EventEmitter();
        this.BadgeTheme = BadgeTheme;
        this.hasActions = false;
    }
    ngOnChanges() {
        this.hasActions = this.actions.length > 0;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: BulkActionsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.17", type: BulkActionsComponent, isStandalone: false, selector: "ui-workflows-bulk-actions", inputs: { actions: "actions", clearAllLabel: "clearAllLabel", emptyLabel: "emptyLabel", rowLabel: "rowLabel" }, outputs: { allCleared: "allCleared", bulkAction: "bulkAction" }, usesOnChanges: true, ngImport: i0, template: `
        <div class="bulk-actions mb-2 mx-auto" [@trayAnimation]>
            <ui-core-badge *ngIf="rowLabel" [message]="rowLabel" [theme]="BadgeTheme.INFORMATION" />
            <div *ngIf="!hasActions" class="no-actions">
                <ui-core-micro-notification [message]="emptyLabel" theme="warning" />
            </div>
            <ng-container *ngIf="hasActions">
                <ui-core-button *ngFor="let action of actions" [message]="action.text" [icon]="action.icon" class="action-btn" (click)="bulkAction.emit(action)" />
                <div class="row-bar"></div>
            </ng-container>
            <ui-core-button [message]="clearAllLabel" icon="clear" (click)="allCleared.emit()" />
        </div>
    `, isInline: true, styles: [".bulk-actions{align-items:center;background:var(--color-default);border-radius:var(--containers-shape);bottom:40px;box-shadow:var(--elevation-4);display:flex;flex-wrap:wrap;gap:0 20px;max-width:fit-content;min-width:200px;padding:8px 20px;position:sticky;z-index:2}.bulk-actions .action-btn{margin-left:12px}.bulk-actions .no-actions{background:var(--color-sunken);border-radius:var(--containers-shape);padding:16px 12px}.bulk-actions .row-bar{border-right:1px solid var(--color-gray-100);min-height:48px}\n"], dependencies: [{ kind: "directive", type: i2$1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2$1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i2.BadgeComponent, selector: "ui-core-badge", inputs: ["message", "framed", "theme", "type", "centered", "icon", "iconPosition"] }, { kind: "component", type: i2.ButtonComponent, selector: "ui-core-button", inputs: ["themeGroup", "theme", "message", "icon", "iconPosition", "disabled", "disabledMessage", "showSpinner", "buttonClass", "width", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "ariaLabel", "isFormValid", "e2e", "buttonId"] }, { kind: "component", type: i2.MicroNotificationComponent, selector: "ui-core-micro-notification", inputs: ["message", "boldText", "theme", "containerTheme", "icon", "animationPath", "animationData", "animationFreeze", "animationFreezeFrame", "animationLoop", "animationLoopTotal", "ariaPrefix"] }], animations: [
            AnimationUtils.buildAnimation('trayAnimation', [
                AnimationUtils.buildTransition(TransitionStateChange.WHEN_CREATED, animationTiming, effectsIn),
                AnimationUtils.buildTransition(TransitionStateChange.WHEN_DESTROYED, animationTiming, effectsOut)
            ])
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: BulkActionsComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-workflows-bulk-actions', template: `
        <div class="bulk-actions mb-2 mx-auto" [@trayAnimation]>
            <ui-core-badge *ngIf="rowLabel" [message]="rowLabel" [theme]="BadgeTheme.INFORMATION" />
            <div *ngIf="!hasActions" class="no-actions">
                <ui-core-micro-notification [message]="emptyLabel" theme="warning" />
            </div>
            <ng-container *ngIf="hasActions">
                <ui-core-button *ngFor="let action of actions" [message]="action.text" [icon]="action.icon" class="action-btn" (click)="bulkAction.emit(action)" />
                <div class="row-bar"></div>
            </ng-container>
            <ui-core-button [message]="clearAllLabel" icon="clear" (click)="allCleared.emit()" />
        </div>
    `, animations: [
                        AnimationUtils.buildAnimation('trayAnimation', [
                            AnimationUtils.buildTransition(TransitionStateChange.WHEN_CREATED, animationTiming, effectsIn),
                            AnimationUtils.buildTransition(TransitionStateChange.WHEN_DESTROYED, animationTiming, effectsOut)
                        ])
                    ], styles: [".bulk-actions{align-items:center;background:var(--color-default);border-radius:var(--containers-shape);bottom:40px;box-shadow:var(--elevation-4);display:flex;flex-wrap:wrap;gap:0 20px;max-width:fit-content;min-width:200px;padding:8px 20px;position:sticky;z-index:2}.bulk-actions .action-btn{margin-left:12px}.bulk-actions .no-actions{background:var(--color-sunken);border-radius:var(--containers-shape);padding:16px 12px}.bulk-actions .row-bar{border-right:1px solid var(--color-gray-100);min-height:48px}\n"] }]
        }], propDecorators: { actions: [{
                type: Input
            }], clearAllLabel: [{
                type: Input
            }], emptyLabel: [{
                type: Input
            }], rowLabel: [{
                type: Input
            }], allCleared: [{
                type: Output
            }], bulkAction: [{
                type: Output
            }] } });

class ChipEditorComponent extends BaseTextComponent {
    constructor(textService) {
        super(textService, 'ui-workflows-chip-editor');
        /**
        * The max length of a single chip
        **/
        this.maxCharacterLength = 25;
        /**
        * The max number of chips allowed
        **/
        this.maxChipCount = 20;
        /**
        * Optional regular expression used to prevent invalid characters from being entered
        **/
        this.invalidCharactersRegex = null;
        /**
        * When enabled, chip messages will be translated to lowercase characters
        **/
        this.lowercaseOnly = false;
        /**
        * The currently applied chips
        **/
        this.chips = [];
        /**
        * A custom placeholder for the input. Default is "Add..."
        **/
        this.placeholder = '';
        /**
        * Required. A label for the input field.
        **/
        this.label = '';
        /**
        * Can be used to visually hide the label. Label should always be provided, and hidden if undesired
        **/
        this.hideLabel = false;
        /**
        * Optional. A header that renders above the label.
        **/
        this.header = '';
        /**
        * Set to true to disable buttons.
        **/
        this.disableButtons = false;
        /**
        * Shows a Close button when no changes are detected.
        * Emits the cancelled event.
        **/
        this.showCloseButton = false;
        /**
        * Array of values that a user may select from (but are not required).
        * Presented as a typeahead.
        **/
        this.options = [];
        /**
        * Emits the chips when the primary button is clicked
        **/
        this.updated = new EventEmitter();
        /**
        * Emits if the user cancels
        **/
        this.cancelled = new EventEmitter();
        /**
        * Emits after a copy-to-clipboard attempt completes. Payload is the success
        * boolean — true when the value reached the clipboard, false on failure.
        * Use this to log audit events at the call site.
        **/
        this.copied = new EventEmitter();
        this.copyValue = '';
        this.inputId = HtmlUtils.generateRandomId();
        this.labelId = HtmlUtils.generateRandomId();
        this.chipListItems = [];
        this.canAddMore = true;
        this.hasChanges = false;
        this.instructions = '';
        this.typeaheadOptions = [];
        // expose enum
        this.NotificationTheme = NotificationTheme;
        this.setInstructions();
    }
    ngOnChanges(changes) {
        if (changes.chips || changes.options) {
            if (!changes.chips) {
                this.setTypeaheadOptions();
            }
            else {
                // Reset will also set the options, no need to call both
                this.reset();
            }
        }
        if (changes.maxChipCount) {
            this.setInstructions();
        }
    }
    onPaste(value) {
        const newChips = value.split(',');
        this.setChipList([...this.currentValues, ...newChips], true);
    }
    addChip(value) {
        const newChip = value || '';
        if (newChip) {
            this.setChipList([...this.currentValues, newChip], true);
        }
    }
    onContainerClick(event) {
        if (this.inputComponent) {
            this.inputComponent.setFocusOnInput();
            // Stop the event
            EventUtils.stopEvent(event);
        }
    }
    onActionClick(event) {
        this.closeMenu();
        // Stop the event from bubbling up to onContainerClick
        EventUtils.stopEvent(event);
    }
    closeMenu() {
        // Since onContainerClick is stopping the click event, there are some scenarios where we
        // need to manually close the menu
        if (this.inputComponent) {
            this.inputComponent.close();
        }
    }
    removeChip(item) {
        const newList = this.currentValues.filter(message => message !== item.message);
        this.setChipList(newList, true);
        this.closeMenu();
    }
    setChipList(chips, setHasChanges) {
        const sanitizedList = chips.map(chip => this.sanitizeChip(chip)).filter(chip => !!chip);
        const noDupesList = [...new Set(sanitizedList)];
        const newList = noDupesList.slice(0, this.maxChipCount);
        this.chipListItems = newList.map(message => new ChipListItem(message));
        this.canAddMore = this.chipListItems.length < this.maxChipCount;
        this.copyValue = newList.join(', ');
        this.setTypeaheadOptions();
        if (setHasChanges) {
            this.hasChanges = false;
            if (this.chips.length === newList.length) {
                // Length is the same, need to compare values
                this.chips.forEach((value, index) => {
                    if (value !== newList[index]) {
                        this.hasChanges = true;
                    }
                });
            }
            else {
                this.hasChanges = true; // Different lengths, something changed
            }
        }
    }
    sanitizeChip(chip) {
        let cleanChip = (chip || '').trim();
        if (this.invalidCharactersRegex) {
            cleanChip = cleanChip.replace(this.invalidCharactersRegex, '');
        }
        if (this.lowercaseOnly) {
            cleanChip = cleanChip.toLocaleLowerCase();
        }
        return cleanChip.substring(0, this.maxCharacterLength);
    }
    setInstructions() {
        this.instructions = format(this.text.instructions, { maxChipCount: this.maxChipCount });
    }
    setTypeaheadOptions() {
        const availableOptions = this.options?.filter(o => !this.currentValues.includes(o));
        this.typeaheadOptions = availableOptions.map(o => new WorkflowInputOption(o)) || [];
    }
    get currentValues() {
        return this.chipListItems.map(chip => chip.message);
    }
    submit() {
        this.updated.emit(this.currentValues);
    }
    cancel() {
        this.reset();
        this.cancelled.emit();
    }
    close() {
        this.cancelled.emit();
    }
    reset() {
        // Reset back to the input value as the original set of chips
        this.hasChanges = false;
        this.setChipList(this.chips, false);
    }
    getDefaultText() {
        return {
            defaultPlaceholder: 'Add...',
            instructions: 'Press Enter to add new values. You may not exceed {{ maxChipCount }} values.',
            saveButton: 'Save Changes',
            savingButton: 'Saving...',
            cancelButton: 'Cancel',
            closeButton: 'Close',
            pendingChipListLabel: 'Pending values',
            savedChipListLabel: 'Existing values',
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: ChipEditorComponent, deps: [{ token: i2.TextService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.17", type: ChipEditorComponent, isStandalone: false, selector: "ui-workflows-chip-editor", inputs: { maxCharacterLength: "maxCharacterLength", maxChipCount: "maxChipCount", invalidCharactersRegex: "invalidCharactersRegex", lowercaseOnly: "lowercaseOnly", chips: "chips", placeholder: "placeholder", label: "label", hideLabel: "hideLabel", header: "header", disableButtons: "disableButtons", showCloseButton: "showCloseButton", options: "options" }, outputs: { updated: "updated", cancelled: "cancelled", copied: "copied" }, viewQueries: [{ propertyName: "inputComponent", first: true, predicate: WorkflowInputComponent, descendants: true }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div>\n    <div class=\"text-strong\" *ngIf=\"header\">{{ header }}</div>\n    <label [id]=\"labelId\" [attr.for]=\"inputId\" *ngIf=\"!hideLabel\">{{ label }}</label>\n</div>\n\n<div class=\"chip-editor-container container-form dropdown-container container-equal-padding\"\n    (click)=\"onContainerClick($event)\">\n    <div class=\"chip-list-container\" *ngIf=\"chipListItems.length > 0\">\n        <ui-core-chip-list\n            [label]=\"hasChanges ? text.pendingChipListLabel : text.savedChipListLabel\" [hideLabel]=\"true\"\n            [items]=\"chipListItems\" [showRemoveButton]=\"true\"\n            (itemRemoved)=\"removeChip($event)\">\n        </ui-core-chip-list>\n\n        <div class=\"chip-actions\" *ngIf=\"copyValue\">\n            <ui-core-copy-to-clipboard-button (click)=\"onActionClick($event)\"\n                (copied)=\"copied.emit($event)\"\n                [value]=\"copyValue\"\n                [label]=\"label\"\n                size=\"md\"\n                e2e=\"chip-editor-copy-button\"\n            ></ui-core-copy-to-clipboard-button>\n        </div>\n    </div>\n    <div *ngIf=\"canAddMore\">\n        <ui-forms-workflow-input\n            e2e=\"chip-editor\"\n            [inputId]=\"inputId\"\n            [labelId]=\"labelId\"\n            [ariaLabel]=\"hideLabel ? label : undefined\"\n            [placeholder]=\"placeholder || text.defaultPlaceholder\"\n            [maxLength]=\"maxCharacterLength\"\n            [invalidCharactersRegex]=\"invalidCharactersRegex\"\n            [lowercaseOnly]=\"lowercaseOnly\"\n            [disablePaste]=\"true\"\n            [submitOnEnter]=\"true\"\n            [hideDropdownContainer]=\"true\"\n            [desktopMenuGap]=\"false\"\n            [options]=\"typeaheadOptions\"\n            (pasted)=\"onPaste($event)\"\n            (submitted)=\"addChip($event)\">\n        </ui-forms-workflow-input>\n    </div>\n</div>\n\n<div class=\"container-transparent container-equal-padding\">\n    <ui-core-micro-notification\n        [theme]=\"NotificationTheme.NEUTRAL\" \n        [message]=\"instructions\">\n    </ui-core-micro-notification>\n</div>\n\n<ui-core-button-group *ngIf=\"hasChanges\"\n    [disableButtons]=\"disableButtons\"\n    [primaryButtonText]=\"text.saveButton\"\n    [primaryButtonDisabledText]=\"text.savingButton\"\n    [secondaryButtonText]=\"text.cancelButton\"\n    [marginBottom]=\"false\"\n    e2e=\"chip-editor\"\n    (primaryButtonClicked)=\"submit()\"\n    (secondaryButtonClicked)=\"cancel()\">\n</ui-core-button-group>\n\n<ui-core-button-group *ngIf=\"!hasChanges && showCloseButton\"\n    [secondaryButtonText]=\"text.closeButton\"\n    [marginBottom]=\"false\"\n    e2e=\"chip-editor\"\n    (secondaryButtonClicked)=\"close()\">\n</ui-core-button-group>", styles: [".chip-editor-container{display:flex;gap:var(--spacing-150);flex-direction:column}.chip-list-container{display:inline-flex;gap:var(--spacing-150);max-width:100%;overflow:hidden}.chip-list-container ui-core-chip-list{width:100%;max-width:100%;overflow:hidden}.chip-list-container .chip-actions{flex:0 0 auto}ui-forms-workflow-input{display:block;width:100%}\n"], dependencies: [{ kind: "directive", type: i2$1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i2.ButtonGroupComponent, selector: "ui-core-button-group", inputs: ["disableButtons", "primaryButtonText", "primaryButtonDisabledText", "primaryButtonIcon", "primaryButtonIconPosition", "showPrimarySpinner", "primaryButtonUrl", "primaryButtonUrlParams", "primaryButtonUsesExternalUrlNewTab", "secondaryButtonText", "secondaryButtonIcon", "secondaryButtonIconPosition", "showSecondarySpinner", "secondaryButtonTheme", "secondaryButtonUrl", "secondaryButtonUrlParams", "secondaryButtonUsesExternalUrlNewTab", "tertiaryButtonText", "tertiaryButtonIcon", "tertiaryButtonIconPosition", "showTertiarySpinner", "tertiaryButtonTheme", "tertiaryButtonUrl", "tertiaryButtonUrlParams", "tertiaryButtonUsesExternalUrlNewTab", "isFormValid", "withinFormRenderer", "errorMessages", "e2e", "marginBottom", "marginTop", "stacked"], outputs: ["primaryButtonClicked", "secondaryButtonClicked", "tertiaryButtonClicked"] }, { kind: "component", type: i2.ChipListComponent, selector: "ui-core-chip-list", inputs: ["label", "hideLabel", "items", "showRemoveButton", "disabled"], outputs: ["itemClicked", "itemRemoved"] }, { kind: "component", type: i2.CopyToClipboardButtonComponent, selector: "ui-core-copy-to-clipboard-button", inputs: ["buttonClass", "label", "size", "value", "e2e", "statusMessagePlacement"], outputs: ["copied"] }, { kind: "component", type: i2.MicroNotificationComponent, selector: "ui-core-micro-notification", inputs: ["message", "boldText", "theme", "containerTheme", "icon", "animationPath", "animationData", "animationFreeze", "animationFreezeFrame", "animationLoop", "animationLoopTotal", "ariaPrefix"] }, { kind: "component", type: i4.WorkflowInputComponent, selector: "ui-forms-workflow-input", inputs: ["value", "inputId", "placeholder", "ariaLabel", "labelId", "maxLength", "invalidCharactersRegex", "lowercaseOnly", "disablePaste", "submitOnEnter", "options", "hideDropdownContainer", "desktopMenuGap"], outputs: ["change", "submitted", "pasted"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: ChipEditorComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-workflows-chip-editor', template: "<div>\n    <div class=\"text-strong\" *ngIf=\"header\">{{ header }}</div>\n    <label [id]=\"labelId\" [attr.for]=\"inputId\" *ngIf=\"!hideLabel\">{{ label }}</label>\n</div>\n\n<div class=\"chip-editor-container container-form dropdown-container container-equal-padding\"\n    (click)=\"onContainerClick($event)\">\n    <div class=\"chip-list-container\" *ngIf=\"chipListItems.length > 0\">\n        <ui-core-chip-list\n            [label]=\"hasChanges ? text.pendingChipListLabel : text.savedChipListLabel\" [hideLabel]=\"true\"\n            [items]=\"chipListItems\" [showRemoveButton]=\"true\"\n            (itemRemoved)=\"removeChip($event)\">\n        </ui-core-chip-list>\n\n        <div class=\"chip-actions\" *ngIf=\"copyValue\">\n            <ui-core-copy-to-clipboard-button (click)=\"onActionClick($event)\"\n                (copied)=\"copied.emit($event)\"\n                [value]=\"copyValue\"\n                [label]=\"label\"\n                size=\"md\"\n                e2e=\"chip-editor-copy-button\"\n            ></ui-core-copy-to-clipboard-button>\n        </div>\n    </div>\n    <div *ngIf=\"canAddMore\">\n        <ui-forms-workflow-input\n            e2e=\"chip-editor\"\n            [inputId]=\"inputId\"\n            [labelId]=\"labelId\"\n            [ariaLabel]=\"hideLabel ? label : undefined\"\n            [placeholder]=\"placeholder || text.defaultPlaceholder\"\n            [maxLength]=\"maxCharacterLength\"\n            [invalidCharactersRegex]=\"invalidCharactersRegex\"\n            [lowercaseOnly]=\"lowercaseOnly\"\n            [disablePaste]=\"true\"\n            [submitOnEnter]=\"true\"\n            [hideDropdownContainer]=\"true\"\n            [desktopMenuGap]=\"false\"\n            [options]=\"typeaheadOptions\"\n            (pasted)=\"onPaste($event)\"\n            (submitted)=\"addChip($event)\">\n        </ui-forms-workflow-input>\n    </div>\n</div>\n\n<div class=\"container-transparent container-equal-padding\">\n    <ui-core-micro-notification\n        [theme]=\"NotificationTheme.NEUTRAL\" \n        [message]=\"instructions\">\n    </ui-core-micro-notification>\n</div>\n\n<ui-core-button-group *ngIf=\"hasChanges\"\n    [disableButtons]=\"disableButtons\"\n    [primaryButtonText]=\"text.saveButton\"\n    [primaryButtonDisabledText]=\"text.savingButton\"\n    [secondaryButtonText]=\"text.cancelButton\"\n    [marginBottom]=\"false\"\n    e2e=\"chip-editor\"\n    (primaryButtonClicked)=\"submit()\"\n    (secondaryButtonClicked)=\"cancel()\">\n</ui-core-button-group>\n\n<ui-core-button-group *ngIf=\"!hasChanges && showCloseButton\"\n    [secondaryButtonText]=\"text.closeButton\"\n    [marginBottom]=\"false\"\n    e2e=\"chip-editor\"\n    (secondaryButtonClicked)=\"close()\">\n</ui-core-button-group>", styles: [".chip-editor-container{display:flex;gap:var(--spacing-150);flex-direction:column}.chip-list-container{display:inline-flex;gap:var(--spacing-150);max-width:100%;overflow:hidden}.chip-list-container ui-core-chip-list{width:100%;max-width:100%;overflow:hidden}.chip-list-container .chip-actions{flex:0 0 auto}ui-forms-workflow-input{display:block;width:100%}\n"] }]
        }], ctorParameters: () => [{ type: i2.TextService }], propDecorators: { inputComponent: [{
                type: ViewChild,
                args: [WorkflowInputComponent]
            }], maxCharacterLength: [{
                type: Input
            }], maxChipCount: [{
                type: Input
            }], invalidCharactersRegex: [{
                type: Input
            }], lowercaseOnly: [{
                type: Input
            }], chips: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], label: [{
                type: Input
            }], hideLabel: [{
                type: Input
            }], header: [{
                type: Input
            }], disableButtons: [{
                type: Input
            }], showCloseButton: [{
                type: Input
            }], options: [{
                type: Input
            }], updated: [{
                type: Output
            }], cancelled: [{
                type: Output
            }], copied: [{
                type: Output
            }] } });

class BaseDataCardItem {
    constructor(label, value, type) {
        this.label = label;
        this.type = type;
        // Can be used to give unique ids when multiple items are present.
        this.id = '';
        this.e2e = null;
        this.value = null;
        this.values = null;
        if (Array.isArray(value)) {
            this.values = value;
        }
        else {
            this.value = value;
        }
    }
}

class DataCardComponent extends BaseTextComponent {
    constructor(textService, windowService) {
        super(textService, 'ui-workflows-data-card');
        this.textService = textService;
        this.windowService = windowService;
        /**
        * Optional.
        **/
        this.header = '';
        /**
        * Optional badges that display to the right of the header text.
        **/
        this.headerBadges = [];
        /**
        * Items to be rendered.
        **/
        this.items = [];
        /**
        * Items to be rendered within groupings. Each DataCardItemGroup contains an array of DataCardItem along with an optional group label.
        **/
        this.itemGroups = [];
        /**
        * Optional. When provided, an action button will be rendered in the bottom left corner of the card.
        **/
        this.firstActionButtonIcon = '';
        /**
        * Required if "firstActionButtonIcon" is provided. The label for the first action button.
        **/
        this.firstActionButtonLabel = '';
        /**
        * Optional. The neutral theme for the first action button. Defaults to 'secondary'.
        **/
        this.firstActionButtonTheme = 'secondary';
        /**
        * Optional. When provided, a second action button will be rendered in the bottom left corner of the card.
        **/
        this.secondActionButtonIcon = '';
        /**
        * Required if "secondActionButtonIcon" is provided. The label for the second action button.
        **/
        this.secondActionButtonLabel = '';
        /**
        * Optional. The neutral theme for the second action button. Defaults to 'secondary'.
        **/
        this.secondActionButtonTheme = 'secondary';
        /**
        * The theme of the card, which directly corresponds to our standard container classes.
        **/
        this.theme = 'bordered';
        /**
        * Optional. E2E customization.
        **/
        this.e2e = null;
        /**
        * The number of columns to show on tablet. Max is 4.
        * For example, if this is used inside an enhanced modal, recommended number of columns for tablet is 2.
        **/
        this.tabletColumns = 3;
        /**
        * The number of columns to show on desktop. Max is 4.
        **/
        this.desktopColumns = 3;
        /**
        * Adds margin to the bottom, useful when stacking multiple cards.
        **/
        this.marginBottom = false;
        /**
        * If enabled, adds a class to make the card full height of the parent container.
        **/
        this.fullHeight = false;
        /**
        * If enabled, reduces spacing and removes horizontal rules within the Data Card for a more compact appearance.
        **/
        this.isCompact = false;
        /**
        * Emits if the user cancels the edit (with the "Cancel" button or by closing the modal)
        **/
        this.editCanceled = new EventEmitter();
        /**
        * Emits the item with the updatedValue set.
        **/
        this.itemEdited = new EventEmitter();
        /**
        * Emits the item when the icon right is clicked.
        **/
        this.iconRightClicked = new EventEmitter();
        /**
        * Emits the item when the link is clicked.
        **/
        this.linkClicked = new EventEmitter();
        /**
        * Emits when the first action button is clicked.
        **/
        this.firstActionButtonClicked = new EventEmitter();
        /**
        * Emits when the second action button is clicked.
        **/
        this.secondActionButtonClicked = new EventEmitter();
        /**
        * Emits after a copy-to-clipboard attempt completes on one of the display
        * items. Payload identifies which item's label was copied and whether the
        * copy succeeded. Use this to log audit events at the call site.
        **/
        this.copied = new EventEmitter();
        /**
        * Emits when a user toggles the mask on a masked display item. Payload
        * identifies the item and whether the mask is now on (true) or off/revealed
        * (false). Use this to log audit events at the call site.
        **/
        this.maskToggleClicked = new EventEmitter();
        this.hasBadges = false;
        this.containerClasses = 'container-bordered';
        this.e2ePrefix = 'data-card-';
        this.firstRowItemCount = 3;
        this.gridItems = [];
        this.groupedGridItems = [];
        this.isMobile = false;
        this.isTablet = false;
        this.windowService.windowSize$.pipe(this.takeUntilDestroyed()).subscribe(windowSize => {
            this.isMobile = windowSize.isMobile;
            this.isTablet = windowSize.isTablet;
            this.updateFirstRowItemCount();
        });
    }
    ngOnChanges(changes) {
        if (changes.headerBadges) {
            this.hasBadges = this.headerBadges?.length > 0;
        }
        if (changes.items || changes.itemGroups || changes.e2e) {
            this.e2ePrefix = this.e2e ? HtmlUtils.formatE2EPrefix(this.e2e) : 'data-card-';
            if (changes.items) {
                const items = this.items?.filter(item => !!item) || [];
                items.forEach((item, index) => {
                    if (!item.e2e) {
                        item.e2e = this.e2ePrefix + 'item-' + index;
                    }
                });
                this.gridItems = items.map(item => new GridItem(item));
            }
            if (changes.itemGroups) {
                for (let groupIndex = 0; groupIndex < this.itemGroups.length; groupIndex++) {
                    const itemGroup = this.itemGroups[groupIndex];
                    const items = itemGroup.items?.filter(item => !!item) || [];
                    items.forEach((item, index) => {
                        if (!item.e2e) {
                            item.e2e = this.e2ePrefix + 'group-' + groupIndex + '-item-' + index;
                        }
                    });
                }
                this.groupedGridItems = this.itemGroups.map(group => ({
                    label: group.label,
                    items: group.items.map(item => new GridItem(item))
                }));
            }
        }
        if (changes.desktopColumns || changes.tabletColumns) {
            this.updateFirstRowItemCount();
        }
        if (changes.theme || changes.marginBottom || changes.header || changes.fullHeight) {
            this.containerClasses = `container-${this.theme} container-equal-padding`;
            if (this.marginBottom) {
                this.containerClasses += ' mb-5';
            }
            if (this.fullHeight) {
                this.containerClasses += ' full-height';
            }
        }
    }
    updateFirstRowItemCount() {
        if (this.isMobile) {
            this.firstRowItemCount = 1;
        }
        else if (this.isTablet) {
            this.firstRowItemCount = this.tabletColumns;
        }
        else {
            this.firstRowItemCount = this.desktopColumns;
        }
    }
    editItemCanceled(item) {
        this.editCanceled.emit(item);
    }
    editItemUpdated(item, newValue) {
        item.updatedValue = newValue;
        this.itemEdited.emit(item);
    }
    onIconRightClick(item) {
        this.iconRightClicked.emit(item);
    }
    onLinkClick(item) {
        this.linkClicked.emit(item);
    }
    onFirstActionButtonClick() {
        this.firstActionButtonClicked.emit();
    }
    onSecondActionButtonClick() {
        this.secondActionButtonClicked.emit();
    }
    onItemCopied(item, success) {
        this.copied.emit({ label: item.label, success });
    }
    onItemMaskToggled(item, maskIsOn) {
        this.maskToggleClicked.emit({ item, maskIsOn });
    }
    onSensitiveItemMaskToggle(maskIsOn, item) {
        if (maskIsOn || item._inProgress || item._hasUnmaskedValue) {
            return;
        }
        item._inProgress = true;
        item.values = [this.text.sensitiveLoadingText];
        const unmaskedData$ = item.getUnmaskedValue();
        unmaskedData$.pipe(this.takeUntilDestroyed(), take(1), catchError(val => of(''))).subscribe(unmaskedData => {
            if (unmaskedData) {
                item.values = [unmaskedData];
                item._hasUnmaskedValue = true;
                item._failed = false;
            }
            else {
                item.values = [];
                item._hasUnmaskedValue = false;
                item._failed = true;
            }
            item._inProgress = false;
        });
    }
    getDefaultText() {
        return {
            sensitiveLoadingText: 'Loading...',
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: DataCardComponent, deps: [{ token: i2.TextService }, { token: i2.WindowService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.17", type: DataCardComponent, isStandalone: false, selector: "ui-workflows-data-card", inputs: { header: "header", headerBadges: "headerBadges", items: "items", itemGroups: "itemGroups", firstActionButtonIcon: "firstActionButtonIcon", firstActionButtonLabel: "firstActionButtonLabel", firstActionButtonTheme: "firstActionButtonTheme", secondActionButtonIcon: "secondActionButtonIcon", secondActionButtonLabel: "secondActionButtonLabel", secondActionButtonTheme: "secondActionButtonTheme", theme: "theme", e2e: "e2e", tabletColumns: "tabletColumns", desktopColumns: "desktopColumns", marginBottom: "marginBottom", fullHeight: "fullHeight", isCompact: "isCompact" }, outputs: { editCanceled: "editCanceled", itemEdited: "itemEdited", iconRightClicked: "iconRightClicked", linkClicked: "linkClicked", firstActionButtonClicked: "firstActionButtonClicked", secondActionButtonClicked: "secondActionButtonClicked", copied: "copied", maskToggleClicked: "maskToggleClicked" }, usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div *ngIf=\"gridItems.length || groupedGridItems.length\" [class]=\"containerClasses\" [attr.data-e2e]=\"e2e\">\n    <div *ngIf=\"header || hasBadges\" class=\"d-flex align-items-center mb-4\">\n        <h4 *ngIf=\"header\" class=\"mb-0 mr-1\">{{ header }}</h4>\n        <ui-core-badge-list *ngIf=\"hasBadges\" [items]=\"headerBadges\" [marginTop]=\"false\">\n        </ui-core-badge-list>\n    </div>\n    \n    @if (gridItems.length) {\n        <ng-container *ngTemplateOutlet=\"gridLayoutTemplate; context: { items: gridItems }\">\n        </ng-container>\n    }\n    @for (group of groupedGridItems; track group; let i = $index) {\n        <div *ngIf=\"group.label\" class=\"text-color-tertiary\" [class]=\"isCompact ? 'mb-1' : 'mb-3'\">\n            {{ group.label }}\n        </div>\n        <ng-container *ngTemplateOutlet=\"gridLayoutTemplate; context: { items: group.items }\">\n        </ng-container>\n        <hr *ngIf=\"i < groupedGridItems.length - 1\" [class]=\"isCompact ? 'mt-half mb-2' : 'my-6'\"/>\n    }\n\n    <div *ngIf=\"firstActionButtonIcon && firstActionButtonLabel\" [class]=\"isCompact ? 'mt-1' : 'mt-3'\">\n        <ui-core-button\n            themeGroup=\"neutral\"\n            [theme]=\"firstActionButtonTheme\"\n            [e2e]=\"e2ePrefix + 'action-button-1'\"\n            [icon]=\"firstActionButtonIcon\"\n            [message]=\"firstActionButtonLabel\"\n            (click)=\"onFirstActionButtonClick()\">\n        </ui-core-button>\n        <ui-core-button *ngIf=\"secondActionButtonIcon && secondActionButtonLabel\"\n            themeGroup=\"neutral\"\n            [theme]=\"secondActionButtonTheme\"\n            buttonClass=\"ml-3\"\n            [e2e]=\"e2ePrefix + 'action-button-2'\"\n            [icon]=\"secondActionButtonIcon\"\n            [message]=\"secondActionButtonLabel\"\n            (click)=\"onSecondActionButtonClick()\">\n        </ui-core-button>\n    </div>\n</div>\n\n<ng-template #gridLayoutTemplate let-items=\"items\">\n    <ui-core-grid-layout\n        [borderedRows]=\"!isCompact\"\n        [desktopColumns]=\"desktopColumns\"\n        [items]=\"items\" \n        [itemTemplate]=\"gridItemTemplate\" \n        [noRowGap]=\"isCompact\"\n        [tabletColumns]=\"tabletColumns\">\n    </ui-core-grid-layout>\n</ng-template>\n\n<ng-template #gridItemTemplate let-item=\"item\" let-index=\"index\">\n    <ui-workflows-edit-label-value-modal *ngIf=\"item.data.type === 'editable'\"\n        [label]=\"item.data.label\"\n        [value]=\"item.data.value\"\n        [errorMessage]=\"item.data.errorMessage\"\n        [maxLength]=\"item.data.maxLength\"\n        [validationRegex]=\"item.data.validationRegex\"\n        [rightAlignEditButton]=\"true\"\n        [showSpinner]=\"item.data.showSpinner\"\n        [e2e]=\"item.data.e2e\"\n        [showTextArea]=\"item.data.showTextArea\"\n        [valueIsOptional]=\"item.data.valueIsOptional\"\n        [editLinkText]=\"item.data.editLinkText\"\n        (cancelled)=\"editItemCanceled(item.data)\"\n        (updated)=\"editItemUpdated(item.data, $event)\"\n        [elementClass]=\"isCompact && index >= firstRowItemCount ? 'mt-3' : ''\"\n    ></ui-workflows-edit-label-value-modal>\n    <ui-core-label-value *ngIf=\"item.data.type === 'display'\"\n        [label]=\"item.data.label\"\n        [labelIcon]=\"item.data.labelIcon\"\n        [value]=\"item.data.value\"\n        [values]=\"item.data.values\"\n        [e2e]=\"item.data.e2e\"\n        [iconLeft]=\"item.data.iconLeft\"\n        [tooltipContent]=\"item.data.tooltipContent\"\n        [masked]=\"item.data.masked\"\n        [showCopyToClipboard]=\"item.data.showCopyToClipboard\"\n        [iconRight]=\"item.data.iconRight\"\n        [iconLeftColorClass]=\"item.data.iconLeftColorClass\"\n        [iconLeftAllowEmojis]=\"item.data.iconLeftAllowEmojis\"\n        [iconRightAriaLabel]=\"item.data.iconRightAriaLabel\"\n        [rightAlignIconButtons]=\"true\"\n        [url]=\"item.data.url\"\n        [externalUrlNewTab]=\"item.data.externalUrlNewTab\"\n        [valueIsLink]=\"item.data.valueIsLink\"\n        (iconRightClicked)=\"onIconRightClick(item.data)\"\n        (linkClicked)=\"onLinkClick(item.data)\"\n        (maskToggleClicked)=\"onItemMaskToggled(item.data, $event)\"\n        (copied)=\"onItemCopied(item.data, $event)\"\n        [notificationMessage]=\"item.data.notificationMessage\"\n        [notificationTheme]=\"item.data.notificationTheme\"\n        [notificationIcon]=\"item.data.notificationIcon\"\n        [elementClass]=\"isCompact && index >= firstRowItemCount ? 'mt-3' : ''\"\n    ></ui-core-label-value>\n    <ui-core-label-value *ngIf=\"item.data.type === 'sensitive'\"\n        [label]=\"item.data.label\"\n        [values]=\"item.data.values\"\n        [maskedValues]=\"item.data.maskedValues\"\n        [e2e]=\"item.data.e2e\"\n        [masked]=\"!item.data._inProgress\"\n        [showSpinner]=\"item.data._inProgress\"\n        [rightAlignIconButtons]=\"true\"\n        (maskToggleClicked)=\"onSensitiveItemMaskToggle($event, item.data)\"\n        [elementClass]=\"isCompact && index >= firstRowItemCount ? 'mt-3' : ''\"\n    ></ui-core-label-value>\n</ng-template>", dependencies: [{ kind: "directive", type: i2$1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2$1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: i2.BadgeListComponent, selector: "ui-core-badge-list", inputs: ["items", "marginTop", "max", "rightAlign"] }, { kind: "component", type: i2.ButtonComponent, selector: "ui-core-button", inputs: ["themeGroup", "theme", "message", "icon", "iconPosition", "disabled", "disabledMessage", "showSpinner", "buttonClass", "width", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "ariaLabel", "isFormValid", "e2e", "buttonId"] }, { kind: "component", type: i2.GridLayoutComponent, selector: "ui-core-grid-layout", inputs: ["items", "itemTemplate", "tabletColumns", "desktopColumns", "layout", "equalHeightRows", "borderedRows", "noRowGap", "smallColumnGap", "masonryColumnDistribution"] }, { kind: "component", type: i2.LabelValueComponent, selector: "ui-core-label-value", inputs: ["label", "value", "values", "labelIcon", "tooltipContent", "tooltipPlacement", "iconLeft", "iconRight", "iconRightAriaLabel", "iconLeftColorClass", "iconLeftAllowEmojis", "masked", "maskedValues", "showCopyToClipboard", "rightAlignIconButtons", "elementClass", "borderBottom", "valueClass", "valueIsLink", "valueSubLinkText", "url", "externalUrlNewTab", "showSpinner", "e2e", "valueIsUnselectable", "notificationMessage", "notificationTheme", "notificationIcon"], outputs: ["iconRightClicked", "linkClicked", "maskToggleClicked", "copied"] }, { kind: "component", type: EditLabelValueModalComponent, selector: "ui-workflows-edit-label-value-modal", inputs: ["label", "value", "errorMessage", "maxLength", "validationRegex", "showSpinner", "showTextArea", "valueIsOptional", "editLinkText", "submitButtonText", "e2e", "rightAlignEditButton", "elementClass", "borderBottom", "lockScrim", "confirmUnsavedChanges"], outputs: ["cancelled", "updated"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: DataCardComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-workflows-data-card', template: "<div *ngIf=\"gridItems.length || groupedGridItems.length\" [class]=\"containerClasses\" [attr.data-e2e]=\"e2e\">\n    <div *ngIf=\"header || hasBadges\" class=\"d-flex align-items-center mb-4\">\n        <h4 *ngIf=\"header\" class=\"mb-0 mr-1\">{{ header }}</h4>\n        <ui-core-badge-list *ngIf=\"hasBadges\" [items]=\"headerBadges\" [marginTop]=\"false\">\n        </ui-core-badge-list>\n    </div>\n    \n    @if (gridItems.length) {\n        <ng-container *ngTemplateOutlet=\"gridLayoutTemplate; context: { items: gridItems }\">\n        </ng-container>\n    }\n    @for (group of groupedGridItems; track group; let i = $index) {\n        <div *ngIf=\"group.label\" class=\"text-color-tertiary\" [class]=\"isCompact ? 'mb-1' : 'mb-3'\">\n            {{ group.label }}\n        </div>\n        <ng-container *ngTemplateOutlet=\"gridLayoutTemplate; context: { items: group.items }\">\n        </ng-container>\n        <hr *ngIf=\"i < groupedGridItems.length - 1\" [class]=\"isCompact ? 'mt-half mb-2' : 'my-6'\"/>\n    }\n\n    <div *ngIf=\"firstActionButtonIcon && firstActionButtonLabel\" [class]=\"isCompact ? 'mt-1' : 'mt-3'\">\n        <ui-core-button\n            themeGroup=\"neutral\"\n            [theme]=\"firstActionButtonTheme\"\n            [e2e]=\"e2ePrefix + 'action-button-1'\"\n            [icon]=\"firstActionButtonIcon\"\n            [message]=\"firstActionButtonLabel\"\n            (click)=\"onFirstActionButtonClick()\">\n        </ui-core-button>\n        <ui-core-button *ngIf=\"secondActionButtonIcon && secondActionButtonLabel\"\n            themeGroup=\"neutral\"\n            [theme]=\"secondActionButtonTheme\"\n            buttonClass=\"ml-3\"\n            [e2e]=\"e2ePrefix + 'action-button-2'\"\n            [icon]=\"secondActionButtonIcon\"\n            [message]=\"secondActionButtonLabel\"\n            (click)=\"onSecondActionButtonClick()\">\n        </ui-core-button>\n    </div>\n</div>\n\n<ng-template #gridLayoutTemplate let-items=\"items\">\n    <ui-core-grid-layout\n        [borderedRows]=\"!isCompact\"\n        [desktopColumns]=\"desktopColumns\"\n        [items]=\"items\" \n        [itemTemplate]=\"gridItemTemplate\" \n        [noRowGap]=\"isCompact\"\n        [tabletColumns]=\"tabletColumns\">\n    </ui-core-grid-layout>\n</ng-template>\n\n<ng-template #gridItemTemplate let-item=\"item\" let-index=\"index\">\n    <ui-workflows-edit-label-value-modal *ngIf=\"item.data.type === 'editable'\"\n        [label]=\"item.data.label\"\n        [value]=\"item.data.value\"\n        [errorMessage]=\"item.data.errorMessage\"\n        [maxLength]=\"item.data.maxLength\"\n        [validationRegex]=\"item.data.validationRegex\"\n        [rightAlignEditButton]=\"true\"\n        [showSpinner]=\"item.data.showSpinner\"\n        [e2e]=\"item.data.e2e\"\n        [showTextArea]=\"item.data.showTextArea\"\n        [valueIsOptional]=\"item.data.valueIsOptional\"\n        [editLinkText]=\"item.data.editLinkText\"\n        (cancelled)=\"editItemCanceled(item.data)\"\n        (updated)=\"editItemUpdated(item.data, $event)\"\n        [elementClass]=\"isCompact && index >= firstRowItemCount ? 'mt-3' : ''\"\n    ></ui-workflows-edit-label-value-modal>\n    <ui-core-label-value *ngIf=\"item.data.type === 'display'\"\n        [label]=\"item.data.label\"\n        [labelIcon]=\"item.data.labelIcon\"\n        [value]=\"item.data.value\"\n        [values]=\"item.data.values\"\n        [e2e]=\"item.data.e2e\"\n        [iconLeft]=\"item.data.iconLeft\"\n        [tooltipContent]=\"item.data.tooltipContent\"\n        [masked]=\"item.data.masked\"\n        [showCopyToClipboard]=\"item.data.showCopyToClipboard\"\n        [iconRight]=\"item.data.iconRight\"\n        [iconLeftColorClass]=\"item.data.iconLeftColorClass\"\n        [iconLeftAllowEmojis]=\"item.data.iconLeftAllowEmojis\"\n        [iconRightAriaLabel]=\"item.data.iconRightAriaLabel\"\n        [rightAlignIconButtons]=\"true\"\n        [url]=\"item.data.url\"\n        [externalUrlNewTab]=\"item.data.externalUrlNewTab\"\n        [valueIsLink]=\"item.data.valueIsLink\"\n        (iconRightClicked)=\"onIconRightClick(item.data)\"\n        (linkClicked)=\"onLinkClick(item.data)\"\n        (maskToggleClicked)=\"onItemMaskToggled(item.data, $event)\"\n        (copied)=\"onItemCopied(item.data, $event)\"\n        [notificationMessage]=\"item.data.notificationMessage\"\n        [notificationTheme]=\"item.data.notificationTheme\"\n        [notificationIcon]=\"item.data.notificationIcon\"\n        [elementClass]=\"isCompact && index >= firstRowItemCount ? 'mt-3' : ''\"\n    ></ui-core-label-value>\n    <ui-core-label-value *ngIf=\"item.data.type === 'sensitive'\"\n        [label]=\"item.data.label\"\n        [values]=\"item.data.values\"\n        [maskedValues]=\"item.data.maskedValues\"\n        [e2e]=\"item.data.e2e\"\n        [masked]=\"!item.data._inProgress\"\n        [showSpinner]=\"item.data._inProgress\"\n        [rightAlignIconButtons]=\"true\"\n        (maskToggleClicked)=\"onSensitiveItemMaskToggle($event, item.data)\"\n        [elementClass]=\"isCompact && index >= firstRowItemCount ? 'mt-3' : ''\"\n    ></ui-core-label-value>\n</ng-template>" }]
        }], ctorParameters: () => [{ type: i2.TextService }, { type: i2.WindowService }], propDecorators: { header: [{
                type: Input
            }], headerBadges: [{
                type: Input
            }], items: [{
                type: Input
            }], itemGroups: [{
                type: Input
            }], firstActionButtonIcon: [{
                type: Input
            }], firstActionButtonLabel: [{
                type: Input
            }], firstActionButtonTheme: [{
                type: Input
            }], secondActionButtonIcon: [{
                type: Input
            }], secondActionButtonLabel: [{
                type: Input
            }], secondActionButtonTheme: [{
                type: Input
            }], theme: [{
                type: Input
            }], e2e: [{
                type: Input
            }], tabletColumns: [{
                type: Input
            }], desktopColumns: [{
                type: Input
            }], marginBottom: [{
                type: Input
            }], fullHeight: [{
                type: Input
            }], isCompact: [{
                type: Input
            }], editCanceled: [{
                type: Output
            }], itemEdited: [{
                type: Output
            }], iconRightClicked: [{
                type: Output
            }], linkClicked: [{
                type: Output
            }], firstActionButtonClicked: [{
                type: Output
            }], secondActionButtonClicked: [{
                type: Output
            }], copied: [{
                type: Output
            }], maskToggleClicked: [{
                type: Output
            }] } });

class DataCardEditItem extends BaseDataCardItem {
    constructor(label, value) {
        super(label, value, 'editable');
        this.label = label;
        this.value = value;
        // Can be used to customize the form
        this.errorMessage = '';
        this.maxLength = FormUtils.defaultMaxLength;
        this.submitButtonText = '';
        this.validationRegex = '';
        this.showTextArea = false;
        this.valueIsOptional = false;
        // Can be used to customize the label-value
        this.showSpinner = false; // Useful for long api calls
        this.editLinkText = '';
        // The new value emitted by the form
        this.updatedValue = '';
    }
    persistUpdatedValue() {
        if (this.updatedValue || this.valueIsOptional) {
            this.value = this.updatedValue;
            this.updatedValue = '';
            this.showSpinner = false;
        }
    }
    static fromObject(data) {
        const value = data.value || '';
        const validValue = !!value || !!data.valueIsOptional;
        if (validValue && data.label) {
            const item = new DataCardEditItem(data.label, value);
            // Base properties
            item.id = data.id || '';
            item.e2e = data.e2e || null;
            // Additional properties
            item.errorMessage = data.errorMessage || '';
            item.maxLength = data.maxLength || FormUtils.defaultMaxLength;
            item.submitButtonText = data.submitButtonText || '';
            item.validationRegex = data.validationRegex || '';
            item.showTextArea = data.showTextArea || false;
            item.valueIsOptional = data.valueIsOptional || false;
            item.editLinkText = data.editLinkText || '';
            // Note: updatedValue is not set here, as it is not needed initially.
            return item;
        }
        return null;
    }
}

class DataCardDisplayItem extends BaseDataCardItem {
    constructor(label, value) {
        super(label, value, 'display');
        this.labelIcon = '';
        this.iconLeft = '';
        this.iconRight = '';
        this.iconRightAriaLabel = '';
        this.iconLeftColorClass = '';
        this.iconLeftAllowEmojis = false;
        this.tooltipContent = '';
        this.masked = false;
        this.showCopyToClipboard = false;
        this.valueIsLink = false;
        this.externalUrlNewTab = false;
        this.url = '';
        this.notificationMessage = '';
        this.notificationTheme = null;
        this.notificationIcon = '';
    }
    static fromObject(data) {
        const value = data.value || data.values || null;
        if (value && data.label) {
            const item = new DataCardDisplayItem(data.label, value);
            // Base properties
            item.id = data.id || '';
            item.e2e = data.e2e || null;
            // Additional properties
            item.labelIcon = data.labelIcon || '';
            item.iconLeft = data.iconLeft || '';
            item.iconRight = data.iconRight || '';
            item.iconRightAriaLabel = data.iconRightAriaLabel || '';
            item.iconLeftColorClass = data.iconLeftColorClass || '';
            item.iconLeftAllowEmojis = data.iconLeftAllowEmojis || false;
            item.tooltipContent = data.tooltipContent || '';
            item.masked = data.masked || false;
            item.showCopyToClipboard = data.showCopyToClipboard || false;
            item.valueIsLink = data.valueIsLink || false;
            item.externalUrlNewTab = data.externalUrlNewTab || false;
            item.url = data.url || '';
            item.notificationMessage = data.notificationMessage || '';
            item.notificationTheme = data.notificationTheme || null;
            item.notificationIcon = data.notificationIcon || '';
            return item;
        }
        return null;
    }
}

class DataCardSensitiveItem extends BaseDataCardItem {
    constructor(label, maskedValue, getUnmaskedValue) {
        super(label, [], 'sensitive');
        this.maskedValues = [];
        this.getUnmaskedValue = null;
        // Component only flags, do not set these.
        this._inProgress = false;
        this._failed = false;
        this._hasUnmaskedValue = false;
        // Pass an empty array in as the values, use this maskedValue as the maskedValues property.
        this.maskedValues = [maskedValue];
        this.getUnmaskedValue = getUnmaskedValue;
    }
    static fromObject(data) {
        const maskedValue = data.maskedValue || null;
        if (maskedValue && data.label && data.getUnmaskedValue) {
            const item = new DataCardSensitiveItem(data.label, maskedValue, data.getUnmaskedValue);
            // Base properties
            item.id = data.id || '';
            item.e2e = data.e2e || null;
            return item;
        }
        return null;
    }
}

function isDataCardItem(item) {
    return item instanceof DataCardEditItem ||
        item instanceof DataCardDisplayItem ||
        item instanceof DataCardSensitiveItem;
}
function dataCardItemFromObject(data) {
    if (!data) {
        return null;
    }
    if (data.type === 'sensitive') {
        return DataCardSensitiveItem.fromObject(data);
    }
    else if (data.type === 'editable') {
        return DataCardEditItem.fromObject(data);
    }
    else {
        return DataCardDisplayItem.fromObject(data);
    }
}

class DataCardItemGroup {
    constructor(items = [], label) {
        this.items = items;
        this.label = label;
    }
    static fromObject(data) {
        const items = data.items?.map((item) => dataCardItemFromObject(item)).filter((item) => !!item) || [];
        return new DataCardItemGroup(items, data.label);
    }
}

class DataCardModel {
    constructor(items, itemGroups = []) {
        this.items = items;
        this.itemGroups = itemGroups;
        this.header = '';
        this.headerBadges = [];
        this.firstActionButtonIcon = '';
        this.firstActionButtonLabel = '';
        this.secondActionButtonIcon = '';
        this.secondActionButtonLabel = '';
        this.theme = ContainerTheme.DEFAULT;
        this.e2e = null;
        this.tabletColumns = 3;
        this.desktopColumns = 3;
        this.marginBottom = false;
        this.fullHeight = false;
    }
    static fromObject(data) {
        const items = data.items || [];
        const itemGroups = data.itemGroups || [];
        // Validate that we have either items or itemGroups
        const hasItems = Array.isArray(items) && items.length > 0;
        const hasItemGroups = Array.isArray(itemGroups) && itemGroups.length > 0;
        if (!hasItems && !hasItemGroups) {
            return null;
        }
        // Process items
        const validItems = hasItems ? items.filter(item => isDataCardItem(item)) : [];
        // Process itemGroups
        const validItemGroups = hasItemGroups
            ? itemGroups.map((group) => DataCardItemGroup.fromObject(group)).filter((group) => !!group && group.items.length > 0)
            : [];
        // Ensure we have at least some valid content
        if (validItems.length === 0 && validItemGroups.length === 0) {
            return null;
        }
        const result = new DataCardModel(validItems, validItemGroups);
        // Header
        result.header = data.header || '';
        result.headerBadges = data.headerBadges || [];
        // Actions
        result.firstActionButtonIcon = data.firstActionButtonIcon || '';
        result.firstActionButtonLabel = data.firstActionButtonLabel || '';
        result.secondActionButtonIcon = data.secondActionButtonIcon || '';
        result.secondActionButtonLabel = data.secondActionButtonLabel || '';
        // Display
        result.theme = data.theme || ContainerTheme.DEFAULT;
        result.tabletColumns = data.tabletColumns || 3;
        result.desktopColumns = data.desktopColumns || 3;
        result.marginBottom = data.marginBottom || false;
        result.fullHeight = data.fullHeight || false;
        result.e2e = data.e2e || null;
        return result;
    }
}

class ListItemHeader {
    constructor(headerText, visible) {
        this.headerText = headerText;
        this.visible = visible;
    }
}

var DateFilterType;
(function (DateFilterType) {
    DateFilterType["CUSTOM"] = "CUSTOM";
    DateFilterType["LAST_7_DAYS"] = "LAST_7_DAYS";
    DateFilterType["LAST_30_DAYS"] = "LAST_30_DAYS";
    DateFilterType["LAST_365_DAYS"] = "LAST_365_DAYS";
    DateFilterType["NEXT_30_DAYS"] = "NEXT_30_DAYS";
    DateFilterType["NEXT_60_DAYS"] = "NEXT_60_DAYS";
    DateFilterType["PAST_90_DAYS"] = "PAST_90_DAYS";
    DateFilterType["PAST_180_DAYS"] = "PAST_180_DAYS";
    DateFilterType["PAST_MONTH"] = "PAST_MONTH";
    DateFilterType["PAST_WEEK"] = "PAST_WEEK";
    DateFilterType["PAST_YEAR"] = "PAST_YEAR";
    DateFilterType["PREVIOUS_BUSINESS_DAY"] = "PREVIOUS_BUSINESS_DAY";
    DateFilterType["THIS_MONTH"] = "THIS_MONTH";
    DateFilterType["THIS_YEAR"] = "THIS_YEAR";
    DateFilterType["TODAY"] = "TODAY";
})(DateFilterType || (DateFilterType = {}));

class SearchSortFilter {
    constructor(label, icon = '') {
        this.label = label;
        this.icon = icon;
        this.isMultiSelect = false;
        this._isDateRange = false;
        this._isTimeSpan = false;
        this._isAmountRange = false;
    }
}

class SearchSortFilterComponent extends BaseTextComponent {
    constructor(modalService, textService, windowService) {
        super(textService, 'ui-workflows-search-sort-filter');
        this.modalService = modalService;
        this.textService = textService;
        this.windowService = windowService;
        /**
        * Optional. Whether or not to automatically set focus within the search input.
        **/
        this.autoFocusSearchInput = false;
        /**
        * Optional text used to override the default placeholder text for the search field.
        **/
        this.searchFieldPlaceholder = '';
        /**
        * Optional text used to manually set the search field value.
        **/
        this.searchFieldText = '';
        /**
        * Optional array of PickerOptions that are used to sort the list.
        **/
        this.sortOptions = [];
        /**
        * Optional value of the default sort option.
        **/
        this.sortOptionDefaultValue = '';
        /**
        * Optional. The available customized filters to show. Each SearchSortFilter must define a list of options.
        **/
        this.customFilters = [];
        /**
        * Optional. Specifies whether to include the standard date filters. Defaults to false.
        **/
        this.includeDateFilters = false;
        /**
        * Optional. If "includeDateFilters" is true, this flag determines whether to use "past" or "future" date filters.
        * Defaults to false ("past" date filters).
        **/
        this.useFutureDateFilters = false;
        /**
        * Optional. Specifies whether to include the standard amount range filter. Defaults to false.
        **/
        this.includeAmountRangeFilter = false;
        /**
        * Optional. Whether or not this component's container <div> should have padding at the top. Defaults to true.
        **/
        this.paddingTop = true;
        /**
        * Optional. Whether or not this component is nested within the List Component. Defaults to false.
        **/
        this.withinListComponent = false;
        /**
        * Optional. Whether or not this component shows a "Select All" checkbox to the left of the search field.
        * Only currently applies if "withinListComponent" is true. Defaults to false.
        **/
        this.showSelectAllCheckbox = false;
        /**
        * Optional. Whether or not the "Select All" checkbox is checked.
        * Only applies if "showSelectAllCheckbox" is true. Defaults to false.
        **/
        this.selectAllCheckboxChecked = false;
        /**
        * Optional. Whether or not the "Select All" checkbox is in the indeterminate state.
        * Only applies if "showSelectAllCheckbox" is true. Defaults to false.
        **/
        this.selectAllCheckboxIndeterminate = false;
        /**
        * Optional. E2E testing - data-e2e attribute attached to the list.
        **/
        this.e2e = 'search-sort-filter';
        /**
        * Emits boolean value when the "Select All" checkbox is toggled.
        **/
        this.allSelected = new EventEmitter();
        /**
        * Emits search value on change.
        **/
        this.searched = new EventEmitter();
        /**
        * Emits sort value when the sort option is changed.
        **/
        this.sorted = new EventEmitter();
        /**
        * Emits all available filters when a filter value is changed.
        **/
        this.filtered = new EventEmitter();
        /**
        * Emits all available filters and a boolean that specifies whether to refilter when the "Clear All" filters
        * button is clicked. A true value (the default) means that the list should be refiltered.
        **/
        this.filtersCleared = new EventEmitter();
        this.HtmlAttributeStateEnum = HtmlAttributeState;
        this.e2ePrefix = '';
        this.filters = [];
        this.hasActiveFilters = false;
        this.showOptions = false;
        this.sortValue = '';
        this.dateRangeFutureOptions = [
            new PickerOption(this.text.todayOptionText, DateFilterType.TODAY),
            new PickerOption(this.text.next30DaysOptionText, DateFilterType.NEXT_30_DAYS),
            new PickerOption(this.text.next60DaysOptionText, DateFilterType.NEXT_60_DAYS)
        ];
        this.dateRangePastOptions = [
            new PickerOption(this.text.todayOptionText, DateFilterType.TODAY),
            new PickerOption(this.text.past90DaysOptionText, DateFilterType.PAST_90_DAYS),
            new PickerOption(this.text.past180DaysOptionText, DateFilterType.PAST_180_DAYS),
            new PickerOption(this.text.pastYearOptionText, DateFilterType.PAST_YEAR),
            new PickerOption(this.text.thisYearOptionText, DateFilterType.THIS_YEAR)
        ];
        this.windowService.windowSize$.pipe(this.takeUntilDestroyed()).subscribe(windowSize => {
            this.isMobile = windowSize.isMobile;
        });
        this.setE2EPrefix();
    }
    ngOnInit() {
        this.buildListFilters();
    }
    ngOnChanges(changes) {
        if (changes.customFilters) {
            this.buildListFilters();
        }
        if (changes.e2e) {
            this.setE2EPrefix();
        }
    }
    buildListFilters() {
        this.filters = [...this.customFilters];
        for (const filter of this.filters) {
            if (filter.isMultiSelect) {
                filter._pickerOptions = filter.options.map(opt => new MultiSelectPickerOption(opt.label, opt.value));
            }
            else {
                filter._pickerOptions = filter.options;
            }
        }
        if (this.includeDateFilters) {
            this.addDateRangeFilter();
            this.addTimeSpanFilter();
        }
        if (this.includeAmountRangeFilter) {
            this.addAmountRangeFilter();
        }
    }
    addDateRangeFilter() {
        const dateRangeFilter = new SearchSortFilter(this.text.dateRangeFilterLabel);
        dateRangeFilter._isDateRange = true;
        this.filters.push(dateRangeFilter);
    }
    addTimeSpanFilter() {
        const timeSpanFilter = new SearchSortFilter(this.text.timeSpanFilterLabel, 'event_available');
        timeSpanFilter._isTimeSpan = true;
        timeSpanFilter._pickerOptions = this.useFutureDateFilters ? this.dateRangeFutureOptions : this.dateRangePastOptions;
        this.filters.push(timeSpanFilter);
    }
    addAmountRangeFilter() {
        const amountRangeFilter = new SearchSortFilter(this.text.amountRangeFilterLabel);
        amountRangeFilter._isAmountRange = true;
        this.filters.push(amountRangeFilter);
    }
    get optionsLabel() {
        const hasFilters = this.filters.length > 0;
        const hasSort = this.sortOptions.length > 0;
        if (hasFilters && hasSort) {
            return this.text.sortAndFilterButtonText;
        }
        if (hasFilters) {
            return this.text.filterLabel;
        }
        return this.text.sortByLabel;
    }
    toggleOptions() {
        if (this.isMobile) {
            this.modalService.openMobileOnlyModal(this.mobileFiltersModal);
        }
        else {
            this.showOptions = !this.showOptions;
        }
    }
    onSelectAllChange(checked) {
        this.allSelected.emit(checked);
    }
    onSearchChange(searchText) {
        this.searched.emit(searchText);
    }
    onSortChange(value) {
        this.sortValue = value;
        this.sorted.emit(value);
    }
    onFilterValueChange(value, filter) {
        if (value) {
            const option = filter._pickerOptions.find(o => o.value === value);
            if (option) {
                filter._activeValue = option.value;
                if (filter._isTimeSpan) {
                    this.filters.find(f => f._isDateRange)._activeValues = [];
                }
            }
            this.emitActiveFilterChange();
        }
    }
    onFilterValuesChange(values, filter) {
        if (filter && !filter._activeValues && values?.length === 0) { // Filter wasn't changed by user in this case
            return;
        }
        if (values?.length) {
            filter._activeValues = values;
            if (filter._isDateRange) {
                this.filters.find(f => f._isTimeSpan)._activeValue = null;
            }
        }
        else {
            filter._activeValues = [];
        }
        this.emitActiveFilterChange();
    }
    emitActiveFilterChange() {
        this.hasActiveFilters = true;
        this.filtered.emit(this.filters);
    }
    clearAllFilters(refilter = true) {
        for (const filter of this.filters) {
            if (filter.isMultiSelect || filter._isDateRange || filter._isAmountRange) {
                filter._activeValues = [];
            }
            else {
                filter._activeValue = null;
            }
        }
        this.hasActiveFilters = false;
        this.sortValue = this.sortOptionDefaultValue;
        this.filtersCleared.emit({ filters: this.filters, refilter });
    }
    closeModal() {
        this.modalService.closeMostRecentModal();
    }
    setE2EPrefix() {
        this.e2ePrefix = HtmlUtils.formatE2EPrefix(this.e2e || 'search-sort-filter');
    }
    getDefaultText() {
        return {
            selectAllCheckboxAriaLabel: 'Select All',
            sortAndFilterButtonText: 'Sort & Filter',
            sortByLabel: 'Sort by',
            filterLabel: 'Filter',
            dateRangeFilterLabel: 'Date Range',
            timeSpanFilterLabel: 'Time Span',
            amountRangeFilterLabel: 'Amount Range',
            todayOptionText: 'Today',
            next30DaysOptionText: 'Next 30 days',
            next60DaysOptionText: 'Next 60 days',
            past90DaysOptionText: 'Past 90 days',
            past180DaysOptionText: 'Past 180 days',
            pastYearOptionText: 'Past year',
            thisYearOptionText: 'This year',
            clearAllFiltersButtonText: 'Clear All',
            mobileFiltersModalPrimaryButtonText: 'Done',
            mobileFiltersModalSecondaryButtonText: 'Clear All'
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: SearchSortFilterComponent, deps: [{ token: i2.ModalService }, { token: i2.TextService }, { token: i2.WindowService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.17", type: SearchSortFilterComponent, isStandalone: false, selector: "ui-workflows-search-sort-filter", inputs: { autoFocusSearchInput: "autoFocusSearchInput", searchFieldPlaceholder: "searchFieldPlaceholder", searchFieldText: "searchFieldText", sortOptions: "sortOptions", sortOptionDefaultValue: "sortOptionDefaultValue", customFilters: "customFilters", includeDateFilters: "includeDateFilters", useFutureDateFilters: "useFutureDateFilters", includeAmountRangeFilter: "includeAmountRangeFilter", paddingTop: "paddingTop", withinListComponent: "withinListComponent", showSelectAllCheckbox: "showSelectAllCheckbox", selectAllCheckboxChecked: "selectAllCheckboxChecked", selectAllCheckboxIndeterminate: "selectAllCheckboxIndeterminate", e2e: "e2e" }, outputs: { allSelected: "allSelected", searched: "searched", sorted: "sorted", filtered: "filtered", filtersCleared: "filtersCleared" }, viewQueries: [{ propertyName: "mobileFiltersModal", first: true, predicate: ["mobileFiltersModal"], descendants: true }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div\n    role=\"search\"\n    class=\"position-relative\"\n    [id]=\"e2ePrefix + 'container'\"\n    [@collapseOrSlideState]=\"'collapseState'\"\n    [class]=\"showOptions && !isMobile ? 'pb-1' : 'pb-4'\"\n    [class.pt-4]=\"paddingTop\"\n    [class.pl-3]=\"withinListComponent\"\n    [class.pr-3]=\"withinListComponent && sortOptions.length === 0 && filters.length === 0\"\n    [class.px-md-4]=\"withinListComponent\">\n    <div class=\"flex-align-center\">\n\n        @if (withinListComponent && showSelectAllCheckbox) {\n            <ui-forms-checkbox\n                class=\"select-all-checkbox\"\n                [ariaLabel]=\"text.selectAllCheckboxAriaLabel\"\n                [checked]=\"selectAllCheckboxChecked\"\n                [e2e]=\"e2ePrefix + 'select-all-checkbox'\"\n                [indeterminate]=\"selectAllCheckboxIndeterminate\"\n                [isChild]=\"true\"\n                (change)=\"onSelectAllChange($event)\">\n            </ui-forms-checkbox>\n        }\n        <ui-forms-search-input\n            class=\"flex-fill\"\n            size=\"lg\"\n            [autoFocus]=\"autoFocusSearchInput\"\n            [e2e]=\"e2ePrefix + 'search'\"\n            [placeholder]=\"searchFieldPlaceholder\"\n            [value]=\"searchFieldText\"\n            (change)=\"onSearchChange($event)\">\n        </ui-forms-search-input>\n\n        @if (!isMobile && (filters.length > 0 || sortOptions.length > 0)) {\n            <ui-core-button\n                class=\"ml-5 mr-2\"\n                icon=\"filter_list\"\n                [ariaControls]=\"e2ePrefix + 'sort-and-filter-container'\"\n                [ariaExpanded]=\"showOptions\"\n                [e2e]=\"e2ePrefix + 'sort-filter-toggle-button'\"\n                [message]=\"optionsLabel\"\n                (click)=\"toggleOptions()\">\n            </ui-core-button>\n        }\n\n        @if (isMobile && filters.length > 0) {\n            <ui-core-icon-button\n                icon=\"filter_list\"\n                [ariaControls]=\"e2ePrefix + 'mobile-filters-modal'\"\n                [ariaHasPopup]=\"HtmlAttributeStateEnum.TRUE\"\n                [class]=\"withinListComponent ? 'mx-4' : 'ml-4'\"\n                [e2e]=\"e2ePrefix + 'sort-filter-toggle-button'\"\n                [message]=\"optionsLabel\"\n                (click)=\"toggleOptions()\">\n            </ui-core-icon-button>\n        }\n\n        @if (isMobile && sortOptions.length > 0 && (!filters || filters.length === 0)) {\n            <ui-forms-picker\n                display=\"icon\"\n                iconLeft=\"filter_list\"\n                [class]=\"withinListComponent ? 'mx-4' : 'ml-4'\"\n                [e2e]=\"e2ePrefix + 'sort-toggle-button'\"\n                [label]=\"text.sortByLabel\"\n                [options]=\"sortOptions\"\n                [value]=\"sortValue || sortOptionDefaultValue\"\n                (change)=\"onSortChange($event)\">\n            </ui-forms-picker>\n        }\n    </div>\n\n    @if (!isMobile && showOptions) {\n        <div\n            class=\"flex-align-center justify-content-end flex-wrap mt-3\"\n            uiCoreReplayUnmask\n            [id]=\"e2ePrefix + 'sort-and-filter-container'\"\n            [@collapseOrSlideState]=\"'collapseState'\">\n\n            @if (hasActiveFilters) {\n                <ui-core-button\n                    buttonClass=\"py-0\"\n                    class=\"mb-2\"\n                    icon=\"close\"\n                    theme=\"link\"\n                    [message]=\"text.clearAllFiltersButtonText\"\n                    [e2e]=\"e2ePrefix + 'clear-all-button'\"\n                    (click)=\"clearAllFilters()\">\n                </ui-core-button>\n            }\n\n            @for (filter of filters; track filter.label) {\n                <div class=\"ml-2 mb-2\">\n                    <ng-container\n                        [ngTemplateOutlet]=\"filterTemplate\"\n                        [ngTemplateOutletContext]=\"{ filter }\">\n                    </ng-container>\n                </div>\n            }\n\n            @if (sortOptions.length > 0) {\n                <div class=\"ml-2 mb-2\">\n                    <ng-container [ngTemplateOutlet]=\"sortTemplate\"></ng-container>\n                </div>\n            }\n        </div>\n    }\n</div>\n\n<ng-template #mobileFiltersModal>\n    <ui-core-modal\n        [id]=\"e2ePrefix + 'mobile-filters-modal'\"\n        [e2e]=\"e2ePrefix + 'mobile-filters-modal'\"\n        [primaryButtonText]=\"text.mobileFiltersModalPrimaryButtonText\"\n        [secondaryButtonText]=\"text.mobileFiltersModalSecondaryButtonText\"\n        [title]=\"optionsLabel\"\n        (primaryButtonClicked)=\"closeModal()\"\n        (secondaryButtonClicked)=\"clearAllFilters()\">\n\n        @if (sortOptions.length > 0) {\n            <div\n                class=\"mb-3\"\n                uiCoreReplayUnmask>\n                <ng-container [ngTemplateOutlet]=\"sortTemplate\"></ng-container>\n            </div>\n        }\n\n        @for (filter of filters; track filter.label) {\n            <div\n                class=\"mb-3\"\n                uiCoreReplayUnmask>\n                <ng-container\n                    [ngTemplateOutlet]=\"filterTemplate\"\n                    [ngTemplateOutletContext]=\"{ filter }\">\n                </ng-container>\n            </div>\n        }\n    </ui-core-modal>\n</ng-template>\n<ng-template #sortTemplate>\n    <ui-forms-picker\n        display=\"selection\"\n        iconLeft=\"sort\"\n        [e2e]=\"e2ePrefix + 'sort-picker'\"\n        [label]=\"text.sortByLabel\"\n        [options]=\"sortOptions\"\n        [value]=\"sortValue || sortOptionDefaultValue\"\n        (change)=\"onSortChange($event)\">\n    </ui-forms-picker>\n</ng-template>\n<ng-template #filterTemplate let-filter=\"filter\">\n    @if (filter._isDateRange) {\n        <ui-forms-date-range\n            display=\"selection\"\n            [label]=\"filter.label\"\n            [value]=\"filter._activeValues\"\n            (change)=\"onFilterValuesChange($event, filter)\">\n        </ui-forms-date-range>\n    } @else if (filter.isMultiSelect) {\n        <ui-forms-multi-select-picker\n            [e2e]=\"e2ePrefix + 'multi-select-filter-picker'\"\n            [iconLeft]=\"filter.icon\"\n            [label]=\"filter.label\"\n            [options]=\"filter._pickerOptions\"\n            [value]=\"filter._activeValues\"\n            (change)=\"onFilterValuesChange($event, filter)\">\n        </ui-forms-multi-select-picker>\n    } @else if (filter._isAmountRange) {\n        <ui-forms-amount-range\n            display=\"selection\"\n            [label]=\"filter.label\"\n            [value]=\"filter._activeValues\"\n            (change)=\"onFilterValuesChange($event, filter)\">\n        </ui-forms-amount-range>\n    } @else {\n        <ui-forms-picker\n            display=\"selection\"\n            [e2e]=\"e2ePrefix + 'filter-picker'\"\n            [iconLeft]=\"filter.icon\"\n            [label]=\"filter.label\"\n            [options]=\"filter._pickerOptions\"\n            [value]=\"filter._activeValue\"\n            (change)=\"onFilterValueChange($event, filter)\">\n        </ui-forms-picker>\n    }\n</ng-template>\n", styles: [".select-all-checkbox{margin-left:-4px;margin-right:8px}\n"], dependencies: [{ kind: "directive", type: i2$1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: i2.ButtonComponent, selector: "ui-core-button", inputs: ["themeGroup", "theme", "message", "icon", "iconPosition", "disabled", "disabledMessage", "showSpinner", "buttonClass", "width", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "ariaLabel", "isFormValid", "e2e", "buttonId"] }, { kind: "component", type: i2.IconButtonComponent, selector: "ui-core-icon-button", inputs: ["message", "icon", "size", "disabled", "buttonClass", "ariaPressed", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "e2e", "theme", "usesGlassHoverState", "buttonId"] }, { kind: "component", type: i2.ModalComponent, selector: "ui-core-modal", inputs: ["headerTemplate", "footerTemplate", "noBodyPadding", "noHeaderBorder", "useFormRendererButtons", "useFooterButtons", "showPrimarySpinner", "useGlassBackground"] }, { kind: "directive", type: i2.ReplayUnmaskDirective, selector: "[uiCoreReplayUnmask]" }, { kind: "component", type: i4.AmountRangeComponent, selector: "ui-forms-amount-range", inputs: ["value", "display", "iconLeft", "ariaDescription"] }, { kind: "component", type: i4.CheckboxComponent, selector: "ui-forms-checkbox", inputs: ["indeterminate", "isChild", "secondaryLabel", "subtextLines", "ariaLabel"] }, { kind: "component", type: i4.DateRangeComponent, selector: "ui-forms-date-range", inputs: ["value", "allowToday", "desktopMaxWidth", "disableFutureDates", "disablePastDates", "display", "iconLeft", "maxDate", "minDate", "mobileDoneButtonLabel", "placeholder", "theme", "ariaDescription"] }, { kind: "component", type: i4.MultiSelectPickerComponent, selector: "ui-forms-multi-select-picker", inputs: ["value", "options", "display", "searchPlaceholder", "actions"] }, { kind: "component", type: i4.PickerComponent, selector: "ui-forms-picker", inputs: ["value", "options", "display", "actions"] }, { kind: "component", type: i4.SearchInputComponent, selector: "ui-forms-search-input", inputs: ["value", "maxLength", "placeholder", "size", "autoFocus", "locked", "inputId", "clearButtonId", "isSearchBar"], outputs: ["inputHasFocus"] }], animations: [collapseOrSlideState] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: SearchSortFilterComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-workflows-search-sort-filter', animations: [collapseOrSlideState], template: "<div\n    role=\"search\"\n    class=\"position-relative\"\n    [id]=\"e2ePrefix + 'container'\"\n    [@collapseOrSlideState]=\"'collapseState'\"\n    [class]=\"showOptions && !isMobile ? 'pb-1' : 'pb-4'\"\n    [class.pt-4]=\"paddingTop\"\n    [class.pl-3]=\"withinListComponent\"\n    [class.pr-3]=\"withinListComponent && sortOptions.length === 0 && filters.length === 0\"\n    [class.px-md-4]=\"withinListComponent\">\n    <div class=\"flex-align-center\">\n\n        @if (withinListComponent && showSelectAllCheckbox) {\n            <ui-forms-checkbox\n                class=\"select-all-checkbox\"\n                [ariaLabel]=\"text.selectAllCheckboxAriaLabel\"\n                [checked]=\"selectAllCheckboxChecked\"\n                [e2e]=\"e2ePrefix + 'select-all-checkbox'\"\n                [indeterminate]=\"selectAllCheckboxIndeterminate\"\n                [isChild]=\"true\"\n                (change)=\"onSelectAllChange($event)\">\n            </ui-forms-checkbox>\n        }\n        <ui-forms-search-input\n            class=\"flex-fill\"\n            size=\"lg\"\n            [autoFocus]=\"autoFocusSearchInput\"\n            [e2e]=\"e2ePrefix + 'search'\"\n            [placeholder]=\"searchFieldPlaceholder\"\n            [value]=\"searchFieldText\"\n            (change)=\"onSearchChange($event)\">\n        </ui-forms-search-input>\n\n        @if (!isMobile && (filters.length > 0 || sortOptions.length > 0)) {\n            <ui-core-button\n                class=\"ml-5 mr-2\"\n                icon=\"filter_list\"\n                [ariaControls]=\"e2ePrefix + 'sort-and-filter-container'\"\n                [ariaExpanded]=\"showOptions\"\n                [e2e]=\"e2ePrefix + 'sort-filter-toggle-button'\"\n                [message]=\"optionsLabel\"\n                (click)=\"toggleOptions()\">\n            </ui-core-button>\n        }\n\n        @if (isMobile && filters.length > 0) {\n            <ui-core-icon-button\n                icon=\"filter_list\"\n                [ariaControls]=\"e2ePrefix + 'mobile-filters-modal'\"\n                [ariaHasPopup]=\"HtmlAttributeStateEnum.TRUE\"\n                [class]=\"withinListComponent ? 'mx-4' : 'ml-4'\"\n                [e2e]=\"e2ePrefix + 'sort-filter-toggle-button'\"\n                [message]=\"optionsLabel\"\n                (click)=\"toggleOptions()\">\n            </ui-core-icon-button>\n        }\n\n        @if (isMobile && sortOptions.length > 0 && (!filters || filters.length === 0)) {\n            <ui-forms-picker\n                display=\"icon\"\n                iconLeft=\"filter_list\"\n                [class]=\"withinListComponent ? 'mx-4' : 'ml-4'\"\n                [e2e]=\"e2ePrefix + 'sort-toggle-button'\"\n                [label]=\"text.sortByLabel\"\n                [options]=\"sortOptions\"\n                [value]=\"sortValue || sortOptionDefaultValue\"\n                (change)=\"onSortChange($event)\">\n            </ui-forms-picker>\n        }\n    </div>\n\n    @if (!isMobile && showOptions) {\n        <div\n            class=\"flex-align-center justify-content-end flex-wrap mt-3\"\n            uiCoreReplayUnmask\n            [id]=\"e2ePrefix + 'sort-and-filter-container'\"\n            [@collapseOrSlideState]=\"'collapseState'\">\n\n            @if (hasActiveFilters) {\n                <ui-core-button\n                    buttonClass=\"py-0\"\n                    class=\"mb-2\"\n                    icon=\"close\"\n                    theme=\"link\"\n                    [message]=\"text.clearAllFiltersButtonText\"\n                    [e2e]=\"e2ePrefix + 'clear-all-button'\"\n                    (click)=\"clearAllFilters()\">\n                </ui-core-button>\n            }\n\n            @for (filter of filters; track filter.label) {\n                <div class=\"ml-2 mb-2\">\n                    <ng-container\n                        [ngTemplateOutlet]=\"filterTemplate\"\n                        [ngTemplateOutletContext]=\"{ filter }\">\n                    </ng-container>\n                </div>\n            }\n\n            @if (sortOptions.length > 0) {\n                <div class=\"ml-2 mb-2\">\n                    <ng-container [ngTemplateOutlet]=\"sortTemplate\"></ng-container>\n                </div>\n            }\n        </div>\n    }\n</div>\n\n<ng-template #mobileFiltersModal>\n    <ui-core-modal\n        [id]=\"e2ePrefix + 'mobile-filters-modal'\"\n        [e2e]=\"e2ePrefix + 'mobile-filters-modal'\"\n        [primaryButtonText]=\"text.mobileFiltersModalPrimaryButtonText\"\n        [secondaryButtonText]=\"text.mobileFiltersModalSecondaryButtonText\"\n        [title]=\"optionsLabel\"\n        (primaryButtonClicked)=\"closeModal()\"\n        (secondaryButtonClicked)=\"clearAllFilters()\">\n\n        @if (sortOptions.length > 0) {\n            <div\n                class=\"mb-3\"\n                uiCoreReplayUnmask>\n                <ng-container [ngTemplateOutlet]=\"sortTemplate\"></ng-container>\n            </div>\n        }\n\n        @for (filter of filters; track filter.label) {\n            <div\n                class=\"mb-3\"\n                uiCoreReplayUnmask>\n                <ng-container\n                    [ngTemplateOutlet]=\"filterTemplate\"\n                    [ngTemplateOutletContext]=\"{ filter }\">\n                </ng-container>\n            </div>\n        }\n    </ui-core-modal>\n</ng-template>\n<ng-template #sortTemplate>\n    <ui-forms-picker\n        display=\"selection\"\n        iconLeft=\"sort\"\n        [e2e]=\"e2ePrefix + 'sort-picker'\"\n        [label]=\"text.sortByLabel\"\n        [options]=\"sortOptions\"\n        [value]=\"sortValue || sortOptionDefaultValue\"\n        (change)=\"onSortChange($event)\">\n    </ui-forms-picker>\n</ng-template>\n<ng-template #filterTemplate let-filter=\"filter\">\n    @if (filter._isDateRange) {\n        <ui-forms-date-range\n            display=\"selection\"\n            [label]=\"filter.label\"\n            [value]=\"filter._activeValues\"\n            (change)=\"onFilterValuesChange($event, filter)\">\n        </ui-forms-date-range>\n    } @else if (filter.isMultiSelect) {\n        <ui-forms-multi-select-picker\n            [e2e]=\"e2ePrefix + 'multi-select-filter-picker'\"\n            [iconLeft]=\"filter.icon\"\n            [label]=\"filter.label\"\n            [options]=\"filter._pickerOptions\"\n            [value]=\"filter._activeValues\"\n            (change)=\"onFilterValuesChange($event, filter)\">\n        </ui-forms-multi-select-picker>\n    } @else if (filter._isAmountRange) {\n        <ui-forms-amount-range\n            display=\"selection\"\n            [label]=\"filter.label\"\n            [value]=\"filter._activeValues\"\n            (change)=\"onFilterValuesChange($event, filter)\">\n        </ui-forms-amount-range>\n    } @else {\n        <ui-forms-picker\n            display=\"selection\"\n            [e2e]=\"e2ePrefix + 'filter-picker'\"\n            [iconLeft]=\"filter.icon\"\n            [label]=\"filter.label\"\n            [options]=\"filter._pickerOptions\"\n            [value]=\"filter._activeValue\"\n            (change)=\"onFilterValueChange($event, filter)\">\n        </ui-forms-picker>\n    }\n</ng-template>\n", styles: [".select-all-checkbox{margin-left:-4px;margin-right:8px}\n"] }]
        }], ctorParameters: () => [{ type: i2.ModalService }, { type: i2.TextService }, { type: i2.WindowService }], propDecorators: { mobileFiltersModal: [{
                type: ViewChild,
                args: ['mobileFiltersModal']
            }], autoFocusSearchInput: [{
                type: Input
            }], searchFieldPlaceholder: [{
                type: Input
            }], searchFieldText: [{
                type: Input
            }], sortOptions: [{
                type: Input
            }], sortOptionDefaultValue: [{
                type: Input
            }], customFilters: [{
                type: Input
            }], includeDateFilters: [{
                type: Input
            }], useFutureDateFilters: [{
                type: Input
            }], includeAmountRangeFilter: [{
                type: Input
            }], paddingTop: [{
                type: Input
            }], withinListComponent: [{
                type: Input
            }], showSelectAllCheckbox: [{
                type: Input
            }], selectAllCheckboxChecked: [{
                type: Input
            }], selectAllCheckboxIndeterminate: [{
                type: Input
            }], e2e: [{
                type: Input
            }], allSelected: [{
                type: Output
            }], searched: [{
                type: Output
            }], sorted: [{
                type: Output
            }], filtered: [{
                type: Output
            }], filtersCleared: [{
                type: Output
            }] } });

class EndOfListComponent {
    constructor() {
        /**
        * Required. The array of items (of class ListItem) to render in a list.
        **/
        this.items = [];
        /**
        * Required. The title text that displays when there are no items in the list.
        **/
        this.noListItemsTitleText = '';
        /**
        * Required. The subtitle text that displays when there are no items in the list.
        **/
        this.noListItemsSubtitleText = '';
        /**
        * Required. The subtitle text that displays when the end of the list has been reached.
        **/
        this.endOfListText = '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: EndOfListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.17", type: EndOfListComponent, isStandalone: false, selector: "ui-workflows-end-of-list", inputs: { items: "items", noListItemsTitleText: "noListItemsTitleText", noListItemsSubtitleText: "noListItemsSubtitleText", endOfListText: "endOfListText" }, ngImport: i0, template: "<div *ngIf=\"items\" class=\"text-center text-color-tertiary px-2\" [class]=\"items.length === 0 ? 'pt-1 pb-7' : 'py-4'\">\n    <div *ngIf=\"items.length === 0\" class=\"text-semibold\">{{ noListItemsTitleText }}</div>\n    <div class=\"text-second\">{{ items.length === 0 ? noListItemsSubtitleText : endOfListText }}</div>\n</div>", dependencies: [{ kind: "directive", type: i2$1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: EndOfListComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-workflows-end-of-list', template: "<div *ngIf=\"items\" class=\"text-center text-color-tertiary px-2\" [class]=\"items.length === 0 ? 'pt-1 pb-7' : 'py-4'\">\n    <div *ngIf=\"items.length === 0\" class=\"text-semibold\">{{ noListItemsTitleText }}</div>\n    <div class=\"text-second\">{{ items.length === 0 ? noListItemsSubtitleText : endOfListText }}</div>\n</div>" }]
        }], propDecorators: { items: [{
                type: Input
            }], noListItemsTitleText: [{
                type: Input
            }], noListItemsSubtitleText: [{
                type: Input
            }], endOfListText: [{
                type: Input
            }] } });

class ListTemplateComponent extends BaseDestroyComponent {
    constructor(windowService) {
        super();
        this.windowService = windowService;
        /**
        * If the "avatarIcon" input is provided, this input controls the avatar's background color class. Any class tied to a background-color can be used here.
        **/
        this.avatarBackgroundClass = 'bg-brand-secondary';
        /**
        * If the "avatarIcon" input is provided, this input controls the avatar's icon color class. Any class tied to a font color can be used here.
        **/
        this.avatarIconColorClass = 'color-white';
        /**
        * If either input for "avatarIcon" or "avatarImageUrl" is provided, this input controls the shape of the avatar.
        **/
        this.avatarShape = 'circle';
        /**
        * Enable emoji support for icons. Checking for emojis is expensive, so only enable if needed.
        **/
        this.allowEmojis = false;
        /**
        * Enables "thread mode", which slightly changes the layout to better suit threaded conversations, which includes vertically centering the top left content.
        **/
        this.threadModeEnabled = false;
        /**
        * E2E testing - data-e2e attribute attached to top left element
        **/
        this.e2eTopLeft = null;
        /**
        * E2E testing - data-e2e attribute attached to top right element
        **/
        this.e2eTopRight = null;
        /**
        * An array of details that display in a horizontal list separated by pipes in the bottom left corner.
        * Use the PipedDetail class to define each detail, which may have a message, icon, cssClass, NotificationTheme, and more.
        **/
        this.bottomLeftPipedDetails = [];
        /**
        * E2E testing - data-e2e attribute attached to bottom left element
        **/
        this.e2eBottomLeft = null;
        /**
        * An array of details that display in a horizontal list separated by pipes in the bottom right corner.
        * Use the PipedDetail class to define each detail, which may have a message, icon, cssClass, NotificationTheme, and more.
        **/
        this.bottomRightPipedDetails = [];
        /**
        * E2E testing - data-e2e attribute attached to bottom right element
        **/
        this.e2eBottomRight = null;
        /**
        * Size of the vertical spacing around the template.
        * Small/sm, Medium/md or Large/lg which each correspond to standard spacing variables. Defaults to small.
        **/
        this.verticalPaddingSize = 'sm';
        this.windowService.windowSize$.pipe(this.takeUntilDestroyed()).subscribe(windowSize => {
            this.isLowRes = windowSize.isLowRes;
            this.isMobile = windowSize.isMobile;
        });
    }
    ngOnChanges(changes) {
        if (changes.bottomLeftHtml) {
            this.sanitizedBottomLeftHtml = SanitizationUtils.allowRichTextOnly(this.bottomLeftHtml);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: ListTemplateComponent, deps: [{ token: i2.WindowService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.17", type: ListTemplateComponent, isStandalone: false, selector: "ui-workflows-list-template", inputs: { avatarIcon: "avatarIcon", avatarImageUrl: "avatarImageUrl", avatarBackgroundClass: "avatarBackgroundClass", avatarIconColorClass: "avatarIconColorClass", avatarShape: "avatarShape", allowEmojis: "allowEmojis", threadModeEnabled: "threadModeEnabled", topLeftText: "topLeftText", topLeftClass: "topLeftClass", topLeftIcon: "topLeftIcon", topLeftScreenReaderText: "topLeftScreenReaderText", e2eTopLeft: "e2eTopLeft", topLeftAdditionalText: "topLeftAdditionalText", topCenterBadge: "topCenterBadge", topRightText: "topRightText", topRightClass: "topRightClass", topRightIcon: "topRightIcon", topRightBadge: "topRightBadge", topRightScreenReaderText: "topRightScreenReaderText", e2eTopRight: "e2eTopRight", bottomLeftText: "bottomLeftText", bottomLeftHtml: "bottomLeftHtml", bottomLeftPipedDetails: "bottomLeftPipedDetails", bottomLeftScreenReaderText: "bottomLeftScreenReaderText", e2eBottomLeft: "e2eBottomLeft", bottomRightText: "bottomRightText", bottomRightPipedDetails: "bottomRightPipedDetails", bottomRightScreenReaderText: "bottomRightScreenReaderText", e2eBottomRight: "e2eBottomRight", verticalPaddingSize: "verticalPaddingSize" }, usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div\n  class=\"list-template-container\"\n  [class.py-2]=\"verticalPaddingSize === 'sm'\"\n  [class.py-3]=\"verticalPaddingSize === 'md'\"\n  [class.py-4]=\"verticalPaddingSize === 'lg'\">\n\n  @if (!isLowRes && (avatarIcon || avatarImageUrl)) {\n    <div\n      class=\"mr-2 mr-md-3\"\n      uiCoreReplayUnmask\n      aria-hidden=\"true\">\n      <ui-core-avatar\n        [imageUrl]=\"avatarImageUrl\"\n        [icon]=\"avatarIcon\"\n        [backgroundClass]=\"avatarBackgroundClass\"\n        [colorClass]=\"avatarIconColorClass\"\n        [shape]=\"avatarShape\"\n        size=\"lg\">\n      </ui-core-avatar>\n    </div>\n  }\n\n  <div\n    class=\"list-template-column-container\"\n    [class.is-low-res]=\"isLowRes\">\n    <div\n      class=\"list-template-column text-color-primary\"\n      [class.flex-align-center]=\"threadModeEnabled\"\n      [class.flex-fill]=\"topCenterBadge\">\n      <div\n        class=\"list-template-top-left text-compact\"\n        [class]=\"topLeftClass\"\n        [class.flex-align-center]=\"topLeftIcon && topLeftText\"\n        [class.pr-0]=\"topCenterBadge\"\n        [attr.data-e2e]=\"e2eTopLeft\">\n\n        @if (topLeftScreenReaderText) {\n          <span class=\"sr-only\">{{ topLeftScreenReaderText }}</span>\n        }\n\n        <span [class.mr-2]=\"topLeftIcon\">{{ topLeftText }}@if (topLeftAdditionalText) {<span class=\"text-color-tertiary pl-2\">{{ topLeftAdditionalText }}</span>}</span>\n\n        @if (topLeftIcon) {\n          <ui-core-icon\n            [allowEmojis]=\"allowEmojis\"\n            [icon]=\"topLeftIcon\"\n            size=\"xxl\">\n          </ui-core-icon>\n        }\n      </div>\n\n      @if (!threadModeEnabled) {\n        <div\n          class=\"list-template-btm-left\"\n          [attr.data-e2e]=\"e2eBottomLeft\">\n\n          @if (bottomLeftScreenReaderText) {\n            <span class=\"sr-only\">{{ bottomLeftScreenReaderText }}</span>\n          }\n\n          @if (bottomLeftText) {\n            <span class=\"text-color-tertiary\">{{ bottomLeftText }}</span>\n          }\n\n          @if (sanitizedBottomLeftHtml) {\n            <div\n              class=\"text-color-tertiary\"\n              [innerHTML]=\"sanitizedBottomLeftHtml\">\n            </div>\n          }\n\n          @if (bottomLeftPipedDetails?.length) {\n             <ui-core-piped-details\n              [allowEmojis]=\"allowEmojis\"\n              [details]=\"isMobile ? bottomLeftPipedDetails.slice(0, 2) : bottomLeftPipedDetails\">\n             </ui-core-piped-details>\n          }\n        </div>\n      }\n    </div>\n\n    @if (topCenterBadge) {\n      <div\n        class=\"list-template-column mx-1\"\n        [class.flex-align-center]=\"threadModeEnabled\">\n        <ui-core-badge\n          [icon]=\"topCenterBadge.icon\"\n          [message]=\"topCenterBadge.message\"\n          [theme]=\"topCenterBadge.theme\"\n          [framed]=\"topCenterBadge.framed\">\n        </ui-core-badge>\n      </div>\n    }\n\n    <div class=\"list-template-column\">\n      <div\n        class=\"list-template-top-right text-compact\"\n        [class]=\"topRightClass\"\n        [class.flex-align-center]=\"topRightIcon && topRightText\"\n        [attr.data-e2e]=\"e2eTopRight\">\n\n        @if (topRightIcon) {\n          <ui-core-icon\n            [allowEmojis]=\"allowEmojis\"\n            class=\"mr-1\"\n            [icon]=\"topRightIcon\"\n            size=\"xxl\">\n          </ui-core-icon>\n        }\n\n        @if (topRightScreenReaderText) {\n          <span class=\"sr-only\">{{ topRightScreenReaderText }}</span>\n        }\n\n        @if (topRightText && !topRightBadge) {\n          <span [class.mr-2]=\"topRightBadge\">{{ topRightText }}</span>\n        }\n\n        @if (topRightBadge) {\n          <ui-core-badge\n            [icon]=\"topRightBadge.icon\"\n            [message]=\"topRightBadge.message\"\n            [theme]=\"topRightBadge.theme\"\n            [framed]=\"topRightBadge.framed\">\n          </ui-core-badge>\n        }\n      </div>\n      <div\n        class=\"list-template-btm-right\"\n        [attr.data-e2e]=\"e2eBottomRight\">\n\n        @if (bottomRightScreenReaderText) {\n          <span class=\"sr-only\">{{ bottomRightScreenReaderText }}</span>\n        }\n\n        @if (bottomRightText) {\n          <span class=\"text-color-tertiary\">{{ bottomRightText }}</span>\n        }\n\n        @if (bottomRightPipedDetails?.length) {\n          <ui-core-piped-details\n            [allowEmojis]=\"allowEmojis\"\n            [details]=\"isMobile ? bottomRightPipedDetails.slice(0, 2) : bottomRightPipedDetails\"\n            alignment=\"right\">\n          </ui-core-piped-details>\n        }\n      </div>\n    </div>\n  </div>\n</div>\n", styles: [".list-template-container{display:flex;padding:0 16px}.list-template-column-container{display:flex;flex:auto;justify-content:space-between}.list-template-column-container.is-low-res{flex-direction:column;justify-content:flex-start}.list-template-column-container.is-low-res .list-template-top-right,.list-template-column-container.is-low-res .list-template-btm-right{text-align:left}.list-template-column-container.is-low-res .list-template-top-right{margin-top:4px}.list-template-top-left,.list-template-btm-left{padding-right:16px;word-break:break-word}.list-template-top-right,.list-template-btm-right{text-align:right;white-space:nowrap}.list-template-btm-left,.list-template-btm-right{font-size:var(--type-caption-size);line-height:var(--type-height-snug)}.list-template-top-left,.list-template-top-right{margin-bottom:4px}.flex-align-center{display:flex;align-items:center}\n"], dependencies: [{ kind: "component", type: i2.AvatarComponent, selector: "ui-core-avatar", inputs: ["ariaLabel", "backgroundClass", "colorClass", "completed", "disabled", "icon", "imageRotationClass", "imageUrl", "shape", "size", "progressValue", "progressMax", "progressAnimationStart"] }, { kind: "component", type: i2.BadgeComponent, selector: "ui-core-badge", inputs: ["message", "framed", "theme", "type", "centered", "icon", "iconPosition"] }, { kind: "component", type: i2.IconComponent, selector: "ui-core-icon", inputs: ["icon", "size", "colorClass", "allowEmojis", "ariaLabel", "alignWithText", "collapseHeight", "scaleWithFonts", "animationPath", "animationData", "animationFreeze", "animationFreezeFrame", "animationLoop", "animationLoopTotal"], outputs: ["animationCompleted"] }, { kind: "component", type: i2.PipedDetailsComponent, selector: "ui-core-piped-details", inputs: ["details", "allowEmojis", "alignment"] }, { kind: "directive", type: i2.ReplayUnmaskDirective, selector: "[uiCoreReplayUnmask]" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: ListTemplateComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-workflows-list-template', template: "<div\n  class=\"list-template-container\"\n  [class.py-2]=\"verticalPaddingSize === 'sm'\"\n  [class.py-3]=\"verticalPaddingSize === 'md'\"\n  [class.py-4]=\"verticalPaddingSize === 'lg'\">\n\n  @if (!isLowRes && (avatarIcon || avatarImageUrl)) {\n    <div\n      class=\"mr-2 mr-md-3\"\n      uiCoreReplayUnmask\n      aria-hidden=\"true\">\n      <ui-core-avatar\n        [imageUrl]=\"avatarImageUrl\"\n        [icon]=\"avatarIcon\"\n        [backgroundClass]=\"avatarBackgroundClass\"\n        [colorClass]=\"avatarIconColorClass\"\n        [shape]=\"avatarShape\"\n        size=\"lg\">\n      </ui-core-avatar>\n    </div>\n  }\n\n  <div\n    class=\"list-template-column-container\"\n    [class.is-low-res]=\"isLowRes\">\n    <div\n      class=\"list-template-column text-color-primary\"\n      [class.flex-align-center]=\"threadModeEnabled\"\n      [class.flex-fill]=\"topCenterBadge\">\n      <div\n        class=\"list-template-top-left text-compact\"\n        [class]=\"topLeftClass\"\n        [class.flex-align-center]=\"topLeftIcon && topLeftText\"\n        [class.pr-0]=\"topCenterBadge\"\n        [attr.data-e2e]=\"e2eTopLeft\">\n\n        @if (topLeftScreenReaderText) {\n          <span class=\"sr-only\">{{ topLeftScreenReaderText }}</span>\n        }\n\n        <span [class.mr-2]=\"topLeftIcon\">{{ topLeftText }}@if (topLeftAdditionalText) {<span class=\"text-color-tertiary pl-2\">{{ topLeftAdditionalText }}</span>}</span>\n\n        @if (topLeftIcon) {\n          <ui-core-icon\n            [allowEmojis]=\"allowEmojis\"\n            [icon]=\"topLeftIcon\"\n            size=\"xxl\">\n          </ui-core-icon>\n        }\n      </div>\n\n      @if (!threadModeEnabled) {\n        <div\n          class=\"list-template-btm-left\"\n          [attr.data-e2e]=\"e2eBottomLeft\">\n\n          @if (bottomLeftScreenReaderText) {\n            <span class=\"sr-only\">{{ bottomLeftScreenReaderText }}</span>\n          }\n\n          @if (bottomLeftText) {\n            <span class=\"text-color-tertiary\">{{ bottomLeftText }}</span>\n          }\n\n          @if (sanitizedBottomLeftHtml) {\n            <div\n              class=\"text-color-tertiary\"\n              [innerHTML]=\"sanitizedBottomLeftHtml\">\n            </div>\n          }\n\n          @if (bottomLeftPipedDetails?.length) {\n             <ui-core-piped-details\n              [allowEmojis]=\"allowEmojis\"\n              [details]=\"isMobile ? bottomLeftPipedDetails.slice(0, 2) : bottomLeftPipedDetails\">\n             </ui-core-piped-details>\n          }\n        </div>\n      }\n    </div>\n\n    @if (topCenterBadge) {\n      <div\n        class=\"list-template-column mx-1\"\n        [class.flex-align-center]=\"threadModeEnabled\">\n        <ui-core-badge\n          [icon]=\"topCenterBadge.icon\"\n          [message]=\"topCenterBadge.message\"\n          [theme]=\"topCenterBadge.theme\"\n          [framed]=\"topCenterBadge.framed\">\n        </ui-core-badge>\n      </div>\n    }\n\n    <div class=\"list-template-column\">\n      <div\n        class=\"list-template-top-right text-compact\"\n        [class]=\"topRightClass\"\n        [class.flex-align-center]=\"topRightIcon && topRightText\"\n        [attr.data-e2e]=\"e2eTopRight\">\n\n        @if (topRightIcon) {\n          <ui-core-icon\n            [allowEmojis]=\"allowEmojis\"\n            class=\"mr-1\"\n            [icon]=\"topRightIcon\"\n            size=\"xxl\">\n          </ui-core-icon>\n        }\n\n        @if (topRightScreenReaderText) {\n          <span class=\"sr-only\">{{ topRightScreenReaderText }}</span>\n        }\n\n        @if (topRightText && !topRightBadge) {\n          <span [class.mr-2]=\"topRightBadge\">{{ topRightText }}</span>\n        }\n\n        @if (topRightBadge) {\n          <ui-core-badge\n            [icon]=\"topRightBadge.icon\"\n            [message]=\"topRightBadge.message\"\n            [theme]=\"topRightBadge.theme\"\n            [framed]=\"topRightBadge.framed\">\n          </ui-core-badge>\n        }\n      </div>\n      <div\n        class=\"list-template-btm-right\"\n        [attr.data-e2e]=\"e2eBottomRight\">\n\n        @if (bottomRightScreenReaderText) {\n          <span class=\"sr-only\">{{ bottomRightScreenReaderText }}</span>\n        }\n\n        @if (bottomRightText) {\n          <span class=\"text-color-tertiary\">{{ bottomRightText }}</span>\n        }\n\n        @if (bottomRightPipedDetails?.length) {\n          <ui-core-piped-details\n            [allowEmojis]=\"allowEmojis\"\n            [details]=\"isMobile ? bottomRightPipedDetails.slice(0, 2) : bottomRightPipedDetails\"\n            alignment=\"right\">\n          </ui-core-piped-details>\n        }\n      </div>\n    </div>\n  </div>\n</div>\n", styles: [".list-template-container{display:flex;padding:0 16px}.list-template-column-container{display:flex;flex:auto;justify-content:space-between}.list-template-column-container.is-low-res{flex-direction:column;justify-content:flex-start}.list-template-column-container.is-low-res .list-template-top-right,.list-template-column-container.is-low-res .list-template-btm-right{text-align:left}.list-template-column-container.is-low-res .list-template-top-right{margin-top:4px}.list-template-top-left,.list-template-btm-left{padding-right:16px;word-break:break-word}.list-template-top-right,.list-template-btm-right{text-align:right;white-space:nowrap}.list-template-btm-left,.list-template-btm-right{font-size:var(--type-caption-size);line-height:var(--type-height-snug)}.list-template-top-left,.list-template-top-right{margin-bottom:4px}.flex-align-center{display:flex;align-items:center}\n"] }]
        }], ctorParameters: () => [{ type: i2.WindowService }], propDecorators: { avatarIcon: [{
                type: Input
            }], avatarImageUrl: [{
                type: Input
            }], avatarBackgroundClass: [{
                type: Input
            }], avatarIconColorClass: [{
                type: Input
            }], avatarShape: [{
                type: Input
            }], allowEmojis: [{
                type: Input
            }], threadModeEnabled: [{
                type: Input
            }], topLeftText: [{
                type: Input
            }], topLeftClass: [{
                type: Input
            }], topLeftIcon: [{
                type: Input
            }], topLeftScreenReaderText: [{
                type: Input
            }], e2eTopLeft: [{
                type: Input
            }], topLeftAdditionalText: [{
                type: Input
            }], topCenterBadge: [{
                type: Input
            }], topRightText: [{
                type: Input
            }], topRightClass: [{
                type: Input
            }], topRightIcon: [{
                type: Input
            }], topRightBadge: [{
                type: Input
            }], topRightScreenReaderText: [{
                type: Input
            }], e2eTopRight: [{
                type: Input
            }], bottomLeftText: [{
                type: Input
            }], bottomLeftHtml: [{
                type: Input
            }], bottomLeftPipedDetails: [{
                type: Input
            }], bottomLeftScreenReaderText: [{
                type: Input
            }], e2eBottomLeft: [{
                type: Input
            }], bottomRightText: [{
                type: Input
            }], bottomRightPipedDetails: [{
                type: Input
            }], bottomRightScreenReaderText: [{
                type: Input
            }], e2eBottomRight: [{
                type: Input
            }], verticalPaddingSize: [{
                type: Input
            }] } });

class ListComponent extends BaseTextComponent {
    set lazyLoadSentinel(el) {
        this.disconnectIntersectionObserver();
        this.lazyLoadSentinelEl = el?.nativeElement;
        if (el?.nativeElement && this.lazyLoad) {
            this.observeLazyLoadSentinel(el.nativeElement);
        }
    }
    constructor(dateProvider, modalService, textService, windowService) {
        super(textService, 'ui-workflows-list');
        this.dateProvider = dateProvider;
        this.modalService = modalService;
        this.textService = textService;
        this.windowService = windowService;
        this.e2eAttr = '';
        /**
        * Required. The array of items (of class ListItem) to render in a list.
        **/
        this.items = [];
        /**
        * Enables scroll-triggered lazy loading. When true, the "Show More" button is hidden and additional items are revealed
        * automatically as the user scrolls toward the end of the list. Defaults to false.
        **/
        this.lazyLoad = false;
        /**
        * If "lazyLoad" is true, this controls how far from the end of the list the trigger to load more items is called.
        * Larger values trigger earlier (more pre-fetch); smaller values trigger closer to the end of the list.
        * The value must be a positive CSS length. Defaults to "200px".
        **/
        this.lazyLoadTriggerDistance = '200px';
        /**
        * If "lazyLoad" is true, this displays a loading animation and message at the end of the list when the user scrolls to the trigger point.
        * A parent component can fetch additional items from the backend then set this property to false when the fetch completes. Defaults to false.
        **/
        this.loading = false;
        /**
        * Enable emoji support for icons. Checking for emojis is expensive, so only enable if needed.
        **/
        this.allowEmojis = false;
        /**
        * Enable "thread mode" to:
        *  - allow any list item's drawer to be expanded without automatically collapsing other expanded drawers
        *  - allow mobile details templates to render in a drawer instead of a modal
        *  - slightly changes List Template layout to better suit threaded conversations
        **/
        this.threadModeEnabled = false;
        /**
        * Specifies whether to display a checkbox or toggle to the right of each list item.
        **/
        this.selectionMode = 'none';
        /**
        * If "selectionMode" is set, this allows for an optional "off" aria-label for accessibility purposes.
        **/
        this.selectionToggledOffAriaLabel = '';
        /**
        * If "selectionMode" is set, this allows for an optional "on" aria-label for accessibility purposes.
        **/
        this.selectionToggledOnAriaLabel = '';
        /**
        * If "clickable" is set to true, this controls the icon that shows at the end of the list item on desktop/tablet.
        **/
        this.clickableIcon = 'chevron_right';
        /**
        * If "clickable" is set to true, this allows setting an optional label to the right of the "clickableIcon" on desktop/tablet.
        **/
        this.clickableLabel = '';
        /**
        * Optional text to show as a header at the top of the list.
        **/
        this.header = '';
        /**
        * Specifies whether the header should stick to the top of the page when scrolling. Only intended for use within web-client.
        * If using within a modal, wrap the list within a .modal-list-container to preserve sticky behavior. Defaults to true.
        **/
        this.stickyHeader = true;
        /**
        * Whether or not the desktop details template should render in a drawer. Defaults to true; set to false to render in a modal.
        **/
        this.detailsTemplateIsDrawer = true;
        /**
        * Optional. Locks the details modal scrim, preventing the user from closing the modal by clicking outside of it.
        * Defaults to false. Content modals should generally have unlocked scrims for ADA reasons —
        * users, especially keyboard users, rely on scrim dismissal as a standard affordance.
        **/
        this.lockDetailsModalScrim = false;
        /**
        * Optional text used to override the default "No Items" title text.
        **/
        this.noListItemsTitleText = '';
        /**
        * Optional text used to override the default "no list items to display" subtitle text.
        **/
        this.noListItemsSubtitleText = '';
        /**
        * Optional text used to override the default "you've reached the end of list" subtitle text.
        * This text will only appear when the "pageSize" is set.
        **/
        this.endOfListText = '';
        /**
        * Specifies whether to show search / sort / filter functionality for the list. Defaults to false.
        **/
        this.searchEnabled = false;
        /**
        * Optional text used to override the default placeholder text for the search field.
        **/
        this.searchFieldPlaceholder = '';
        /**
        * Optional text used to manually set the search field value.
        **/
        this.searchFieldText = '';
        /**
        * Optional array of PickerOptions that are used to sort the list.
        **/
        this.sortOptions = [];
        /**
        * Optional value of the default sort option.
        **/
        this.sortOptionDefaultValue = '';
        /**
        * The available customized list filters to show. Each SearchSortFilter must define a list of options.
        **/
        this.customFilters = [];
        /**
        * Specifies whether to include the standard date filters. Defaults to false.
        **/
        this.includeDateFilters = false;
        /**
        * If "includeDateFilters" is true, this flag determines whether to use "past" or "future" date filters.
        * Defaults to false ("past" date filters).
        **/
        this.useFutureDateFilters = false;
        /**
        * If "showBorder" is true, a rounded border will be shown around the list. Defaults to true.
        **/
        this.showBorder = true;
        /**
        * Optional array of "checked" items (of class ListItem).
        * When "bulkActions" is specified, this array is used for managing selection state.
        **/
        this.checkedItems = [];
        /**
        * E2E testing - data-e2e attribute attached to the list.
        **/
        this.e2e = 'list';
        /**
        * Emits search value on change.
        **/
        this.searched = new EventEmitter();
        /**
        * Emits sort value when the sort option is changed.
        **/
        this.sorted = new EventEmitter();
        /**
        * Emits all available filters when a filter value is changed.
        **/
        this.filtered = new EventEmitter();
        /**
        * Emits all available filters and a boolean that specifies whether to refilter when the "Clear All" filters
        * button is clicked. A true value (the default) means that the list should be refiltered.
        **/
        this.filtersCleared = new EventEmitter();
        /**
        * Emits when the mobile "View All" modal is closed.
        **/
        this.mobileViewAllModalClosed = new EventEmitter();
        /**
        * When a checkbox or toggle is clicked, the ListItem is emitted with an updated "checked" property.
        **/
        this.controlToggled = new EventEmitter();
        /**
        * Emits a ListItem when a list row is clicked, which allows the parent component to navigate to a new page, open a modal, etc.
        **/
        this.listRowClicked = new EventEmitter();
        /**
        * Emits when the "Show More" button is clicked.
        **/
        this.showMoreButtonClicked = new EventEmitter();
        /**
        * Emits when a bulk action is clicked.
        **/
        this.bulkAction = new EventEmitter();
        /**
        * Emits when the bulk action's "Clear All" button is clicked.
        **/
        this.bulkActionsCleared = new EventEmitter();
        /**
        * Emits the current ListItem when the primary button within the drawer/modal is clicked.
        **/
        this.detailsPrimaryButtonClicked = new EventEmitter();
        /**
        * Emits the current ListItem when the secondary button within the drawer/modal is clicked.
        **/
        this.detailsSecondaryButtonClicked = new EventEmitter();
        /**
        * Emits the current ListItem when the tertiary button within the drawer/modal is clicked.
        **/
        this.detailsTertiaryButtonClicked = new EventEmitter();
        this.HtmlAttributeStateEnum = HtmlAttributeState;
        this.bulkActionsSelectedLabel = '';
        this.e2ePrefix = '';
        this.detailModalE2E = '';
        this.listId = '';
        this.listItemHeaders = [];
        this.windowService.windowSize$.pipe(this.takeUntilDestroyed()).subscribe(windowSize => {
            this.isMobile = windowSize.isMobile;
        });
        this.setE2EPrefix();
    }
    ngOnInit() {
        this.listId = HtmlUtils.generateRandomId();
        this.resetPageSize();
        this.toggledOffAriaLabel = this.selectionToggledOffAriaLabel || this.text.selectionToggledOffAriaLabel;
        this.toggledOnAriaLabel = this.selectionToggledOnAriaLabel || this.text.selectionToggledOnAriaLabel;
    }
    ngOnChanges(changes) {
        if (changes.items && this.items?.length) {
            this.populateListItemHeadersAndE2E();
        }
        if (changes.checkedItems) {
            if (this.bulkActions?.length) {
                this.bulkActionsSelectedLabel = format(this.text.bulkActionsSelectedLabel, { numItems: this.checkedItems.length });
            }
            if (this.items?.length && this.items.every(i => i.checked)) {
                this.selectAllCheckboxChecked = true;
                this.selectAllCheckboxIndeterminate = false;
            }
            else if (this.items.every(i => !i.checked)) {
                this.selectAllCheckboxChecked = false;
                this.selectAllCheckboxIndeterminate = false;
            }
            else {
                this.selectAllCheckboxIndeterminate = this.checkedItems.length > 0 && this.checkedItems.length < this.totalItemCount;
            }
        }
        if (changes.e2e) {
            this.setE2EPrefix();
        }
        if (changes.loading && !changes.loading.firstChange && !this.loading
            && this.lazyLoadSentinelEl && this.numItemsToShow < this.items.length) {
            // Re-observe the sentinel so the observer does a fresh initial-state check.
            // Without this, if loading flips false without items growing, the observer
            // stays silent until the user manually scrolls the sentinel in/out of view.
            this.disconnectIntersectionObserver();
            this.observeLazyLoadSentinel(this.lazyLoadSentinelEl);
        }
    }
    ngAfterViewInit() {
        if (this.items.some(item => item.showDetails) && this.detailsTemplate) {
            const detailsItem = this.items.find(item => item.showDetails);
            this.showItemDetails(detailsItem);
            setTimeout(() => {
                const index = this.items.findIndex(item => item === detailsItem);
                const detailsItemElement = document.querySelector(`#${this.listId}-item-drawer-${index}`);
                if (detailsItemElement) {
                    detailsItemElement.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                }
            }, 100);
        }
    }
    onToggle(item, checked) {
        item.checked = checked;
        this.controlToggled.emit(item);
    }
    onListRowClick(item) {
        const shouldOpenDetails = !!this.detailsTemplate && !item.showDetails;
        if (this.threadModeEnabled) {
            if (item.showDetails) {
                item.showDetails = false;
            }
        }
        else {
            for (const i of this.items) {
                if (i.showDetails) { // it's possible for showDetails to be set to true and selectedItem to be outdated (e.g. updating Transaction Tags)
                    i.showDetails = false;
                }
            }
        }
        if (shouldOpenDetails) {
            this.showItemDetails(item);
        }
        else {
            this.selectedItem = null;
        }
        if (this.clickable || this.detailsTemplate) {
            this.listRowClicked.emit(item);
        }
    }
    showItemDetails(item) {
        item.showDetails = true;
        this.selectedItem = item;
        if (this.isMobile && !this.threadModeEnabled || !this.detailsTemplateIsDrawer) {
            this.detailModalE2E = (item.e2e || this.e2ePrefix) + 'details-modal';
            this.modalService.openEnhancedModal(this.detailsModal);
        }
    }
    detailsPrimaryButtonClick() {
        this.detailsPrimaryButtonClicked.emit(this.selectedItem);
    }
    detailsSecondaryButtonClick() {
        this.detailsSecondaryButtonClicked.emit(this.selectedItem);
    }
    detailsTertiaryButtonClick() {
        this.detailsTertiaryButtonClicked.emit(this.selectedItem);
    }
    populateListItemHeadersAndE2E() {
        const headers = [];
        let lastHeaderText = '';
        for (let item of this.items) {
            const headerText = item.headerDate ? this.getDateString(item.headerDate) : item.headerStaticText;
            if (headerText && lastHeaderText !== headerText) {
                headers.push(new ListItemHeader(headerText, true));
                lastHeaderText = headerText;
            }
            else {
                headers.push(new ListItemHeader(headerText, false));
            }
            // Format item e2e values
            if (item.e2e) {
                item.e2e = HtmlUtils.formatE2EPrefix(item.e2e);
            }
        }
        this.listItemHeaders = headers;
    }
    getDateString(date) {
        const currentYear = this.dateProvider.getDate().getFullYear();
        const isCurrentYear = date.getFullYear() === currentYear;
        const language = LANGUAGES.find(l => l.code === this.textService.getLanguage());
        return DateUtils.getFIDateFormatString(date, `dddd, MMM DD${isCurrentYear ? '' : ', YYYY'}`, language);
    }
    onSearchToggleClick() {
        this.autoFocusSearchInput = true;
        if (this.isMobile) {
            this.openMobileViewAllModal();
        }
        else {
            this.showSearchSortFilter = !this.showSearchSortFilter;
        }
    }
    onSearchChange(searchText) {
        this.searched.emit(searchText);
        this.searchInputChanged = true;
    }
    onSortChange(value) {
        this.sorted.emit(value);
    }
    onFilterChange(filters) {
        this.filtered.emit(filters);
    }
    onFilterClearAllChange(event) {
        this.filtersCleared.emit(event);
    }
    onSelectAllChange(checked) {
        this.items.filter(item => !item.locked).forEach(item => item.checked = checked);
    }
    onDetailsModalClose() {
        if (this.selectedItem) {
            this.selectedItem.showDetails = false;
        }
    }
    closeMobileViewAllModal() {
        this.isMobileViewAllModalOpen = false;
        this.autoFocusSearchInput = false;
        this.mobileViewAllModalClosed.emit();
    }
    // Used through ViewChild when the list filters need to be reset
    clearAllFilters() {
        if (this.searchSortFilterComponent) {
            this.searchSortFilterComponent.clearAllFilters(false);
        }
    }
    // Used through ViewChild when the list paging needs to be reset to the default number of items
    resetPageSize() {
        if (this.isMobile && this.header) {
            this.numItemsToShow = 7; // mobile List with "header" option always starts with showing 7 items
        }
        else {
            this.numItemsToShow = this.pageSize;
        }
    }
    showMore() {
        this.showMoreClicked = false;
        if (this.isMobile && this.header && !this.isMobileViewAllModalOpen) {
            this.openMobileViewAllModal();
        }
        else {
            if (this.isMobileViewAllModalOpen) {
                this.numModalItemsToShow += this.pageSize;
            }
            else {
                this.numItemsToShow += this.pageSize;
            }
            this.showMoreButtonClicked.emit();
            setTimeout(() => this.showMoreClicked = true, 250); // delay needed for screen reader to announce
        }
    }
    doBulkAction(action) {
        const bulkActionEvent = action.action(this.checkedItems);
        this.bulkAction.emit(bulkActionEvent);
    }
    clearBulkActions() {
        this.items.filter(item => item.checked).forEach(item => item.checked = false);
        this.bulkActionsCleared.emit();
    }
    observeLazyLoadSentinel(target) {
        if (typeof IntersectionObserver === 'undefined') {
            return;
        }
        this.intersectionObserver = new IntersectionObserver(entries => {
            if (entries[0]?.isIntersecting && !this.loading && this.numItemsToShow < this.items.length) {
                this.showMore();
            }
        }, { rootMargin: `0px 0px ${this.lazyLoadTriggerDistance} 0px` });
        this.intersectionObserver.observe(target);
    }
    disconnectIntersectionObserver() {
        if (this.intersectionObserver) {
            this.intersectionObserver.disconnect();
            this.intersectionObserver = undefined;
        }
    }
    ngOnDestroy() {
        this.disconnectIntersectionObserver();
        super.ngOnDestroy();
    }
    openMobileViewAllModal() {
        this.numModalItemsToShow = this.pageSize;
        this.modalService.openMobileOnlyModal(this.mobileViewAllModal);
        this.isMobileViewAllModalOpen = true;
    }
    setE2EPrefix() {
        this.e2eAttr = this.e2e || 'list';
        this.e2ePrefix = HtmlUtils.formatE2EPrefix(this.e2eAttr);
    }
    getDefaultText() {
        return {
            toggleSearchLabel: 'Toggle Search',
            defaultClickableLabel: 'View Details',
            defaultDetailsTemplateTitle: 'Details',
            selectionToggledOffAriaLabel: 'Off',
            selectionToggledOnAriaLabel: 'On',
            showMoreButtonText: 'Show More',
            seeAllButtonText: 'See All',
            endOfListText: 'You\'ve reached the end of the list.',
            noListItemsTitleText: 'No Items',
            noListItemsSubtitleText: 'There are no items to display.',
            ariaLiveMoreOptionsShown: 'More items shown below.',
            ariaLiveNoResultsFound: 'No results found.',
            ariaLiveOneResultFound: 'One result found.',
            ariaLiveMultipleResultsFound: 'Multiple results found.',
            bulkActionsSelectedLabel: '{{ numItems }} Selected',
            bulkNoCommonActionsLabel: 'No common actions',
            clearCheckedItemsButtonLabel: 'Clear All',
            loadingMoreItemsText: 'Getting more items',
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: ListComponent, deps: [{ token: i1$1.DateProvider }, { token: i2.ModalService }, { token: i2.TextService }, { token: i2.WindowService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.17", type: ListComponent, isStandalone: false, selector: "ui-workflows-list", inputs: { items: "items", pageSize: "pageSize", lazyLoad: "lazyLoad", lazyLoadTriggerDistance: "lazyLoadTriggerDistance", loading: "loading", allowEmojis: "allowEmojis", threadModeEnabled: "threadModeEnabled", selectionMode: "selectionMode", selectionToggledOffAriaLabel: "selectionToggledOffAriaLabel", selectionToggledOnAriaLabel: "selectionToggledOnAriaLabel", hideRightContentOnMobile: "hideRightContentOnMobile", clickable: "clickable", clickableIcon: "clickableIcon", clickableLabel: "clickableLabel", header: "header", stickyHeader: "stickyHeader", detailsTemplate: "detailsTemplate", detailsTemplateIsDrawer: "detailsTemplateIsDrawer", lockDetailsModalScrim: "lockDetailsModalScrim", detailsTemplateTitle: "detailsTemplateTitle", detailsPrimaryButtonText: "detailsPrimaryButtonText", detailsSecondaryButtonText: "detailsSecondaryButtonText", detailsTertiaryButtonText: "detailsTertiaryButtonText", detailsTertiaryButtonIcon: "detailsTertiaryButtonIcon", noListItemsTitleText: "noListItemsTitleText", noListItemsSubtitleText: "noListItemsSubtitleText", endOfListText: "endOfListText", searchEnabled: "searchEnabled", searchFieldPlaceholder: "searchFieldPlaceholder", searchFieldText: "searchFieldText", sortOptions: "sortOptions", sortOptionDefaultValue: "sortOptionDefaultValue", customFilters: "customFilters", includeDateFilters: "includeDateFilters", useFutureDateFilters: "useFutureDateFilters", showBorder: "showBorder", bulkActions: "bulkActions", checkedItems: "checkedItems", totalItemCount: "totalItemCount", e2e: "e2e" }, outputs: { searched: "searched", sorted: "sorted", filtered: "filtered", filtersCleared: "filtersCleared", mobileViewAllModalClosed: "mobileViewAllModalClosed", controlToggled: "controlToggled", listRowClicked: "listRowClicked", showMoreButtonClicked: "showMoreButtonClicked", bulkAction: "bulkAction", bulkActionsCleared: "bulkActionsCleared", detailsPrimaryButtonClicked: "detailsPrimaryButtonClicked", detailsSecondaryButtonClicked: "detailsSecondaryButtonClicked", detailsTertiaryButtonClicked: "detailsTertiaryButtonClicked" }, host: { properties: { "attr.data-e2e": "this.e2eAttr" } }, viewQueries: [{ propertyName: "detailsModal", first: true, predicate: ["detailsModal"], descendants: true }, { propertyName: "mobileViewAllModal", first: true, predicate: ["mobileViewAllModal"], descendants: true }, { propertyName: "searchSortFilterComponent", first: true, predicate: SearchSortFilterComponent, descendants: true }, { propertyName: "lazyLoadSentinel", first: true, predicate: ["lazyLoadSentinel"], descendants: true }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div\n    class=\"list-container\"\n    [class.bordered]=\"showBorder\"\n    [id]=\"e2ePrefix + 'container'\"\n    [class.with-header]=\"!!header\"\n    [class.pt-6]=\"!searchEnabled && items.length === 0\">\n\n    @if (!!header) {\n        <div\n            class=\"list-group-header\"\n            [class.with-search]=\"searchEnabled\">\n            <h4\n                class=\"flex-fill mb-0\"\n                [class.mt-half]=\"searchEnabled && items.length === 0\">\n                {{ header }}\n            </h4>\n\n            @if (searchEnabled && items.length > 0) {\n                <ui-core-icon-button\n                    [ariaControls]=\"!isMobile && showSearchSortFilter ? 'search-sort-filter-container' : undefined\"\n                    [ariaExpanded]=\"!isMobile && showSearchSortFilter\"\n                    [ariaHasPopup]=\"isMobile ? HtmlAttributeStateEnum.TRUE : HtmlAttributeStateEnum.FALSE\"\n                    [e2e]=\"e2ePrefix + 'search-toggle-button'\"\n                    icon=\"search\"\n                    [message]=\"text.toggleSearchLabel\"\n                    (click)=\"onSearchToggleClick()\">\n                </ui-core-icon-button>\n            }\n        </div>\n    }\n\n    <ng-container\n        [ngTemplateOutlet]=\"searchTemplate\"\n        [ngTemplateOutletContext]=\"{hideFilters: header && (isMobile || !showSearchSortFilter)}\">\n    </ng-container>\n    <ng-container\n        [ngTemplateOutlet]=\"listTemplate\"\n        [ngTemplateOutletContext]=\"{itemsToShow: numItemsToShow}\">\n    </ng-container>\n    <ng-container\n        [ngTemplateOutlet]=\"endOfListTemplate\"\n        [ngTemplateOutletContext]=\"{itemsToShow: numItemsToShow, seeAllButton: header && isMobile}\">\n    </ng-container>\n</div>\n\n<ng-template\n    #listTemplate\n    let-itemsToShow=\"itemsToShow\"\n    let-isModal=\"isModal\">\n\n    @for (item of items | slice:0:itemsToShow; track item; let idx = $index; let first = $first; let last = $last) {\n        @let e2eValue = item.e2e || e2ePrefix;\n        @let indexCount = item.e2e ? '' : '-' + (idx + 1);\n\n        @if (listItemHeaders[idx]?.visible) {\n            <div\n                class=\"list-item-header\"\n                role=\"heading\"\n                aria-level=\"5\"\n                [class.border-radius-top]=\"first && showBorder && ((!searchEnabled && !header) || isModal)\"\n                [class.sticky]=\"stickyHeader\">\n                {{ listItemHeaders[idx].headerText }}\n            </div>\n        }\n        <div\n            class=\"list-item-row\"\n            [attr.data-e2e]=\"item.e2e ? item.e2e + 'row' : undefined\"\n            [class]=\"item.backgroundClass\"\n            [class.border-radius-top]=\"!searchEnabled && !listItemHeaders[idx]?.visible && idx === 0 && showBorder\"\n            [class.border-radius-bottom]=\"last && showBorder\"\n            [class.border-top]=\"!listItemHeaders[idx]?.visible && idx !== 0\"\n            [class.clickable]=\"clickable || detailsTemplate\"\n            [class.has-selection-mode]=\"selectionMode !== 'none'\" [class.is-mobile]=\"isMobile\">\n            <div class=\"flex-fill\">\n                <div class=\"d-flex\">\n\n                    @if (selectionMode === 'checkbox') {\n                        <div class=\"list-item-clickable-container mt-2 pl-2 pl-md-3\">\n                            <ui-forms-checkbox\n                                [checked]=\"item.checked\"\n                                [e2e]=\"e2eValue + 'checkbox' + indexCount\"\n                                [hideLabel]=\"true\"\n                                [isChild]=\"true\"\n                                [label]=\"item.checked ? toggledOnAriaLabel : toggledOffAriaLabel\"\n                                [locked]=\"item.locked\"\n                                (change)=\"onToggle(item, $event)\">\n                            </ui-forms-checkbox>\n                        </div>\n                    }\n                    <div\n                        class=\"list-item-content\"\n                        [attr.aria-controls]=\"detailsTemplate && item.showDetails ? (detailsTemplateIsDrawer && (!isMobile || threadModeEnabled) ? listId + '-item-drawer-' + idx : e2ePrefix + 'details-modal') : undefined\"\n                        [attr.aria-expanded]=\"detailsTemplate ? item.showDetails : undefined\"\n                        [attr.data-e2e]=\"e2eValue + 'item' + indexCount\"\n                        [attr.role]=\"clickable || detailsTemplate ? 'button' : undefined\"\n                        [class.focusable]=\"clickable || detailsTemplate\" [class.open]=\"item.showDetails\"\n                        [tabindex]=\"clickable || detailsTemplate ? 0 : -1\"\n                        [id]=\"listId + '-item-' + idx\"\n                        (click)=\"onListRowClick(item)\" (keyup.enter)=\"onListRowClick(item)\">\n\n                        @if (listItemHeaders[idx]?.headerText) {\n                            <div class=\"sr-only\">{{ listItemHeaders[idx].headerText + ' - ' }}</div>\n                        }\n\n                        @if (item.topLeftBadges?.length) {\n                            <div class=\"top-left-badges-container\">\n                                <ui-core-badge-list [items]=\"item.topLeftBadges\"></ui-core-badge-list>\n                            </div>\n                        }\n                        <ui-workflows-list-template\n                            [allowEmojis]=\"allowEmojis\"\n                            [avatarBackgroundClass]=\"item.avatarBackgroundClass\"\n                            [avatarIconColorClass]=\"item.avatarIconColorClass\"\n                            [avatarIcon]=\"item.avatarIcon\"\n                            [avatarImageUrl]=\"item.avatarImageUrl\"\n                            [avatarShape]=\"item.avatarShape\"\n                            [topLeftText]=\"item.topLeftText\"\n                            [topLeftClass]=\"item.topLeftClass\"\n                            [topLeftIcon]=\"item.topLeftIcon\"\n                            [topLeftScreenReaderText]=\"item.topLeftScreenReaderText\"\n                            [topLeftAdditionalText]=\"item.topLeftAdditionalText\"\n                            [e2eTopLeft]=\"item.e2eTopLeft\"\n                            [topCenterBadge]=\"item.topCenterBadge\"\n                            [topRightClass]=\"item.topRightClass\"\n                            [topRightText]=\"isMobile && (item.actionButtonText && item.actionButtonTheme === 'tertiary' || hideRightContentOnMobile) ? '' : item.topRightText\"\n                            [topRightIcon]=\"isMobile && (item.actionButtonText && item.actionButtonTheme === 'tertiary' || hideRightContentOnMobile) ? '' : item.topRightIcon\"\n                            [topRightBadge]=\"isMobile && (item.actionButtonText && item.actionButtonTheme === 'tertiary' || hideRightContentOnMobile) ? '' : item.topRightBadge\"\n                            [topRightScreenReaderText]=\"item.topRightScreenReaderText\"\n                            [e2eTopRight]=\"item.e2eTopRight\"\n                            [bottomLeftText]=\"item.bottomLeftText\"\n                            [bottomLeftHtml]=\"item.bottomLeftHtml\"\n                            [bottomLeftPipedDetails]=\"item.bottomLeftPipedDetails\"\n                            [bottomLeftScreenReaderText]=\"item.bottomLeftScreenReaderText\"\n                            [e2eBottomLeft]=\"item.e2eBottomLeft\"\n                            [bottomRightText]=\"isMobile && (item.actionButtonText  && item.actionButtonTheme === 'tertiary' || hideRightContentOnMobile) ? '' : item.bottomRightText\"\n                            [bottomRightPipedDetails]=\"isMobile && (item.actionButtonText && item.actionButtonTheme === 'tertiary' || hideRightContentOnMobile) ? '' : item.bottomRightPipedDetails\"\n                            [bottomRightScreenReaderText]=\"item.bottomRightScreenReaderText\"\n                            [e2eBottomRight]=\"item.e2eBottomRight\"\n                            [threadModeEnabled]=\"threadModeEnabled && item.showDetails\"\n                            [verticalPaddingSize]=\"item.verticalPaddingSize\">\n                        </ui-workflows-list-template>\n                    </div>\n\n                    @if (item.actionButtonText && (item.actionButtonTheme === 'tertiary' || !isMobile)) {\n                        <ng-container\n                            [ngTemplateOutlet]=\"actionButtonTemplate\"\n                            [ngTemplateOutletContext]=\"{e2eValue: e2eValue, item: item}\">\n                        </ng-container>\n                    }\n\n                    @if (selectionMode === 'toggle') {\n                        <div class=\"list-item-clickable-container flex-align-center pr-half\">\n                            <ui-forms-toggle\n                                [class]=\"item.actionButtonText ? 'border-left pl-1 pt-2 pb-1' : 'pt-1'\"\n                                [checked]=\"item.checked\"\n                                [e2e]=\"e2eValue + 'toggle' + indexCount\"\n                                [hideLabel]=\"true\"\n                                [hideLockIcon]=\"true\"\n                                [label]=\"item.checked ? toggledOnAriaLabel : toggledOffAriaLabel\"\n                                [locked]=\"item.locked\"\n                                (change)=\"onToggle(item, $event)\">\n                            </ui-forms-toggle>\n                        </div>\n                    }\n                </div>\n\n                @if (item.actionButtonText && item.actionButtonTheme === 'secondary' && isMobile) {\n                    <ng-container\n                        [ngTemplateOutlet]=\"actionButtonTemplate\"\n                        [ngTemplateOutletContext]=\"{e2eValue: e2eValue, item: item}\">\n                    </ng-container>\n                }\n            </div>\n\n            @if ((clickable && clickableIcon) || detailsTemplate) {\n                <div\n                    [attr.data-e2e]=\"e2eValue + 'item-clickable' + indexCount\"\n                    class=\"list-item-clickable-container flex-align-center\"\n                    [class]=\"clickableIcon === 'chevron_right' ? 'pr-half' : 'pr-1'\"\n                    (click)=\"onListRowClick(item)\">\n\n                    <!-- keyboard accessibility is intentionally not wired up here as this is an extra (click) option for sighted users -->\n                    @if (isMobile && !threadModeEnabled) {\n                        <ui-core-icon\n                            class=\"mr-half\"\n                            [icon]=\"clickableIcon\"\n                            size=\"xxl\">\n                        </ui-core-icon>\n                    } @else {\n                        <div class=\"flex-align-center\">\n                            <ui-core-icon\n                                class=\"d-inline-flex mr-1\"\n                                [colorClass]=\"detailsTemplate && detailsTemplateIsDrawer && item.showDetails ? 'color-brand-secondary' : ''\"\n                                [size]=\"clickableLabel ? 'xl' : 'xxl'\"\n                                [icon]=\"detailsTemplate && detailsTemplateIsDrawer ? (item.showDetails ? 'arrow_drop_up' : 'arrow_drop_down') : clickableIcon\">\n                            </ui-core-icon>\n\n                            @if (clickableLabel && !threadModeEnabled) {\n                                <span class=\"text-second text-semibold mr-1\">\n                                    {{ clickableLabel }}\n                                </span>\n                            }\n                        </div>\n                    }\n                </div>\n            }\n        </div>\n\n        @if (item.showDetails && detailsTemplate && detailsTemplateIsDrawer && (!isMobile || threadModeEnabled)) {\n            <div\n                class=\"list-item-drawer\"\n                [class.bg-brand]=\"!threadModeEnabled\"\n                [id]=\"listId + '-item-drawer-' + idx\"\n                role=\"region\"\n                [attr.aria-labelledby]=\"listId + '-item-' + idx\"\n                [attr.data-e2e]=\"e2eValue + 'details' + indexCount\"\n                [@collapseOrSlideState]=\"'collapseState'\">\n                <ng-container\n                    [ngTemplateOutlet]=\"detailsTemplate\"\n                    [ngTemplateOutletContext]=\"{item: item.originalItem}\">\n                </ng-container>\n\n                @if (detailsPrimaryButtonText || detailsSecondaryButtonText || detailsTertiaryButtonText) {\n                    <div class=\"px-4 pb-4\">\n                        <ui-core-button-group\n                            [marginBottom]=\"false\"\n                            [primaryButtonText]=\"detailsPrimaryButtonText\"\n                            [secondaryButtonText]=\"detailsSecondaryButtonText\"\n                            [tertiaryButtonText]=\"detailsTertiaryButtonText\"\n                            [tertiaryButtonIcon]=\"detailsTertiaryButtonIcon\"\n                            [e2e]=\"e2eValue + 'drawer' + indexCount\"\n                            (primaryButtonClicked)=\"detailsPrimaryButtonClick()\"\n                            (secondaryButtonClicked)=\"detailsSecondaryButtonClick()\"\n                            (tertiaryButtonClicked)=\"detailsTertiaryButtonClick()\">\n                        </ui-core-button-group>\n                    </div>\n                }\n            </div>\n        }\n    }\n</ng-template>\n\n<ng-template\n    #actionButtonTemplate\n    let-e2eValue=\"e2eValue\"\n    let-item=\"item\">\n    <div\n        class=\"list-item-action-button-container\"\n        [class.secondary-theme]=\"item.actionButtonTheme === 'secondary'\">\n\n        @if (isMobile && item.actionButtonIcon && item.actionButtonTheme === 'tertiary' && !item.actionButtonTertiaryTextDisplaysOnMobile) {\n            <ui-core-icon-button\n                [e2e]=\"e2eValue + 'action-button'\"\n                [icon]=\"item.actionButtonIcon\"\n                [message]=\"item.actionButtonText\"\n                (click)=\"item.actionButtonMethod(item)\">\n            </ui-core-icon-button>\n        } @else {\n            <ui-core-button\n                [buttonClass]=\"item.actionButtonTheme === 'secondary' ? 'my-2 px-md-6 py-md-2' : ''\"\n                [e2e]=\"e2eValue + 'action-button'\"\n                [icon]=\"item.actionButtonIcon\"\n                [message]=\"item.actionButtonText\"\n                [theme]=\"item.actionButtonTheme\"\n                width=\"full\"\n                (click)=\"item.actionButtonMethod(item)\">\n            </ui-core-button>\n        }\n    </div>\n</ng-template>\n\n<ng-template\n    #searchTemplate\n    let-hideFilters=\"hideFilters\">\n\n    @if (searchEnabled && !hideFilters) {\n        <ui-workflows-search-sort-filter\n            [autoFocusSearchInput]=\"autoFocusSearchInput\"\n            [customFilters]=\"customFilters\"\n            [includeDateFilters]=\"includeDateFilters\"\n            [paddingTop]=\"!header\"\n            [searchFieldPlaceholder]=\"searchFieldPlaceholder\"\n            [searchFieldText]=\"searchFieldText\"\n            [selectAllCheckboxChecked]=\"selectAllCheckboxChecked\"\n            [selectAllCheckboxIndeterminate]=\"selectAllCheckboxIndeterminate\"\n            [showSelectAllCheckbox]=\"selectionMode === 'checkbox'\"\n            [sortOptions]=\"sortOptions\"\n            [sortOptionDefaultValue]=\"sortOptionDefaultValue\"\n            [useFutureDateFilters]=\"useFutureDateFilters\"\n            [withinListComponent]=\"true\"\n            (filtered)=\"onFilterChange($event)\"\n            (filtersCleared)=\"onFilterClearAllChange($event)\"\n            (allSelected)=\"onSelectAllChange($event)\"\n            (searched)=\"onSearchChange($event)\"\n            (sorted)=\"onSortChange($event)\">\n        </ui-workflows-search-sort-filter>\n\n        @if (searchInputChanged) {\n            <div\n                class=\"sr-only\"\n                aria-live=\"polite\">\n\n                @if (items.length === 0) {\n                    <span>{{ text.ariaLiveNoResultsFound }}</span>\n                } @else if (items.length === 1) {\n                    <span>{{ text.ariaLiveOneResultFound }}</span>\n                } @else {\n                    <span>{{ text.ariaLiveMultipleResultsFound }}</span>\n                }\n            </div>\n        }\n    }\n</ng-template>\n\n<ng-template\n    #endOfListTemplate\n    let-itemsToShow=\"itemsToShow\"\n    let-seeAllButton=\"seeAllButton\">\n\n    @if (items && itemsToShow < items.length && (seeAllButton || !lazyLoad)) {\n        <div class=\"text-center py-3\">\n            <ui-core-button\n                [ariaControls]=\"isMobile && !!header ? e2ePrefix + 'mobile-view-all-modal' : e2ePrefix + 'container'\"\n                [ariaHasPopup]=\"isMobile && !!header ? HtmlAttributeStateEnum.TRUE : HtmlAttributeStateEnum.FALSE\"\n                [message]=\"seeAllButton ? text.seeAllButtonText : text.showMoreButtonText\"\n                theme=\"secondary\"\n                (click)=\"showMore()\">\n            </ui-core-button>\n        </div>\n    }\n\n    @if (lazyLoad && !seeAllButton && items && itemsToShow < items.length) {\n        <div\n            #lazyLoadSentinel\n            class=\"lazy-load-sentinel\"\n            aria-hidden=\"true\">\n        </div>\n\n        @if (loading) {\n            <div class=\"text-center py-3\">\n                <ui-core-spinner\n                    [message]=\"text.loadingMoreItemsText\"\n                    [centered]=\"true\">\n                </ui-core-spinner>\n            </div>\n        }\n    }\n\n    @if (showMoreClicked) {\n        <span\n            class=\"sr-only\"\n            aria-live=\"polite\">{{ text.ariaLiveMoreOptionsShown }}</span>\n    }\n\n    @if (items && (itemsToShow >= items.length || (!itemsToShow && items.length === 0))) {\n        <ui-workflows-end-of-list\n            [items]=\"items\"\n            [endOfListText]=\"endOfListText || text.endOfListText\"\n            [noListItemsTitleText]=\"noListItemsTitleText || text.noListItemsTitleText\"\n            [noListItemsSubtitleText]=\"noListItemsSubtitleText || text.noListItemsSubtitleText\">\n        </ui-workflows-end-of-list>\n    }\n</ng-template>\n\n@if (selectionMode === 'checkbox' && bulkActions?.length > 0 && checkedItems?.length > 0) {\n    <ui-workflows-bulk-actions\n        [actions]=\"bulkActions\"\n        [rowLabel]=\"bulkActionsSelectedLabel\"\n        [emptyLabel]=\"text.bulkNoCommonActionsLabel\"\n        [clearAllLabel]=\"text.clearCheckedItemsButtonLabel\"\n        (bulkAction)=\"doBulkAction($event)\"\n        (allCleared)=\"clearBulkActions()\">\n    </ui-workflows-bulk-actions>\n}\n\n<ng-template #detailsModal>\n    <ui-core-modal\n        [id]=\"e2ePrefix + 'details-modal'\"\n        [e2e]=\"detailModalE2E\"\n        [primaryButtonText]=\"detailsPrimaryButtonText\"\n        [secondaryButtonText]=\"detailsSecondaryButtonText\"\n        [actionButtonText]=\"detailsTertiaryButtonText\"\n        [actionButtonIcon]=\"detailsTertiaryButtonIcon\"\n        [title]=\"detailsTemplateTitle ?? text.defaultDetailsTemplateTitle\"\n        [lockScrim]=\"lockDetailsModalScrim\"\n        (closed)=\"onDetailsModalClose()\"\n        (primaryButtonClicked)=\"detailsPrimaryButtonClick()\"\n        (secondaryButtonClicked)=\"detailsSecondaryButtonClick()\"\n        (actionButtonClicked)=\"detailsTertiaryButtonClick()\">\n\n        @if (selectedItem) {\n            <ng-container\n                [ngTemplateOutlet]=\"detailsTemplate\"\n                [ngTemplateOutletContext]=\"{item: selectedItem.originalItem}\">\n            </ng-container>\n        }\n    </ui-core-modal>\n</ng-template>\n\n<ng-template #mobileViewAllModal>\n    <ui-core-modal\n        [id]=\"e2ePrefix + 'mobile-view-all-modal'\"\n        [e2e]=\"e2ePrefix + 'mobile-view-all-modal'\"\n        [noBodyPadding]=\"true\"\n        [title]=\"header\"\n        (closed)=\"closeMobileViewAllModal()\">\n        <div class=\"mt-4\">\n            <ng-container [ngTemplateOutlet]=\"searchTemplate\"></ng-container>\n        </div>\n        <div\n            class=\"modal-list-container mx-2 mb-2\"\n            [class.bordered]=\"showBorder\"\n            [class.border-0]=\"items.length === 0\">\n            <ng-container\n                [ngTemplateOutlet]=\"listTemplate\"\n                [ngTemplateOutletContext]=\"{itemsToShow: numModalItemsToShow, isModal: true}\">\n            </ng-container>\n        </div>\n        <ng-container\n            [ngTemplateOutlet]=\"endOfListTemplate\"\n            [ngTemplateOutletContext]=\"{itemsToShow: numModalItemsToShow}\">\n        </ng-container>\n    </ui-core-modal>\n</ng-template>\n", styles: [".lazy-load-sentinel{height:1px;width:100%}.list-container{background-color:var(--color-default);position:relative}.list-container.with-header.bordered{border:1px solid var(--color-stroke-1)}.list-container.bordered,.modal-list-container.bordered{border:1px solid var(--color-stroke-1);border-radius:var(--containers-shape)}.list-group-header{align-items:center;display:flex;padding:16px 20px}.list-group-header.with-search{padding-top:12px;padding-bottom:12px}@media (max-width: 767.98px){.list-group-header{padding:16px 12px 20px 16px}.list-group-header.with-search{padding-top:12px;padding-bottom:16px}}.list-item-header{background-color:var(--color-gray-50);color:var(--color-content-secondary);font-size:var(--type-caption-size);font-weight:var(--type-weight-semibold);padding-bottom:var(--spacing-50);padding-left:16px;padding-top:var(--spacing-50);z-index:5}.list-item-header.sticky{position:sticky;top:var(--navbar-mobile-height)}:host-context(.fixed-top-notification) .list-item-header.sticky{top:calc(var(--navbar-mobile-height) * 2)}.modal-list-container .list-item-header.sticky{overflow:hidden;top:0}.modal-list-container .list-item-header.sticky:first-child{border-top-left-radius:var(--containers-shape);border-top-right-radius:var(--containers-shape)}@media (min-width: 1080px){.list-item-header.sticky{top:var(--navbar-desktop-height)}:host-context(.fixed-top-notification) .list-item-header.sticky{top:calc(var(--navbar-desktop-height) + var(--navbar-mobile-height))}}.list-item-header.sticky+.list-item-row .list-item-content{scroll-margin-top:calc(var(--navbar-desktop-height) + 25px)}@media (max-width: 1079.98px){.list-item-header.sticky+.list-item-row .list-item-content{scroll-margin-top:calc(var(--navbar-mobile-height) + 25px)}}.list-item-row{display:flex}@media (hover: hover){.list-item-row:has(.list-item-content.focusable:not(.open):focus) .list-item-clickable-container{background-color:var(--color-hover)}}.list-item-content{flex:1 1 auto;overflow:hidden}@media (hover: hover){.list-item-content.focusable:not(.open):focus,.list-item-content.focusable:not(.open):focus~div{background-color:var(--color-hover)}}.list-item-content .top-left-badges-container{padding:0 16px}.list-item-action-button-container{align-items:center;display:flex;padding:0 var(--spacing-200)}@media (max-width: 767.98px){.list-item-action-button-container.secondary-theme{display:block}.list-item-action-button-container:not(.secondary-theme){padding:0 var(--spacing-100)}}.list-item-drawer{border-radius:var(--containers-shape);margin:4px}.clickable{transition:background-color var(--transition-duration) var(--transition-timing)}.clickable:not(.has-selection-mode):hover{cursor:pointer;background-color:var(--color-hover)}@media (hover: hover){.clickable.has-selection-mode:hover{cursor:pointer;background-color:var(--color-hover)}}\n"], dependencies: [{ kind: "directive", type: i2$1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: i2.BadgeListComponent, selector: "ui-core-badge-list", inputs: ["items", "marginTop", "max", "rightAlign"] }, { kind: "component", type: i2.ButtonComponent, selector: "ui-core-button", inputs: ["themeGroup", "theme", "message", "icon", "iconPosition", "disabled", "disabledMessage", "showSpinner", "buttonClass", "width", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "ariaLabel", "isFormValid", "e2e", "buttonId"] }, { kind: "component", type: i2.ButtonGroupComponent, selector: "ui-core-button-group", inputs: ["disableButtons", "primaryButtonText", "primaryButtonDisabledText", "primaryButtonIcon", "primaryButtonIconPosition", "showPrimarySpinner", "primaryButtonUrl", "primaryButtonUrlParams", "primaryButtonUsesExternalUrlNewTab", "secondaryButtonText", "secondaryButtonIcon", "secondaryButtonIconPosition", "showSecondarySpinner", "secondaryButtonTheme", "secondaryButtonUrl", "secondaryButtonUrlParams", "secondaryButtonUsesExternalUrlNewTab", "tertiaryButtonText", "tertiaryButtonIcon", "tertiaryButtonIconPosition", "showTertiarySpinner", "tertiaryButtonTheme", "tertiaryButtonUrl", "tertiaryButtonUrlParams", "tertiaryButtonUsesExternalUrlNewTab", "isFormValid", "withinFormRenderer", "errorMessages", "e2e", "marginBottom", "marginTop", "stacked"], outputs: ["primaryButtonClicked", "secondaryButtonClicked", "tertiaryButtonClicked"] }, { kind: "component", type: i2.IconComponent, selector: "ui-core-icon", inputs: ["icon", "size", "colorClass", "allowEmojis", "ariaLabel", "alignWithText", "collapseHeight", "scaleWithFonts", "animationPath", "animationData", "animationFreeze", "animationFreezeFrame", "animationLoop", "animationLoopTotal"], outputs: ["animationCompleted"] }, { kind: "component", type: i2.IconButtonComponent, selector: "ui-core-icon-button", inputs: ["message", "icon", "size", "disabled", "buttonClass", "ariaPressed", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "e2e", "theme", "usesGlassHoverState", "buttonId"] }, { kind: "component", type: i2.ModalComponent, selector: "ui-core-modal", inputs: ["headerTemplate", "footerTemplate", "noBodyPadding", "noHeaderBorder", "useFormRendererButtons", "useFooterButtons", "showPrimarySpinner", "useGlassBackground"] }, { kind: "component", type: i2.SpinnerComponent, selector: "ui-core-spinner", inputs: ["message", "size", "buttonIcon", "hideSpinner", "centered", "delayMs", "buttonSpinner"] }, { kind: "component", type: i4.CheckboxComponent, selector: "ui-forms-checkbox", inputs: ["indeterminate", "isChild", "secondaryLabel", "subtextLines", "ariaLabel"] }, { kind: "component", type: i4.ToggleComponent, selector: "ui-forms-toggle", inputs: ["subtextLines", "showSpinner", "icon", "allowNull", "hideLockIcon"] }, { kind: "component", type: EndOfListComponent, selector: "ui-workflows-end-of-list", inputs: ["items", "noListItemsTitleText", "noListItemsSubtitleText", "endOfListText"] }, { kind: "component", type: SearchSortFilterComponent, selector: "ui-workflows-search-sort-filter", inputs: ["autoFocusSearchInput", "searchFieldPlaceholder", "searchFieldText", "sortOptions", "sortOptionDefaultValue", "customFilters", "includeDateFilters", "useFutureDateFilters", "includeAmountRangeFilter", "paddingTop", "withinListComponent", "showSelectAllCheckbox", "selectAllCheckboxChecked", "selectAllCheckboxIndeterminate", "e2e"], outputs: ["allSelected", "searched", "sorted", "filtered", "filtersCleared"] }, { kind: "component", type: BulkActionsComponent, selector: "ui-workflows-bulk-actions", inputs: ["actions", "clearAllLabel", "emptyLabel", "rowLabel"], outputs: ["allCleared", "bulkAction"] }, { kind: "component", type: ListTemplateComponent, selector: "ui-workflows-list-template", inputs: ["avatarIcon", "avatarImageUrl", "avatarBackgroundClass", "avatarIconColorClass", "avatarShape", "allowEmojis", "threadModeEnabled", "topLeftText", "topLeftClass", "topLeftIcon", "topLeftScreenReaderText", "e2eTopLeft", "topLeftAdditionalText", "topCenterBadge", "topRightText", "topRightClass", "topRightIcon", "topRightBadge", "topRightScreenReaderText", "e2eTopRight", "bottomLeftText", "bottomLeftHtml", "bottomLeftPipedDetails", "bottomLeftScreenReaderText", "e2eBottomLeft", "bottomRightText", "bottomRightPipedDetails", "bottomRightScreenReaderText", "e2eBottomRight", "verticalPaddingSize"] }, { kind: "pipe", type: i2$1.SlicePipe, name: "slice" }], animations: [collapseOrSlideState] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: ListComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-workflows-list', animations: [collapseOrSlideState], template: "<div\n    class=\"list-container\"\n    [class.bordered]=\"showBorder\"\n    [id]=\"e2ePrefix + 'container'\"\n    [class.with-header]=\"!!header\"\n    [class.pt-6]=\"!searchEnabled && items.length === 0\">\n\n    @if (!!header) {\n        <div\n            class=\"list-group-header\"\n            [class.with-search]=\"searchEnabled\">\n            <h4\n                class=\"flex-fill mb-0\"\n                [class.mt-half]=\"searchEnabled && items.length === 0\">\n                {{ header }}\n            </h4>\n\n            @if (searchEnabled && items.length > 0) {\n                <ui-core-icon-button\n                    [ariaControls]=\"!isMobile && showSearchSortFilter ? 'search-sort-filter-container' : undefined\"\n                    [ariaExpanded]=\"!isMobile && showSearchSortFilter\"\n                    [ariaHasPopup]=\"isMobile ? HtmlAttributeStateEnum.TRUE : HtmlAttributeStateEnum.FALSE\"\n                    [e2e]=\"e2ePrefix + 'search-toggle-button'\"\n                    icon=\"search\"\n                    [message]=\"text.toggleSearchLabel\"\n                    (click)=\"onSearchToggleClick()\">\n                </ui-core-icon-button>\n            }\n        </div>\n    }\n\n    <ng-container\n        [ngTemplateOutlet]=\"searchTemplate\"\n        [ngTemplateOutletContext]=\"{hideFilters: header && (isMobile || !showSearchSortFilter)}\">\n    </ng-container>\n    <ng-container\n        [ngTemplateOutlet]=\"listTemplate\"\n        [ngTemplateOutletContext]=\"{itemsToShow: numItemsToShow}\">\n    </ng-container>\n    <ng-container\n        [ngTemplateOutlet]=\"endOfListTemplate\"\n        [ngTemplateOutletContext]=\"{itemsToShow: numItemsToShow, seeAllButton: header && isMobile}\">\n    </ng-container>\n</div>\n\n<ng-template\n    #listTemplate\n    let-itemsToShow=\"itemsToShow\"\n    let-isModal=\"isModal\">\n\n    @for (item of items | slice:0:itemsToShow; track item; let idx = $index; let first = $first; let last = $last) {\n        @let e2eValue = item.e2e || e2ePrefix;\n        @let indexCount = item.e2e ? '' : '-' + (idx + 1);\n\n        @if (listItemHeaders[idx]?.visible) {\n            <div\n                class=\"list-item-header\"\n                role=\"heading\"\n                aria-level=\"5\"\n                [class.border-radius-top]=\"first && showBorder && ((!searchEnabled && !header) || isModal)\"\n                [class.sticky]=\"stickyHeader\">\n                {{ listItemHeaders[idx].headerText }}\n            </div>\n        }\n        <div\n            class=\"list-item-row\"\n            [attr.data-e2e]=\"item.e2e ? item.e2e + 'row' : undefined\"\n            [class]=\"item.backgroundClass\"\n            [class.border-radius-top]=\"!searchEnabled && !listItemHeaders[idx]?.visible && idx === 0 && showBorder\"\n            [class.border-radius-bottom]=\"last && showBorder\"\n            [class.border-top]=\"!listItemHeaders[idx]?.visible && idx !== 0\"\n            [class.clickable]=\"clickable || detailsTemplate\"\n            [class.has-selection-mode]=\"selectionMode !== 'none'\" [class.is-mobile]=\"isMobile\">\n            <div class=\"flex-fill\">\n                <div class=\"d-flex\">\n\n                    @if (selectionMode === 'checkbox') {\n                        <div class=\"list-item-clickable-container mt-2 pl-2 pl-md-3\">\n                            <ui-forms-checkbox\n                                [checked]=\"item.checked\"\n                                [e2e]=\"e2eValue + 'checkbox' + indexCount\"\n                                [hideLabel]=\"true\"\n                                [isChild]=\"true\"\n                                [label]=\"item.checked ? toggledOnAriaLabel : toggledOffAriaLabel\"\n                                [locked]=\"item.locked\"\n                                (change)=\"onToggle(item, $event)\">\n                            </ui-forms-checkbox>\n                        </div>\n                    }\n                    <div\n                        class=\"list-item-content\"\n                        [attr.aria-controls]=\"detailsTemplate && item.showDetails ? (detailsTemplateIsDrawer && (!isMobile || threadModeEnabled) ? listId + '-item-drawer-' + idx : e2ePrefix + 'details-modal') : undefined\"\n                        [attr.aria-expanded]=\"detailsTemplate ? item.showDetails : undefined\"\n                        [attr.data-e2e]=\"e2eValue + 'item' + indexCount\"\n                        [attr.role]=\"clickable || detailsTemplate ? 'button' : undefined\"\n                        [class.focusable]=\"clickable || detailsTemplate\" [class.open]=\"item.showDetails\"\n                        [tabindex]=\"clickable || detailsTemplate ? 0 : -1\"\n                        [id]=\"listId + '-item-' + idx\"\n                        (click)=\"onListRowClick(item)\" (keyup.enter)=\"onListRowClick(item)\">\n\n                        @if (listItemHeaders[idx]?.headerText) {\n                            <div class=\"sr-only\">{{ listItemHeaders[idx].headerText + ' - ' }}</div>\n                        }\n\n                        @if (item.topLeftBadges?.length) {\n                            <div class=\"top-left-badges-container\">\n                                <ui-core-badge-list [items]=\"item.topLeftBadges\"></ui-core-badge-list>\n                            </div>\n                        }\n                        <ui-workflows-list-template\n                            [allowEmojis]=\"allowEmojis\"\n                            [avatarBackgroundClass]=\"item.avatarBackgroundClass\"\n                            [avatarIconColorClass]=\"item.avatarIconColorClass\"\n                            [avatarIcon]=\"item.avatarIcon\"\n                            [avatarImageUrl]=\"item.avatarImageUrl\"\n                            [avatarShape]=\"item.avatarShape\"\n                            [topLeftText]=\"item.topLeftText\"\n                            [topLeftClass]=\"item.topLeftClass\"\n                            [topLeftIcon]=\"item.topLeftIcon\"\n                            [topLeftScreenReaderText]=\"item.topLeftScreenReaderText\"\n                            [topLeftAdditionalText]=\"item.topLeftAdditionalText\"\n                            [e2eTopLeft]=\"item.e2eTopLeft\"\n                            [topCenterBadge]=\"item.topCenterBadge\"\n                            [topRightClass]=\"item.topRightClass\"\n                            [topRightText]=\"isMobile && (item.actionButtonText && item.actionButtonTheme === 'tertiary' || hideRightContentOnMobile) ? '' : item.topRightText\"\n                            [topRightIcon]=\"isMobile && (item.actionButtonText && item.actionButtonTheme === 'tertiary' || hideRightContentOnMobile) ? '' : item.topRightIcon\"\n                            [topRightBadge]=\"isMobile && (item.actionButtonText && item.actionButtonTheme === 'tertiary' || hideRightContentOnMobile) ? '' : item.topRightBadge\"\n                            [topRightScreenReaderText]=\"item.topRightScreenReaderText\"\n                            [e2eTopRight]=\"item.e2eTopRight\"\n                            [bottomLeftText]=\"item.bottomLeftText\"\n                            [bottomLeftHtml]=\"item.bottomLeftHtml\"\n                            [bottomLeftPipedDetails]=\"item.bottomLeftPipedDetails\"\n                            [bottomLeftScreenReaderText]=\"item.bottomLeftScreenReaderText\"\n                            [e2eBottomLeft]=\"item.e2eBottomLeft\"\n                            [bottomRightText]=\"isMobile && (item.actionButtonText  && item.actionButtonTheme === 'tertiary' || hideRightContentOnMobile) ? '' : item.bottomRightText\"\n                            [bottomRightPipedDetails]=\"isMobile && (item.actionButtonText && item.actionButtonTheme === 'tertiary' || hideRightContentOnMobile) ? '' : item.bottomRightPipedDetails\"\n                            [bottomRightScreenReaderText]=\"item.bottomRightScreenReaderText\"\n                            [e2eBottomRight]=\"item.e2eBottomRight\"\n                            [threadModeEnabled]=\"threadModeEnabled && item.showDetails\"\n                            [verticalPaddingSize]=\"item.verticalPaddingSize\">\n                        </ui-workflows-list-template>\n                    </div>\n\n                    @if (item.actionButtonText && (item.actionButtonTheme === 'tertiary' || !isMobile)) {\n                        <ng-container\n                            [ngTemplateOutlet]=\"actionButtonTemplate\"\n                            [ngTemplateOutletContext]=\"{e2eValue: e2eValue, item: item}\">\n                        </ng-container>\n                    }\n\n                    @if (selectionMode === 'toggle') {\n                        <div class=\"list-item-clickable-container flex-align-center pr-half\">\n                            <ui-forms-toggle\n                                [class]=\"item.actionButtonText ? 'border-left pl-1 pt-2 pb-1' : 'pt-1'\"\n                                [checked]=\"item.checked\"\n                                [e2e]=\"e2eValue + 'toggle' + indexCount\"\n                                [hideLabel]=\"true\"\n                                [hideLockIcon]=\"true\"\n                                [label]=\"item.checked ? toggledOnAriaLabel : toggledOffAriaLabel\"\n                                [locked]=\"item.locked\"\n                                (change)=\"onToggle(item, $event)\">\n                            </ui-forms-toggle>\n                        </div>\n                    }\n                </div>\n\n                @if (item.actionButtonText && item.actionButtonTheme === 'secondary' && isMobile) {\n                    <ng-container\n                        [ngTemplateOutlet]=\"actionButtonTemplate\"\n                        [ngTemplateOutletContext]=\"{e2eValue: e2eValue, item: item}\">\n                    </ng-container>\n                }\n            </div>\n\n            @if ((clickable && clickableIcon) || detailsTemplate) {\n                <div\n                    [attr.data-e2e]=\"e2eValue + 'item-clickable' + indexCount\"\n                    class=\"list-item-clickable-container flex-align-center\"\n                    [class]=\"clickableIcon === 'chevron_right' ? 'pr-half' : 'pr-1'\"\n                    (click)=\"onListRowClick(item)\">\n\n                    <!-- keyboard accessibility is intentionally not wired up here as this is an extra (click) option for sighted users -->\n                    @if (isMobile && !threadModeEnabled) {\n                        <ui-core-icon\n                            class=\"mr-half\"\n                            [icon]=\"clickableIcon\"\n                            size=\"xxl\">\n                        </ui-core-icon>\n                    } @else {\n                        <div class=\"flex-align-center\">\n                            <ui-core-icon\n                                class=\"d-inline-flex mr-1\"\n                                [colorClass]=\"detailsTemplate && detailsTemplateIsDrawer && item.showDetails ? 'color-brand-secondary' : ''\"\n                                [size]=\"clickableLabel ? 'xl' : 'xxl'\"\n                                [icon]=\"detailsTemplate && detailsTemplateIsDrawer ? (item.showDetails ? 'arrow_drop_up' : 'arrow_drop_down') : clickableIcon\">\n                            </ui-core-icon>\n\n                            @if (clickableLabel && !threadModeEnabled) {\n                                <span class=\"text-second text-semibold mr-1\">\n                                    {{ clickableLabel }}\n                                </span>\n                            }\n                        </div>\n                    }\n                </div>\n            }\n        </div>\n\n        @if (item.showDetails && detailsTemplate && detailsTemplateIsDrawer && (!isMobile || threadModeEnabled)) {\n            <div\n                class=\"list-item-drawer\"\n                [class.bg-brand]=\"!threadModeEnabled\"\n                [id]=\"listId + '-item-drawer-' + idx\"\n                role=\"region\"\n                [attr.aria-labelledby]=\"listId + '-item-' + idx\"\n                [attr.data-e2e]=\"e2eValue + 'details' + indexCount\"\n                [@collapseOrSlideState]=\"'collapseState'\">\n                <ng-container\n                    [ngTemplateOutlet]=\"detailsTemplate\"\n                    [ngTemplateOutletContext]=\"{item: item.originalItem}\">\n                </ng-container>\n\n                @if (detailsPrimaryButtonText || detailsSecondaryButtonText || detailsTertiaryButtonText) {\n                    <div class=\"px-4 pb-4\">\n                        <ui-core-button-group\n                            [marginBottom]=\"false\"\n                            [primaryButtonText]=\"detailsPrimaryButtonText\"\n                            [secondaryButtonText]=\"detailsSecondaryButtonText\"\n                            [tertiaryButtonText]=\"detailsTertiaryButtonText\"\n                            [tertiaryButtonIcon]=\"detailsTertiaryButtonIcon\"\n                            [e2e]=\"e2eValue + 'drawer' + indexCount\"\n                            (primaryButtonClicked)=\"detailsPrimaryButtonClick()\"\n                            (secondaryButtonClicked)=\"detailsSecondaryButtonClick()\"\n                            (tertiaryButtonClicked)=\"detailsTertiaryButtonClick()\">\n                        </ui-core-button-group>\n                    </div>\n                }\n            </div>\n        }\n    }\n</ng-template>\n\n<ng-template\n    #actionButtonTemplate\n    let-e2eValue=\"e2eValue\"\n    let-item=\"item\">\n    <div\n        class=\"list-item-action-button-container\"\n        [class.secondary-theme]=\"item.actionButtonTheme === 'secondary'\">\n\n        @if (isMobile && item.actionButtonIcon && item.actionButtonTheme === 'tertiary' && !item.actionButtonTertiaryTextDisplaysOnMobile) {\n            <ui-core-icon-button\n                [e2e]=\"e2eValue + 'action-button'\"\n                [icon]=\"item.actionButtonIcon\"\n                [message]=\"item.actionButtonText\"\n                (click)=\"item.actionButtonMethod(item)\">\n            </ui-core-icon-button>\n        } @else {\n            <ui-core-button\n                [buttonClass]=\"item.actionButtonTheme === 'secondary' ? 'my-2 px-md-6 py-md-2' : ''\"\n                [e2e]=\"e2eValue + 'action-button'\"\n                [icon]=\"item.actionButtonIcon\"\n                [message]=\"item.actionButtonText\"\n                [theme]=\"item.actionButtonTheme\"\n                width=\"full\"\n                (click)=\"item.actionButtonMethod(item)\">\n            </ui-core-button>\n        }\n    </div>\n</ng-template>\n\n<ng-template\n    #searchTemplate\n    let-hideFilters=\"hideFilters\">\n\n    @if (searchEnabled && !hideFilters) {\n        <ui-workflows-search-sort-filter\n            [autoFocusSearchInput]=\"autoFocusSearchInput\"\n            [customFilters]=\"customFilters\"\n            [includeDateFilters]=\"includeDateFilters\"\n            [paddingTop]=\"!header\"\n            [searchFieldPlaceholder]=\"searchFieldPlaceholder\"\n            [searchFieldText]=\"searchFieldText\"\n            [selectAllCheckboxChecked]=\"selectAllCheckboxChecked\"\n            [selectAllCheckboxIndeterminate]=\"selectAllCheckboxIndeterminate\"\n            [showSelectAllCheckbox]=\"selectionMode === 'checkbox'\"\n            [sortOptions]=\"sortOptions\"\n            [sortOptionDefaultValue]=\"sortOptionDefaultValue\"\n            [useFutureDateFilters]=\"useFutureDateFilters\"\n            [withinListComponent]=\"true\"\n            (filtered)=\"onFilterChange($event)\"\n            (filtersCleared)=\"onFilterClearAllChange($event)\"\n            (allSelected)=\"onSelectAllChange($event)\"\n            (searched)=\"onSearchChange($event)\"\n            (sorted)=\"onSortChange($event)\">\n        </ui-workflows-search-sort-filter>\n\n        @if (searchInputChanged) {\n            <div\n                class=\"sr-only\"\n                aria-live=\"polite\">\n\n                @if (items.length === 0) {\n                    <span>{{ text.ariaLiveNoResultsFound }}</span>\n                } @else if (items.length === 1) {\n                    <span>{{ text.ariaLiveOneResultFound }}</span>\n                } @else {\n                    <span>{{ text.ariaLiveMultipleResultsFound }}</span>\n                }\n            </div>\n        }\n    }\n</ng-template>\n\n<ng-template\n    #endOfListTemplate\n    let-itemsToShow=\"itemsToShow\"\n    let-seeAllButton=\"seeAllButton\">\n\n    @if (items && itemsToShow < items.length && (seeAllButton || !lazyLoad)) {\n        <div class=\"text-center py-3\">\n            <ui-core-button\n                [ariaControls]=\"isMobile && !!header ? e2ePrefix + 'mobile-view-all-modal' : e2ePrefix + 'container'\"\n                [ariaHasPopup]=\"isMobile && !!header ? HtmlAttributeStateEnum.TRUE : HtmlAttributeStateEnum.FALSE\"\n                [message]=\"seeAllButton ? text.seeAllButtonText : text.showMoreButtonText\"\n                theme=\"secondary\"\n                (click)=\"showMore()\">\n            </ui-core-button>\n        </div>\n    }\n\n    @if (lazyLoad && !seeAllButton && items && itemsToShow < items.length) {\n        <div\n            #lazyLoadSentinel\n            class=\"lazy-load-sentinel\"\n            aria-hidden=\"true\">\n        </div>\n\n        @if (loading) {\n            <div class=\"text-center py-3\">\n                <ui-core-spinner\n                    [message]=\"text.loadingMoreItemsText\"\n                    [centered]=\"true\">\n                </ui-core-spinner>\n            </div>\n        }\n    }\n\n    @if (showMoreClicked) {\n        <span\n            class=\"sr-only\"\n            aria-live=\"polite\">{{ text.ariaLiveMoreOptionsShown }}</span>\n    }\n\n    @if (items && (itemsToShow >= items.length || (!itemsToShow && items.length === 0))) {\n        <ui-workflows-end-of-list\n            [items]=\"items\"\n            [endOfListText]=\"endOfListText || text.endOfListText\"\n            [noListItemsTitleText]=\"noListItemsTitleText || text.noListItemsTitleText\"\n            [noListItemsSubtitleText]=\"noListItemsSubtitleText || text.noListItemsSubtitleText\">\n        </ui-workflows-end-of-list>\n    }\n</ng-template>\n\n@if (selectionMode === 'checkbox' && bulkActions?.length > 0 && checkedItems?.length > 0) {\n    <ui-workflows-bulk-actions\n        [actions]=\"bulkActions\"\n        [rowLabel]=\"bulkActionsSelectedLabel\"\n        [emptyLabel]=\"text.bulkNoCommonActionsLabel\"\n        [clearAllLabel]=\"text.clearCheckedItemsButtonLabel\"\n        (bulkAction)=\"doBulkAction($event)\"\n        (allCleared)=\"clearBulkActions()\">\n    </ui-workflows-bulk-actions>\n}\n\n<ng-template #detailsModal>\n    <ui-core-modal\n        [id]=\"e2ePrefix + 'details-modal'\"\n        [e2e]=\"detailModalE2E\"\n        [primaryButtonText]=\"detailsPrimaryButtonText\"\n        [secondaryButtonText]=\"detailsSecondaryButtonText\"\n        [actionButtonText]=\"detailsTertiaryButtonText\"\n        [actionButtonIcon]=\"detailsTertiaryButtonIcon\"\n        [title]=\"detailsTemplateTitle ?? text.defaultDetailsTemplateTitle\"\n        [lockScrim]=\"lockDetailsModalScrim\"\n        (closed)=\"onDetailsModalClose()\"\n        (primaryButtonClicked)=\"detailsPrimaryButtonClick()\"\n        (secondaryButtonClicked)=\"detailsSecondaryButtonClick()\"\n        (actionButtonClicked)=\"detailsTertiaryButtonClick()\">\n\n        @if (selectedItem) {\n            <ng-container\n                [ngTemplateOutlet]=\"detailsTemplate\"\n                [ngTemplateOutletContext]=\"{item: selectedItem.originalItem}\">\n            </ng-container>\n        }\n    </ui-core-modal>\n</ng-template>\n\n<ng-template #mobileViewAllModal>\n    <ui-core-modal\n        [id]=\"e2ePrefix + 'mobile-view-all-modal'\"\n        [e2e]=\"e2ePrefix + 'mobile-view-all-modal'\"\n        [noBodyPadding]=\"true\"\n        [title]=\"header\"\n        (closed)=\"closeMobileViewAllModal()\">\n        <div class=\"mt-4\">\n            <ng-container [ngTemplateOutlet]=\"searchTemplate\"></ng-container>\n        </div>\n        <div\n            class=\"modal-list-container mx-2 mb-2\"\n            [class.bordered]=\"showBorder\"\n            [class.border-0]=\"items.length === 0\">\n            <ng-container\n                [ngTemplateOutlet]=\"listTemplate\"\n                [ngTemplateOutletContext]=\"{itemsToShow: numModalItemsToShow, isModal: true}\">\n            </ng-container>\n        </div>\n        <ng-container\n            [ngTemplateOutlet]=\"endOfListTemplate\"\n            [ngTemplateOutletContext]=\"{itemsToShow: numModalItemsToShow}\">\n        </ng-container>\n    </ui-core-modal>\n</ng-template>\n", styles: [".lazy-load-sentinel{height:1px;width:100%}.list-container{background-color:var(--color-default);position:relative}.list-container.with-header.bordered{border:1px solid var(--color-stroke-1)}.list-container.bordered,.modal-list-container.bordered{border:1px solid var(--color-stroke-1);border-radius:var(--containers-shape)}.list-group-header{align-items:center;display:flex;padding:16px 20px}.list-group-header.with-search{padding-top:12px;padding-bottom:12px}@media (max-width: 767.98px){.list-group-header{padding:16px 12px 20px 16px}.list-group-header.with-search{padding-top:12px;padding-bottom:16px}}.list-item-header{background-color:var(--color-gray-50);color:var(--color-content-secondary);font-size:var(--type-caption-size);font-weight:var(--type-weight-semibold);padding-bottom:var(--spacing-50);padding-left:16px;padding-top:var(--spacing-50);z-index:5}.list-item-header.sticky{position:sticky;top:var(--navbar-mobile-height)}:host-context(.fixed-top-notification) .list-item-header.sticky{top:calc(var(--navbar-mobile-height) * 2)}.modal-list-container .list-item-header.sticky{overflow:hidden;top:0}.modal-list-container .list-item-header.sticky:first-child{border-top-left-radius:var(--containers-shape);border-top-right-radius:var(--containers-shape)}@media (min-width: 1080px){.list-item-header.sticky{top:var(--navbar-desktop-height)}:host-context(.fixed-top-notification) .list-item-header.sticky{top:calc(var(--navbar-desktop-height) + var(--navbar-mobile-height))}}.list-item-header.sticky+.list-item-row .list-item-content{scroll-margin-top:calc(var(--navbar-desktop-height) + 25px)}@media (max-width: 1079.98px){.list-item-header.sticky+.list-item-row .list-item-content{scroll-margin-top:calc(var(--navbar-mobile-height) + 25px)}}.list-item-row{display:flex}@media (hover: hover){.list-item-row:has(.list-item-content.focusable:not(.open):focus) .list-item-clickable-container{background-color:var(--color-hover)}}.list-item-content{flex:1 1 auto;overflow:hidden}@media (hover: hover){.list-item-content.focusable:not(.open):focus,.list-item-content.focusable:not(.open):focus~div{background-color:var(--color-hover)}}.list-item-content .top-left-badges-container{padding:0 16px}.list-item-action-button-container{align-items:center;display:flex;padding:0 var(--spacing-200)}@media (max-width: 767.98px){.list-item-action-button-container.secondary-theme{display:block}.list-item-action-button-container:not(.secondary-theme){padding:0 var(--spacing-100)}}.list-item-drawer{border-radius:var(--containers-shape);margin:4px}.clickable{transition:background-color var(--transition-duration) var(--transition-timing)}.clickable:not(.has-selection-mode):hover{cursor:pointer;background-color:var(--color-hover)}@media (hover: hover){.clickable.has-selection-mode:hover{cursor:pointer;background-color:var(--color-hover)}}\n"] }]
        }], ctorParameters: () => [{ type: i1$1.DateProvider }, { type: i2.ModalService }, { type: i2.TextService }, { type: i2.WindowService }], propDecorators: { e2eAttr: [{
                type: HostBinding,
                args: ['attr.data-e2e']
            }], detailsModal: [{
                type: ViewChild,
                args: ['detailsModal']
            }], mobileViewAllModal: [{
                type: ViewChild,
                args: ['mobileViewAllModal']
            }], searchSortFilterComponent: [{
                type: ViewChild,
                args: [SearchSortFilterComponent]
            }], items: [{
                type: Input
            }], pageSize: [{
                type: Input
            }], lazyLoad: [{
                type: Input
            }], lazyLoadTriggerDistance: [{
                type: Input
            }], loading: [{
                type: Input
            }], allowEmojis: [{
                type: Input
            }], threadModeEnabled: [{
                type: Input
            }], selectionMode: [{
                type: Input
            }], selectionToggledOffAriaLabel: [{
                type: Input
            }], selectionToggledOnAriaLabel: [{
                type: Input
            }], hideRightContentOnMobile: [{
                type: Input
            }], clickable: [{
                type: Input
            }], clickableIcon: [{
                type: Input
            }], clickableLabel: [{
                type: Input
            }], header: [{
                type: Input
            }], stickyHeader: [{
                type: Input
            }], detailsTemplate: [{
                type: Input
            }], detailsTemplateIsDrawer: [{
                type: Input
            }], lockDetailsModalScrim: [{
                type: Input
            }], detailsTemplateTitle: [{
                type: Input
            }], detailsPrimaryButtonText: [{
                type: Input
            }], detailsSecondaryButtonText: [{
                type: Input
            }], detailsTertiaryButtonText: [{
                type: Input
            }], detailsTertiaryButtonIcon: [{
                type: Input
            }], noListItemsTitleText: [{
                type: Input
            }], noListItemsSubtitleText: [{
                type: Input
            }], endOfListText: [{
                type: Input
            }], searchEnabled: [{
                type: Input
            }], searchFieldPlaceholder: [{
                type: Input
            }], searchFieldText: [{
                type: Input
            }], sortOptions: [{
                type: Input
            }], sortOptionDefaultValue: [{
                type: Input
            }], customFilters: [{
                type: Input
            }], includeDateFilters: [{
                type: Input
            }], useFutureDateFilters: [{
                type: Input
            }], showBorder: [{
                type: Input
            }], bulkActions: [{
                type: Input
            }], checkedItems: [{
                type: Input
            }], totalItemCount: [{
                type: Input
            }], e2e: [{
                type: Input
            }], searched: [{
                type: Output
            }], sorted: [{
                type: Output
            }], filtered: [{
                type: Output
            }], filtersCleared: [{
                type: Output
            }], mobileViewAllModalClosed: [{
                type: Output
            }], controlToggled: [{
                type: Output
            }], listRowClicked: [{
                type: Output
            }], showMoreButtonClicked: [{
                type: Output
            }], bulkAction: [{
                type: Output
            }], bulkActionsCleared: [{
                type: Output
            }], detailsPrimaryButtonClicked: [{
                type: Output
            }], detailsSecondaryButtonClicked: [{
                type: Output
            }], detailsTertiaryButtonClicked: [{
                type: Output
            }], lazyLoadSentinel: [{
                type: ViewChild,
                args: ['lazyLoadSentinel']
            }] } });

var ListFormFieldType;
(function (ListFormFieldType) {
    ListFormFieldType["AMOUNT"] = "AMOUNT";
    ListFormFieldType["DATEPICKER"] = "DATEPICKER";
    ListFormFieldType["NUMBER"] = "NUMBER";
})(ListFormFieldType || (ListFormFieldType = {}));

const UNKNOWN_VALUE = '--';
class ListFormComponent extends BaseTextComponent {
    constructor(fb, modalService, textService, windowService) {
        super(textService, 'ui-workflows-list-form');
        this.fb = fb;
        this.modalService = modalService;
        this.textService = textService;
        this.windowService = windowService;
        /**
        * Required. The array of form fields (of class ListFormField) with validation.
        * Only Amount, Number and Date fields are supported. Only 2 fields are allowed.
        **/
        this.formFields = [];
        /**
        * Required. The array of items (of class ListFormItem) to render in a list.
        **/
        this.items = [];
        /**
        * Specifies the number of items to display on each "page". Set to "undefined" for no pagination.
        **/
        this.pageSize = 20;
        /**
        * Optional. Locks the modal scrim, preventing the user from closing the modal by clicking outside of it or pressing the Escape key.
        * Defaults to false. Note that locking the scrim also blocks the Escape key — on desktop this removes a standard
        * keyboard affordance, so only set to true for modals where preventing accidental dismissal outweighs that ADA concern.
        * Avoid setting both lockModalScrim and confirmUnsavedChanges to true — they are not designed to be used together.
        **/
        this.lockModalScrim = false;
        /**
        * Optional. When true, prompts the user to confirm before closing the modal if the form has unsaved changes.
        * Defaults to false. Avoid setting both confirmUnsavedChanges and lockModalScrim to true — they are not designed to be used together.
        **/
        this.confirmUnsavedChanges = false;
        this.checkUnsavedChangesHandler = this.checkUnsavedChanges.bind(this);
        /**
        * Optional text used to override the default "No Items" title text.
        **/
        this.noListItemsTitleText = '';
        /**
        * Optional text used to override the default "no list items to display" subtitle text.
        **/
        this.noListItemsSubtitleText = '';
        /**
        * Optional text used to override the default "you've reached the end of list" subtitle text.
        **/
        this.endOfListText = '';
        /**
        * Specifies whether to show search / sort / filter functionality for the list. Defaults to true.
        **/
        this.searchEnabled = true;
        /**
        * Optional text used to override the default placeholder text for the search field.
        **/
        this.searchFieldPlaceholder = '';
        /**
        * Optional text used to manually set the search field value.
        **/
        this.searchFieldText = '';
        /**
        * Optional array of PickerOptions that are used for sorting the list.
        **/
        this.sortOptions = [];
        /**
        * Optional value of the default sort option.
        **/
        this.sortOptionDefaultValue = '';
        /**
        * E2E testing - data-e2e attribute attached to the list.
        **/
        this.e2e = 'list-form';
        /**
        * Emits search value on change.
        **/
        this.searched = new EventEmitter();
        /**
        * Emits sort value when the sort option is changed.
        **/
        this.sorted = new EventEmitter();
        /**
        * Emits when the "Show More" button is clicked.
        **/
        this.showMoreButtonClicked = new EventEmitter();
        /**
        * Emits the currently selected ListFormItem when the primary button within the modal is clicked.
        **/
        this.primaryButtonClicked = new EventEmitter();
        /**
        * Emits the currently selected ListFormItem when the secondary button within the modal is clicked.
        **/
        this.secondaryButtonClicked = new EventEmitter();
        /**
        * Emits the currently selected ListFormItem when the tertiary button within the modal is clicked.
        **/
        this.tertiaryButtonClicked = new EventEmitter();
        /**
        * Emits a ListFormItem object when a list form item's modal opens.
        **/
        this.itemModalOpened = new EventEmitter();
        /**
        * Emits a ListFormItem object when a list form item's field value in the list changes.
        **/
        this.itemChange = new EventEmitter();
        /**
        * Emits when the valid list form items change.
        **/
        this.validItemsChange = new EventEmitter();
        this.HtmlAttributeStateEnum = HtmlAttributeState;
        this.ListFormFieldType = ListFormFieldType;
        this.e2ePrefix = '';
        this.listId = '';
        this.allFields = [];
        this.windowService.windowSize$.pipe(this.takeUntilDestroyed()).subscribe(windowSize => {
            this.isMobile = windowSize.isMobile;
        });
        this.setE2EPrefix();
    }
    ngOnInit() {
        this.listId = HtmlUtils.generateRandomId();
        this.numItemsToShow = this.pageSize;
    }
    ngOnChanges(changes) {
        if (changes.e2e) {
            this.setE2EPrefix();
        }
        if (changes.formFields && this.formFields.length > 0) {
            // List Form only supports up to 2 fields
            this.allFields = this.formFields.slice(0, 2);
        }
        if (changes.formFields || changes.items) {
            this.buildItemForms();
        }
    }
    buildItemForms() {
        if (this.items.length > 0 && this.allFields.length > 0) {
            this.items.forEach(item => {
                if (!item.form) {
                    item._form = this.buildForm(item);
                    this.emitAndValidateItem(item);
                }
                else {
                    this.validateItemForm(item);
                }
            });
        }
    }
    emitAndValidateItem(item) {
        this.itemChange.emit(item);
        this.validateItemForm(item);
    }
    validateItemForm(item) {
        const originalCanBeSubmitted = item.canBeSubmitted;
        item._canBeSubmitted = item.form.valid;
        // If a valid item has been invalidated, emit.
        // If the item is valid, then it either became valid or some data changed, so emit as well.
        const itemBecameInvalid = originalCanBeSubmitted && !item.canBeSubmitted;
        if (item.canBeSubmitted || itemBecameInvalid) {
            this.validItemsChange.emit();
        }
    }
    getMobileValue(item, field) {
        const formValue = item.getFormFieldValue(field.name);
        const value = formValue || field._initialValue;
        if (field.type === ListFormFieldType.AMOUNT) {
            const amount = value;
            return NumberUtils.formatCurrency(amount);
        }
        if (field.type === ListFormFieldType.DATEPICKER) {
            return value || UNKNOWN_VALUE;
        }
        if (field.type === ListFormFieldType.NUMBER) {
            // This is an odd edge case. The number input has an initial value of null.
            // If the user enters 0, which is falsy, the logic is 0 || null, which returns null.
            // Instead we need to check for an explicit zero value.
            if (formValue === 0) {
                // This wants to be a string so the label-value renders a value correctly.
                return '0';
            }
            else if (!value) {
                // Null or undefined
                return UNKNOWN_VALUE;
            }
            return NumberUtils.formatNumber(value, false);
        }
        return value;
    }
    buildForm(item) {
        const form = this.fb.group({});
        this.allFields.forEach(field => {
            const validationFunc = this.getValidatorFunc(field);
            const initialValue = item.getFormItemInitialValue(field.name) || field._initialValue;
            if (validationFunc) {
                form.addControl(field.name, new UntypedFormControl(initialValue, formValidator(validationFunc)));
            }
            else {
                form.addControl(field.name, new UntypedFormControl(initialValue));
            }
        });
        form.valueChanges.pipe(this.takeUntilDestroyed()).subscribe(() => {
            this.emitAndValidateItem(item);
        });
        return form;
    }
    getValidatorFunc(field) {
        const fieldValidator = field.getValidator();
        if (fieldValidator) {
            return field.required ? fieldValidator : optional(fieldValidator);
        }
        else {
            return field.required ? required : null;
        }
    }
    openDetailsModal(item) {
        this.selectedItem = item;
        this.itemModalOpened.emit(item);
        this.modalService.openEnhancedModal(this.detailsModal);
    }
    showMore() {
        this.showMoreClicked = false;
        this.numItemsToShow += this.pageSize;
        this.showMoreButtonClicked.emit();
        setTimeout(() => this.showMoreClicked = true, 250); // delay needed for screen reader to announce
    }
    onPrimaryButtonClick() {
        this.primaryButtonClicked.emit(this.selectedItem);
    }
    onSecondaryButtonClick() {
        this.secondaryButtonClicked.emit(this.selectedItem);
    }
    onTertiaryButtonClick() {
        this.tertiaryButtonClicked.emit(this.selectedItem);
    }
    onSearchChange(searchText) {
        this.searched.emit(searchText);
        this.searchInputChanged = true;
    }
    onSortChange(value) {
        this.sorted.emit(value);
    }
    async checkUnsavedChanges() {
        if (!this.selectedItem?._form?.dirty) {
            return true;
        }
        return this.unsavedChangesModal.showUnsavedChangesModal();
    }
    setE2EPrefix() {
        this.e2ePrefix = HtmlUtils.formatE2EPrefix(this.e2e || 'list-form');
    }
    getDefaultText() {
        return {
            openDetailsModalAriaLabel: 'Open details modal',
            defaultModalTitle: 'Details',
            showMoreButtonText: 'Show More',
            endOfListText: 'You\'ve reached the end of the list.',
            noListItemsTitleText: 'No Items',
            noListItemsSubtitleText: 'There are no items to display.',
            ariaLiveMoreOptionsShown: 'More items shown below.',
            ariaLiveNoResultsFound: 'No results found.',
            ariaLiveOneResultFound: 'One result found.',
            ariaLiveMultipleResultsFound: 'Multiple results found.'
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: ListFormComponent, deps: [{ token: i1.UntypedFormBuilder }, { token: i2.ModalService }, { token: i2.TextService }, { token: i2.WindowService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.17", type: ListFormComponent, isStandalone: false, selector: "ui-workflows-list-form", inputs: { formFields: "formFields", items: "items", pageSize: "pageSize", modalTitle: "modalTitle", lockModalScrim: "lockModalScrim", confirmUnsavedChanges: "confirmUnsavedChanges", modalTopTemplate: "modalTopTemplate", modalBottomTemplate: "modalBottomTemplate", modalPrimaryButtonText: "modalPrimaryButtonText", modalSecondaryButtonText: "modalSecondaryButtonText", modalTertiaryButtonText: "modalTertiaryButtonText", modalTertiaryButtonIcon: "modalTertiaryButtonIcon", noListItemsTitleText: "noListItemsTitleText", noListItemsSubtitleText: "noListItemsSubtitleText", endOfListText: "endOfListText", searchEnabled: "searchEnabled", searchFieldPlaceholder: "searchFieldPlaceholder", searchFieldText: "searchFieldText", sortOptions: "sortOptions", sortOptionDefaultValue: "sortOptionDefaultValue", e2e: "e2e" }, outputs: { searched: "searched", sorted: "sorted", showMoreButtonClicked: "showMoreButtonClicked", primaryButtonClicked: "primaryButtonClicked", secondaryButtonClicked: "secondaryButtonClicked", tertiaryButtonClicked: "tertiaryButtonClicked", itemModalOpened: "itemModalOpened", itemChange: "itemChange", validItemsChange: "validItemsChange" }, viewQueries: [{ propertyName: "detailsModal", first: true, predicate: ["detailsModal"], descendants: true }, { propertyName: "searchComponent", first: true, predicate: SearchInputComponent, descendants: true }, { propertyName: "unsavedChangesModal", first: true, predicate: UnsavedChangesModalComponent, descendants: true, static: true }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div class=\"list-container\" [id]=\"e2ePrefix + 'container'\">\n    @if (searchEnabled) {\n        <ui-workflows-search-sort-filter\n            [searchFieldPlaceholder]=\"searchFieldPlaceholder\"\n            [searchFieldText]=\"searchFieldText\"\n            [sortOptions]=\"sortOptions\"\n            [sortOptionDefaultValue]=\"sortOptionDefaultValue\"\n            [withinListComponent]=\"true\"\n            (searched)=\"onSearchChange($event)\"\n            (sorted)=\"onSortChange($event)\">\n        </ui-workflows-search-sort-filter>\n        @if (searchInputChanged) {\n            <div class=\"sr-only\" aria-live=\"polite\">\n                @if (items.length === 0) {\n                    <span>{{ text.ariaLiveNoResultsFound }}</span>\n                } @else if (items.length === 1) {\n                    <span>{{ text.ariaLiveOneResultFound }}</span>\n                } @else {\n                    <span>{{ text.ariaLiveMultipleResultsFound }}</span>\n                }\n            </div>\n        }\n    }\n    @for (item of (items | slice:0:numItemsToShow); track item) {\n        @if (item._form) {\n            <form>\n                @if (isMobile) {\n                    <div class=\"clickable\" [class]=\"item.backgroundClass\"\n                        [attr.aria-controls]=\"listId\" aria-haspopup=\"true\" tabindex=\"0\" (click)=\"openDetailsModal(item)\">\n                        <div class=\"border-top mb-1\">\n                            @if (item.topLeftBadges?.length) {\n                                <div class=\"top-left-badges-container\">\n                                    <ui-core-badge-list [items]=\"item.topLeftBadges\"></ui-core-badge-list>\n                                </div>\n                            }\n                            <div class=\"flex-align-center\">\n                                <ng-container [ngTemplateOutlet]=\"listItemContentTemplate\" [ngTemplateOutletContext]=\"{item: item}\">\n                                </ng-container>\n                                <ng-container [ngTemplateOutlet]=\"listItemDetailsIconButtonTemplate\" [ngTemplateOutletContext]=\"{item: item}\">\n                                </ng-container>\n                            </div>\n                        </div>\n                        @for (field of allFields; track field.name) {\n                            <div class=\"ml-3\">\n                                <ui-core-label-value\n                                    elementClass=\"pb-4\"\n                                    [iconLeft]=\"item.locked ? 'lock' : ''\"\n                                    [label]=\"field.label\"\n                                    [value]=\"getMobileValue(item, field)\">\n                                </ui-core-label-value>\n                            </div>\n                        }\n                    </div>\n                } @else {\n                    <div class=\"list-item-grid border-top\" [class]=\"item.backgroundClass\">\n                        @if (item.topLeftBadges?.length) {\n                            <div class=\"top-left-badges-container\">\n                                <ui-core-badge-list [items]=\"item.topLeftBadges\"></ui-core-badge-list>\n                            </div>\n                            <div></div>\n                        }\n                        <ng-container [ngTemplateOutlet]=\"listItemContentTemplate\" [ngTemplateOutletContext]=\"{item: item}\">\n                        </ng-container>\n                        <div class=\"d-flex\">\n                            <ng-container [ngTemplateOutlet]=\"listItemFormTemplate\" [ngTemplateOutletContext]=\"{item: item}\">\n                            </ng-container>\n                            @if (modalTopTemplate || modalBottomTemplate) {\n                                <ng-container [ngTemplateOutlet]=\"listItemDetailsIconButtonTemplate\" [ngTemplateOutletContext]=\"{item: item}\">\n                                </ng-container>\n                            }\n                        </div>\n                    </div>\n                }\n            </form>\n        }\n    }\n    @if (items && numItemsToShow < items.length) {\n        <div class=\"text-center py-3\">\n            <ui-core-button\n                [ariaControls]=\"e2ePrefix + 'container'\"\n                [message]=\"text.showMoreButtonText\"\n                theme=\"secondary\"\n                (click)=\"showMore()\">\n            </ui-core-button>\n        </div>\n    }\n    @if (showMoreClicked) {\n        <span class=\"sr-only\" aria-live=\"polite\">{{ text.ariaLiveMoreOptionsShown }}</span>\n    }\n    @if (items && (numItemsToShow >= items.length || (!numItemsToShow && items.length === 0))) {\n        <ui-workflows-end-of-list\n            [items]=\"items\"\n            [endOfListText]=\"endOfListText || text.endOfListText\"\n            [noListItemsTitleText]=\"noListItemsTitleText || text.noListItemsTitleText\"\n            [noListItemsSubtitleText]=\"noListItemsSubtitleText || text.noListItemsSubtitleText\">\n        </ui-workflows-end-of-list>\n    }\n</div>\n\n<ng-template #listItemContentTemplate let-item=\"item\">\n    <div class=\"list-item-content mt-md-4\">\n        <ui-workflows-list-template\n            [avatarBackgroundClass]=\"item.avatarBackgroundClass\"\n            [avatarIconColorClass]=\"item.avatarIconColorClass\"\n            [avatarIcon]=\"item.avatarIcon\"\n            [avatarImageUrl]=\"item.avatarImageUrl\"\n            [avatarShape]=\"item.avatarShape\"\n            [topLeftText]=\"item.topLeftText\"\n            [topLeftClass]=\"item.topLeftClass\"\n            [topLeftIcon]=\"item.topLeftIcon\"\n            [topLeftScreenReaderText]=\"item.topLeftScreenReaderText\"\n            [e2eTopLeft]=\"item.e2eTopLeft\"\n            [bottomLeftText]=\"item.bottomLeftText\"\n            [bottomLeftPipedDetails]=\"item.bottomLeftPipedDetails\"\n            [bottomLeftScreenReaderText]=\"item.bottomLeftScreenReaderText\"\n            [e2eBottomLeft]=\"item.e2eBottomLeft\"\n            [verticalPaddingSize]=\"item.verticalPaddingSize\"\n        ></ui-workflows-list-template>\n    </div>\n</ng-template>\n\n<ng-template #listItemFormTemplate let-item=\"item\">\n    <div class=\"list-item-form-fields\" [class.mr-md-1]=\"!modalTopTemplate && !modalBottomTemplate\" [formGroup]=\"item._form\">\n        @for (field of allFields; track field.name; let isLast = $last) {\n            <div\n                [class.amount-field-container]=\"field.type === ListFormFieldType.AMOUNT\"\n                [class.datepicker-field-container]=\"field.type === ListFormFieldType.DATEPICKER\"\n                [class.number-field-container]=\"field.type === ListFormFieldType.NUMBER\"\n                [class]=\"isLast ? 'mr-md-2' : 'mr-md-4'\">\n                @switch (field.type) {\n                    @case (ListFormFieldType.AMOUNT) {\n                        <ui-forms-amount-input\n                            [errorMessage]=\"field.errorMessage\"\n                            [formControlName]=\"field.name\"\n                            [label]=\"field.label\"\n                            [locked]=\"item.locked\">\n                        </ui-forms-amount-input>\n                    }\n                    @case (ListFormFieldType.DATEPICKER) {\n                        <ui-forms-datepicker\n                            [afterDateText]=\"field.afterDateText\"\n                            [allowToday]=\"true\"\n                            [daysAfter]=\"item.daysAfter\"\n                            [daysPrior]=\"item.daysPrior\"\n                            [disableFutureDates]=\"field.disableFutureDates\"\n                            [disablePastDates]=\"field.disablePastDates\"\n                            [disableHolidays]=\"field.disableHolidays\"\n                            [disableWeekends]=\"field.disableWeekends\"\n                            [errorMessage]=\"field.errorMessage\"\n                            [formControlName]=\"field.name\"\n                            [holidays]=\"field.holidays\"\n                            [label]=\"field.label\"\n                            [locked]=\"item.locked\"\n                            [maxDate]=\"item.maxDate\"\n                            [minDate]=\"item.minDate\"\n                            [priorDateText]=\"field.priorDateText\"\n                            [selectedDateText]=\"field.selectedDateText\">\n                        </ui-forms-datepicker>\n                    }\n                    @case (ListFormFieldType.NUMBER) {\n                        <ui-forms-number-input\n                            [errorMessage]=\"field.errorMessage\"\n                            [formControlName]=\"field.name\"\n                            [max]=\"field.max\"\n                            [min]=\"field.min\"\n                            [decimalPlaces]=\"field.decimalPlaces\"\n                            [label]=\"field.label\"\n                            [locked]=\"item.locked\">\n                        </ui-forms-number-input>\n                    }\n                }\n            </div>\n        }\n    </div>\n</ng-template>\n\n<ng-template #listItemDetailsIconButtonTemplate let-item=\"item\">\n    <ui-core-icon-button\n        [ariaControls]=\"listId\"\n        [ariaHasPopup]=\"HtmlAttributeStateEnum.TRUE\"\n        [buttonClass]=\"isMobile ? 'color-gray-900' : 'color-gray-700'\"\n        class=\"mt-md-7 mr-half mr-md-1\"\n        [e2e]=\"e2ePrefix + '-open-details-modal-button'\"\n        [icon]=\"isMobile ? 'chevron_right' : 'tune'\"\n        [message]=\"text.openDetailsModalAriaLabel\"\n        size=\"md\"\n        (click)=\"openDetailsModal(item)\">\n    </ui-core-icon-button>\n</ng-template>\n\n<ui-core-unsaved-changes-modal></ui-core-unsaved-changes-modal>\n\n<ng-template #detailsModal>\n    <ui-core-modal\n        [id]=\"listId\"\n        [e2e]=\"e2ePrefix + 'details-modal' \"\n        [primaryButtonText]=\"modalPrimaryButtonText\"\n        [secondaryButtonText]=\"modalSecondaryButtonText\"\n        [actionButtonText]=\"modalTertiaryButtonText\"\n        [actionButtonIcon]=\"modalTertiaryButtonIcon\"\n        [title]=\"modalTitle ?? text.defaultModalTitle\"\n        [lockScrim]=\"lockModalScrim\"\n        [beforeClose]=\"confirmUnsavedChanges ? checkUnsavedChangesHandler : null\"\n        (primaryButtonClicked)=\"onPrimaryButtonClick()\"\n        (secondaryButtonClicked)=\"onSecondaryButtonClick()\"\n        (actionButtonClicked)=\"onTertiaryButtonClick()\">\n        @if (selectedItem) {\n            <ng-container [ngTemplateOutlet]=\"modalTopTemplate\" [ngTemplateOutletContext]=\"{item: selectedItem}\">\n            </ng-container>\n        }\n        @if (isMobile) {\n            <ng-container [ngTemplateOutlet]=\"listItemFormTemplate\" [ngTemplateOutletContext]=\"{item: selectedItem}\">\n            </ng-container>\n        }\n        @if (selectedItem) {\n            <ng-container [ngTemplateOutlet]=\"modalBottomTemplate\" [ngTemplateOutletContext]=\"{item: selectedItem}\">\n            </ng-container>\n        }\n    </ui-core-modal>\n</ng-template>\n", styles: [".list-container{background-color:var(--color-default);border:1px solid var(--color-stroke-1);position:relative}@media (min-width: 768px){.list-container{border-radius:var(--containers-shape)}}.list-item-grid{display:grid;grid-template-columns:1fr auto;column-gap:16px}.list-item-content{overflow:hidden}@media (max-width: 767.98px){.list-item-content{flex:1 1 auto}}@media (min-width: 768px){.list-item-form-fields{display:flex;margin-top:var(--spacing-100)}}@media (min-width: 1080px){.amount-field-container{max-width:250px}}@media (min-width: 768px) and (max-width: 1079.98px){.amount-field-container{max-width:180px}}.datepicker-field-container{flex-shrink:0}@media (min-width: 1080px){.datepicker-field-container{max-width:300px}}@media (min-width: 768px) and (max-width: 1079.98px){.datepicker-field-container{max-width:260px}}@media (min-width: 1080px){.number-field-container{max-width:250px;width:250px}}@media (min-width: 768px) and (max-width: 1079.98px){.number-field-container{max-width:180px;width:180px}}.clickable:hover{cursor:pointer;background-color:var(--color-hover)}.top-left-badges-container{padding:8px 16px 0}@media (min-width: 768px){.top-left-badges-container{margin-bottom:-20px}}\n"], dependencies: [{ kind: "directive", type: i2$1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1.NgForm, selector: "form:not([ngNoForm]):not([formGroup]),ng-form,[ngForm]", inputs: ["ngFormOptions"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i2.BadgeListComponent, selector: "ui-core-badge-list", inputs: ["items", "marginTop", "max", "rightAlign"] }, { kind: "component", type: i2.ButtonComponent, selector: "ui-core-button", inputs: ["themeGroup", "theme", "message", "icon", "iconPosition", "disabled", "disabledMessage", "showSpinner", "buttonClass", "width", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "ariaLabel", "isFormValid", "e2e", "buttonId"] }, { kind: "component", type: i2.IconButtonComponent, selector: "ui-core-icon-button", inputs: ["message", "icon", "size", "disabled", "buttonClass", "ariaPressed", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "e2e", "theme", "usesGlassHoverState", "buttonId"] }, { kind: "component", type: i2.LabelValueComponent, selector: "ui-core-label-value", inputs: ["label", "value", "values", "labelIcon", "tooltipContent", "tooltipPlacement", "iconLeft", "iconRight", "iconRightAriaLabel", "iconLeftColorClass", "iconLeftAllowEmojis", "masked", "maskedValues", "showCopyToClipboard", "rightAlignIconButtons", "elementClass", "borderBottom", "valueClass", "valueIsLink", "valueSubLinkText", "url", "externalUrlNewTab", "showSpinner", "e2e", "valueIsUnselectable", "notificationMessage", "notificationTheme", "notificationIcon"], outputs: ["iconRightClicked", "linkClicked", "maskToggleClicked", "copied"] }, { kind: "component", type: i2.ModalComponent, selector: "ui-core-modal", inputs: ["headerTemplate", "footerTemplate", "noBodyPadding", "noHeaderBorder", "useFormRendererButtons", "useFooterButtons", "showPrimarySpinner", "useGlassBackground"] }, { kind: "component", type: i2.UnsavedChangesModalComponent, selector: "ui-core-unsaved-changes-modal", inputs: ["title", "header", "message", "primaryButtonText", "secondaryButtonText", "lockScrim"] }, { kind: "component", type: i4.AmountInputComponent, selector: "ui-forms-amount-input", inputs: ["decimalPlaces", "min", "hideIcon", "allowEmptyField"] }, { kind: "component", type: i4.DatepickerComponent, selector: "ui-forms-datepicker", inputs: ["actionButtonIcon", "actionButtonLabel", "afterDateText", "allowToday", "daysAfter", "daysPrior", "disableAllExceptFirstDayOfMonth", "disableAllExceptLastDayOfMonth", "disableAllExceptFifteenthAndLastDay", "disabledDaysOfMonth", "disabledDaysText", "disableFutureDates", "disableHolidays", "disablePastDates", "disableWeekends", "hideCalendar", "holidays", "iconLeft", "markedDate", "markedDateText", "maxDate", "minDate", "mobileDoneButtonLabel", "placeholder", "priorDateText", "selectedDateText"], outputs: ["actionButtonClick"] }, { kind: "component", type: i4.NumberInputComponent, selector: "ui-forms-number-input", inputs: ["min", "max", "dayOfMonthPicker", "disabledPickerDays", "markedDay", "markedDayLabel", "selectedDayLabel", "disabledDaysText", "decimalPlaces"] }, { kind: "component", type: EndOfListComponent, selector: "ui-workflows-end-of-list", inputs: ["items", "noListItemsTitleText", "noListItemsSubtitleText", "endOfListText"] }, { kind: "component", type: SearchSortFilterComponent, selector: "ui-workflows-search-sort-filter", inputs: ["autoFocusSearchInput", "searchFieldPlaceholder", "searchFieldText", "sortOptions", "sortOptionDefaultValue", "customFilters", "includeDateFilters", "useFutureDateFilters", "includeAmountRangeFilter", "paddingTop", "withinListComponent", "showSelectAllCheckbox", "selectAllCheckboxChecked", "selectAllCheckboxIndeterminate", "e2e"], outputs: ["allSelected", "searched", "sorted", "filtered", "filtersCleared"] }, { kind: "component", type: ListTemplateComponent, selector: "ui-workflows-list-template", inputs: ["avatarIcon", "avatarImageUrl", "avatarBackgroundClass", "avatarIconColorClass", "avatarShape", "allowEmojis", "threadModeEnabled", "topLeftText", "topLeftClass", "topLeftIcon", "topLeftScreenReaderText", "e2eTopLeft", "topLeftAdditionalText", "topCenterBadge", "topRightText", "topRightClass", "topRightIcon", "topRightBadge", "topRightScreenReaderText", "e2eTopRight", "bottomLeftText", "bottomLeftHtml", "bottomLeftPipedDetails", "bottomLeftScreenReaderText", "e2eBottomLeft", "bottomRightText", "bottomRightPipedDetails", "bottomRightScreenReaderText", "e2eBottomRight", "verticalPaddingSize"] }, { kind: "pipe", type: i2$1.SlicePipe, name: "slice" }], animations: [collapseOrSlideState] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: ListFormComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-workflows-list-form', animations: [collapseOrSlideState], template: "<div class=\"list-container\" [id]=\"e2ePrefix + 'container'\">\n    @if (searchEnabled) {\n        <ui-workflows-search-sort-filter\n            [searchFieldPlaceholder]=\"searchFieldPlaceholder\"\n            [searchFieldText]=\"searchFieldText\"\n            [sortOptions]=\"sortOptions\"\n            [sortOptionDefaultValue]=\"sortOptionDefaultValue\"\n            [withinListComponent]=\"true\"\n            (searched)=\"onSearchChange($event)\"\n            (sorted)=\"onSortChange($event)\">\n        </ui-workflows-search-sort-filter>\n        @if (searchInputChanged) {\n            <div class=\"sr-only\" aria-live=\"polite\">\n                @if (items.length === 0) {\n                    <span>{{ text.ariaLiveNoResultsFound }}</span>\n                } @else if (items.length === 1) {\n                    <span>{{ text.ariaLiveOneResultFound }}</span>\n                } @else {\n                    <span>{{ text.ariaLiveMultipleResultsFound }}</span>\n                }\n            </div>\n        }\n    }\n    @for (item of (items | slice:0:numItemsToShow); track item) {\n        @if (item._form) {\n            <form>\n                @if (isMobile) {\n                    <div class=\"clickable\" [class]=\"item.backgroundClass\"\n                        [attr.aria-controls]=\"listId\" aria-haspopup=\"true\" tabindex=\"0\" (click)=\"openDetailsModal(item)\">\n                        <div class=\"border-top mb-1\">\n                            @if (item.topLeftBadges?.length) {\n                                <div class=\"top-left-badges-container\">\n                                    <ui-core-badge-list [items]=\"item.topLeftBadges\"></ui-core-badge-list>\n                                </div>\n                            }\n                            <div class=\"flex-align-center\">\n                                <ng-container [ngTemplateOutlet]=\"listItemContentTemplate\" [ngTemplateOutletContext]=\"{item: item}\">\n                                </ng-container>\n                                <ng-container [ngTemplateOutlet]=\"listItemDetailsIconButtonTemplate\" [ngTemplateOutletContext]=\"{item: item}\">\n                                </ng-container>\n                            </div>\n                        </div>\n                        @for (field of allFields; track field.name) {\n                            <div class=\"ml-3\">\n                                <ui-core-label-value\n                                    elementClass=\"pb-4\"\n                                    [iconLeft]=\"item.locked ? 'lock' : ''\"\n                                    [label]=\"field.label\"\n                                    [value]=\"getMobileValue(item, field)\">\n                                </ui-core-label-value>\n                            </div>\n                        }\n                    </div>\n                } @else {\n                    <div class=\"list-item-grid border-top\" [class]=\"item.backgroundClass\">\n                        @if (item.topLeftBadges?.length) {\n                            <div class=\"top-left-badges-container\">\n                                <ui-core-badge-list [items]=\"item.topLeftBadges\"></ui-core-badge-list>\n                            </div>\n                            <div></div>\n                        }\n                        <ng-container [ngTemplateOutlet]=\"listItemContentTemplate\" [ngTemplateOutletContext]=\"{item: item}\">\n                        </ng-container>\n                        <div class=\"d-flex\">\n                            <ng-container [ngTemplateOutlet]=\"listItemFormTemplate\" [ngTemplateOutletContext]=\"{item: item}\">\n                            </ng-container>\n                            @if (modalTopTemplate || modalBottomTemplate) {\n                                <ng-container [ngTemplateOutlet]=\"listItemDetailsIconButtonTemplate\" [ngTemplateOutletContext]=\"{item: item}\">\n                                </ng-container>\n                            }\n                        </div>\n                    </div>\n                }\n            </form>\n        }\n    }\n    @if (items && numItemsToShow < items.length) {\n        <div class=\"text-center py-3\">\n            <ui-core-button\n                [ariaControls]=\"e2ePrefix + 'container'\"\n                [message]=\"text.showMoreButtonText\"\n                theme=\"secondary\"\n                (click)=\"showMore()\">\n            </ui-core-button>\n        </div>\n    }\n    @if (showMoreClicked) {\n        <span class=\"sr-only\" aria-live=\"polite\">{{ text.ariaLiveMoreOptionsShown }}</span>\n    }\n    @if (items && (numItemsToShow >= items.length || (!numItemsToShow && items.length === 0))) {\n        <ui-workflows-end-of-list\n            [items]=\"items\"\n            [endOfListText]=\"endOfListText || text.endOfListText\"\n            [noListItemsTitleText]=\"noListItemsTitleText || text.noListItemsTitleText\"\n            [noListItemsSubtitleText]=\"noListItemsSubtitleText || text.noListItemsSubtitleText\">\n        </ui-workflows-end-of-list>\n    }\n</div>\n\n<ng-template #listItemContentTemplate let-item=\"item\">\n    <div class=\"list-item-content mt-md-4\">\n        <ui-workflows-list-template\n            [avatarBackgroundClass]=\"item.avatarBackgroundClass\"\n            [avatarIconColorClass]=\"item.avatarIconColorClass\"\n            [avatarIcon]=\"item.avatarIcon\"\n            [avatarImageUrl]=\"item.avatarImageUrl\"\n            [avatarShape]=\"item.avatarShape\"\n            [topLeftText]=\"item.topLeftText\"\n            [topLeftClass]=\"item.topLeftClass\"\n            [topLeftIcon]=\"item.topLeftIcon\"\n            [topLeftScreenReaderText]=\"item.topLeftScreenReaderText\"\n            [e2eTopLeft]=\"item.e2eTopLeft\"\n            [bottomLeftText]=\"item.bottomLeftText\"\n            [bottomLeftPipedDetails]=\"item.bottomLeftPipedDetails\"\n            [bottomLeftScreenReaderText]=\"item.bottomLeftScreenReaderText\"\n            [e2eBottomLeft]=\"item.e2eBottomLeft\"\n            [verticalPaddingSize]=\"item.verticalPaddingSize\"\n        ></ui-workflows-list-template>\n    </div>\n</ng-template>\n\n<ng-template #listItemFormTemplate let-item=\"item\">\n    <div class=\"list-item-form-fields\" [class.mr-md-1]=\"!modalTopTemplate && !modalBottomTemplate\" [formGroup]=\"item._form\">\n        @for (field of allFields; track field.name; let isLast = $last) {\n            <div\n                [class.amount-field-container]=\"field.type === ListFormFieldType.AMOUNT\"\n                [class.datepicker-field-container]=\"field.type === ListFormFieldType.DATEPICKER\"\n                [class.number-field-container]=\"field.type === ListFormFieldType.NUMBER\"\n                [class]=\"isLast ? 'mr-md-2' : 'mr-md-4'\">\n                @switch (field.type) {\n                    @case (ListFormFieldType.AMOUNT) {\n                        <ui-forms-amount-input\n                            [errorMessage]=\"field.errorMessage\"\n                            [formControlName]=\"field.name\"\n                            [label]=\"field.label\"\n                            [locked]=\"item.locked\">\n                        </ui-forms-amount-input>\n                    }\n                    @case (ListFormFieldType.DATEPICKER) {\n                        <ui-forms-datepicker\n                            [afterDateText]=\"field.afterDateText\"\n                            [allowToday]=\"true\"\n                            [daysAfter]=\"item.daysAfter\"\n                            [daysPrior]=\"item.daysPrior\"\n                            [disableFutureDates]=\"field.disableFutureDates\"\n                            [disablePastDates]=\"field.disablePastDates\"\n                            [disableHolidays]=\"field.disableHolidays\"\n                            [disableWeekends]=\"field.disableWeekends\"\n                            [errorMessage]=\"field.errorMessage\"\n                            [formControlName]=\"field.name\"\n                            [holidays]=\"field.holidays\"\n                            [label]=\"field.label\"\n                            [locked]=\"item.locked\"\n                            [maxDate]=\"item.maxDate\"\n                            [minDate]=\"item.minDate\"\n                            [priorDateText]=\"field.priorDateText\"\n                            [selectedDateText]=\"field.selectedDateText\">\n                        </ui-forms-datepicker>\n                    }\n                    @case (ListFormFieldType.NUMBER) {\n                        <ui-forms-number-input\n                            [errorMessage]=\"field.errorMessage\"\n                            [formControlName]=\"field.name\"\n                            [max]=\"field.max\"\n                            [min]=\"field.min\"\n                            [decimalPlaces]=\"field.decimalPlaces\"\n                            [label]=\"field.label\"\n                            [locked]=\"item.locked\">\n                        </ui-forms-number-input>\n                    }\n                }\n            </div>\n        }\n    </div>\n</ng-template>\n\n<ng-template #listItemDetailsIconButtonTemplate let-item=\"item\">\n    <ui-core-icon-button\n        [ariaControls]=\"listId\"\n        [ariaHasPopup]=\"HtmlAttributeStateEnum.TRUE\"\n        [buttonClass]=\"isMobile ? 'color-gray-900' : 'color-gray-700'\"\n        class=\"mt-md-7 mr-half mr-md-1\"\n        [e2e]=\"e2ePrefix + '-open-details-modal-button'\"\n        [icon]=\"isMobile ? 'chevron_right' : 'tune'\"\n        [message]=\"text.openDetailsModalAriaLabel\"\n        size=\"md\"\n        (click)=\"openDetailsModal(item)\">\n    </ui-core-icon-button>\n</ng-template>\n\n<ui-core-unsaved-changes-modal></ui-core-unsaved-changes-modal>\n\n<ng-template #detailsModal>\n    <ui-core-modal\n        [id]=\"listId\"\n        [e2e]=\"e2ePrefix + 'details-modal' \"\n        [primaryButtonText]=\"modalPrimaryButtonText\"\n        [secondaryButtonText]=\"modalSecondaryButtonText\"\n        [actionButtonText]=\"modalTertiaryButtonText\"\n        [actionButtonIcon]=\"modalTertiaryButtonIcon\"\n        [title]=\"modalTitle ?? text.defaultModalTitle\"\n        [lockScrim]=\"lockModalScrim\"\n        [beforeClose]=\"confirmUnsavedChanges ? checkUnsavedChangesHandler : null\"\n        (primaryButtonClicked)=\"onPrimaryButtonClick()\"\n        (secondaryButtonClicked)=\"onSecondaryButtonClick()\"\n        (actionButtonClicked)=\"onTertiaryButtonClick()\">\n        @if (selectedItem) {\n            <ng-container [ngTemplateOutlet]=\"modalTopTemplate\" [ngTemplateOutletContext]=\"{item: selectedItem}\">\n            </ng-container>\n        }\n        @if (isMobile) {\n            <ng-container [ngTemplateOutlet]=\"listItemFormTemplate\" [ngTemplateOutletContext]=\"{item: selectedItem}\">\n            </ng-container>\n        }\n        @if (selectedItem) {\n            <ng-container [ngTemplateOutlet]=\"modalBottomTemplate\" [ngTemplateOutletContext]=\"{item: selectedItem}\">\n            </ng-container>\n        }\n    </ui-core-modal>\n</ng-template>\n", styles: [".list-container{background-color:var(--color-default);border:1px solid var(--color-stroke-1);position:relative}@media (min-width: 768px){.list-container{border-radius:var(--containers-shape)}}.list-item-grid{display:grid;grid-template-columns:1fr auto;column-gap:16px}.list-item-content{overflow:hidden}@media (max-width: 767.98px){.list-item-content{flex:1 1 auto}}@media (min-width: 768px){.list-item-form-fields{display:flex;margin-top:var(--spacing-100)}}@media (min-width: 1080px){.amount-field-container{max-width:250px}}@media (min-width: 768px) and (max-width: 1079.98px){.amount-field-container{max-width:180px}}.datepicker-field-container{flex-shrink:0}@media (min-width: 1080px){.datepicker-field-container{max-width:300px}}@media (min-width: 768px) and (max-width: 1079.98px){.datepicker-field-container{max-width:260px}}@media (min-width: 1080px){.number-field-container{max-width:250px;width:250px}}@media (min-width: 768px) and (max-width: 1079.98px){.number-field-container{max-width:180px;width:180px}}.clickable:hover{cursor:pointer;background-color:var(--color-hover)}.top-left-badges-container{padding:8px 16px 0}@media (min-width: 768px){.top-left-badges-container{margin-bottom:-20px}}\n"] }]
        }], ctorParameters: () => [{ type: i1.UntypedFormBuilder }, { type: i2.ModalService }, { type: i2.TextService }, { type: i2.WindowService }], propDecorators: { detailsModal: [{
                type: ViewChild,
                args: ['detailsModal']
            }], searchComponent: [{
                type: ViewChild,
                args: [SearchInputComponent]
            }], unsavedChangesModal: [{
                type: ViewChild,
                args: [UnsavedChangesModalComponent, { static: true }]
            }], formFields: [{
                type: Input
            }], items: [{
                type: Input
            }], pageSize: [{
                type: Input
            }], modalTitle: [{
                type: Input
            }], lockModalScrim: [{
                type: Input
            }], confirmUnsavedChanges: [{
                type: Input
            }], modalTopTemplate: [{
                type: Input
            }], modalBottomTemplate: [{
                type: Input
            }], modalPrimaryButtonText: [{
                type: Input
            }], modalSecondaryButtonText: [{
                type: Input
            }], modalTertiaryButtonText: [{
                type: Input
            }], modalTertiaryButtonIcon: [{
                type: Input
            }], noListItemsTitleText: [{
                type: Input
            }], noListItemsSubtitleText: [{
                type: Input
            }], endOfListText: [{
                type: Input
            }], searchEnabled: [{
                type: Input
            }], searchFieldPlaceholder: [{
                type: Input
            }], searchFieldText: [{
                type: Input
            }], sortOptions: [{
                type: Input
            }], sortOptionDefaultValue: [{
                type: Input
            }], e2e: [{
                type: Input
            }], searched: [{
                type: Output
            }], sorted: [{
                type: Output
            }], showMoreButtonClicked: [{
                type: Output
            }], primaryButtonClicked: [{
                type: Output
            }], secondaryButtonClicked: [{
                type: Output
            }], tertiaryButtonClicked: [{
                type: Output
            }], itemModalOpened: [{
                type: Output
            }], itemChange: [{
                type: Output
            }], validItemsChange: [{
                type: Output
            }] } });

class ListFormField {
    constructor(type, label, name) {
        this.type = type;
        this.label = label;
        this.name = name;
        this.errorMessage = '';
        this.required = true;
        // Date specific fields
        this.afterDateText = '';
        this.disableFutureDates = false;
        this.disablePastDates = false;
        this.disableHolidays = false;
        this.disableWeekends = false;
        this.holidays = [];
        this.priorDateText = '';
        this.selectedDateText = '';
        // Number specific fields
        this.min = 0;
        this.max = DEFAULT_MAX_NUMBER;
        this.decimalPlaces = 0;
        switch (type) {
            case ListFormFieldType.AMOUNT:
                this._initialValue = 0;
                break;
            case ListFormFieldType.NUMBER:
                this._initialValue = null;
                break;
            default:
                this._initialValue = '';
                break;
        }
    }
    getValidator() {
        switch (this.type) {
            case ListFormFieldType.AMOUNT:
                return positiveAmount; // needed to prevent zero default values from being considered valid
            default:
                return null;
        }
    }
}

class ListItem {
    constructor(item) {
        // The original data object for reference
        this.originalItem = null;
        this.e2e = null; // optional e2e identifier for the list row & details, should be unique per item & context specific (i.e. 'balance-summary-alert', or 'card-control-config')
        this.verticalPaddingSize = 'sm';
        // List item controls
        this.checked = false;
        this.locked = false; // locks list item controls
        this.showDetails = false;
        this.avatarIconColorClass = 'color-white';
        this.avatarBackgroundClass = 'bg-brand-secondary';
        this.avatarShape = 'circle';
        this.topLeftBadges = [];
        this.e2eTopLeft = null;
        this.e2eTopRight = null;
        this.bottomLeftPipedDetails = [];
        this.e2eBottomLeft = null;
        this.bottomRightPipedDetails = [];
        this.e2eBottomRight = null;
        this.actionButtonTertiaryTextDisplaysOnMobile = false;
        this.actionButtonTheme = 'secondary';
        this.originalItem = item;
    }
}

class ListFormItem extends ListItem {
    constructor() {
        super(...arguments);
        // Optional initial values
        this.initialValues = new Map();
        // Pseudo-private properties used by the List Form Component that should NOT be modified externally
        this._canBeSubmitted = false;
        this._form = null;
    }
    get canBeSubmitted() {
        return this._canBeSubmitted;
    }
    get form() {
        return this._form;
    }
    getFormItemInitialValue(name) {
        const initialValue = this.initialValues.get(name);
        return initialValue || null;
    }
    getFormFieldValue(name) {
        const control = this.form?.get(name);
        if (control) {
            return control.value;
        }
        return null;
    }
    resetFormFieldValues(fields) {
        fields.forEach(field => {
            const control = this.form?.get(field.name);
            control.setValue(field._initialValue);
        });
        this._canBeSubmitted = this.form.valid;
    }
}

/* eslint-disable max-classes-per-file */
class ColumnFilterControl {
}
class ColumnFilterOption {
}
class ColumnFilterList {
}
// equivalent to FilterEvent interface in Admin SPA
class TableFilter {
}
class TableFilterEvent {
}
var TableFilterType;
(function (TableFilterType) {
    TableFilterType["STRING"] = "string";
    TableFilterType["DATE_RANGE"] = "date-range";
})(TableFilterType || (TableFilterType = {}));

class TableAction {
}

class TableActionsComponent {
    constructor() {
        this.menuTitle = '';
        this.tableAction = new EventEmitter();
        this.buttonActions = [];
    }
    ngOnChanges() {
        this.buttonActions = this.filterActions();
    }
    filterActions() {
        const visibleActions = [];
        this.actions.forEach(action => {
            if (!action.visible || action.visible(this.item)) {
                visibleActions.push({
                    ...action,
                    action: () => this.tableAction.emit(action)
                });
            }
        });
        return visibleActions;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TableActionsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.17", type: TableActionsComponent, isStandalone: false, selector: "ui-workflows-table-actions", inputs: { actions: "actions", item: "item", menuTitle: "menuTitle" }, outputs: { tableAction: "tableAction" }, usesOnChanges: true, ngImport: i0, template: `
        @if (buttonActions.length === 1) {
            <ui-core-button
                *ngFor="let action of buttonActions"
                (click)="action.action(action)"
                [message]="action.text"
                [icon]="action.icon"
                [theme]="action.icon ? 'tertiary' : 'link'"
                class="table-action"
            ></ui-core-button>
        } 
        @else if (buttonActions.length > 1) {
            <ui-core-button-menu
                icon="more_vert"
                [desktopMenuWidth]="200"
                [title]="menuTitle"
                [options]="buttonActions"
                class="table-action"
                e2e="table-actions-dropdown"
            ></ui-core-button-menu>
        }
    `, isInline: true, dependencies: [{ kind: "directive", type: i2$1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: i2.ButtonComponent, selector: "ui-core-button", inputs: ["themeGroup", "theme", "message", "icon", "iconPosition", "disabled", "disabledMessage", "showSpinner", "buttonClass", "width", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "ariaLabel", "isFormValid", "e2e", "buttonId"] }, { kind: "component", type: i2.ButtonMenuComponent, selector: "ui-core-button-menu", inputs: ["icon", "title", "options", "e2e", "display", "gridIconAboveMessage", "gridIconShape", "gridRowPosition", "iconTheme"], outputs: ["buttonClicked"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TableActionsComponent, decorators: [{
            type: Component,
            args: [{
                    standalone: false,
                    selector: 'ui-workflows-table-actions',
                    template: `
        @if (buttonActions.length === 1) {
            <ui-core-button
                *ngFor="let action of buttonActions"
                (click)="action.action(action)"
                [message]="action.text"
                [icon]="action.icon"
                [theme]="action.icon ? 'tertiary' : 'link'"
                class="table-action"
            ></ui-core-button>
        } 
        @else if (buttonActions.length > 1) {
            <ui-core-button-menu
                icon="more_vert"
                [desktopMenuWidth]="200"
                [title]="menuTitle"
                [options]="buttonActions"
                class="table-action"
                e2e="table-actions-dropdown"
            ></ui-core-button-menu>
        }
    `,
                    changeDetection: ChangeDetectionStrategy.OnPush
                }]
        }], propDecorators: { actions: [{
                type: Input
            }], item: [{
                type: Input
            }], menuTitle: [{
                type: Input
            }], tableAction: [{
                type: Output
            }] } });

class TableActionEvent {
}

/* eslint-disable max-classes-per-file */
class TableBadgesContext {
}
class TableIconContext extends IconComponent {
    constructor() {
        super(...arguments);
        // should accept all ui-core-icon inputs, plus:
        this.iconPosition = 'left';
    }
}
class TableTagsContext {
}

class TableColumn {
}
var TableStickyColumnConfig;
(function (TableStickyColumnConfig) {
    TableStickyColumnConfig["FIRST"] = "first";
    TableStickyColumnConfig["LAST"] = "last";
    TableStickyColumnConfig["BOTH"] = "both";
    TableStickyColumnConfig["NONE"] = "none";
})(TableStickyColumnConfig || (TableStickyColumnConfig = {}));

var TableSortDirection;
(function (TableSortDirection) {
    TableSortDirection["ASCENDING"] = "ASC";
    TableSortDirection["DESCENDING"] = "DESC";
})(TableSortDirection || (TableSortDirection = {}));

class TableState {
    constructor() {
        this.currentPage = 1;
        this.filters = {};
        this.pageSize = 10;
        this.searchTerm = '';
        this.sortColumn = '';
        this.sortDirection = TableSortDirection.ASCENDING;
    }
    get sortTerm() {
        return TableState.buildSortTerm(this.sortColumn, this.sortDirection);
    }
    static buildSortTerm(column, direction) {
        return column ? `${column}~${direction}` : '';
    }
    clone() {
        const clone = new TableState();
        clone.currentPage = this.currentPage;
        clone.filters = { ...this.filters };
        clone.pageSize = this.pageSize;
        clone.searchTerm = this.searchTerm;
        clone.sortColumn = this.sortColumn;
        clone.sortDirection = this.sortDirection;
        return clone;
    }
}

class TableCellContent {
}

class TableRow {
}
class TableColumnData {
}
class TableRowData {
}
class TableRowColumnData {
}

class TableStateService {
    constructor() {
        this.tableStates = new Map();
        this.idDelimiter = '__';
    }
    saveState(tableStateId, state, tableStateParam) {
        if (tableStateId && state) {
            let stateId = tableStateId;
            if (tableStateParam) {
                stateId = tableStateId + this.idDelimiter + tableStateParam;
                // only allow 1 state per tableStateId
                this.tableStates.forEach((_, key) => {
                    if (key.startsWith(tableStateId + this.idDelimiter)) {
                        this.tableStates.delete(key);
                    }
                });
            }
            this.tableStates.set(stateId, state);
        }
    }
    getState(tableStateId, tableStateParam) {
        const stateId = tableStateParam ? tableStateId + this.idDelimiter + tableStateParam : tableStateId;
        if (stateId && this.tableStates.has(stateId)) {
            return this.tableStates.get(stateId).clone(); // clone for immutability
        }
        return null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TableStateService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TableStateService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TableStateService, decorators: [{
            type: Injectable
        }] });

var TableTemplateType;
(function (TableTemplateType) {
    TableTemplateType["BADGES"] = "badges";
    TableTemplateType["ICON"] = "icon";
    TableTemplateType["TAGS"] = "tags";
    TableTemplateType["_READY"] = "_ready";
})(TableTemplateType || (TableTemplateType = {}));

class TableTemplatesService {
    constructor() {
        this.tableTemplates = new Map();
        this.areTemplatesLoaded = new BehaviorSubject(false);
        this.templatesLoaded$ = this.areTemplatesLoaded.asObservable();
    }
    add(name, ref) {
        this.tableTemplates.set(name, ref);
        if (name === TableTemplateType._READY) {
            this.areTemplatesLoaded.next(true);
        }
    }
    get(name) {
        return this.tableTemplates.get(name);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TableTemplatesService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TableTemplatesService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TableTemplatesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

class TableTemplatesDefinitionsComponent {
    constructor(tableTemplatesService) {
        this.tableTemplatesService = tableTemplatesService;
        this.BadgeTheme = BadgeTheme;
        this.TableTemplateType = TableTemplateType;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TableTemplatesDefinitionsComponent, deps: [{ token: TableTemplatesService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.17", type: TableTemplatesDefinitionsComponent, isStandalone: false, selector: "ui-workflows-table-template-definitions", ngImport: i0, template: `
        <!-- 
            Badge or Badge List
            context: TableBadgesContext | string
        -->
        <ng-template #badges let-badges="badges" let-column="columnValue">
            <ui-core-badge-list [items]="badges || (badges !== false ? [{ message: column, theme: BadgeTheme.INFORMATION }] : null)" [marginTop]="false" />
        </ng-template>
        {{ tableTemplatesService.add(TableTemplateType.BADGES, badges) }}

        <!-- 
            Icon (with optional text & subtext)
            context: TableIconContext
        -->
        <ng-template #icon let-icon="icon" let-allowEmojis="allowEmojis" let-colorClass="colorClass" let-size="size" let-text="text" let-subtext="subtext" let-iconPosition="iconPosition" let-column="columnValue">
            <div class="table-template-icon" [class.icon-right]="iconPosition === 'right'">
                <ui-core-icon [icon]="icon || column" [colorClass]="colorClass || 'color-brand-primary'" [size]="size || 'xl'" [allowEmojis]="allowEmojis" />
                <span *ngIf="text || subtext" class="icon-text">
                    <span *ngIf="text">{{ text }}</span><br *ngIf="text && subtext" />
                    <span *ngIf="subtext" class="sub-text">{{ subtext }}</span>
                </span>
            </div>
        </ng-template>
        {{ tableTemplatesService.add(TableTemplateType.ICON, icon) }}

        <!-- 
            Tags
            context: TableTagsContext
        -->
        <ng-template #tags let-tags="tags">
            <ui-core-chip-list *ngIf="tags" [items]="tags" [hideLabel]="true" />
        </ng-template>
        {{ tableTemplatesService.add(TableTemplateType.TAGS, tags) }}


        <!-- _internal -->
        <ng-template #_templatesReady />
        {{ tableTemplatesService.add(TableTemplateType._READY, _templatesReady) }}
    `, isInline: true, dependencies: [{ kind: "directive", type: i2$1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i2.BadgeListComponent, selector: "ui-core-badge-list", inputs: ["items", "marginTop", "max", "rightAlign"] }, { kind: "component", type: i2.ChipListComponent, selector: "ui-core-chip-list", inputs: ["label", "hideLabel", "items", "showRemoveButton", "disabled"], outputs: ["itemClicked", "itemRemoved"] }, { kind: "component", type: i2.IconComponent, selector: "ui-core-icon", inputs: ["icon", "size", "colorClass", "allowEmojis", "ariaLabel", "alignWithText", "collapseHeight", "scaleWithFonts", "animationPath", "animationData", "animationFreeze", "animationFreezeFrame", "animationLoop", "animationLoopTotal"], outputs: ["animationCompleted"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TableTemplatesDefinitionsComponent, decorators: [{
            type: Component,
            args: [{
                    standalone: false,
                    selector: 'ui-workflows-table-template-definitions',
                    template: `
        <!-- 
            Badge or Badge List
            context: TableBadgesContext | string
        -->
        <ng-template #badges let-badges="badges" let-column="columnValue">
            <ui-core-badge-list [items]="badges || (badges !== false ? [{ message: column, theme: BadgeTheme.INFORMATION }] : null)" [marginTop]="false" />
        </ng-template>
        {{ tableTemplatesService.add(TableTemplateType.BADGES, badges) }}

        <!-- 
            Icon (with optional text & subtext)
            context: TableIconContext
        -->
        <ng-template #icon let-icon="icon" let-allowEmojis="allowEmojis" let-colorClass="colorClass" let-size="size" let-text="text" let-subtext="subtext" let-iconPosition="iconPosition" let-column="columnValue">
            <div class="table-template-icon" [class.icon-right]="iconPosition === 'right'">
                <ui-core-icon [icon]="icon || column" [colorClass]="colorClass || 'color-brand-primary'" [size]="size || 'xl'" [allowEmojis]="allowEmojis" />
                <span *ngIf="text || subtext" class="icon-text">
                    <span *ngIf="text">{{ text }}</span><br *ngIf="text && subtext" />
                    <span *ngIf="subtext" class="sub-text">{{ subtext }}</span>
                </span>
            </div>
        </ng-template>
        {{ tableTemplatesService.add(TableTemplateType.ICON, icon) }}

        <!-- 
            Tags
            context: TableTagsContext
        -->
        <ng-template #tags let-tags="tags">
            <ui-core-chip-list *ngIf="tags" [items]="tags" [hideLabel]="true" />
        </ng-template>
        {{ tableTemplatesService.add(TableTemplateType.TAGS, tags) }}


        <!-- _internal -->
        <ng-template #_templatesReady />
        {{ tableTemplatesService.add(TableTemplateType._READY, _templatesReady) }}
    `,
                }]
        }], ctorParameters: () => [{ type: TableTemplatesService }] });

const MIN_COL_WIDTH = '1';
class TableComponent extends BaseTextComponent {
    constructor(tableStateService, tableTemplatesService, windowService, changeDetector, ngZone, textService) {
        super(textService, 'ui-workflows-table');
        this.tableStateService = tableStateService;
        this.tableTemplatesService = tableTemplatesService;
        this.windowService = windowService;
        this.changeDetector = changeDetector;
        this.ngZone = ngZone;
        this.textService = textService;
        /**
        * Use "external" control mode for paging and sorting.
        * boolean: false by default, which means all data is loaded initially & the table will perform all actions internally (client-side)
        * If true, the table will only emit sort & page events, and not do any client-side sorting or paging.
        * this can be safely toggled to false by the parent component if/when all data is loaded
        **/
        this.externalSortAndPaging = false;
        /**
         * Use "external" control mode for searching and filtering.
         * boolean: false by default, which means all data is loaded initially & the table will perform all actions internally (client-side)
         * If true, the table will only emit search & filter events, but not do any client-side filtering or searching. (filterOptions must be provided by parent component)
         * If set to true, this SHOULD NOT be dynamically toggled by the parent component. We can't safely filter or search if we don't know if we have all the data, it must rely on the API requests (future work possible).
         */
        this.externalSearchAndFilter = false;
        /**
        * CSS width attribute of actions column
        **/
        this.actionsColumnFixedWidth = MIN_COL_WIDTH;
        /**
        * Array of TableColumn objects used to define table structure
        **/
        this.columns = [];
        /**
        * Array of data objects that will be processed by the TableColumns in this.columns, and displayed
        **/
        this.data = [];
        /**
        * E2E testing - data-e2e attribute attached to table
        **/
        this.e2e = 'ui-table';
        /**
        * String text to display if data is empty, or filtered to 0
        **/
        this.emptyText = this.text.noResultsText;
        /**
        * Boolean to show/hide grid-lines between cells
        **/
        this.gridLines = false;
        /**
        * Number of current page
        **/
        this.page = 1;
        /**
        * Number of items to display per page
        **/
        this.pageSize = 10;
        /**
        * Array of numbers used to populate page size dropdown
        **/
        this.pageSizes = [5, 10, 25, 50, 100];
        /**
        * Number of items in the table (total)
        **/
        this.resultCount = 0;
        /**
        * String value of search query, will automatically search/filter if provided
        **/
        this.searchTerm = '';
        /**
        * Boolean to show a checkbox on each row, and a "Select All" checkbox at the top of the column. Emits rowChecked when checked/unchecked
        **/
        this.showCheckbox = false;
        /**
        * Boolean to show or hide the column title & sort headers
        **/
        this.showColumnHeaders = true;
        /**
        * Boolean to show or hide the paging & page controls
        **/
        this.showPageControls = false;
        /**
        * Boolean to show or hide the search input & filters
        **/
        this.showSearchAndFilter = false;
        /**
        * Boolean to determine search input width - if true it will stretch across the whole table header
        **/
        this.searchFullWidth = false;
        /**
        * String name of column to sort by initially
        **/
        this.sortColumn = '';
        /**
        * Direction of initial sort
        **/
        this.sortDirection = TableSortDirection.ASCENDING;
        /**
        * Sets which columns will be sticky/frozen when scrolling
        **/
        this.stickyColumns = TableStickyColumnConfig.FIRST;
        /**
        * Boolean to show alternating row background colors
        **/
        this.striped = true;
        /**
        * String id of table. Must be unique per table, and is required to maintain usage-specific state.
        * Keeps table state on navigation. Caches sort/search/filter/paging state in onDestroy.
        **/
        this.tableStateId = '';
        /**
        * String parameter to more specifically define the tableState id.
        * example: using a userId so that session log states can be maintained when viewing multiple users.
        **/
        this.tableStateParam = '';
        /**
        * Boolean to indicate that user's sort/search/filter/paging selections should persist when the data changes.
        * Keeps table state on data update. Set to `false` & don't set a "tableStateId" if you need the table state to reset when the data updates.
        **/
        this.keepStateOnUpdate = true;
        // Header Row
        /**
        * Title text to be displayed above table
        **/
        this.title = '';
        /**
        * Subtitle text to be displayed above table
        **/
        this.subtitle = '';
        /**
        * Optional badges that render next to the title/subtitle
        **/
        this.badges = [];
        /**
        * Array of Page Actions to show in header/title row above the table
        * These do not provide or act on Table data, but are available for additional actions
        **/
        this.headerActions = [];
        /**
        * Optional. Sets the header page actions more menu button icon. Defaults to three vertical dots.
        **/
        this.pageActionsMenuIcon = '';
        /**
        * Optional. Sets the header page actions more menu button text. Defaults to 'More'.
        **/
        this.pageActionsMenuText = '';
        // User actions
        /**
        * Emits row data item when a row is clicked/enter-key. Only emits if a column is marked as clickable.
        **/
        this.rowClicked = new EventEmitter();
        /**
        * Emits when a row action is clicked/enter-key
        **/
        this.tableAction = new EventEmitter();
        /**
        * Emits array of currently checked rows when a row (or select-all) checkbox is checked/unchecked
        **/
        this.rowChecked = new EventEmitter();
        // Individual table state emitters
        /**
        * Emits list of active filters when filters are changed
        **/
        this.filtersChanged = new EventEmitter();
        /**
        * Emits new page number when a new page is requested
        **/
        this.pageChanged = new EventEmitter();
        /**
        * Emits new page size when size is changed
        **/
        this.pageSizeChanged = new EventEmitter();
        /**
        * Emits searchTerm string when a search is requested
        **/
        this.searched = new EventEmitter();
        /**
        * Emits sort term ${column}~${direction} when column is sorted
        **/
        this.sorted = new EventEmitter();
        this.MIN_COL_WIDTH = MIN_COL_WIDTH;
        this.actionsColMinWidth = '';
        this.activeFilters = {};
        this.bulkActionRows = [];
        this.bulkActionsSelectedLabel = '';
        this.clickable = false;
        this.dataPageList = [];
        this.firstColFixed = false;
        this.firstColContent = false;
        this.hasActiveFilters = false;
        this.hasActionsColumn = false;
        this.isMobile = false;
        this.isSelectAllChecked = false;
        this.lastColFixed = false;
        this.lastColContent = false;
        this.pageSizeOptions = [];
        this.pageSizeText = '';
        this.scrollable = false;
        this.scrollLeftComplete = true;
        this.scrollRightComplete = true;
        this.stickyClass = '';
        this.templatesReady = false;
        this.TableSortDirection = TableSortDirection;
        this.TableFilterType = TableFilterType;
        this._data = [];
        this._externalSearchAndFilter = false;
        this.animationFrameTick = false;
        this.buildingFilters = false;
        this.hasState = false;
        this.isSelectAll = false;
        this.isSelectRow = false;
        this.searchTermPartsUC = [];
        this.sortKeyPrefix = '__sortValue_';
        this.minDateValue = 19700101;
        this.maxDateValue = 20500101;
        // When we navigate away from this component, save the state.
        this.componentDestroyed$.subscribe(() => this.saveState(true));
        this.windowService.windowSize$.pipe(this.takeUntilDestroyed()).subscribe(windowSize => {
            this.isMobile = windowSize.isMobile;
            this.setScrollState();
            if (this.showPageControls) {
                this.setupSortAndPaging();
            }
        });
    }
    ngOnInit() {
        // ready pre-defined templates
        this.tableTemplatesService.templatesLoaded$.pipe(this.takeUntilDestroyed()).subscribe(loaded => {
            if (loaded) {
                this.setupColumns();
                this.templatesReady = true;
                this.changeDetector.detectChanges();
            }
        });
        // init this once, it can't be dynamic & react to onChanges without causing issues
        this._externalSearchAndFilter = this.externalSearchAndFilter;
        // Set up page sizes
        this.pageSizeOptions = this.pageSizes.map(size => new PickerOption(size.toString(), size));
        if (!this.pageSize || !this.pageSizes.includes(this.pageSize)) {
            this.pageSize = this.pageSizes[0];
        }
        this.initPageSize = this.pageSize;
        if (this.keepStateOnUpdate && !this.tableStateId) {
            this.saveState();
        }
    }
    ngOnChanges(changes) {
        // restore previous state
        if (this.tableStateId || this.keepStateOnUpdate) {
            this.restoreState(changes);
        }
        else {
            this.resetState();
        }
        if ((changes.data || changes.columns || changes.actions || changes.bulkActions || changes.searchableProps)) {
            this.prepData();
            if (changes.columns && this.columns?.length) {
                this.setupColumns();
            }
            if (this.showSearchAndFilter) {
                this.setupFilters();
            }
            if (this.hasActiveFilters || this.searchTerm) {
                this.filterData();
            }
            else {
                this.updateTableControls();
            }
        }
        else if (changes.sortColumn || changes.sortDirection) {
            this.setupSortAndPaging();
        }
        if (changes.stickyColumns) {
            this.stickyClass = this.stickyColumns === TableStickyColumnConfig.NONE ? '' : 'sticky sticky-' + this.stickyColumns;
            this.firstColFixed = this.stickyColumns === TableStickyColumnConfig.FIRST || this.stickyColumns === TableStickyColumnConfig.BOTH;
            this.lastColFixed = this.stickyColumns === TableStickyColumnConfig.LAST || this.stickyColumns === TableStickyColumnConfig.BOTH;
            this.firstColContent = this.firstColFixed && !this.showCheckbox;
            this.lastColContent = this.lastColFixed && !this.hasActionsColumn;
            this.changeDetector.detectChanges();
            this.setScrollState();
        }
        if (changes.pageSize && (!this.pageSize || !this.pageSizes.includes(this.pageSize))) {
            this.pageSize = this.pageSizes[0];
        }
        if (this.externalSortAndPaging && changes.page && changes.pageSize && this.columns?.length && this.data?.length) {
            // save external page changes & overwrite tableState ASAP, if we're already init-ed
            this.saveState();
        }
        if (changes.externalSearchAndFilter && !changes.externalSearchAndFilter.firstChange && this._externalSearchAndFilter !== this.externalSearchAndFilter) {
            // Dev warning when attempting to toggle search & filter dynamically. We could improve this behavior in the future, but for now this matches the Grid component & expected use-cases.
            // eslint-disable-next-line no-console
            console.warn('Attempted change to externalSearchAndFilter ignored - this is not supported and may cause issues. Once initialized, externalSearchAndFilter should not be changed dynamically.');
        }
    }
    ngAfterViewInit() {
        this.setScrollState();
    }
    onScroll() {
        if (!this.animationFrameTick) {
            window.requestAnimationFrame(() => {
                this.setScrollState();
                this.animationFrameTick = false;
            });
            this.animationFrameTick = true;
        }
    }
    sortOnColumn(column) {
        if (!column._tData.sortName) {
            return;
        }
        if (column._tData.sortName === this.sortColumn) {
            // This is the same column, just need to flip the direction
            this.sortDirection = this.sortDirection === TableSortDirection.ASCENDING ? TableSortDirection.DESCENDING : TableSortDirection.ASCENDING;
        }
        else {
            // This is a new column, always default to ascending.
            this.sortColumn = column._tData.sortName;
            this.sortDirection = TableSortDirection.ASCENDING;
        }
        if (this.externalSortAndPaging) {
            this.page = 1;
        }
        this.saveState();
        if (!this.externalSortAndPaging) {
            this.doSort(true);
        }
        const sortColumnName = this.sortColumn.startsWith(this.sortKeyPrefix) ? this.sortColumn.slice(this.sortKeyPrefix.length) : this.sortColumn;
        this.sorted.emit(TableState.buildSortTerm(sortColumnName, this.sortDirection));
    }
    doTableAction(row, action) {
        if (this.tableActionProcessingProp) {
            row[this.tableActionProcessingProp] = true;
        }
        const tableActionEvent = action.action(this.removeTableRowData(row));
        this.tableAction.emit(tableActionEvent);
    }
    doBulkTableAction(action) {
        const bulkActionEvent = action.action(this.removeTableRowDataFromList(this.bulkActionRows));
        this.tableAction.emit(bulkActionEvent);
    }
    rowClick(row, event) {
        // emit row click if not checkbox or action
        if (this.clickable && !EventUtils.didEventTouchClass(event, 'ui-form-control') && !EventUtils.didEventTouchClass(event, 'table-action')) {
            this.rowClicked.emit(this.removeTableRowData(row));
        }
    }
    onSelectRow(row, isSelectAll = false) {
        this.isSelectRow = true;
        row._tData.checked = isSelectAll ? this.isSelectAllChecked : !row._tData.checked;
        if (!this.isSelectAll) {
            this.handleChecked();
        }
        this.isSelectRow = false;
    }
    onSelectAll(event) {
        if (!this.isSelectRow) { // need block so that selectRow & selectAll don't step on each other
            const isClearAll = event === false;
            this.isSelectAll = true;
            this.isSelectAllChecked = isClearAll ? false : event.target.checked;
            const data = isClearAll ? this._data : this.filteredData;
            data.forEach(row => {
                this.onSelectRow(row, true);
            });
            this.handleChecked();
            this.isSelectAll = false;
        }
    }
    changePageSize(pageSizeNumber) {
        this.pageSize = pageSizeNumber;
        this.saveState();
        this.pageSizeChanged.emit(pageSizeNumber);
        this.setupPaging();
    }
    changePage(pageNumber) {
        let newPageNumber = pageNumber;
        if (isNaN(pageNumber)) {
            newPageNumber = pageNumber === 'previous' ? this.page - 1 : pageNumber === 'next' ? this.page + 1 : pageNumber;
            if (isNaN(newPageNumber)) {
                return;
            }
        }
        if (newPageNumber < 1) {
            newPageNumber = 1;
        }
        if (newPageNumber > this.pages.length) {
            newPageNumber = this.pages.length;
        }
        if (newPageNumber !== this.page) {
            this.pageChanged.emit(newPageNumber);
            this.page = newPageNumber;
        }
        this.saveState();
        this.setupPaging();
    }
    setRowHighlight(event, turnOff = false) {
        // show row highlight/selected when sr-only button is focused
        this.tableScroller.nativeElement.querySelectorAll('tr.focused').forEach(frow => frow.classList.remove('focused'));
        if (!turnOff) {
            const row = event.currentTarget.closest('tr');
            row.classList.add('focused');
        }
    }
    doSearch(searchTerm) {
        this.searchTerm = searchTerm && typeof searchTerm === 'string' ? searchTerm : '';
        const searchEmit = { searchTerm: this.searchTerm };
        if (this.searchTerm === '') {
            this.searchTermPartsUC = [];
        }
        this.clearSearchHighlights();
        this.saveState();
        if (!this._externalSearchAndFilter) {
            this.filterData();
            searchEmit['filteredData'] = this.removeTableRowDataFromList(this.filteredData);
        }
        this.searched.emit(searchEmit);
    }
    onFilterChange(selectedOptions, filter) {
        if (!this.buildingFilters) {
            this.updateFilterOptions(selectedOptions, filter);
            this.saveState();
            if (!this._externalSearchAndFilter) {
                this.filterData();
            }
            this.emitFilters();
        }
    }
    updateFilterOptions(selectedOptions, filter) {
        // add or remove filter in active filters list
        if (selectedOptions.length) {
            if (filter.type === TableFilterType.DATE_RANGE) {
                // convert dates to integers, eliminates timestamp & timezone issues (until we have a time filter)
                filter._value = [this.dateStringToInt(selectedOptions[0]), this.dateStringToInt(selectedOptions[1])];
            }
            this.activeFilters[filter.propertyName] = selectedOptions;
        }
        else {
            delete this.activeFilters[filter.propertyName];
        }
        this.hasActiveFilters = Object.keys(this.activeFilters).length > 0;
    }
    clearAllFilters() {
        this.clearFilterState();
        this.saveState();
        this.filteredData = this._data;
        this.updateTableControls();
        this.emitFilters();
    }
    prepData() {
        this._data = [];
        this.filteredData = [];
        if (!this.data?.length || !this.columns?.length) {
            return;
        }
        this.hasActionsColumn = this.actions?.length > 0;
        const setBulkActions = this.bulkActions?.length;
        let hasActiveBulkActions = false;
        this.data.forEach((oRow) => {
            const rowData = new TableRowData();
            const row = Object.assign({}, oRow);
            if (this.hasActionsColumn) {
                rowData.hasRowActions = this.hasRowActions(oRow);
            }
            if (setBulkActions) {
                rowData.bulkActions = this.getBulkActions(oRow);
                if (rowData.bulkActions?.length) {
                    hasActiveBulkActions = true;
                }
            }
            row['_tData'] = rowData;
            const searchValues = [];
            // run format & sort functions to create table content
            this.columns.forEach(column => {
                const rowColumnData = rowData[column.propertyName] = {};
                let cellContent = this.getCellContent(oRow, column);
                rowColumnData.formatted = cellContent;
                // Set tooltip content now so it's ready to be included in the searchValues
                if (column.toolTipFn) {
                    rowColumnData.tooltip = (column.toolTipFn(oRow[column.propertyName], oRow, column) || '').trim();
                }
                if (this.showSearchAndFilter) {
                    // If the column is searchable, add both the column search text and the tooltip to searchValues
                    if (!this._externalSearchAndFilter && column.searchable !== false) {
                        const columnSearchText = cellContent.searchText || `${cellContent.text || ''} ${cellContent.subtext || ''}`.trim();
                        if (columnSearchText) {
                            searchValues.push(columnSearchText);
                        }
                        if (rowColumnData.tooltip) {
                            searchValues.push(rowColumnData.tooltip);
                        }
                    }
                    if (!this._externalSearchAndFilter && column.filterable && column.displayName) {
                        if (column.date) {
                            const value = DateUtils.getLocalDateFormatString(DateUtils.parseFIDate(oRow[column.propertyName]), globalSettings.fiTimeZone, 'YYYYMMDD');
                            rowColumnData.filterValue = value ? parseInt(value, 10) : null;
                        }
                        else {
                            rowColumnData.filterValue = Array.isArray(oRow[column.propertyName])
                                ? oRow[column.propertyName]
                                : cellContent.searchText || cellContent.text || '';
                        }
                    }
                }
                if (!this.externalSortAndPaging && column.sortFn) {
                    // need top-level, unique id for fast/easy array-sort
                    row[this.sortKeyPrefix + column.propertyName] = column.sortFn(oRow[column.propertyName], oRow, column);
                }
                if (column.templateContextFn) {
                    // create & store context object for template
                    rowColumnData.templateContext = column.templateContextFn(oRow[column.propertyName], oRow, column);
                    if (rowColumnData.templateContext?.searchText) {
                        searchValues.push(rowColumnData.templateContext.searchText);
                    }
                }
            });
            if (!this._externalSearchAndFilter && this.showSearchAndFilter) {
                this.searchableProps?.forEach(prop => {
                    const searchableValue = oRow[prop] || '';
                    if (searchableValue) {
                        if (typeof searchableValue === 'string') {
                            searchValues.push(searchableValue);
                        }
                        else if (typeof searchableValue === 'number') {
                            searchValues.push(searchableValue.toString());
                        }
                        else if (Array.isArray(searchableValue)) {
                            searchValues.push(searchableValue.join(', '));
                        }
                    }
                });
                // Join search values with whitespace. This, combined with splitting the search term on whitespace, prevents
                // a search term like "123" from matching on two distinct values "12" and "3" combined together.
                rowData.searchText = searchValues.join(' ').toUpperCase() || '';
            }
            this._data.push(row);
        });
        this.filteredData = this._data;
        if (hasActiveBulkActions) {
            // bulk actions require the checkbox column
            this.showCheckbox = true;
        }
    }
    getCellContent(row, column) {
        let content = new TableCellContent();
        Object.assign(content, row[column.propertyName]);
        const rawCellData = row[column.propertyName];
        if (column.formatFn) {
            const formatVal = column.formatFn(rawCellData, row, column) || '';
            content = typeof formatVal === 'string' ? { text: formatVal } : formatVal;
        }
        else if (column.date) {
            content = { text: DateUtils.getLocalDateFormatString(DateUtils.parseFIDate(rawCellData), globalSettings.fiTimeZone, column.dateFormat || 'MM/DD/YYYY') };
        }
        else if (Array.isArray(rawCellData)) {
            content = { text: rawCellData.join(', ') };
        }
        else {
            const type = typeof rawCellData;
            if (type === 'number') {
                content = { text: rawCellData.toString() };
            }
            else if (type === 'string') {
                content = { text: rawCellData };
            }
            else if (type === 'boolean') {
                const booleanAsText = rawCellData ? this.text.trueLabel : this.text.falseLabel;
                content = { text: booleanAsText };
            }
        }
        if (content.html) {
            content.html = SanitizationUtils.allowRichTextOnly(content.html);
            if (!this._externalSearchAndFilter && column.searchable !== false) {
                content.searchText = content.searchText || SanitizationUtils.allowTextOnly(content.html);
            }
        }
        return content;
    }
    setupFilters() {
        this.buildingFilters = true;
        // create filters & options
        const filters = [];
        this.columns?.filter(col => col.filterable && col.displayName).forEach(col => {
            filters.push(this.createFilterOptions(col));
        });
        // set filter values
        filters.forEach(filter => {
            let checkedOptions = [];
            if (filter.type === TableFilterType.DATE_RANGE) {
                if (this.activeFilters[filter.propertyName] && this.activeFilters[filter.propertyName].length === 2) {
                    checkedOptions = this.activeFilters[filter.propertyName];
                }
            }
            else {
                if (this.hasState) { // if user has saved options, use those only
                    checkedOptions = this.activeFilters[filter.propertyName]?.filter(opt => filter.options.map(o => o.value).includes(opt)) || [];
                }
                else {
                    checkedOptions = filter.options.filter(opt => opt.checked).map(opt => opt.value);
                }
            }
            this.updateFilterOptions(checkedOptions, filter);
        });
        this.filters = filters;
        // let filter pickers render & emit their default states before continuing
        this.changeDetector.detectChanges();
        this.buildingFilters = false;
    }
    setupSortAndPaging() {
        this.resultCount = this.externalSortAndPaging ? this.resultCount : this.filteredData?.length || 0;
        if (this.showPageControls) {
            const formattedResultCount = NumberUtils.formatNumber(this.resultCount);
            this.pageSizeText = format(this.text.pageSizeText, { resultCount: formattedResultCount });
        }
        // Set up sort column and direction
        // doSort calls setupPaging internally, so do one or the other
        if (!this.externalSortAndPaging && this.filteredData && this.sortColumn && this.columns.some(c => c._tData.sortName === this.sortColumn)) {
            this.doSort(false);
        }
        else {
            this.setupPaging();
        }
    }
    setupPaging() {
        if (this.showPageControls) {
            let pageArr = [];
            if (this.resultCount && this.pageSize) {
                pageArr = Array(Math.ceil(this.resultCount / this.pageSize)).fill(1).map((x, y) => x + y);
                if (pageArr.length > 0 && this.page > pageArr.length) {
                    this.page = pageArr.length;
                }
            }
            this.pages = pageArr;
            const pageInd = (this.page - 1) * this.pageSize;
            const maxEnd = pageInd + this.pageSize;
            const end = maxEnd > this.resultCount ? this.resultCount : maxEnd;
            const prePage = this.filteredData ? this.filteredData.slice(pageInd, end) : [];
            this.setDisplayPages();
            this.dataPage = !this.externalSortAndPaging ? prePage : this.filteredData;
        }
        else {
            this.dataPage = this.filteredData;
        }
        this.setSearchHighlight();
    }
    setDisplayPages() {
        const pageMax = this.isMobile ? 5 : 9;
        const pageDisplayCount = (pageMax - 1) / 2;
        // we want to keep the page selected centered in the list of numbers
        // unless it's in first 3 for mobile, or 5 for desktop
        let start = this.page - pageDisplayCount;
        let end = 0;
        let size = 0;
        // if it's in the first few numbers, we need to extend the end out so
        // we always have the same amount of numbers displayed for UI/UX consistency
        if (start < 1) {
            end = Math.abs(start) + 1;
            start = 1;
        }
        if (!this.pages || this.pages.length < pageMax) {
            start = 1;
        }
        end += this.page + pageDisplayCount;
        // make sure we don't display numbers after the last page available
        if (this.pages && end > this.pages.length) {
            if (this.pages.length > pageMax) {
                start -= Math.abs(end - this.pages.length);
            }
            else {
                start = 1;
            }
            end = this.pages.length;
        }
        size = !this.pages ? 0 : this.pages.length < pageMax ? this.pages.length : pageMax;
        this.dataPageList = Array(size).fill(1).map((x, y) => x + y + (start - 1));
    }
    getSortColumnName(column) {
        return column.sortColumnName ? column.sortColumnName : column.sortFn ? (this.sortKeyPrefix + column.propertyName) : column.propertyName;
    }
    doSort(resetCurrentPage) {
        this.filteredData = ArrayUtils.sortByField(this.filteredData, this.sortColumn, this.sortDirection === TableSortDirection.DESCENDING);
        if (resetCurrentPage) {
            this.page = 1;
        }
        this.setupPaging();
    }
    setupColumns() {
        let clickableRows = false;
        this.columns.forEach(col => {
            const colData = { wrapClass: '' };
            if (col.displayName) {
                if (col.displayName.constructor.name === 'String') {
                    colData.text = col.displayName;
                }
                else if (col.displayName instanceof TableCellContent && col.displayName.html) {
                    col.displayName.html = SanitizationUtils.allowRichTextOnly(col.displayName.html);
                }
                if (col.sortable) {
                    colData.sortLabel = format(this.text.ariaSortLabel, { columnName: col.displayName['text'] || col.displayName });
                    colData.sortName = this.getSortColumnName(col);
                }
            }
            if (col.width) {
                colData.width = col.width === 'max' ? '100%' : col.width === 'min' ? MIN_COL_WIDTH : col.width;
            }
            if (col.columnTemplate) {
                colData.template = typeof col.columnTemplate === 'string' ? this.tableTemplatesService.get(col.columnTemplate) : col.columnTemplate;
            }
            if (col.wrap) {
                colData.wrapClass = col.wrap === 'force' ? 'text-break' : col.wrap === 'none' ? 'text-nowrap' : '';
            }
            col._tData = colData;
            if (col.clickable) {
                if (clickableRows) {
                    // We already found a clickable column, this is bad data.
                    col.clickable = false;
                }
                else {
                    clickableRows = true;
                }
            }
        });
        this.clickable = clickableRows;
        if (this.actionsColumnFixedWidth !== MIN_COL_WIDTH) {
            // we always 'min' the actions column, so custom width needs to be a min-width
            this.actionsColMinWidth = this.actionsColumnFixedWidth;
        }
    }
    hasRowActions(row) {
        return this.actions?.some(action => !action.visible || action.visible(row));
    }
    getBulkActions(row) {
        return this.bulkActions?.filter(action => !action.visible || action.visible(row));
    }
    createFilterOptions(col) {
        const filterControl = new ColumnFilterControl();
        filterControl.label = col.displayName['text'] || col.displayName;
        filterControl.propertyName = col.propertyName;
        if (col.filterOptions) {
            const options = col.filterOptions;
            options.map(option => option.label = option.label || option.value);
            filterControl.options = options;
        }
        else if (col.date) {
            let min;
            let max;
            this.filteredData.forEach(row => {
                const value = row._tData[col.propertyName].filterValue;
                if (value) {
                    min = min ? Math.min(min, value) : value;
                    max = max ? Math.max(max, value) : value;
                }
            });
            // using min/max dateValues to prevent invalid dates/data from skewing the rangeAllowed
            filterControl.rangeAllowed = [
                DateUtils.parseFIDateFormat(Math.max(min, this.minDateValue).toString(), 'YYYYMMDD'),
                DateUtils.parseFIDateFormat(Math.min(max, this.maxDateValue).toString(), 'YYYYMMDD')
            ];
            filterControl.type = TableFilterType.DATE_RANGE;
        }
        else if (!this._externalSearchAndFilter) {
            let filterOptions = new Set();
            this.filteredData.forEach(row => {
                const filterValue = row._tData[col.propertyName].filterValue;
                let text = null;
                if (!filterValue && filterValue !== 0) {
                    text = col.allowBlankFilter ? `(No ${col.displayName})` : null;
                }
                else {
                    text = row._tData[col.propertyName].filterValue;
                }
                if (text && Array.isArray(text)) {
                    text.forEach(option => filterOptions.add(option));
                }
                else if (text) {
                    filterOptions.add(text);
                }
            });
            const sortedOptions = [...filterOptions].sort((a, b) => a.toLowerCase().localeCompare(b.toLowerCase()));
            filterControl.options = sortedOptions.map(opt => ({ label: opt, value: opt !== `(No ${col.displayName})` ? opt : '' }));
        }
        return filterControl;
    }
    filterData() {
        this.searchTermPartsUC = [];
        let filteredData = this._data;
        let hasSearchTermParts = false;
        if (this.searchTerm.length > 0) {
            // Clone the searchTerm string using string interpolation, then trim it. Since searchTerm is bound back to the
            // search input, the .trim() call was modifying the value and removing spaces unexpectedly.
            this.searchTermPartsUC = `${this.searchTerm}`.trim().toUpperCase().split(/\s+/);
            hasSearchTermParts = this.searchTermPartsUC.length > 0;
        }
        if (!this._externalSearchAndFilter && (this.hasActiveFilters || hasSearchTermParts)) {
            const filteredRows = [];
            this._data.forEach((row) => {
                let filterResult = true;
                if (this.hasActiveFilters) {
                    // needs to pass all filters
                    filterResult = Object.keys(this.activeFilters).every(columnName => {
                        const filterValue = row._tData[columnName].filterValue;
                        if (this.isDateRangeFilter(columnName)) {
                            const dateValue = this.filters.find(f => f.propertyName === columnName)._value;
                            return dateValue && filterValue >= dateValue[0] && filterValue <= dateValue[1];
                        }
                        return Array.isArray(filterValue)
                            ? filterValue.some(arr => this.activeFilters[columnName].includes(arr))
                            : this.activeFilters[columnName].includes(filterValue);
                    });
                }
                let searchResult = true;
                if (hasSearchTermParts) {
                    if (row._tData.searchText) {
                        // Must match on all search term parts
                        searchResult = this.searchTermPartsUC.every(part => row._tData.searchText.includes(part));
                    }
                    else {
                        // There's no searchable text for this row, so return false
                        searchResult = false;
                    }
                }
                if (filterResult && searchResult) {
                    filteredRows.push(row);
                }
            });
            filteredData = filteredRows;
        }
        this.filteredData = filteredData;
        this.updateTableControls();
    }
    isDateRangeFilter(columnName) {
        return this.filters.find(f => f.propertyName === columnName)?.type === TableFilterType.DATE_RANGE;
    }
    updateTableControls() {
        this.setupSortAndPaging();
        if (this.showCheckbox) {
            if (this.bulkActionRows.length) {
                // update checked states after bulk action
                this.handleChecked();
            }
            else {
                // need to check "Select All" state after search/filter
                this.checkForSelectAll();
            }
        }
        // need to setScrollState, but Angular wants a render cycle before it can measure new DOM - DEV-47974
        this.ngZone.runOutsideAngular(() => {
            setTimeout(() => this.setScrollState());
        });
    }
    handleChecked() {
        this.checkForSelectAll();
        const selectedRows = this._data?.filter(row => row._tData.checked);
        if (this.bulkActions?.length) {
            this.bulkActionRows = selectedRows;
            this.bulkActionsSelectedLabel = format(this.text.bulkActionsSelectedLabel, { numItems: selectedRows.length });
            let commonActions = this.bulkActions;
            if (selectedRows.length) {
                // find all actions shared by selected rows
                const sharedActions = Object.values(selectedRows).reduce((initial, row) => {
                    return new Set(row._tData.bulkActions.filter(i => initial.has(i)));
                }, new Set(selectedRows[0]._tData.bulkActions));
                commonActions = Array.from(sharedActions);
            }
            this.bulkActionsVisible = commonActions;
        }
        if (selectedRows.length) {
            this.rowChecked.emit(this.removeTableRowDataFromList(selectedRows));
        }
    }
    checkForSelectAll() {
        this.isSelectAllChecked = this.filteredData.every(row => row._tData.checked);
    }
    setScrollState() {
        const wrapper = this.tableScroller?.nativeElement;
        if (wrapper) {
            let scrollLeftComplete = true;
            let scrollRightComplete = true;
            let scrollable = wrapper.scrollWidth > wrapper.clientWidth;
            if (scrollable && this.stickyColumns !== TableStickyColumnConfig.NONE) {
                if (this.stickyColumns !== TableStickyColumnConfig.LAST) {
                    const scrollMax = wrapper.clientWidth + Math.ceil(wrapper.scrollLeft);
                    scrollRightComplete = scrollMax >= wrapper.scrollWidth;
                }
                if (this.stickyColumns !== TableStickyColumnConfig.FIRST) {
                    scrollLeftComplete = wrapper.scrollLeft === 0;
                }
            }
            this.scrollable = scrollable;
            this.scrollLeftComplete = scrollLeftComplete;
            this.scrollRightComplete = scrollRightComplete;
            this.changeDetector.detectChanges();
        }
    }
    removeTableRowData(row) {
        let cleanRow = { ...row };
        delete cleanRow._tData;
        const sortKeys = Object.keys(cleanRow).filter(key => key.startsWith(this.sortKeyPrefix));
        sortKeys.forEach(key => {
            delete cleanRow[key];
        });
        return cleanRow;
    }
    removeTableRowDataFromList(rows) {
        return rows.map(row => this.removeTableRowData(row));
    }
    emitFilters() {
        const filterEmit = { filters: [], searchTerm: this.searchTerm };
        if (this.hasActiveFilters) {
            const filters = Object.keys(this.activeFilters).map(column => {
                const event = new TableFilter();
                event.criteria = column;
                event.activeFilters = this.activeFilters[column];
                const currentFilter = this.filters.find(filter => filter.propertyName === column);
                event.allSelected = currentFilter.options?.length === this.activeFilters[column].length;
                event.noneSelected = false;
                return event;
            });
            filterEmit.filters = filters;
            if (!this._externalSearchAndFilter) {
                filterEmit['filteredData'] = this.removeTableRowDataFromList(this.filteredData);
            }
        }
        else {
            // no active filters, emit all data
            if (!this._externalSearchAndFilter) {
                filterEmit['filteredData'] = this._data;
            }
        }
        this.filtersChanged.emit(filterEmit);
    }
    saveState(onNav = false) {
        if (this.tableStateId || this.keepStateOnUpdate) {
            let tableState = new TableState();
            tableState.searchTerm = this.searchTerm;
            tableState.pageSize = this.pageSize;
            tableState.currentPage = this.page;
            tableState.sortColumn = this.sortColumn;
            tableState.sortDirection = this.sortDirection;
            tableState.filters = this.activeFilters;
            this.tableState = tableState;
            if (this.tableStateId && onNav) {
                this.tableStateService.saveState(this.tableStateId, tableState, this.tableStateParam);
            }
        }
    }
    restoreState(currentChanges) {
        let tableState;
        if (this.tableState) {
            tableState = this.tableState;
        }
        else if (this.tableStateId) {
            tableState = this.tableStateService.getState(this.tableStateId, this.tableStateParam);
        }
        if (tableState) {
            this.hasState = true;
            this.page = currentChanges.page?.currentValue ?? tableState.currentPage;
            this.pageSize = currentChanges.pageSize?.currentValue ?? tableState.pageSize ?? this.initPageSize;
            this.sortColumn = currentChanges.sortColumn?.currentValue ?? tableState.sortColumn;
            this.sortDirection = currentChanges.sortDirection?.currentValue ?? tableState.sortDirection;
            this.searchTerm = tableState.searchTerm;
            this.activeFilters = tableState.filters;
            this.hasActiveFilters = Object.keys(tableState.filters).length > 0;
        }
    }
    resetState() {
        this.clearFilterState();
        this.page = 1;
        this.pageSize = this.initPageSize;
        this.sortColumn = '';
        this.sortDirection = TableSortDirection.ASCENDING;
        this.hasState = false;
    }
    clearFilterState() {
        this.activeFilters = {};
        this.hasActiveFilters = false;
        this.searchTerm = '';
        this.searchTermPartsUC = [];
    }
    setSearchHighlight(isRetry = false) {
        this.clearSearchHighlights();
        if (this.searchTermPartsUC.length > 0) {
            if (this.tableScroller?.nativeElement) {
                // ensure filtered rows have rendered before searching
                this.changeDetector.detectChanges();
                const ranges = this.getSearchTextRanges();
                // Create a Highlight object & set it in the registry
                // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                // @ts-ignore
                CSS.highlights.set('search-highlight', new Highlight(...ranges));
            }
            else if (!isRetry) {
                // on nav restoreState, nativeElement might not be ready yet, retry once after a tick
                this.ngZone.runOutsideAngular(() => {
                    setTimeout(() => this.setSearchHighlight(true));
                });
            }
        }
    }
    getSearchTextRanges() {
        // get all text nodes from the tbody, filter for searchable cells & ignore '.no-highlight' nodes
        const treeWalker = document.createTreeWalker(this.tableScroller.nativeElement.querySelector('tbody'), NodeFilter.SHOW_TEXT, {
            acceptNode: (node) => {
                const cell = node.parentNode.closest('td');
                if (cell && cell.className.indexOf('searchable') > -1) {
                    // some elements may contain text, but shouldn't be highlighted, (icons, sr-only, etc...)
                    if (node.parentNode.className.indexOf('no-highlight') > -1) {
                        return NodeFilter.FILTER_REJECT;
                    }
                    return NodeFilter.FILTER_ACCEPT;
                }
                return NodeFilter.FILTER_REJECT;
            }
        });
        const searchableTextNodesUC = [];
        let currentNode = treeWalker.nextNode();
        while (currentNode) {
            searchableTextNodesUC.push({ node: currentNode, textUC: currentNode.textContent.toUpperCase() });
            currentNode = treeWalker.nextNode();
        }
        // search for every term part in every node
        return [...this.searchTermPartsUC].map(termUC => this.searchNodesForTerm(termUC, searchableTextNodesUC)).flat();
    }
    searchNodesForTerm(termUC, searchableTextNodesUC) {
        return searchableTextNodesUC
            .map(({ node, textUC }) => {
            const indices = [];
            let startPos = 0;
            while (startPos < textUC.length) {
                const index = textUC.indexOf(termUC, startPos);
                if (index === -1) {
                    break;
                }
                indices.push(index);
                startPos = index + termUC.length;
            }
            // Create a range object for each instance of text found
            return indices.map(index => {
                const range = new Range();
                range.setStart(node, index);
                range.setEnd(node, index + termUC.length);
                return range;
            });
        })
            .flat();
    }
    clearSearchHighlights() {
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        CSS.highlights.clear();
    }
    dateStringToInt(dateString) {
        const dateParts = dateString.split('/');
        return parseInt(dateParts[2] + dateParts[0] + dateParts[1], 10);
    }
    getDefaultText() {
        return {
            actionsMenuLabel: 'Actions',
            ariaRowClick: 'Select Row',
            ariaSortLabel: 'Sort By {{ columnName }}',
            bulkActionsSelectedLabel: '{{ numItems }} Selected',
            bulkNoCommonActionsLabel: 'No common actions',
            checkAllLabel: 'Check All Rows',
            checkRowLabel: 'Check This Row',
            clearFiltersButtonLabel: 'Clear All',
            multiSelectSearchPlaceholderPrefix: 'Search',
            noResultsText: 'No Results',
            pageSizeLabel: 'Showing',
            pageSizeText: 'at a time of {{ resultCount }}',
            pageNextButtonLabel: 'Next',
            pagePreviousButtonLabel: 'Previous',
            clearCheckedItemsButtonLabel: 'Clear All',
            trueLabel: 'True',
            falseLabel: 'False',
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TableComponent, deps: [{ token: TableStateService }, { token: TableTemplatesService }, { token: i2.WindowService }, { token: i0.ChangeDetectorRef }, { token: i0.NgZone }, { token: i2.TextService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.17", type: TableComponent, isStandalone: false, selector: "ui-workflows-table", inputs: { externalSortAndPaging: "externalSortAndPaging", externalSearchAndFilter: "externalSearchAndFilter", actions: "actions", actionsColumnFixedWidth: "actionsColumnFixedWidth", bulkActions: "bulkActions", columns: "columns", data: "data", searchableProps: "searchableProps", e2e: "e2e", emptyText: "emptyText", gridLines: "gridLines", page: "page", pageSize: "pageSize", pageSizes: "pageSizes", resultCount: "resultCount", searchTerm: "searchTerm", showCheckbox: "showCheckbox", showColumnHeaders: "showColumnHeaders", showPageControls: "showPageControls", showSearchAndFilter: "showSearchAndFilter", searchFullWidth: "searchFullWidth", sortColumn: "sortColumn", sortDirection: "sortDirection", stickyColumns: "stickyColumns", striped: "striped", tableActionProcessingProp: "tableActionProcessingProp", tableStateId: "tableStateId", tableStateParam: "tableStateParam", keepStateOnUpdate: "keepStateOnUpdate", title: "title", subtitle: "subtitle", badges: "badges", headerActions: "headerActions", pageActionsMenuIcon: "pageActionsMenuIcon", pageActionsMenuText: "pageActionsMenuText" }, outputs: { rowClicked: "rowClicked", tableAction: "tableAction", rowChecked: "rowChecked", filtersChanged: "filtersChanged", pageChanged: "pageChanged", pageSizeChanged: "pageSizeChanged", searched: "searched", sorted: "sorted" }, viewQueries: [{ propertyName: "tableScroller", first: true, predicate: ["tableScroller"], descendants: true }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "@if (title || subtitle || headerActions?.length > 0 || badges?.length > 0) {\n    <div class=\"d-flex\">\n        <div *ngIf=\"title || subtitle || badges?.length > 0\" class=\"table-title\">\n            <div *ngIf=\"title || subtitle\">\n                <span *ngIf=\"title\" class=\"text-strong\" role=\"heading\" aria-level=\"3\">{{ title }}</span>\n                <span *ngIf=\"subtitle\" [class.ml-1]=\"title\">{{ subtitle }}</span>\n            </div>\n            <div *ngIf=\"badges?.length > 0\" class=\"d-flex align-items-center\">\n                <ui-core-badge-list [items]=\"badges\" [marginTop]=\"false\"></ui-core-badge-list>\n            </div>\n        </div>\n        <div *ngIf=\"headerActions?.length > 0\" class=\"ml-auto\">\n            <ui-core-page-actions \n                [actions]=\"headerActions\" [withinModal]=\"true\"\n                [moreMenuIcon]=\"pageActionsMenuIcon\" \n                [moreMenuButtonText]=\"pageActionsMenuText\">\n            </ui-core-page-actions>\n        </div>\n    </div>\n}\n\n<div *ngIf=\"templatesReady && (resultCount !== 0 || showSearchAndFilter)\"\n    [ngClass]=\"['table-container mb-2', stickyClass]\" [class.scroll-left-complete]=\"scrollLeftComplete\" [class.scroll-right-complete]=\"scrollRightComplete\">\n    <div *ngIf=\"showSearchAndFilter\" class=\"table-filter-controls\">\n        <ui-forms-search-input [value]=\"searchTerm\" (change)=\"doSearch($event)\" [class.full-width]=\"isMobile || searchFullWidth\" [e2e]=\"e2e\" />\n        @for (filter of filters; track filter.propertyName) {\n            <ui-forms-multi-select-picker\n                *ngIf=\"filter.type !== TableFilterType.DATE_RANGE\"\n                [label]=\"filter.label\"\n                theme=\"primary\"\n                [options]=\"filter.options\"\n                display=\"label\"\n                [searchPlaceholder]=\"text.multiSelectSearchPlaceholderPrefix + ' ' + filter.label\"\n                [value]=\"activeFilters[filter.propertyName] || []\"\n                (change)=\"onFilterChange($event, filter)\" />\n            <ui-forms-date-range\n                *ngIf=\"filter.type === TableFilterType.DATE_RANGE\"\n                [label]=\"filter.label\"\n                display=\"selection\"\n                theme=\"primary\"\n                [minDate]=\"filter.rangeAllowed[0]\"\n                [maxDate]=\"filter.rangeAllowed[1]\"\n                [value]=\"activeFilters[filter.propertyName] || []\"\n                (change)=\"onFilterChange($event, filter)\" />\n        }\n        <ui-core-button *ngIf=\"hasActiveFilters\" [message]=\"text.clearFiltersButtonLabel\" icon=\"close\" theme=\"link\" buttonClass=\"clear-btn\" (click)=\"clearAllFilters()\"></ui-core-button>\n    </div>\n    <div #tableScroller class=\"table-scroller\" [class.sticky]=\"!!stickyColumns\" [class.scrollable]=\"scrollable\" (scroll)=\"scrollable && onScroll()\">\n        <table [class.striped]=\"striped\" [class.grid-lines]=\"gridLines\" role=\"grid\" [attr.data-e2e]=\"e2e\">\n            <thead *ngIf=\"showColumnHeaders && resultCount !== 0\">\n                <tr>\n                    <th *ngIf=\"showCheckbox\" class=\"check-cell\" [class.sticky]=\"firstColFixed\" [attr.width]=\"MIN_COL_WIDTH\">\n                        <div class=\"sticky-shadow\"></div>\n                        <ui-forms-checkbox (click)=\"onSelectAll($event)\" [isChild]=\"true\"\n                            [checked]=\"isSelectAllChecked\" [label]=\"text.checkAllLabel\" [hideLabel]=\"true\" class=\"checkbox-all-selector\"\n                        ></ui-forms-checkbox>\n                    </th>\n                    @for (column of columns; track $index; let first = $first; let last = $last) {\n                        <th [style.min-width.px]=\"column.minWidth\"\n                            [style.width]=\"column._tData.width\"\n                            [attr.width]=\"column._tData.width\"\n                            [class.sortable]=\"column._tData.sortName\"\n                            [class.sticky]=\"(first && firstColContent) || (last && lastColContent)\"\n                            (click)=\"sortOnColumn(column)\">\n                            <div class=\"sticky-shadow\"></div>\n                            <div [ngClass]=\"['d-flex align-items-center', column.align ? 'column-' + column.align : '']\">\n                                <div [ngClass]=\"['column-label text-caption text-semibold', column._tData.wrapClass, column.headerClass || '']\">\n                                    @if (column._tData.sortName) {\n                                        <ui-core-clickable [attr.aria-label]=\"column._tData.sortLabel\" buttonClass=\"text-caption text-semibold\">\n                                            <ng-container [ngTemplateOutlet]=\"cellTemplate\" [ngTemplateOutletContext]=\"{ content: column._tData.text ? column._tData : column.displayName }\" />\n                                        </ui-core-clickable>\n                                        <i *ngIf=\"sortColumn === column._tData.sortName\" class=\"material-icons text-base\">\n                                            {{ sortDirection === TableSortDirection.ASCENDING ? 'expand_less' : 'expand_more' }}\n                                        </i>\n                                    } @else {\n                                        <ng-container [ngTemplateOutlet]=\"cellTemplate\" [ngTemplateOutletContext]=\"{ content: column._tData.text ? column._tData : column.displayName || '' }\" />\n                                    }\n                                </div>\n                            </div>\n                        </th>\n                    }\n                    <th *ngIf=\"hasActionsColumn\" [class.sticky]=\"lastColFixed\" [attr.width]=\"MIN_COL_WIDTH\" [style.min-width]=\"actionsColMinWidth\">\n                        <div *ngIf=\"lastColFixed\" class=\"sticky-shadow\"></div>\n                    </th>\n                </tr>\n            </thead>\n            <tbody *ngIf=\"resultCount !== 0\">\n                @for (item of dataPage; track $index; let i = $index) {\n                    <tr (click)=\"rowClick(item, $event)\" [class.clickable]=\"clickable\" [attr.data-e2e]=\"e2e+'-row-'+i\">\n                        <td *ngIf=\"showCheckbox\" class=\"check-cell\" [class.sticky]=\"firstColFixed\">\n                            <div class=\"sticky-shadow\"></div>\n                            <ui-forms-checkbox (click)=\"onSelectRow(item)\" [isChild]=\"true\"\n                                [checked]=\"item._tData.checked\" [label]=\"text.checkRowLabel\" [hideLabel]=\"true\" class=\"checkbox-selector\"></ui-forms-checkbox>\n                        </td>\n                        @for (column of columns; track $index; let first = $first; let last = $last) {\n                            <td [ngClass]=\"['table-column', column._tData.wrapClass, column.contentClass || '', column.align ? 'column-' + column.align : '']\"\n                                [class.searchable]=\"column.searchable !== false\" [class.sticky]=\"(first && firstColContent) || (last && lastColContent)\">\n                                <div class=\"sticky-shadow\"></div>\n                                @if (column.clickable) {\n                                    <ng-container [ngTemplateOutlet]=\"clickableButtonTemplate\" [ngTemplateOutletContext]=\"{ message: item._tData[column.propertyName]?.formatted?.text || item[column.propertyName] }\" />\n                                } @else {\n                                    @if (item._tData[column.propertyName]?.tooltip) {\n                                        <span placement=\"top auto\" [ngbTooltip]=\"item._tData[column.propertyName]?.tooltip\" container=\"body\">\n                                            <ng-container [ngTemplateOutlet]=\"dynamicCellTemplate\" [ngTemplateOutletContext]=\"{ column, item }\" />\n                                            <span class=\"sr-only no-highlight\">{{ item._tData[column.propertyName]?.tooltip }}</span>\n                                        </span>\n                                    } @else {\n                                        <ng-container [ngTemplateOutlet]=\"dynamicCellTemplate\" [ngTemplateOutletContext]=\"{ column, item }\" />\n                                    }\n                                }\n                            </td>\n                        }\n                        <td *ngIf=\"hasActionsColumn\" class=\"action-col\" [class.sticky]=\"lastColFixed\">\n                            <div class=\"sticky-shadow\"></div>\n                            <ui-core-spinner *ngIf=\"tableActionProcessingProp && item[tableActionProcessingProp]\" class=\"pt-3\"></ui-core-spinner>\n                            <ui-workflows-table-actions *ngIf=\"hasActionsColumn && (!tableActionProcessingProp || !item[tableActionProcessingProp]) && item._tData.hasRowActions\"\n                                [menuTitle]=\"text.actionsMenuLabel\" [actions]=\"actions\" [item]=\"item\" (tableAction)=\"doTableAction(item, $event)\"></ui-workflows-table-actions>\n                        </td>\n                    </tr>\n                }\n            </tbody>\n            <tbody *ngIf=\"resultCount === 0\">\n                <tr><td [attr.colspan]=\"columns?.length ? columns.length + 2 : 1\" class=\"empty-table p-5\">\n                    {{ emptyText }}\n                </td></tr>\n            </tbody>\n        </table>\n    </div>\n</div>\n\n<ui-workflows-bulk-actions *ngIf=\"bulkActionRows?.length > 0\"\n    [actions]=\"bulkActionsVisible\" [rowLabel]=\"bulkActionsSelectedLabel\" [emptyLabel]=\"text.bulkNoCommonActionsLabel\"\n    [clearAllLabel]=\"text.clearCheckedItemsButtonLabel\" (bulkAction)=\"doBulkTableAction($event)\" (allCleared)=\"onSelectAll(false)\" />\n\n<ng-template #dynamicCellTemplate let-column=\"column\" let-item=\"item\">\n    <ng-container *ngIf=\"!column._tData.template\"\n        [ngTemplateOutlet]=\"cellTemplate\" [ngTemplateOutletContext]=\"{ content: item._tData[column.propertyName].formatted || item[column.propertyName] }\" />\n    <ng-container *ngIf=\"column._tData.template\"\n        [ngTemplateOutlet]=\"column._tData.template\"\n        [ngTemplateOutletContext]=\"item._tData[column.propertyName]?.templateContext ? item._tData[column.propertyName]?.templateContext : { item, columnValue: item[column.propertyName] }\" />\n</ng-template>\n\n<ng-template #cellTemplate let-content=\"content\">\n    <div *ngIf=\"content.text\">{{ content.text }}</div>\n    <div *ngIf=\"content.subtext\" class=\"sub-text\">{{ content.subtext }}</div>\n    <div *ngIf=\"content.html\" [innerHTML]=\"content.html\"></div>\n</ng-template>\n\n<ng-template #clickableButtonTemplate let-message=\"message\">\n    <ui-core-button [message]=\"message\" theme=\"link\" buttonClass=\"table-clickable-link btn-wrap\" [ariaLabel]=\"text.ariaRowClick + ' ' + message\"\n        (focusin)=\"setRowHighlight($event)\" (focusout)=\"setRowHighlight($event, true)\">\n    </ui-core-button>\n</ng-template>\n\n<footer *ngIf=\"showPageControls\" class=\"mb-3\" [class.mobile]=\"isMobile\">\n    <div *ngIf=\"pageSizeOptions.length > 0 && resultCount > 0\" class=\"page-size\">\n        <ui-forms-picker (change)=\"$event && changePageSize($event)\" [options]=\"pageSizeOptions\" [value]=\"pageSize\" [label]=\"text.pageSizeLabel\" display=\"selection\"></ui-forms-picker>\n        <span class=\"pl-2\">{{ pageSizeText }}</span>\n    </div>\n    <div class=\"page-spacer\"></div>\n    <div *ngIf=\"dataPageList.length > 1\" class=\"page-nav\">\n        <ui-core-button \n            buttonClass=\"py-half px-2\"\n            class=\"pr-1\"\n            [disabled]=\"page === 1\"\n            icon=\"keyboard_arrow_left\"\n            [message]=\"text.pagePreviousButtonLabel\"\n            [showSpinner]=\"false\"\n            theme=\"link\"\n            (click)=\"changePage('previous')\">\n        </ui-core-button>\n        <div class=\"pages-wrapper\">\n            <ui-core-button \n                *ngFor=\"let displayPage of dataPageList\"\n                buttonClass=\"no-min-width py-half px-2\"\n                [message]=\"displayPage\"\n                [theme]=\"displayPage === page ? 'primary' : 'link'\"\n                (click)=\"changePage(displayPage)\">\n            </ui-core-button>\n        </div>\n        <ui-core-button \n            buttonClass=\"py-half px-2\"\n            class=\"pl-1\"\n            [disabled]=\"page === pages.length\"\n            icon=\"keyboard_arrow_right\"\n            iconPosition=\"right\"\n            [message]=\"text.pageNextButtonLabel\"\n            [showSpinner]=\"false\"\n            theme=\"link\"\n            (click)=\"changePage('next')\">\n        </ui-core-button>\n    </div>\n</footer>\n\n<ui-workflows-table-template-definitions *ngIf=\"!templatesReady\" />\n", styles: [".table-title{padding:12px 16px;display:flex;align-items:center;flex-wrap:wrap;row-gap:8px;column-gap:8px}.table-container{border:1px solid var(--color-stroke-1);border-radius:var(--containers-shape);transition:border-radius var(--transition-duration) var(--transition-timing);overflow:hidden;width:100%}.table-container.sticky-both:not(.scroll-right-complete),.table-container.sticky-first:not(.scroll-right-complete){border-bottom-right-radius:0;border-top-right-radius:0}.table-container.sticky-both:not(.scroll-left-complete),.table-container.sticky-last:not(.scroll-left-complete){border-bottom-left-radius:0;border-top-left-radius:0}.table-container:not(.sticky){display:table}.table-container .table-filter-controls{display:flex;flex-wrap:wrap;align-items:center;background-color:var(--color-gray-100);padding:8px 16px}.table-container .table-filter-controls ui-forms-search-input{width:300px;min-width:300px;margin:8px 16px 8px 0}.table-container .table-filter-controls ui-forms-search-input.full-width{width:100%;margin-right:0;min-width:0}.table-container .table-filter-controls ui-forms-multi-select-picker,.table-container .table-filter-controls ui-forms-date-range{margin:8px 12px 8px 0}.table-container .table-filter-controls ui-forms-multi-select-picker:last-child,.table-container .table-filter-controls ui-forms-date-range:last-child{margin-right:0}.table-scroller.scrollable{overflow-x:auto}.table-scroller.scrollable .sticky-shadow{box-shadow:0 0 8px #00000040}table{background-color:var(--color-default);border-collapse:separate;border-spacing:0;margin-bottom:0;height:100%;width:100%;position:relative}table th{color:var(--color-gray-900);font-weight:400;padding:12px 16px;border:none;vertical-align:bottom;background-color:var(--color-gray-100)}table th .sticky-shadow{background-color:var(--color-gray-100)}table th.sortable{cursor:pointer;padding-right:20px}table th.sortable .column-label{position:relative;padding-right:2px}table th.sortable .column-label button{color:var(--color-gray-900)}table th.sortable .column-label .material-icons{position:absolute;bottom:-4px;right:-16px}table th.check-cell{padding-bottom:2px;padding-right:6px}table td{font-size:var(--type-body2-size);padding:16px;border-top:1px solid var(--color-stroke-1);vertical-align:top}table td.action-col{padding-top:4px;text-align:right}table td.check-cell{padding-top:8px;padding-right:6px}table tr:first-of-type td{border-top:none}table.grid-lines td,table.grid-lines th{border-left:1px solid var(--color-stroke-1);border-top-color:var(--color-gray-100)}table.grid-lines td:first-child,table.grid-lines th:first-child{border-left:none}table th.sticky,table td.sticky{position:sticky;top:0;left:0;z-index:2;border-left-width:0;border-right-width:0;background-color:var(--color-default)}table th.sticky:first-of-type,table td.sticky:first-of-type{left:0}table th.sticky:first-of-type .sticky-shadow,table td.sticky:first-of-type .sticky-shadow{left:0;clip-path:inset(0px -8px 0px 0px)}table th.sticky:last-of-type,table td.sticky:last-of-type{right:0}table th.sticky:last-of-type .sticky-shadow,table td.sticky:last-of-type .sticky-shadow{right:0;clip-path:inset(0px 0px 0px -8px)}table th.sticky .sticky-shadow,table td.sticky .sticky-shadow{top:0;position:absolute;width:100%;height:100%}table th.sticky .column-label,table td.sticky .column-label{position:relative}table.striped tbody tr:nth-of-type(2n) td{background-color:var(--color-sunken)}table tbody tr.clickable:hover>td{cursor:pointer;background-color:var(--color-hover)}table tbody tr.clickable:hover>td.sticky{background-color:var(--color-default)}table tbody tr.clickable:hover>td.sticky .sticky-shadow{background-color:var(--color-hover);z-index:-1}table .empty-table{color:var(--color-gray-700);text-align:center}footer{display:flex;flex-wrap:wrap-reverse;justify-content:space-between;row-gap:var(--spacing-250)}footer .page-size{display:flex;align-items:center}footer .page-spacer{flex-grow:10}footer .page-nav{display:flex;align-items:center;flex-grow:1;justify-content:space-between}footer.mobile{flex-direction:column-reverse}footer.mobile .page-spacer{display:none}.column-left{text-align:left;justify-content:start;justify-items:left}.column-center{text-align:center;justify-content:center;justify-items:center}.column-right{text-align:right;justify-content:end;justify-items:right}:host-context(.using-keyboard) table tbody tr.clickable.focused>td{cursor:pointer;background-color:var(--color-hover)}:host-context(.using-keyboard) table tbody tr.clickable.focused>td.sticky{background-color:var(--color-default)}:host-context(.using-keyboard) table tbody tr.clickable.focused>td.sticky .sticky-shadow{background-color:var(--color-hover);z-index:-1}\n"], dependencies: [{ kind: "directive", type: i2$1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2$1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2$1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2$1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i5.NgbTooltip, selector: "[ngbTooltip]", inputs: ["animation", "autoClose", "placement", "popperOptions", "triggers", "positionTarget", "container", "disableTooltip", "tooltipClass", "tooltipContext", "openDelay", "closeDelay", "ngbTooltip"], outputs: ["shown", "hidden"], exportAs: ["ngbTooltip"] }, { kind: "component", type: i2.BadgeListComponent, selector: "ui-core-badge-list", inputs: ["items", "marginTop", "max", "rightAlign"] }, { kind: "component", type: i2.ButtonComponent, selector: "ui-core-button", inputs: ["themeGroup", "theme", "message", "icon", "iconPosition", "disabled", "disabledMessage", "showSpinner", "buttonClass", "width", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "ariaLabel", "isFormValid", "e2e", "buttonId"] }, { kind: "component", type: i2.ClickableComponent, selector: "ui-core-clickable", inputs: ["disabled", "buttonClass", "ariaLabel", "e2e"] }, { kind: "component", type: i2.PageActionsComponent, selector: "ui-core-page-actions", inputs: ["withinModal", "withinNav", "showTwoOutsideMenu", "alignLeft", "moreMenuIcon", "moreMenuButtonText", "actions"] }, { kind: "component", type: i2.SpinnerComponent, selector: "ui-core-spinner", inputs: ["message", "size", "buttonIcon", "hideSpinner", "centered", "delayMs", "buttonSpinner"] }, { kind: "component", type: i4.CheckboxComponent, selector: "ui-forms-checkbox", inputs: ["indeterminate", "isChild", "secondaryLabel", "subtextLines", "ariaLabel"] }, { kind: "component", type: i4.DateRangeComponent, selector: "ui-forms-date-range", inputs: ["value", "allowToday", "desktopMaxWidth", "disableFutureDates", "disablePastDates", "display", "iconLeft", "maxDate", "minDate", "mobileDoneButtonLabel", "placeholder", "theme", "ariaDescription"] }, { kind: "component", type: i4.MultiSelectPickerComponent, selector: "ui-forms-multi-select-picker", inputs: ["value", "options", "display", "searchPlaceholder", "actions"] }, { kind: "component", type: i4.PickerComponent, selector: "ui-forms-picker", inputs: ["value", "options", "display", "actions"] }, { kind: "component", type: i4.SearchInputComponent, selector: "ui-forms-search-input", inputs: ["value", "maxLength", "placeholder", "size", "autoFocus", "locked", "inputId", "clearButtonId", "isSearchBar"], outputs: ["inputHasFocus"] }, { kind: "component", type: TableTemplatesDefinitionsComponent, selector: "ui-workflows-table-template-definitions" }, { kind: "component", type: BulkActionsComponent, selector: "ui-workflows-bulk-actions", inputs: ["actions", "clearAllLabel", "emptyLabel", "rowLabel"], outputs: ["allCleared", "bulkAction"] }, { kind: "component", type: TableActionsComponent, selector: "ui-workflows-table-actions", inputs: ["actions", "item", "menuTitle"], outputs: ["tableAction"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TableComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-workflows-table', template: "@if (title || subtitle || headerActions?.length > 0 || badges?.length > 0) {\n    <div class=\"d-flex\">\n        <div *ngIf=\"title || subtitle || badges?.length > 0\" class=\"table-title\">\n            <div *ngIf=\"title || subtitle\">\n                <span *ngIf=\"title\" class=\"text-strong\" role=\"heading\" aria-level=\"3\">{{ title }}</span>\n                <span *ngIf=\"subtitle\" [class.ml-1]=\"title\">{{ subtitle }}</span>\n            </div>\n            <div *ngIf=\"badges?.length > 0\" class=\"d-flex align-items-center\">\n                <ui-core-badge-list [items]=\"badges\" [marginTop]=\"false\"></ui-core-badge-list>\n            </div>\n        </div>\n        <div *ngIf=\"headerActions?.length > 0\" class=\"ml-auto\">\n            <ui-core-page-actions \n                [actions]=\"headerActions\" [withinModal]=\"true\"\n                [moreMenuIcon]=\"pageActionsMenuIcon\" \n                [moreMenuButtonText]=\"pageActionsMenuText\">\n            </ui-core-page-actions>\n        </div>\n    </div>\n}\n\n<div *ngIf=\"templatesReady && (resultCount !== 0 || showSearchAndFilter)\"\n    [ngClass]=\"['table-container mb-2', stickyClass]\" [class.scroll-left-complete]=\"scrollLeftComplete\" [class.scroll-right-complete]=\"scrollRightComplete\">\n    <div *ngIf=\"showSearchAndFilter\" class=\"table-filter-controls\">\n        <ui-forms-search-input [value]=\"searchTerm\" (change)=\"doSearch($event)\" [class.full-width]=\"isMobile || searchFullWidth\" [e2e]=\"e2e\" />\n        @for (filter of filters; track filter.propertyName) {\n            <ui-forms-multi-select-picker\n                *ngIf=\"filter.type !== TableFilterType.DATE_RANGE\"\n                [label]=\"filter.label\"\n                theme=\"primary\"\n                [options]=\"filter.options\"\n                display=\"label\"\n                [searchPlaceholder]=\"text.multiSelectSearchPlaceholderPrefix + ' ' + filter.label\"\n                [value]=\"activeFilters[filter.propertyName] || []\"\n                (change)=\"onFilterChange($event, filter)\" />\n            <ui-forms-date-range\n                *ngIf=\"filter.type === TableFilterType.DATE_RANGE\"\n                [label]=\"filter.label\"\n                display=\"selection\"\n                theme=\"primary\"\n                [minDate]=\"filter.rangeAllowed[0]\"\n                [maxDate]=\"filter.rangeAllowed[1]\"\n                [value]=\"activeFilters[filter.propertyName] || []\"\n                (change)=\"onFilterChange($event, filter)\" />\n        }\n        <ui-core-button *ngIf=\"hasActiveFilters\" [message]=\"text.clearFiltersButtonLabel\" icon=\"close\" theme=\"link\" buttonClass=\"clear-btn\" (click)=\"clearAllFilters()\"></ui-core-button>\n    </div>\n    <div #tableScroller class=\"table-scroller\" [class.sticky]=\"!!stickyColumns\" [class.scrollable]=\"scrollable\" (scroll)=\"scrollable && onScroll()\">\n        <table [class.striped]=\"striped\" [class.grid-lines]=\"gridLines\" role=\"grid\" [attr.data-e2e]=\"e2e\">\n            <thead *ngIf=\"showColumnHeaders && resultCount !== 0\">\n                <tr>\n                    <th *ngIf=\"showCheckbox\" class=\"check-cell\" [class.sticky]=\"firstColFixed\" [attr.width]=\"MIN_COL_WIDTH\">\n                        <div class=\"sticky-shadow\"></div>\n                        <ui-forms-checkbox (click)=\"onSelectAll($event)\" [isChild]=\"true\"\n                            [checked]=\"isSelectAllChecked\" [label]=\"text.checkAllLabel\" [hideLabel]=\"true\" class=\"checkbox-all-selector\"\n                        ></ui-forms-checkbox>\n                    </th>\n                    @for (column of columns; track $index; let first = $first; let last = $last) {\n                        <th [style.min-width.px]=\"column.minWidth\"\n                            [style.width]=\"column._tData.width\"\n                            [attr.width]=\"column._tData.width\"\n                            [class.sortable]=\"column._tData.sortName\"\n                            [class.sticky]=\"(first && firstColContent) || (last && lastColContent)\"\n                            (click)=\"sortOnColumn(column)\">\n                            <div class=\"sticky-shadow\"></div>\n                            <div [ngClass]=\"['d-flex align-items-center', column.align ? 'column-' + column.align : '']\">\n                                <div [ngClass]=\"['column-label text-caption text-semibold', column._tData.wrapClass, column.headerClass || '']\">\n                                    @if (column._tData.sortName) {\n                                        <ui-core-clickable [attr.aria-label]=\"column._tData.sortLabel\" buttonClass=\"text-caption text-semibold\">\n                                            <ng-container [ngTemplateOutlet]=\"cellTemplate\" [ngTemplateOutletContext]=\"{ content: column._tData.text ? column._tData : column.displayName }\" />\n                                        </ui-core-clickable>\n                                        <i *ngIf=\"sortColumn === column._tData.sortName\" class=\"material-icons text-base\">\n                                            {{ sortDirection === TableSortDirection.ASCENDING ? 'expand_less' : 'expand_more' }}\n                                        </i>\n                                    } @else {\n                                        <ng-container [ngTemplateOutlet]=\"cellTemplate\" [ngTemplateOutletContext]=\"{ content: column._tData.text ? column._tData : column.displayName || '' }\" />\n                                    }\n                                </div>\n                            </div>\n                        </th>\n                    }\n                    <th *ngIf=\"hasActionsColumn\" [class.sticky]=\"lastColFixed\" [attr.width]=\"MIN_COL_WIDTH\" [style.min-width]=\"actionsColMinWidth\">\n                        <div *ngIf=\"lastColFixed\" class=\"sticky-shadow\"></div>\n                    </th>\n                </tr>\n            </thead>\n            <tbody *ngIf=\"resultCount !== 0\">\n                @for (item of dataPage; track $index; let i = $index) {\n                    <tr (click)=\"rowClick(item, $event)\" [class.clickable]=\"clickable\" [attr.data-e2e]=\"e2e+'-row-'+i\">\n                        <td *ngIf=\"showCheckbox\" class=\"check-cell\" [class.sticky]=\"firstColFixed\">\n                            <div class=\"sticky-shadow\"></div>\n                            <ui-forms-checkbox (click)=\"onSelectRow(item)\" [isChild]=\"true\"\n                                [checked]=\"item._tData.checked\" [label]=\"text.checkRowLabel\" [hideLabel]=\"true\" class=\"checkbox-selector\"></ui-forms-checkbox>\n                        </td>\n                        @for (column of columns; track $index; let first = $first; let last = $last) {\n                            <td [ngClass]=\"['table-column', column._tData.wrapClass, column.contentClass || '', column.align ? 'column-' + column.align : '']\"\n                                [class.searchable]=\"column.searchable !== false\" [class.sticky]=\"(first && firstColContent) || (last && lastColContent)\">\n                                <div class=\"sticky-shadow\"></div>\n                                @if (column.clickable) {\n                                    <ng-container [ngTemplateOutlet]=\"clickableButtonTemplate\" [ngTemplateOutletContext]=\"{ message: item._tData[column.propertyName]?.formatted?.text || item[column.propertyName] }\" />\n                                } @else {\n                                    @if (item._tData[column.propertyName]?.tooltip) {\n                                        <span placement=\"top auto\" [ngbTooltip]=\"item._tData[column.propertyName]?.tooltip\" container=\"body\">\n                                            <ng-container [ngTemplateOutlet]=\"dynamicCellTemplate\" [ngTemplateOutletContext]=\"{ column, item }\" />\n                                            <span class=\"sr-only no-highlight\">{{ item._tData[column.propertyName]?.tooltip }}</span>\n                                        </span>\n                                    } @else {\n                                        <ng-container [ngTemplateOutlet]=\"dynamicCellTemplate\" [ngTemplateOutletContext]=\"{ column, item }\" />\n                                    }\n                                }\n                            </td>\n                        }\n                        <td *ngIf=\"hasActionsColumn\" class=\"action-col\" [class.sticky]=\"lastColFixed\">\n                            <div class=\"sticky-shadow\"></div>\n                            <ui-core-spinner *ngIf=\"tableActionProcessingProp && item[tableActionProcessingProp]\" class=\"pt-3\"></ui-core-spinner>\n                            <ui-workflows-table-actions *ngIf=\"hasActionsColumn && (!tableActionProcessingProp || !item[tableActionProcessingProp]) && item._tData.hasRowActions\"\n                                [menuTitle]=\"text.actionsMenuLabel\" [actions]=\"actions\" [item]=\"item\" (tableAction)=\"doTableAction(item, $event)\"></ui-workflows-table-actions>\n                        </td>\n                    </tr>\n                }\n            </tbody>\n            <tbody *ngIf=\"resultCount === 0\">\n                <tr><td [attr.colspan]=\"columns?.length ? columns.length + 2 : 1\" class=\"empty-table p-5\">\n                    {{ emptyText }}\n                </td></tr>\n            </tbody>\n        </table>\n    </div>\n</div>\n\n<ui-workflows-bulk-actions *ngIf=\"bulkActionRows?.length > 0\"\n    [actions]=\"bulkActionsVisible\" [rowLabel]=\"bulkActionsSelectedLabel\" [emptyLabel]=\"text.bulkNoCommonActionsLabel\"\n    [clearAllLabel]=\"text.clearCheckedItemsButtonLabel\" (bulkAction)=\"doBulkTableAction($event)\" (allCleared)=\"onSelectAll(false)\" />\n\n<ng-template #dynamicCellTemplate let-column=\"column\" let-item=\"item\">\n    <ng-container *ngIf=\"!column._tData.template\"\n        [ngTemplateOutlet]=\"cellTemplate\" [ngTemplateOutletContext]=\"{ content: item._tData[column.propertyName].formatted || item[column.propertyName] }\" />\n    <ng-container *ngIf=\"column._tData.template\"\n        [ngTemplateOutlet]=\"column._tData.template\"\n        [ngTemplateOutletContext]=\"item._tData[column.propertyName]?.templateContext ? item._tData[column.propertyName]?.templateContext : { item, columnValue: item[column.propertyName] }\" />\n</ng-template>\n\n<ng-template #cellTemplate let-content=\"content\">\n    <div *ngIf=\"content.text\">{{ content.text }}</div>\n    <div *ngIf=\"content.subtext\" class=\"sub-text\">{{ content.subtext }}</div>\n    <div *ngIf=\"content.html\" [innerHTML]=\"content.html\"></div>\n</ng-template>\n\n<ng-template #clickableButtonTemplate let-message=\"message\">\n    <ui-core-button [message]=\"message\" theme=\"link\" buttonClass=\"table-clickable-link btn-wrap\" [ariaLabel]=\"text.ariaRowClick + ' ' + message\"\n        (focusin)=\"setRowHighlight($event)\" (focusout)=\"setRowHighlight($event, true)\">\n    </ui-core-button>\n</ng-template>\n\n<footer *ngIf=\"showPageControls\" class=\"mb-3\" [class.mobile]=\"isMobile\">\n    <div *ngIf=\"pageSizeOptions.length > 0 && resultCount > 0\" class=\"page-size\">\n        <ui-forms-picker (change)=\"$event && changePageSize($event)\" [options]=\"pageSizeOptions\" [value]=\"pageSize\" [label]=\"text.pageSizeLabel\" display=\"selection\"></ui-forms-picker>\n        <span class=\"pl-2\">{{ pageSizeText }}</span>\n    </div>\n    <div class=\"page-spacer\"></div>\n    <div *ngIf=\"dataPageList.length > 1\" class=\"page-nav\">\n        <ui-core-button \n            buttonClass=\"py-half px-2\"\n            class=\"pr-1\"\n            [disabled]=\"page === 1\"\n            icon=\"keyboard_arrow_left\"\n            [message]=\"text.pagePreviousButtonLabel\"\n            [showSpinner]=\"false\"\n            theme=\"link\"\n            (click)=\"changePage('previous')\">\n        </ui-core-button>\n        <div class=\"pages-wrapper\">\n            <ui-core-button \n                *ngFor=\"let displayPage of dataPageList\"\n                buttonClass=\"no-min-width py-half px-2\"\n                [message]=\"displayPage\"\n                [theme]=\"displayPage === page ? 'primary' : 'link'\"\n                (click)=\"changePage(displayPage)\">\n            </ui-core-button>\n        </div>\n        <ui-core-button \n            buttonClass=\"py-half px-2\"\n            class=\"pl-1\"\n            [disabled]=\"page === pages.length\"\n            icon=\"keyboard_arrow_right\"\n            iconPosition=\"right\"\n            [message]=\"text.pageNextButtonLabel\"\n            [showSpinner]=\"false\"\n            theme=\"link\"\n            (click)=\"changePage('next')\">\n        </ui-core-button>\n    </div>\n</footer>\n\n<ui-workflows-table-template-definitions *ngIf=\"!templatesReady\" />\n", styles: [".table-title{padding:12px 16px;display:flex;align-items:center;flex-wrap:wrap;row-gap:8px;column-gap:8px}.table-container{border:1px solid var(--color-stroke-1);border-radius:var(--containers-shape);transition:border-radius var(--transition-duration) var(--transition-timing);overflow:hidden;width:100%}.table-container.sticky-both:not(.scroll-right-complete),.table-container.sticky-first:not(.scroll-right-complete){border-bottom-right-radius:0;border-top-right-radius:0}.table-container.sticky-both:not(.scroll-left-complete),.table-container.sticky-last:not(.scroll-left-complete){border-bottom-left-radius:0;border-top-left-radius:0}.table-container:not(.sticky){display:table}.table-container .table-filter-controls{display:flex;flex-wrap:wrap;align-items:center;background-color:var(--color-gray-100);padding:8px 16px}.table-container .table-filter-controls ui-forms-search-input{width:300px;min-width:300px;margin:8px 16px 8px 0}.table-container .table-filter-controls ui-forms-search-input.full-width{width:100%;margin-right:0;min-width:0}.table-container .table-filter-controls ui-forms-multi-select-picker,.table-container .table-filter-controls ui-forms-date-range{margin:8px 12px 8px 0}.table-container .table-filter-controls ui-forms-multi-select-picker:last-child,.table-container .table-filter-controls ui-forms-date-range:last-child{margin-right:0}.table-scroller.scrollable{overflow-x:auto}.table-scroller.scrollable .sticky-shadow{box-shadow:0 0 8px #00000040}table{background-color:var(--color-default);border-collapse:separate;border-spacing:0;margin-bottom:0;height:100%;width:100%;position:relative}table th{color:var(--color-gray-900);font-weight:400;padding:12px 16px;border:none;vertical-align:bottom;background-color:var(--color-gray-100)}table th .sticky-shadow{background-color:var(--color-gray-100)}table th.sortable{cursor:pointer;padding-right:20px}table th.sortable .column-label{position:relative;padding-right:2px}table th.sortable .column-label button{color:var(--color-gray-900)}table th.sortable .column-label .material-icons{position:absolute;bottom:-4px;right:-16px}table th.check-cell{padding-bottom:2px;padding-right:6px}table td{font-size:var(--type-body2-size);padding:16px;border-top:1px solid var(--color-stroke-1);vertical-align:top}table td.action-col{padding-top:4px;text-align:right}table td.check-cell{padding-top:8px;padding-right:6px}table tr:first-of-type td{border-top:none}table.grid-lines td,table.grid-lines th{border-left:1px solid var(--color-stroke-1);border-top-color:var(--color-gray-100)}table.grid-lines td:first-child,table.grid-lines th:first-child{border-left:none}table th.sticky,table td.sticky{position:sticky;top:0;left:0;z-index:2;border-left-width:0;border-right-width:0;background-color:var(--color-default)}table th.sticky:first-of-type,table td.sticky:first-of-type{left:0}table th.sticky:first-of-type .sticky-shadow,table td.sticky:first-of-type .sticky-shadow{left:0;clip-path:inset(0px -8px 0px 0px)}table th.sticky:last-of-type,table td.sticky:last-of-type{right:0}table th.sticky:last-of-type .sticky-shadow,table td.sticky:last-of-type .sticky-shadow{right:0;clip-path:inset(0px 0px 0px -8px)}table th.sticky .sticky-shadow,table td.sticky .sticky-shadow{top:0;position:absolute;width:100%;height:100%}table th.sticky .column-label,table td.sticky .column-label{position:relative}table.striped tbody tr:nth-of-type(2n) td{background-color:var(--color-sunken)}table tbody tr.clickable:hover>td{cursor:pointer;background-color:var(--color-hover)}table tbody tr.clickable:hover>td.sticky{background-color:var(--color-default)}table tbody tr.clickable:hover>td.sticky .sticky-shadow{background-color:var(--color-hover);z-index:-1}table .empty-table{color:var(--color-gray-700);text-align:center}footer{display:flex;flex-wrap:wrap-reverse;justify-content:space-between;row-gap:var(--spacing-250)}footer .page-size{display:flex;align-items:center}footer .page-spacer{flex-grow:10}footer .page-nav{display:flex;align-items:center;flex-grow:1;justify-content:space-between}footer.mobile{flex-direction:column-reverse}footer.mobile .page-spacer{display:none}.column-left{text-align:left;justify-content:start;justify-items:left}.column-center{text-align:center;justify-content:center;justify-items:center}.column-right{text-align:right;justify-content:end;justify-items:right}:host-context(.using-keyboard) table tbody tr.clickable.focused>td{cursor:pointer;background-color:var(--color-hover)}:host-context(.using-keyboard) table tbody tr.clickable.focused>td.sticky{background-color:var(--color-default)}:host-context(.using-keyboard) table tbody tr.clickable.focused>td.sticky .sticky-shadow{background-color:var(--color-hover);z-index:-1}\n"] }]
        }], ctorParameters: () => [{ type: TableStateService }, { type: TableTemplatesService }, { type: i2.WindowService }, { type: i0.ChangeDetectorRef }, { type: i0.NgZone }, { type: i2.TextService }], propDecorators: { tableScroller: [{
                type: ViewChild,
                args: ['tableScroller', { static: false }]
            }], externalSortAndPaging: [{
                type: Input
            }], externalSearchAndFilter: [{
                type: Input
            }], actions: [{
                type: Input
            }], actionsColumnFixedWidth: [{
                type: Input
            }], bulkActions: [{
                type: Input
            }], columns: [{
                type: Input
            }], data: [{
                type: Input
            }], searchableProps: [{
                type: Input
            }], e2e: [{
                type: Input
            }], emptyText: [{
                type: Input
            }], gridLines: [{
                type: Input
            }], page: [{
                type: Input
            }], pageSize: [{
                type: Input
            }], pageSizes: [{
                type: Input
            }], resultCount: [{
                type: Input
            }], searchTerm: [{
                type: Input
            }], showCheckbox: [{
                type: Input
            }], showColumnHeaders: [{
                type: Input
            }], showPageControls: [{
                type: Input
            }], showSearchAndFilter: [{
                type: Input
            }], searchFullWidth: [{
                type: Input
            }], sortColumn: [{
                type: Input
            }], sortDirection: [{
                type: Input
            }], stickyColumns: [{
                type: Input
            }], striped: [{
                type: Input
            }], tableActionProcessingProp: [{
                type: Input
            }], tableStateId: [{
                type: Input
            }], tableStateParam: [{
                type: Input
            }], keepStateOnUpdate: [{
                type: Input
            }], title: [{
                type: Input
            }], subtitle: [{
                type: Input
            }], badges: [{
                type: Input
            }], headerActions: [{
                type: Input
            }], pageActionsMenuIcon: [{
                type: Input
            }], pageActionsMenuText: [{
                type: Input
            }], rowClicked: [{
                type: Output
            }], tableAction: [{
                type: Output
            }], rowChecked: [{
                type: Output
            }], filtersChanged: [{
                type: Output
            }], pageChanged: [{
                type: Output
            }], pageSizeChanged: [{
                type: Output
            }], searched: [{
                type: Output
            }], sorted: [{
                type: Output
            }] } });

class TableTemplateUtils {
    static buildTagList(items) {
        const list = Array.isArray(items) ? items : items ? [items] : undefined;
        if (list?.length) {
            return { tags: list.map(item => new ChipListItem(item)) };
        }
    }
}

class FrequencyOption {
    constructor() {
        this.label = '';
        this.type = null;
        // Start date customizations, only used for RECURRING and ONE_TIME_FUTURE frequencies
        this.startDateLabel = '';
        this.startDateActionButtonLabel = '';
        this.startDateActionButtonIcon = '';
        this.startDateDisableAllExceptFirstDayOfMonth = false;
        this.startDateDisableAllExceptLastDayOfMonth = false;
        this.startDateDisableAllExceptFifteenthAndLastDay = false;
        // Only used for TWO_DAYS_A_MONTH
        this.firstDayLabel = '';
        this.firstDayDescription = '';
        this.secondDayLabel = '';
        this.secondDayDescription = '';
        this.dayBuffer = 0;
        this.dayBufferMessage = '';
    }
}

var FrequencyType;
(function (FrequencyType) {
    FrequencyType["ONE_TIME_FUTURE"] = "ONE_TIME_FUTURE";
    FrequencyType["RECURRING"] = "RECURRING";
    FrequencyType["TWO_DAYS_A_MONTH"] = "TWO_DAYS_A_MONTH";
})(FrequencyType || (FrequencyType = {}));

class FundingOptionsResult {
    constructor() {
        this.fromValue = '';
        this.toValue = '';
        this.fromSelection = null;
        this.toSelection = null;
    }
    get isValid() {
        return !!this.fromValue && !!this.toValue;
    }
}

class FundingOptionsComponent extends BaseTextComponent {
    constructor(fb, windowService, textService) {
        super(textService, 'ui-workflows-funding-options');
        this.fb = fb;
        this.windowService = windowService;
        this.textService = textService;
        /**
        * Fund from options.
        **/
        this.fromGroups = [];
        /**
        * Fund to options.
        **/
        this.toGroups = [];
        /**
        * Actions inside the from dropdown.
        **/
        this.fromActions = [];
        /**
        * Actions inside the to dropdown.
        **/
        this.toActions = [];
        /**
        * The initial value of the from dropdown.
        **/
        this.initialFromValue = '';
        /**
        * The initial value of the to dropdown.
        **/
        this.initialToValue = '';
        /**
        * If the from dropdown should be locked.
        * Note: If there are available actions, this value will be disregarded.
        **/
        this.lockedFrom = false;
        /**
        * If the to dropdown should be locked.
        * Note: If there are available actions, this value will be disregarded.
        * The dropdown will be automatically locked while the from dropdown is unset.
        **/
        this.lockedTo = false;
        /**
        * Optional from label. Default is "From"
        **/
        this.fromLabel = '';
        /**
        * Optional to label. Default is "To"
        **/
        this.toLabel = '';
        /**
        * Values that are temporarily disabled due to the from selection.
        * Values that are always disabled should use the isSelectable property on the dropdown option.
        **/
        this.ineligibleToValues = [];
        /**
        * Used with ineligibleToValues to explain why the option is not selectable.
        **/
        this.ineligibleMessage = '';
        /**
        * Emits when a new value is selected in either dropdown.
        **/
        this.selection = new EventEmitter();
        this.isMobile = false;
        this.fromValue = '';
        this.toValue = '';
        this.lastResult = null;
        this.managedToGroups = [];
        this.windowService.windowSize$.pipe(this.takeUntilDestroyed()).subscribe(windowSize => {
            this.isMobile = windowSize.isMobile;
        });
    }
    ngOnChanges(changes) {
        const toGroupsChanged = changes.toGroups && this.toGroups?.length > 0;
        if (toGroupsChanged || changes.ineligibleToValues) {
            this.buildManagedToGroups();
        }
    }
    ngOnInit() {
        this.form = this.fb.group({
            from: [this.getInitialValue(true), Validators.required],
            to: [this.getInitialValue(false), Validators.required],
        });
    }
    get lockedFromDropdown() {
        // Don't lock if there are actions
        if (this.fromActions.length > 0) {
            return false;
        }
        return this.lockedFrom;
    }
    get lockedToDropdown() {
        // Force the user to pick the from value first
        if (!this.fromValue) {
            return true;
        }
        // Don't lock if there are actions
        if (this.toActions.length > 0) {
            return false;
        }
        return this.lockedTo;
    }
    getInitialValue(isFrom) {
        const initValue = isFrom ? this.initialFromValue : this.initialToValue;
        if (initValue) {
            // If a matching option is found, move forward with this value.
            const option = this.getMatchingOptionFromValue(initValue, isFrom);
            if (option) {
                return initValue;
            }
        }
        return '';
    }
    fromChanged(fromValue) {
        this.fromValue = fromValue || '';
        this.buildManagedToGroups();
        // If the from has been set to the same value as the to dropdown, do not emit the result.
        // The to dropdown will reset itself and emit the latest values.
        // This helps reduce extraneous events from bubbling up to parent components.
        const fromIsSameAsTo = this.fromValue && this.toValue && this.fromValue === this.toValue;
        if (!fromIsSameAsTo) {
            this.buildAndEmitResult();
        }
    }
    toChanged(toValue) {
        this.toValue = toValue || '';
        this.buildAndEmitResult();
    }
    getMatchingOptionFromValue(value, isFrom) {
        const groups = isFrom ? this.fromGroups : this.managedToGroups;
        let match = null;
        groups.forEach(group => {
            if (!match) {
                const matchingOption = group.options.find(o => o.value === value);
                match = matchingOption || null;
            }
        });
        return match;
    }
    getObjectFromValue(value, isFrom) {
        if (!value) {
            return null;
        }
        return this.getMatchingOptionFromValue(value, isFrom)?.object || null;
    }
    buildResult() {
        const result = new FundingOptionsResult();
        result.fromValue = this.fromValue;
        result.toValue = this.toValue;
        result.fromSelection = this.getObjectFromValue(result.fromValue, true);
        result.toSelection = this.getObjectFromValue(result.toValue, false);
        return result;
    }
    buildAndEmitResult() {
        const result = this.buildResult();
        // Check if the result actually changed to prevent duplicate events from bubbling up
        const resultChanged = !this.lastResult || this.lastResult.fromValue !== this.fromValue || this.lastResult.toValue !== this.toValue;
        if (resultChanged) {
            this.selection.emit(result);
            this.lastResult = result;
        }
    }
    buildManagedToGroups() {
        // Clone the groups and their respective options.
        // If there is a to option that matches the selected from option, it will be disabled.
        // Cloning allows us to manipulate the new group array and throw it away when the from account changes.
        this.managedToGroups = this.toGroups.map(g => g.clone());
        const optionsToDisable = [];
        if (this.fromValue) {
            const toOptionMatchingFromValue = this.getMatchingOptionFromValue(this.fromValue, false);
            if (toOptionMatchingFromValue) {
                optionsToDisable.push(toOptionMatchingFromValue);
            }
        }
        this.ineligibleToValues.forEach(value => {
            const match = this.getMatchingOptionFromValue(value, false);
            if (match) {
                optionsToDisable.push(match);
            }
        });
        optionsToDisable.forEach(o => o.setAsIneligible(this.ineligibleMessage));
    }
    validate() {
        if (this.form.invalid) {
            FormUtils.showFormValidation(this.form);
            return null;
        }
        return this.buildResult();
    }
    getDefaultText() {
        return {
            fromLabel: 'From',
            toLabel: 'To',
            requiredError: 'Required',
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: FundingOptionsComponent, deps: [{ token: i1.UntypedFormBuilder }, { token: i2.WindowService }, { token: i2.TextService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.17", type: FundingOptionsComponent, isStandalone: false, selector: "ui-workflows-funding-options", inputs: { fromGroups: "fromGroups", toGroups: "toGroups", fromActions: "fromActions", toActions: "toActions", initialFromValue: "initialFromValue", initialToValue: "initialToValue", lockedFrom: "lockedFrom", lockedTo: "lockedTo", fromLabel: "fromLabel", toLabel: "toLabel", ineligibleToValues: "ineligibleToValues", ineligibleMessage: "ineligibleMessage" }, outputs: { selection: "selection" }, usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<form *ngIf=\"form\" [formGroup]=\"form\" uiFormsRow [showRowClass]=\"false\"\n    class=\"d-flex justify-content-between form-max-width\" [class.flex-column]=\"isMobile\">\n    <ui-forms-template-dropdown [class.funding-options-dropdown]=\"!isMobile\"\n        [errorMessage]=\"text.requiredError\"\n        formControlName=\"from\"\n        [locked]=\"lockedFromDropdown\"\n        [label]=\"fromLabel || text.fromLabel\"\n        [groups]=\"fromGroups\"\n        [actions]=\"fromActions\"\n        (change)=\"fromChanged($event)\">\n    </ui-forms-template-dropdown>\n\n    <div *ngIf=\"!isMobile\" class=\"funding-options-arrow form-content-centered\">\n        <i class=\"material-icons form-content-container\" aria-hidden=\"true\">arrow_forward</i>\n    </div>\n    \n    <ui-forms-template-dropdown [class.funding-options-dropdown]=\"!isMobile\"\n        [errorMessage]=\"text.requiredError\"\n        formControlName=\"to\"\n        [locked]=\"lockedToDropdown\"\n        [lockedMessage]=\"false\"\n        [label]=\"toLabel || text.toLabel\"\n        [groups]=\"managedToGroups\"\n        [actions]=\"toActions\"\n        (change)=\"toChanged($event)\">\n    </ui-forms-template-dropdown>\n</form>\n", styles: [".funding-options-dropdown{width:calc((100% - var(--forms-column-gap)) / 2)}.funding-options-arrow{display:inline-flex;justify-content:center;flex-grow:0;flex-shrink:0}.funding-options-arrow .material-icons{font-size:30px;height:30px;width:30px}\n"], dependencies: [{ kind: "directive", type: i2$1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: i4.FormRowDirective, selector: "[uiFormsRow]", inputs: ["showRowClass"] }, { kind: "component", type: i4.TemplateDropdownComponent, selector: "ui-forms-template-dropdown", inputs: ["groups", "actions", "actionButtonIcon", "actionButtonMessage", "actionButtonMessageHidden", "actionButtonDisabled", "actionButtonDisabledSpinner", "noOptionsMessage"], outputs: ["selection", "actionButtonClick"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: FundingOptionsComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-workflows-funding-options', template: "<form *ngIf=\"form\" [formGroup]=\"form\" uiFormsRow [showRowClass]=\"false\"\n    class=\"d-flex justify-content-between form-max-width\" [class.flex-column]=\"isMobile\">\n    <ui-forms-template-dropdown [class.funding-options-dropdown]=\"!isMobile\"\n        [errorMessage]=\"text.requiredError\"\n        formControlName=\"from\"\n        [locked]=\"lockedFromDropdown\"\n        [label]=\"fromLabel || text.fromLabel\"\n        [groups]=\"fromGroups\"\n        [actions]=\"fromActions\"\n        (change)=\"fromChanged($event)\">\n    </ui-forms-template-dropdown>\n\n    <div *ngIf=\"!isMobile\" class=\"funding-options-arrow form-content-centered\">\n        <i class=\"material-icons form-content-container\" aria-hidden=\"true\">arrow_forward</i>\n    </div>\n    \n    <ui-forms-template-dropdown [class.funding-options-dropdown]=\"!isMobile\"\n        [errorMessage]=\"text.requiredError\"\n        formControlName=\"to\"\n        [locked]=\"lockedToDropdown\"\n        [lockedMessage]=\"false\"\n        [label]=\"toLabel || text.toLabel\"\n        [groups]=\"managedToGroups\"\n        [actions]=\"toActions\"\n        (change)=\"toChanged($event)\">\n    </ui-forms-template-dropdown>\n</form>\n", styles: [".funding-options-dropdown{width:calc((100% - var(--forms-column-gap)) / 2)}.funding-options-arrow{display:inline-flex;justify-content:center;flex-grow:0;flex-shrink:0}.funding-options-arrow .material-icons{font-size:30px;height:30px;width:30px}\n"] }]
        }], ctorParameters: () => [{ type: i1.UntypedFormBuilder }, { type: i2.WindowService }, { type: i2.TextService }], propDecorators: { fromGroups: [{
                type: Input
            }], toGroups: [{
                type: Input
            }], fromActions: [{
                type: Input
            }], toActions: [{
                type: Input
            }], initialFromValue: [{
                type: Input
            }], initialToValue: [{
                type: Input
            }], lockedFrom: [{
                type: Input
            }], lockedTo: [{
                type: Input
            }], fromLabel: [{
                type: Input
            }], toLabel: [{
                type: Input
            }], ineligibleToValues: [{
                type: Input
            }], ineligibleMessage: [{
                type: Input
            }], selection: [{
                type: Output
            }] } });

class NotesResult {
    constructor(isValid, notes = '') {
        this.isValid = isValid;
        this.notes = notes;
    }
}

class NotesComponent {
    constructor() {
        /**
        * The text area field to render inside form-renderer
        **/
        this.field = null;
        /**
        * The e2e hook to pass into form-renderer
        **/
        this.e2e = '';
        this.formRows = [];
    }
    ngOnChanges(changes) {
        if (changes.field && this.field) {
            const row = new FormRendererRow([this.field]);
            this.formRows = [row];
        }
    }
    validate() {
        if (this.formRenderer.form.invalid) {
            FormUtils.showFormValidation(this.formRenderer.form);
            return new NotesResult(false);
        }
        const value = this.formRenderer.form.get(this.field.name)?.value || '';
        return new NotesResult(true, value);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: NotesComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.17", type: NotesComponent, isStandalone: false, selector: "ui-workflows-notes", inputs: { field: "field", e2e: "e2e" }, viewQueries: [{ propertyName: "formRenderer", first: true, predicate: FormRendererComponent, descendants: true, static: true }], usesOnChanges: true, ngImport: i0, template: "<ui-forms-form-renderer [rows]=\"formRows\" [e2e]=\"e2e\" [showNextField]=\"false\">\n</ui-forms-form-renderer>\n", dependencies: [{ kind: "component", type: i4.FormRendererComponent, selector: "ui-forms-form-renderer", inputs: ["rows", "disableButtons", "primaryButtonText", "primaryButtonDisabledText", "primaryButtonIcon", "primaryButtonIconPosition", "secondaryButtonText", "secondaryButtonClearsForm", "secondaryButtonUrl", "secondaryButtonUrlParams", "secondaryButtonUsesExternalUrlNewTab", "secondaryButtonIcon", "secondaryButtonIconPosition", "tertiaryButtonText", "tertiaryButtonIcon", "tertiaryButtonIconPosition", "tertiaryButtonUrl", "tertiaryButtonUrlParams", "tertiaryButtonUsesExternalUrlNewTab", "locked", "loading", "loadingMessage", "storeValuesOnSubmit", "storeValuesOnDestroy", "checkEditedValues", "e2e", "showNextField", "errorMessages", "autoFocus", "marginTop", "marginBottom", "enableBotDetection"], outputs: ["primaryButtonClicked", "secondaryButtonClicked", "tertiaryButtonClicked", "inputChange", "selection", "groupCategoryChange"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: NotesComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-workflows-notes', template: "<ui-forms-form-renderer [rows]=\"formRows\" [e2e]=\"e2e\" [showNextField]=\"false\">\n</ui-forms-form-renderer>\n" }]
        }], propDecorators: { formRenderer: [{
                type: ViewChild,
                args: [FormRendererComponent, { static: true }]
            }], field: [{
                type: Input
            }], e2e: [{
                type: Input
            }] } });

class PaymentOption {
    constructor() {
        this.label = '';
        this.amount = -1;
        this.isDefault = false;
        this.tooltip = '';
        this.subtextLines = [];
    }
}

var PaymentOptionType;
(function (PaymentOptionType) {
    PaymentOptionType["EDITABLE"] = "EDITABLE";
    PaymentOptionType["VARIABLE"] = "VARIABLE";
    PaymentOptionType["FIXED"] = "FIXED";
    PaymentOptionType["UNKNOWN"] = "UNKNOWN";
})(PaymentOptionType || (PaymentOptionType = {}));

class PaymentRadioButtonOption {
    constructor(paymentOption) {
        // Mapped from payment options
        this.label = '';
        this.value = '';
        this.amount = -1;
        this.ariaLabel = '';
        this.subtextLines = [];
        // Helpers to avoid checking enum value
        this.amountIsEditable = false;
        this.amountIsVariable = false;
        this.amountIsUnknown = false;
        // Radio button display/state
        this.formattedAmount = '';
        this.message = '';
        this.messageTheme = NotificationTheme.INFORMATION;
        this.tooltip = '';
        // Used for aria
        this.id = '';
        this.label = paymentOption.label;
        this.value = paymentOption.id;
        this.amount = paymentOption.amount;
        this.ariaLabel = paymentOption.label;
        this.amountIsEditable = paymentOption.type === PaymentOptionType.EDITABLE;
        this.amountIsVariable = paymentOption.type === PaymentOptionType.VARIABLE;
        this.amountIsUnknown = paymentOption.type === PaymentOptionType.UNKNOWN;
        this.tooltip = paymentOption.tooltip;
        this.subtextLines = paymentOption.subtextLines || [];
        if (paymentOption.amount > 0 || paymentOption.amount === 0) {
            this.formattedAmount = NumberUtils.formatCurrency(paymentOption.amount);
            if (this.formattedAmount === this.label) {
                this.formattedAmount = ''; // Redundant info, don't show it
            }
            else {
                this.ariaLabel += `, ${this.formattedAmount}`;
            }
        }
        this.id = HtmlUtils.generateRandomId();
    }
    clearMessage() {
        this.message = '';
    }
}

class PaymentOptionsResult {
    constructor() {
        this.option = null;
        this.amount = -1;
        this.insufficientFunds = false;
    }
    get isValid() {
        if (this.option?.type === PaymentOptionType.UNKNOWN) {
            // Always valid, even with -1 amount.
            // Insufficient funds don't apply since the amount is unknown.
            return true;
        }
        if (this.insufficientFunds) {
            return false;
        }
        return this.amount > 0 || this.option?.type === PaymentOptionType.VARIABLE;
    }
}

class PaymentOptionsComponent extends BaseTextComponent {
    constructor(fb, modalService, windowService, textService) {
        super(textService, 'ui-workflows-payment-options');
        this.fb = fb;
        this.modalService = modalService;
        this.windowService = windowService;
        this.textService = textService;
        /**
        * Current valid payment options
        **/
        this.paymentOptions = [];
        /**
        * Controls form validation. If provided, "insufficient funds" validation is triggered
        * for options/amounts that exceed the available funds specified.
        **/
        this.availableFunds = null;
        /**
        * Optional info message to display beneath the amount input (when no payment options are available) or beneath
        * the payment option radio buttons.
        **/
        this.infoMessage = '';
        /**
        * Set to true to lock every form field.
        **/
        this.locked = false;
        /**
        * The initial value of the editable amount field.
        * This works with both payment options and the amount-only form.
        **/
        this.initialAmountValue = -1;
        /**
        * Set to true to enable the variable amount message for variable payment options.
        * Note: This message will not appear if the insufficient funds message is triggered via availableFunds input.
        **/
        this.showVariableAmountMessage = false;
        /**
        * Optional header that displays above payment option radio buttons. Default is "How much would you like to pay?"
        * Note: does not display in mobile.
        **/
        this.header = '';
        /**
        * Optional subheader that displays above payment option radio buttons and below the header.
        * Note: This supports html.
        **/
        this.subHeader = '';
        /**
        * Optional details that display above payment option radio buttons and below the subheader.
        * Note: This supports html.
        **/
        this.subHeaderDetails = [];
        /**
        * Optional mobile button label, default value is 'Select a payment option'.
        **/
        this.mobilePaymentOptionLabel = '';
        /**
        *  Emitted when the option changes. Only emits if payment options are provided.
        **/
        this.optionChanged = new EventEmitter();
        /**
        *  Emitted when the insufficient funds warning has been resolved. This only emits if the payment option
        *  workflow had been previously validated (ie: parent form submitted).
        **/
        this.insufficientFundsFixed = new EventEmitter();
        // When there are payment options to select. On mobile, this is inside a modal.
        this.radioOptions = [];
        this.radioOptionsErrorMessage = '';
        this.mobileButtonAmount = 0;
        this.mobileButtonErrorMessage = '';
        this.mobileButtonWarningMessage = '';
        this.mobileButtonInfoMessage = '';
        // When there are no payment options, we just show an amount field
        this.showAmountOnlyForm = true;
        // Used by all editable amount inputs
        this.amountWarningMessage = '';
        // Used to keep track of the selected option
        this.selectedPaymentOption = null;
        this.selectedPaymentOptionId = '';
        this.isMobile = false;
        this.hasSubHeaderContent = false;
        this.radioFieldId = '';
        this.workflowFormId = '';
        this.insufficientFundsTriggered = false;
        this.amountOnlyForm = this.fb.group({
            amount: [null, Validators.compose(this.amountInputValidators)],
        });
        this.mobileButtonForm = this.fb.group({
            paymentOptionSummary: [[], Validators.compose(this.mobileButtonValidators)],
        });
        this.editableAmountForm = this.fb.group({
            amount: [null, Validators.compose(this.amountInputValidators)],
        });
        this.windowService.windowSize$.pipe(this.takeUntilDestroyed()).subscribe(windowSize => {
            this.isMobile = windowSize.isMobile;
        });
        this.radioFieldId = HtmlUtils.generateRandomId();
        this.workflowFormId = HtmlUtils.generateRandomId();
    }
    ngOnChanges(changes) {
        if (changes.paymentOptions) {
            this.selectedPaymentOption = null;
            this.selectedPaymentOptionId = '';
            this.resetForms(changes.paymentOptions.isFirstChange());
        }
        else if (changes.initialAmountValue) {
            this.resetForms(changes.initialAmountValue.isFirstChange());
        }
        const needToRefresh = changes.availableFunds || (changes.showVariableAmountMessage && !this.showAmountOnlyForm);
        if (needToRefresh) {
            this.refreshVisibleForms();
        }
        this.hasSubHeaderContent = !!this.subHeader || this.subHeaderDetails.length > 0;
    }
    refreshVisibleForms() {
        if (this.showAmountOnlyForm) {
            FormUtils.updateValueAndValidity(this.amountOnlyForm);
        }
        else {
            this.setSelectedRadioMessage();
            FormUtils.updateValueAndValidity(this.editableAmountForm);
            FormUtils.updateValueAndValidity(this.mobileButtonForm);
        }
    }
    mobileWorkflowInitiated() {
        this.modalService.openMobileOnlyModal(this.mobileModal);
    }
    selectRadioButton(option) {
        const selectedId = option?.value || '';
        if (!option) {
            // Reset the workflow radio options
            this.selectedPaymentOption = null;
            this.selectedPaymentOptionId = '';
        }
        else if (!this.selectedPaymentOption || this.selectedPaymentOption.value !== selectedId) {
            // Set the selected option and related properties
            this.selectedPaymentOption = option;
            this.selectedPaymentOptionId = option.value || '';
            // Clear the error message since a radio option was selected
            this.radioOptionsErrorMessage = '';
            // Clear the editable amount form
            this.editableAmountForm.reset();
            // Update the selected radio option
            this.setSelectedRadioMessage();
            const emitValue = this.paymentOptions.find(po => po.id === this.selectedPaymentOptionId);
            this.optionChanged.emit(emitValue || null);
        }
        this.checkIfInsufficientFundsFixed();
    }
    setSelectedRadioMessage() {
        const matchingRadioOption = this.radioOptions.find(ro => ro.value === this.selectedPaymentOptionId);
        matchingRadioOption?.clearMessage();
        // Prioritize the insufficient funds warning over the variable amount message
        if (this.amountExceedsAvailableFunds(matchingRadioOption?.amount)) {
            matchingRadioOption.message = this.text.insufficientFundsMessage;
            matchingRadioOption.messageTheme = NotificationTheme.WARNING;
        }
        else if (matchingRadioOption?.amountIsVariable && this.showVariableAmountMessage) {
            matchingRadioOption.message = this.text.variableAmountMessage;
            matchingRadioOption.messageTheme = NotificationTheme.INFORMATION;
        }
    }
    amountExceedsAvailableFunds(value) {
        // Available funds can be positive, negative or zero.
        const hasAvailableFunds = !!this.availableFunds || this.availableFunds === 0;
        // Value must be greater than 0
        // Unknown amounts come through with -1, bypassing this logic as well
        const valueIsNumber = !isNaN(value) && value > 0;
        // Only do the math if we have two valid numbers. Things can get weird when one or the other is null.
        if (hasAvailableFunds && valueIsNumber) {
            return value > this.availableFunds;
        }
        return false;
    }
    submitModalWorkflow() {
        if (!this.selectedOptionIsValid()) {
            return;
        }
        // Update the mobile button form. This will be called again when the modal closes,
        // but it's a smoother user experience to do it before the modal animations run.
        this.updateMobileButtonForm();
        this.modalService.closeMostRecentMobileOnlyModal();
    }
    selectedOptionIsValid() {
        if (!this.selectedPaymentOption) {
            this.radioOptionsErrorMessage = this.text.requiredError;
            FormUtils.focusOnFirstError(this.workflowFormId);
            return false;
        }
        if (this.selectedPaymentOption.amountIsEditable) {
            FormUtils.showFormValidation(this.editableAmountForm);
            return this.editableAmountForm.valid;
        }
        return true;
    }
    onModalClose() {
        // Handle the scenario where the user uses the modal close button and not the submit button.
        this.updateMobileButtonForm();
    }
    updateMobileButtonForm() {
        const optionSummaryField = this.mobileButtonForm.get('paymentOptionSummary');
        const summaries = [];
        if (this.selectedPaymentOption?.amountIsEditable) {
            // Editable
            this.mobileButtonAmount = this.editableAmountForm.get('amount').value || 0;
            const value = `${this.selectedPaymentOption.label}: ${NumberUtils.formatCurrency(this.mobileButtonAmount)}`;
            summaries.push(this.getPaymentOptionSummary(value));
        }
        else if (this.selectedPaymentOption?.amount > 0) {
            // Fixed amount or variable payment with non-zero amount
            this.mobileButtonAmount = this.selectedPaymentOption.amount;
            // If there is a formatted amount, show it. It's possible the label is the same as the formatted amount.
            if (this.selectedPaymentOption.formattedAmount) {
                const message = `${this.selectedPaymentOption.label}: ${this.selectedPaymentOption.formattedAmount}`;
                summaries.push(this.getPaymentOptionSummary(message));
            }
            else {
                summaries.push(this.getPaymentOptionSummary(this.selectedPaymentOption.label));
            }
        }
        else if (this.selectedPaymentOption?.amountIsVariable || this.selectedPaymentOption?.amountIsUnknown) {
            // Variable payment with zero amount, or an Unknown payment
            this.mobileButtonAmount = 0;
            summaries.push(this.getPaymentOptionSummary(this.selectedPaymentOption.label));
        }
        else {
            this.mobileButtonAmount = 0;
        }
        optionSummaryField.setValue(summaries);
        // Update form control validation and validity
        FormUtils.showControlValidation(optionSummaryField);
        optionSummaryField.updateValueAndValidity();
    }
    getPaymentOptionSummary(message) {
        return new WorkflowButtonSummary('monetization_on', message);
    }
    resetForms(isFirstLoad) {
        const defaultRadioOption = this.setRadioOptions();
        const hasInitialValues = isFirstLoad && (!!defaultRadioOption || this.initialAmountValue > 0);
        // If there are no payment options, then there is no workflow to show.
        // We can only show an amount input. Reset the form if it was not showing previously.
        const wasShowingAmountOnlyForm = this.showAmountOnlyForm;
        this.showAmountOnlyForm = this.radioOptions.length === 0;
        if (this.showAmountOnlyForm && !wasShowingAmountOnlyForm) {
            this.amountOnlyForm.reset();
        }
        else if (!this.showAmountOnlyForm) {
            if (hasInitialValues && defaultRadioOption) {
                this.selectRadioButton(defaultRadioOption);
            }
            else {
                // Reset the radio buttons and clear the selected option
                this.selectRadioButton(null);
            }
            // Reset the forms completely
            this.editableAmountForm.reset();
            this.mobileButtonAmount = 0;
            this.mobileButtonForm.reset();
        }
        if (hasInitialValues) {
            if (this.initialAmountValue > 0) {
                if (this.showAmountOnlyForm) {
                    this.amountOnlyForm.get('amount').setValue(this.initialAmountValue);
                }
                else if (defaultRadioOption?.amountIsEditable) {
                    this.editableAmountForm.get('amount').setValue(this.initialAmountValue);
                }
            }
            if (this.isMobile) {
                this.updateMobileButtonForm();
            }
        }
    }
    setRadioOptions() {
        this.radioOptions = [];
        let defaultRadioOption = null;
        this.paymentOptions?.filter(o => this.isValidPaymentOption(o)).forEach(o => {
            const newRadio = new PaymentRadioButtonOption(o);
            if (newRadio.formattedAmount) {
                newRadio.ariaLabel = `${o.label}, ${newRadio.formattedAmount}`;
            }
            else {
                newRadio.ariaLabel = o.label;
            }
            const hasDuplicateValue = this.radioOptions.some(ro => ro.value === newRadio.value);
            if (!hasDuplicateValue) {
                this.radioOptions.push(newRadio);
                if (o.isDefault && !defaultRadioOption) {
                    defaultRadioOption = newRadio;
                }
            }
        });
        return defaultRadioOption;
    }
    isValidPaymentOption(option) {
        // Label, type and id are required for all options
        if (!option.label || !option.id || !option.type) {
            return false;
        }
        // Fixed amounts must be greater than 0.
        // Variable must have an amount, but zero is allowed.
        // Editable and Unknown should not have an amount set at all.
        if (option.type === PaymentOptionType.FIXED) {
            return option.amount > 0;
        }
        else if (option.type === PaymentOptionType.VARIABLE) {
            return option.amount === 0 || option.amount > 0;
        }
        else {
            return option.amount === -1;
        }
    }
    get amountInputValidators() {
        // These are used for all amount inputs
        return [
            Validators.required,
            FormUtils.createFormValidator(positiveAmount),
            this.amountInputInsufficientFundsValidator.bind(this)
        ];
    }
    amountInputInsufficientFundsValidator(control) {
        // This method technically isn't validating anything, but we want it to update the warning message
        // in place of an actual form error.
        const value = Number(control.value);
        if (this.amountExceedsAvailableFunds(value)) {
            this.amountWarningMessage = this.text.insufficientFundsMessage;
        }
        else {
            this.amountWarningMessage = '';
            this.checkIfInsufficientFundsFixed();
        }
        return null;
    }
    get mobileButtonValidators() {
        // Used for the mobile workflow button
        return [
            Validators.required,
            this.mobileButtonValidator.bind(this)
        ];
    }
    mobileButtonValidator(control) {
        const errors = {};
        const invalidEditableOption = this.selectedPaymentOption?.amountIsEditable && this.mobileButtonAmount === 0;
        if (invalidEditableOption) {
            errors['missing_amount'] = true;
            this.mobileButtonErrorMessage = this.text.missingEditableAmountError;
            return errors;
        }
        if (this.amountExceedsAvailableFunds(this.mobileButtonAmount)) {
            this.mobileButtonWarningMessage = this.text.insufficientFundsMessage;
        }
        else {
            this.mobileButtonWarningMessage = '';
        }
        if (this.selectedPaymentOption?.amountIsVariable && this.showVariableAmountMessage) {
            this.mobileButtonInfoMessage = this.text.variableAmountMessage;
        }
        else {
            this.mobileButtonInfoMessage = '';
        }
        this.mobileButtonErrorMessage = this.text.requiredError;
        return null;
    }
    getDefaultText() {
        return {
            amountLabel: 'Amount',
            paymentOptionsLabel: 'Select a payment option',
            variableAmountMessage: 'Varies based on amount due',
            insufficientFundsMessage: 'Insufficient funds',
            doneButton: 'Done',
            requiredError: 'Required',
            missingEditableAmountError: 'Amount required',
            placeholder: 'Select Amount',
            paymentOptionsHeader: 'How much would you like to pay?',
        };
    }
    validate() {
        // Validate visible forms
        if (this.showAmountOnlyForm && this.amountOnlyForm.invalid) {
            FormUtils.showFormValidation(this.amountOnlyForm);
            return null;
        }
        if (!this.showAmountOnlyForm && this.isMobile && this.mobileButtonForm.invalid) {
            FormUtils.showFormValidation(this.mobileButtonForm);
            return null;
        }
        if (!this.showAmountOnlyForm && !this.selectedOptionIsValid()) {
            return null;
        }
        return this.buildResult();
    }
    buildResult() {
        const result = new PaymentOptionsResult();
        if (this.showAmountOnlyForm) {
            result.amount = this.amountOnlyForm.value.amount;
        }
        else if (this.selectedOptionIsValid()) {
            result.option = this.paymentOptions.find(po => po.id === this.selectedPaymentOptionId);
            if (this.selectedPaymentOption.amountIsEditable) {
                result.amount = this.editableAmountForm.value.amount;
            }
            else {
                result.amount = this.selectedPaymentOption.amount;
            }
        }
        if (this.amountExceedsAvailableFunds(result.amount)) {
            result.insufficientFunds = true;
            this.insufficientFundsTriggered = true;
        }
        return result;
    }
    checkIfInsufficientFundsFixed() {
        if (this.insufficientFundsTriggered) {
            // If no warning is visible, then the funds were fixed.
            const warningVisible = !!this.amountWarningMessage || this.selectedPaymentOption?.messageTheme === NotificationTheme.WARNING;
            if (!warningVisible) {
                this.insufficientFundsFixed.emit();
                this.insufficientFundsTriggered = false;
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: PaymentOptionsComponent, deps: [{ token: i1.UntypedFormBuilder }, { token: i2.ModalService }, { token: i2.WindowService }, { token: i2.TextService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.17", type: PaymentOptionsComponent, isStandalone: false, selector: "ui-workflows-payment-options", inputs: { paymentOptions: "paymentOptions", availableFunds: "availableFunds", infoMessage: "infoMessage", locked: "locked", initialAmountValue: "initialAmountValue", showVariableAmountMessage: "showVariableAmountMessage", header: "header", subHeader: "subHeader", subHeaderDetails: "subHeaderDetails", mobilePaymentOptionLabel: "mobilePaymentOptionLabel" }, outputs: { optionChanged: "optionChanged", insufficientFundsFixed: "insufficientFundsFixed" }, viewQueries: [{ propertyName: "mobileModal", first: true, predicate: ["mobileModal"], descendants: true, static: true }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "@if (showAmountOnlyForm && amountOnlyForm) {\n    <form [formGroup]=\"amountOnlyForm\" uiForms [showNextField]=\"false\">\n        <div uiFormsRow>\n            <ui-forms-amount-input class=\"ui-form-control\"\n                [errorMessage]=\"text.requiredError\"\n                [warningMessage]=\"amountWarningMessage\"\n                [infoMessage]=\"infoMessage\"\n                formControlName=\"amount\"\n                [label]=\"text.amountLabel\"\n                [locked]=\"locked\">\n            </ui-forms-amount-input>\n        </div>\n    </form>\n}\n\n@if (!showAmountOnlyForm) {\n    @if (isMobile && mobileButtonForm) {\n        <form [formGroup]=\"mobileButtonForm\">\n            <ui-forms-workflow-button formControlName=\"paymentOptionSummary\"\n                [label]=\"mobilePaymentOptionLabel || text.paymentOptionsLabel\"\n                [errorMessage]=\"mobileButtonErrorMessage\"\n                [warningMessage]=\"mobileButtonWarningMessage\"\n                [infoMessage]=\"mobileButtonInfoMessage\"\n                placeholderIcon=\"monetization_on\"\n                [locked]=\"locked\"\n                [placeholder]=\"text.placeholder\"\n                (clicked)=\"mobileWorkflowInitiated()\"\n            ></ui-forms-workflow-button>\n        </form>\n    }\n\n    @if (!isMobile) {\n        <fieldset [attr.aria-describedby]=\"radioFieldId + '_validation-msg'\" role=\"radiogroup\">\n            @if (header || text.paymentOptionsHeader) {\n                <legend class=\"text-second mb-2\">\n                    {{ header || text.paymentOptionsHeader }}\n                </legend>\n            }\n\n            <ng-container [ngTemplateOutlet]=\"workflowFormTemplate\">\n            </ng-container>\n        </fieldset>\n    }\n}\n\n<ng-template #workflowFormTemplate>\n    <div uiForms [showNextField]=\"isMobile\" [id]=\"workflowFormId\">\n        @if (hasSubHeaderContent) {\n            <div class=\"text-caption mb-3\">\n                @if (subHeader) {\n                    <div [innerHTML]=\"subHeader\"></div>\n                }\n                @if (subHeaderDetails.length > 0) {\n                    <div class=\"d-flex flex-wrap\">\n                        @for (detail of subHeaderDetails; track detail) {\n                            <span class=\"pr-4\" [innerHTML]=\"detail\"></span>\n                        }\n                    </div>\n                }\n            </div>\n        }\n\n        <div class=\"ui-form-control\" [class.ng-invalid]=\"radioOptionsErrorMessage\" [class.ng-touched]=\"radioOptionsErrorMessage\">\n            <div class=\"radio-container\">\n                <div class=\"radio-group-container\"\n                    data-e2e=\"payment-options\"\n                    [class.vertical]=\"isMobile\"\n                    [class.three-column-grid]=\"!isMobile\">\n                    @for (option of radioOptions; track option.value; let i = $index) {\n                        <div class=\"radio-button-container\">\n                            <ui-forms-radio-button-option\n                                [label]=\"option.label\"\n                                [value]=\"option.value\"\n                                [name]=\"radioFieldId\"\n                                [checked]=\"selectedPaymentOptionId === option.value\"\n                                [locked]=\"locked\"\n                                uiCoreReplayUnmask\n                                [id]=\"radioFieldId + '-input' + i\"\n                                [e2e]=\"'payment-option-' + (i + 1)\"\n                                [ariaLabel]=\"option.ariaLabel\"\n                                [tooltip]=\"option.tooltip\"\n                                [ariaDescribedBy]=\"option.message ? option.id + '_validation-msg' : undefined\"\n                                (selection)=\"selectRadioButton(option)\"\n                                [hasInput]=\"option.amountIsEditable && option.value === selectedPaymentOptionId\"\n                                [class.edit-field-mobile]=\"isMobile && option.amountIsEditable && option.value === selectedPaymentOptionId\">\n                                @for (line of option.subtextLines; track line) {\n                                    <div class=\"radio-subtext text-caption text-color-tertiary mb-half\">\n                                        {{ line }}\n                                    </div>\n                                }\n                                @if (option.formattedAmount) {\n                                    <div class=\"radio-subtext text-second text-semibold\" aria-hidden=\"true\"\n                                        [attr.data-e2e]=\"'payment-option-' + (i + 1) + '-subtext'\">\n                                        {{ option.formattedAmount }}\n                                    </div>\n                                }\n                                @if (option.value === selectedPaymentOptionId) {\n                                    @if (option.message) {\n                                        <div class=\"mt-1\" [class.payment-option-notification]=\"!isMobile\" [id]=\"option.id + '_validation-msg'\" aria-live=\"polite\">\n                                            <ui-core-micro-notification [message]=\"option.message\" [theme]=\"option.messageTheme\" role=\"alert\"></ui-core-micro-notification>\n                                        </div>\n                                    }\n                                    @if (option.amountIsEditable) {\n                                        <form [formGroup]=\"editableAmountForm\" class=\"d-block mt-1\"\n                                            [class.payment-option-amount-form]=\"!isMobile\" [class.pr-1]=\"isMobile\">\n                                            <ui-forms-amount-input class=\"form-control-validation-m-0\"\n                                                [errorMessage]=\"text.requiredError\"\n                                                [warningMessage]=\"amountWarningMessage\"\n                                                formControlName=\"amount\"\n                                                [label]=\"option.label\"\n                                                [hideLabel]=\"true\"\n                                                [locked]=\"locked\">\n                                            </ui-forms-amount-input>\n                                        </form>\n                                    }\n                                }\n                            </ui-forms-radio-button-option>\n                        </div>\n                    }\n                </div>\n            </div>\n            <ui-forms-field-validation\n                [ariaInputName]=\"mobilePaymentOptionLabel || text.paymentOptionsLabel\"\n                [errorMessage]=\"radioOptionsErrorMessage\"\n                [infoMessage]=\"infoMessage\"\n                [fieldId]=\"radioFieldId\"\n                [locked]=\"locked\">\n            </ui-forms-field-validation>\n        </div>\n    </div>\n</ng-template>\n\n<ng-template #mobileModal>\n    <ui-core-modal [title]=\"mobilePaymentOptionLabel || text.paymentOptionsLabel\"\n        [primaryButtonText]=\"text.doneButton\"\n        e2e=\"payment-options\"\n        [lockScrim]=\"true\"\n        (primaryButtonClicked)=\"submitModalWorkflow()\"\n        (closed)=\"onModalClose()\">\n        <fieldset [attr.aria-describedby]=\"radioFieldId + '_validation-msg'\" role=\"radiogroup\">\n            <ng-container [ngTemplateOutlet]=\"workflowFormTemplate\">\n            </ng-container>\n        </fieldset>\n    </ui-core-modal>\n</ng-template>\n", styles: [".payment-option-amount-form{margin-left:-28px}.radio-container .radio-group-container{display:flex;padding-top:12px;padding-bottom:12px;margin-left:-8px}.radio-container .radio-group-container.vertical{flex-direction:column;margin-left:-8px}.radio-container .radio-group-container.vertical .radio-button-container{max-width:16rem}.radio-container .radio-group-container.three-column-grid{flex-wrap:wrap;gap:0px 24px}.radio-container .radio-group-container.three-column-grid .radio-button-container{width:calc((100% - 104px) / 3)}\n"], dependencies: [{ kind: "directive", type: i2$1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i2.MicroNotificationComponent, selector: "ui-core-micro-notification", inputs: ["message", "boldText", "theme", "containerTheme", "icon", "animationPath", "animationData", "animationFreeze", "animationFreezeFrame", "animationLoop", "animationLoopTotal", "ariaPrefix"] }, { kind: "component", type: i2.ModalComponent, selector: "ui-core-modal", inputs: ["headerTemplate", "footerTemplate", "noBodyPadding", "noHeaderBorder", "useFormRendererButtons", "useFooterButtons", "showPrimarySpinner", "useGlassBackground"] }, { kind: "directive", type: i2.ReplayUnmaskDirective, selector: "[uiCoreReplayUnmask]" }, { kind: "component", type: i4.AmountInputComponent, selector: "ui-forms-amount-input", inputs: ["decimalPlaces", "min", "hideIcon", "allowEmptyField"] }, { kind: "component", type: i4.FieldValidationComponent, selector: "ui-forms-field-validation", inputs: ["fieldId", "locked", "errorMessage", "infoMessage", "successMessage", "warningMessage", "ariaInputName", "criteria", "criteriaDescription"] }, { kind: "directive", type: i4.FormDirective, selector: "[uiForms]", inputs: ["showNextField", "autoFocus"], outputs: ["isValid"] }, { kind: "directive", type: i4.FormRowDirective, selector: "[uiFormsRow]", inputs: ["showRowClass"] }, { kind: "component", type: i4.RadioButtonOptionComponent, selector: "ui-forms-radio-button-option", inputs: ["label", "value", "name", "id", "checked", "locked", "hasTrailingContent", "labelClasses", "isFirst", "showHover", "tooltip", "hasInput", "e2e", "ariaLabel", "ariaDescribedBy", "description"], outputs: ["selection", "blurred"] }, { kind: "component", type: i4.WorkflowButtonComponent, selector: "ui-forms-workflow-button", inputs: ["placeholderIcon", "placeholder"], outputs: ["clicked"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: PaymentOptionsComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-workflows-payment-options', template: "@if (showAmountOnlyForm && amountOnlyForm) {\n    <form [formGroup]=\"amountOnlyForm\" uiForms [showNextField]=\"false\">\n        <div uiFormsRow>\n            <ui-forms-amount-input class=\"ui-form-control\"\n                [errorMessage]=\"text.requiredError\"\n                [warningMessage]=\"amountWarningMessage\"\n                [infoMessage]=\"infoMessage\"\n                formControlName=\"amount\"\n                [label]=\"text.amountLabel\"\n                [locked]=\"locked\">\n            </ui-forms-amount-input>\n        </div>\n    </form>\n}\n\n@if (!showAmountOnlyForm) {\n    @if (isMobile && mobileButtonForm) {\n        <form [formGroup]=\"mobileButtonForm\">\n            <ui-forms-workflow-button formControlName=\"paymentOptionSummary\"\n                [label]=\"mobilePaymentOptionLabel || text.paymentOptionsLabel\"\n                [errorMessage]=\"mobileButtonErrorMessage\"\n                [warningMessage]=\"mobileButtonWarningMessage\"\n                [infoMessage]=\"mobileButtonInfoMessage\"\n                placeholderIcon=\"monetization_on\"\n                [locked]=\"locked\"\n                [placeholder]=\"text.placeholder\"\n                (clicked)=\"mobileWorkflowInitiated()\"\n            ></ui-forms-workflow-button>\n        </form>\n    }\n\n    @if (!isMobile) {\n        <fieldset [attr.aria-describedby]=\"radioFieldId + '_validation-msg'\" role=\"radiogroup\">\n            @if (header || text.paymentOptionsHeader) {\n                <legend class=\"text-second mb-2\">\n                    {{ header || text.paymentOptionsHeader }}\n                </legend>\n            }\n\n            <ng-container [ngTemplateOutlet]=\"workflowFormTemplate\">\n            </ng-container>\n        </fieldset>\n    }\n}\n\n<ng-template #workflowFormTemplate>\n    <div uiForms [showNextField]=\"isMobile\" [id]=\"workflowFormId\">\n        @if (hasSubHeaderContent) {\n            <div class=\"text-caption mb-3\">\n                @if (subHeader) {\n                    <div [innerHTML]=\"subHeader\"></div>\n                }\n                @if (subHeaderDetails.length > 0) {\n                    <div class=\"d-flex flex-wrap\">\n                        @for (detail of subHeaderDetails; track detail) {\n                            <span class=\"pr-4\" [innerHTML]=\"detail\"></span>\n                        }\n                    </div>\n                }\n            </div>\n        }\n\n        <div class=\"ui-form-control\" [class.ng-invalid]=\"radioOptionsErrorMessage\" [class.ng-touched]=\"radioOptionsErrorMessage\">\n            <div class=\"radio-container\">\n                <div class=\"radio-group-container\"\n                    data-e2e=\"payment-options\"\n                    [class.vertical]=\"isMobile\"\n                    [class.three-column-grid]=\"!isMobile\">\n                    @for (option of radioOptions; track option.value; let i = $index) {\n                        <div class=\"radio-button-container\">\n                            <ui-forms-radio-button-option\n                                [label]=\"option.label\"\n                                [value]=\"option.value\"\n                                [name]=\"radioFieldId\"\n                                [checked]=\"selectedPaymentOptionId === option.value\"\n                                [locked]=\"locked\"\n                                uiCoreReplayUnmask\n                                [id]=\"radioFieldId + '-input' + i\"\n                                [e2e]=\"'payment-option-' + (i + 1)\"\n                                [ariaLabel]=\"option.ariaLabel\"\n                                [tooltip]=\"option.tooltip\"\n                                [ariaDescribedBy]=\"option.message ? option.id + '_validation-msg' : undefined\"\n                                (selection)=\"selectRadioButton(option)\"\n                                [hasInput]=\"option.amountIsEditable && option.value === selectedPaymentOptionId\"\n                                [class.edit-field-mobile]=\"isMobile && option.amountIsEditable && option.value === selectedPaymentOptionId\">\n                                @for (line of option.subtextLines; track line) {\n                                    <div class=\"radio-subtext text-caption text-color-tertiary mb-half\">\n                                        {{ line }}\n                                    </div>\n                                }\n                                @if (option.formattedAmount) {\n                                    <div class=\"radio-subtext text-second text-semibold\" aria-hidden=\"true\"\n                                        [attr.data-e2e]=\"'payment-option-' + (i + 1) + '-subtext'\">\n                                        {{ option.formattedAmount }}\n                                    </div>\n                                }\n                                @if (option.value === selectedPaymentOptionId) {\n                                    @if (option.message) {\n                                        <div class=\"mt-1\" [class.payment-option-notification]=\"!isMobile\" [id]=\"option.id + '_validation-msg'\" aria-live=\"polite\">\n                                            <ui-core-micro-notification [message]=\"option.message\" [theme]=\"option.messageTheme\" role=\"alert\"></ui-core-micro-notification>\n                                        </div>\n                                    }\n                                    @if (option.amountIsEditable) {\n                                        <form [formGroup]=\"editableAmountForm\" class=\"d-block mt-1\"\n                                            [class.payment-option-amount-form]=\"!isMobile\" [class.pr-1]=\"isMobile\">\n                                            <ui-forms-amount-input class=\"form-control-validation-m-0\"\n                                                [errorMessage]=\"text.requiredError\"\n                                                [warningMessage]=\"amountWarningMessage\"\n                                                formControlName=\"amount\"\n                                                [label]=\"option.label\"\n                                                [hideLabel]=\"true\"\n                                                [locked]=\"locked\">\n                                            </ui-forms-amount-input>\n                                        </form>\n                                    }\n                                }\n                            </ui-forms-radio-button-option>\n                        </div>\n                    }\n                </div>\n            </div>\n            <ui-forms-field-validation\n                [ariaInputName]=\"mobilePaymentOptionLabel || text.paymentOptionsLabel\"\n                [errorMessage]=\"radioOptionsErrorMessage\"\n                [infoMessage]=\"infoMessage\"\n                [fieldId]=\"radioFieldId\"\n                [locked]=\"locked\">\n            </ui-forms-field-validation>\n        </div>\n    </div>\n</ng-template>\n\n<ng-template #mobileModal>\n    <ui-core-modal [title]=\"mobilePaymentOptionLabel || text.paymentOptionsLabel\"\n        [primaryButtonText]=\"text.doneButton\"\n        e2e=\"payment-options\"\n        [lockScrim]=\"true\"\n        (primaryButtonClicked)=\"submitModalWorkflow()\"\n        (closed)=\"onModalClose()\">\n        <fieldset [attr.aria-describedby]=\"radioFieldId + '_validation-msg'\" role=\"radiogroup\">\n            <ng-container [ngTemplateOutlet]=\"workflowFormTemplate\">\n            </ng-container>\n        </fieldset>\n    </ui-core-modal>\n</ng-template>\n", styles: [".payment-option-amount-form{margin-left:-28px}.radio-container .radio-group-container{display:flex;padding-top:12px;padding-bottom:12px;margin-left:-8px}.radio-container .radio-group-container.vertical{flex-direction:column;margin-left:-8px}.radio-container .radio-group-container.vertical .radio-button-container{max-width:16rem}.radio-container .radio-group-container.three-column-grid{flex-wrap:wrap;gap:0px 24px}.radio-container .radio-group-container.three-column-grid .radio-button-container{width:calc((100% - 104px) / 3)}\n"] }]
        }], ctorParameters: () => [{ type: i1.UntypedFormBuilder }, { type: i2.ModalService }, { type: i2.WindowService }, { type: i2.TextService }], propDecorators: { mobileModal: [{
                type: ViewChild,
                args: ['mobileModal', { static: true }]
            }], paymentOptions: [{
                type: Input
            }], availableFunds: [{
                type: Input
            }], infoMessage: [{
                type: Input
            }], locked: [{
                type: Input
            }], initialAmountValue: [{
                type: Input
            }], showVariableAmountMessage: [{
                type: Input
            }], header: [{
                type: Input
            }], subHeader: [{
                type: Input
            }], subHeaderDetails: [{
                type: Input
            }], mobilePaymentOptionLabel: [{
                type: Input
            }], optionChanged: [{
                type: Output
            }], insufficientFundsFixed: [{
                type: Output
            }] } });

class RadioButtonCardOption {
    constructor() {
        this.label = '';
        this.description = '';
        this.id = ''; // Unique value
        this.isDefault = false;
        this.content = null;
        // Internal component use only
        this._hover = false;
    }
}

class RadioButtonCardsResult {
    constructor() {
        this.option = null;
    }
    get isValid() {
        return !!this.option;
    }
}

class RadioButtonCardsComponent extends BaseTextComponent {
    constructor(textService, windowService) {
        super(textService, 'ui-workflows-radio-button-cards');
        this.textService = textService;
        /**
        * Options eligible to be selected
        **/
        this.options = [];
        /**
        * Optional info message to display beneath the cards.
        **/
        this.infoMessage = '';
        /**
        * Optional error message to display beneath the cards.
        * Default value is "Required"
        **/
        this.errorMessage = '';
        /**
        * Required. Label that displays above all card options.
        **/
        this.label = '';
        /**
        * Optional. When true, displays cards in 3 columns on desktop instead of 2.
        * Mobile view always uses 1 column. Default is false.
        **/
        this.useThreeColumns = false;
        /**
        *  Emitted when the selected option changes.
        **/
        this.optionChanged = new EventEmitter();
        // Used to keep track of the selected option
        this.selectedOption = null;
        this.selectedOptionId = '';
        this.radioFieldId = '';
        this.radioOptions = [];
        this.showErrorState = false;
        this.isMobile = false;
        this.radioFieldId = HtmlUtils.generateRandomId();
        windowService.windowSize$.pipe(this.takeUntilDestroyed()).subscribe(windowSize => {
            this.isMobile = windowSize.isMobile;
        });
    }
    ngOnChanges(changes) {
        if (changes.options) {
            this.resetForms(changes.options.isFirstChange());
        }
    }
    setSelectedOption(option) {
        this.selectRadioButton(option);
    }
    clearSelectedOption() {
        // Funnel all selection through this method
        this.selectRadioButton(null);
    }
    selectRadioButton(option) {
        const selectedId = option?.id || '';
        if (!option) {
            // Reset the workflow radio options
            this.selectedOption = null;
            this.selectedOptionId = '';
        }
        else if (!this.selectedOption || this.selectedOption.id !== selectedId) {
            // Set the selected option and related properties
            this.selectedOption = option;
            this.selectedOptionId = option.id || '';
            // Clear the error message since a radio option was selected
            this.showErrorState = false;
            const emitValue = this.options.find(o => o.id === this.selectedOptionId);
            this.optionChanged.emit(emitValue || null);
        }
    }
    resetForms(isFirstLoad) {
        const defaultRadioOption = this.setRadioOptions();
        const hasInitialValues = isFirstLoad && defaultRadioOption;
        if (hasInitialValues && defaultRadioOption) {
            this.setSelectedOption(defaultRadioOption);
        }
        else {
            // Reset the radio buttons and clear the selected option
            this.clearSelectedOption();
        }
    }
    setRadioOptions() {
        this.radioOptions = [];
        let defaultRadioOption = null;
        this.options?.filter(o => o.id && o.label).forEach(o => {
            const hasDuplicateValue = this.radioOptions.some(ro => ro.id === o.id);
            if (!hasDuplicateValue) {
                this.radioOptions.push(o);
                if (o.isDefault && !defaultRadioOption) {
                    defaultRadioOption = o;
                }
            }
        });
        return defaultRadioOption;
    }
    getDefaultText() {
        return {
            requiredError: 'Required',
        };
    }
    validate() {
        const result = new RadioButtonCardsResult();
        result.option = this.selectedOption;
        this.showErrorState = !result.isValid;
        return result;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: RadioButtonCardsComponent, deps: [{ token: i2.TextService }, { token: i2.WindowService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.17", type: RadioButtonCardsComponent, isStandalone: false, selector: "ui-workflows-radio-button-cards", inputs: { options: "options", infoMessage: "infoMessage", errorMessage: "errorMessage", label: "label", useThreeColumns: "useThreeColumns", contentTemplate: "contentTemplate" }, outputs: { optionChanged: "optionChanged" }, usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<fieldset uiForms [showNextField]=\"false\" [attr.aria-describedby]=\"radioFieldId + '_validation-msg'\">\n\n    <div class=\"ui-form-control\" [class.ng-invalid]=\"showErrorState\" [class.ng-touched]=\"showErrorState\">\n\n        <div class=\"label-container\">\n            <legend uiCoreReplayUnmask>\n                {{ label }}\n            </legend>\n        </div>\n\n        <div data-e2e=\"radio-button-cards\" class=\"radio-button-cards-group\" [class.is-mobile]=\"isMobile\" [class.three-columns]=\"useThreeColumns\">\n            <ng-container *ngFor=\"let option of radioOptions; let i = index\">\n                <div class=\"radio-button-card container-bordered-interactive\"\n                    uiCoreHover (hovered)=\"option._hover = $event\"\n                    [class.selected-card]=\"option.id === selectedOptionId\"\n                    [class.invalid-card]=\"showErrorState\"\n                    (click)=\"setSelectedOption(option)\">\n                    <ui-forms-radio-button-option \n                        [label]=\"option.label\"\n                        [value]=\"option.id\"\n                        [name]=\"radioFieldId\"\n                        [id]=\"radioFieldId + '-input' + i\"\n                        [checked]=\"option.id === selectedOptionId\"\n                        [showHover]=\"option._hover\"\n                        [hasTrailingContent]=\"!!option.badge\"\n                        labelClasses=\"text-semibold\"\n                        [e2e]=\"'radio-button-card-option-' + (i + 1)\"\n                        [ariaLabel]=\"option.label\"\n                        [description]=\"option.description\"\n                        (selection)=\"selectRadioButton(option)\">\n                        @if (option.badge) {\n                            <ui-core-badge\n                                [message]=\"option.badge.message\"\n                                [theme]=\"option.badge.theme\"\n                                [framed]=\"option.badge.framed\"\n                                [icon]=\"option.badge.icon\"\n                                [iconPosition]=\"option.badge.iconPosition\"\n                                class=\"radio-button-cards-badge\">\n                            </ui-core-badge>\n                        }\n                    </ui-forms-radio-button-option>\n                    <div *ngIf=\"option.content && contentTemplate\" class=\"content-container\">\n                        <ng-container [ngTemplateOutlet]=\"contentTemplate\"\n                            [ngTemplateOutletContext]=\"{content: option.content}\">\n                        </ng-container>\n                    </div>\n                </div>\n            </ng-container>\n        </div>\n        <ui-forms-field-validation\n            [ariaInputName]=\"label\"\n            [errorMessage]=\"errorMessage || text.requiredError\"\n            [infoMessage]=\"infoMessage\"\n            [fieldId]=\"radioFieldId\">\n        </ui-forms-field-validation>\n\n    </div>\n\n</fieldset>", styles: [".radio-button-cards-group{display:grid;grid-template-columns:repeat(2,1fr);row-gap:28px;column-gap:28px;padding-top:12px;padding-bottom:12px}.radio-button-cards-group.three-columns{grid-template-columns:repeat(3,1fr)}.is-mobile .radio-button-cards-group{grid-template-columns:1fr}.is-mobile .radio-button-cards-group .radio-button-card{grid-column:span 1}.radio-button-cards-group .radio-button-card{padding:14px 14px 14px 8px;border:1px solid transparent}.radio-button-cards-group .radio-button-card.selected-card{border:1px solid var(--color-primary)!important;background-color:var(--color-hover)}.radio-button-cards-group .radio-button-card.invalid-card{border-color:var(--color-danger)}.radio-button-cards-group .radio-button-card:hover{box-shadow:var(--elevation-4)}.radio-button-cards-group .radio-description{display:block}.radio-button-cards-group .content-container{font-size:var(--type-body2-size);margin-left:calc(16px + var(--forms-radio-button-size));margin-top:8px}.radio-button-cards-badge{display:flex;align-items:center}\n"], dependencies: [{ kind: "directive", type: i2$1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2$1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2$1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: i2.BadgeComponent, selector: "ui-core-badge", inputs: ["message", "framed", "theme", "type", "centered", "icon", "iconPosition"] }, { kind: "directive", type: i2.HoverDirective, selector: "[uiCoreHover]", outputs: ["hovered"] }, { kind: "directive", type: i2.ReplayUnmaskDirective, selector: "[uiCoreReplayUnmask]" }, { kind: "component", type: i4.FieldValidationComponent, selector: "ui-forms-field-validation", inputs: ["fieldId", "locked", "errorMessage", "infoMessage", "successMessage", "warningMessage", "ariaInputName", "criteria", "criteriaDescription"] }, { kind: "directive", type: i4.FormDirective, selector: "[uiForms]", inputs: ["showNextField", "autoFocus"], outputs: ["isValid"] }, { kind: "component", type: i4.RadioButtonOptionComponent, selector: "ui-forms-radio-button-option", inputs: ["label", "value", "name", "id", "checked", "locked", "hasTrailingContent", "labelClasses", "isFirst", "showHover", "tooltip", "hasInput", "e2e", "ariaLabel", "ariaDescribedBy", "description"], outputs: ["selection", "blurred"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: RadioButtonCardsComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-workflows-radio-button-cards', template: "<fieldset uiForms [showNextField]=\"false\" [attr.aria-describedby]=\"radioFieldId + '_validation-msg'\">\n\n    <div class=\"ui-form-control\" [class.ng-invalid]=\"showErrorState\" [class.ng-touched]=\"showErrorState\">\n\n        <div class=\"label-container\">\n            <legend uiCoreReplayUnmask>\n                {{ label }}\n            </legend>\n        </div>\n\n        <div data-e2e=\"radio-button-cards\" class=\"radio-button-cards-group\" [class.is-mobile]=\"isMobile\" [class.three-columns]=\"useThreeColumns\">\n            <ng-container *ngFor=\"let option of radioOptions; let i = index\">\n                <div class=\"radio-button-card container-bordered-interactive\"\n                    uiCoreHover (hovered)=\"option._hover = $event\"\n                    [class.selected-card]=\"option.id === selectedOptionId\"\n                    [class.invalid-card]=\"showErrorState\"\n                    (click)=\"setSelectedOption(option)\">\n                    <ui-forms-radio-button-option \n                        [label]=\"option.label\"\n                        [value]=\"option.id\"\n                        [name]=\"radioFieldId\"\n                        [id]=\"radioFieldId + '-input' + i\"\n                        [checked]=\"option.id === selectedOptionId\"\n                        [showHover]=\"option._hover\"\n                        [hasTrailingContent]=\"!!option.badge\"\n                        labelClasses=\"text-semibold\"\n                        [e2e]=\"'radio-button-card-option-' + (i + 1)\"\n                        [ariaLabel]=\"option.label\"\n                        [description]=\"option.description\"\n                        (selection)=\"selectRadioButton(option)\">\n                        @if (option.badge) {\n                            <ui-core-badge\n                                [message]=\"option.badge.message\"\n                                [theme]=\"option.badge.theme\"\n                                [framed]=\"option.badge.framed\"\n                                [icon]=\"option.badge.icon\"\n                                [iconPosition]=\"option.badge.iconPosition\"\n                                class=\"radio-button-cards-badge\">\n                            </ui-core-badge>\n                        }\n                    </ui-forms-radio-button-option>\n                    <div *ngIf=\"option.content && contentTemplate\" class=\"content-container\">\n                        <ng-container [ngTemplateOutlet]=\"contentTemplate\"\n                            [ngTemplateOutletContext]=\"{content: option.content}\">\n                        </ng-container>\n                    </div>\n                </div>\n            </ng-container>\n        </div>\n        <ui-forms-field-validation\n            [ariaInputName]=\"label\"\n            [errorMessage]=\"errorMessage || text.requiredError\"\n            [infoMessage]=\"infoMessage\"\n            [fieldId]=\"radioFieldId\">\n        </ui-forms-field-validation>\n\n    </div>\n\n</fieldset>", styles: [".radio-button-cards-group{display:grid;grid-template-columns:repeat(2,1fr);row-gap:28px;column-gap:28px;padding-top:12px;padding-bottom:12px}.radio-button-cards-group.three-columns{grid-template-columns:repeat(3,1fr)}.is-mobile .radio-button-cards-group{grid-template-columns:1fr}.is-mobile .radio-button-cards-group .radio-button-card{grid-column:span 1}.radio-button-cards-group .radio-button-card{padding:14px 14px 14px 8px;border:1px solid transparent}.radio-button-cards-group .radio-button-card.selected-card{border:1px solid var(--color-primary)!important;background-color:var(--color-hover)}.radio-button-cards-group .radio-button-card.invalid-card{border-color:var(--color-danger)}.radio-button-cards-group .radio-button-card:hover{box-shadow:var(--elevation-4)}.radio-button-cards-group .radio-description{display:block}.radio-button-cards-group .content-container{font-size:var(--type-body2-size);margin-left:calc(16px + var(--forms-radio-button-size));margin-top:8px}.radio-button-cards-badge{display:flex;align-items:center}\n"] }]
        }], ctorParameters: () => [{ type: i2.TextService }, { type: i2.WindowService }], propDecorators: { options: [{
                type: Input
            }], infoMessage: [{
                type: Input
            }], errorMessage: [{
                type: Input
            }], label: [{
                type: Input
            }], useThreeColumns: [{
                type: Input
            }], contentTemplate: [{
                type: Input
            }], optionChanged: [{
                type: Output
            }] } });

var RecurringEndingType;
(function (RecurringEndingType) {
    RecurringEndingType["NEVER"] = "NEVER";
    RecurringEndingType["AFTER_NUMBER"] = "AFTER_NUMBER";
    RecurringEndingType["ON_DATE"] = "ON_DATE";
})(RecurringEndingType || (RecurringEndingType = {}));

var RecurringFallbackType;
(function (RecurringFallbackType) {
    RecurringFallbackType["PRIOR_DAY"] = "PRIOR_DAY";
    RecurringFallbackType["NEXT_DAY"] = "NEXT_DAY";
})(RecurringFallbackType || (RecurringFallbackType = {}));

class ScheduleOption {
    // If a frequency value was provided, then no frequency selection is required.
    get frequencyRequired() {
        return !this.frequency;
    }
    get feeAccountRequired() {
        return this.fee > 0 && !this.hideFeeAccount;
    }
    constructor(frequency = '') {
        this.frequency = frequency;
        this.fee = 0;
        this.hideFeeAccount = false;
        this.icon = '';
        this.label = '';
        this.description = '';
        this.isDefault = false;
    }
}

class ScheduleOptionsResult {
    constructor(requireFallback) {
        this.requireFallback = requireFallback;
        this.option = null;
        this.feeAccount = null;
        this.frequency = null;
        this.startDate = '';
        this.startMonth = null;
        this.firstDay = null;
        this.secondDay = null;
        this.ending = null;
        this.endingDate = '';
        this.endingNumber = null;
        this.fallback = null;
    }
    get isValid() {
        if (!this.option) {
            return false;
        }
        // If a fee account is required, make sure one was selected
        if (this.option.feeAccountRequired && !this.feeAccount) {
            return false;
        }
        // If it's one time, there's nothing left to check
        if (!this.option.frequencyRequired) {
            return true;
        }
        // Validate everything, including the fallback
        return this.areFrequencySelectionsValid(true);
    }
    areFrequencySelectionsValid(validateFallback) {
        // Future/Recurring options need a frequency and a start date
        if (!this.frequency || !this.isValidDateValue(this.startDate)) {
            return false;
        }
        const frequenciesWithEndings = [FrequencyType.RECURRING, FrequencyType.TWO_DAYS_A_MONTH];
        if (frequenciesWithEndings.includes(this.frequency.type)) {
            // For mobile validation, there is a scenario where we do not want to include the fallback in this check.
            const validFallback = !validateFallback || this.isValidFallback();
            return this.isValidEnding() && validFallback;
        }
        return true;
    }
    isValidDateValue(value) {
        return value && DateUtils.isDateValid(value);
    }
    isValidEnding() {
        if (this.ending === RecurringEndingType.NEVER) {
            return true;
        }
        if (this.ending === RecurringEndingType.ON_DATE && this.isValidDateValue(this.endingDate)) {
            return true;
        }
        if (this.ending === RecurringEndingType.AFTER_NUMBER && this.endingNumber > 1) {
            return true;
        }
        return false;
    }
    isValidFallback() {
        // Fallback is not always required
        if (this.requireFallback && !this.fallback) {
            return false;
        }
        return true;
    }
}

const MAX_DAYS = 31;
class TwoDaysAMonthHelper {
    static getMonthOptions(text) {
        const options = [];
        for (let i = 1; i < 13; i++) {
            const textKey = `month${i}Label`;
            const label = text[textKey] || '';
            if (label) {
                options.push(new DropdownOption(label, i));
            }
        }
        return options;
    }
    static getMonthValue(initValue, dateProvider) {
        if (initValue && initValue > 0 && initValue < 13) {
            return initValue;
        }
        // Return the current month
        return this.getTodayAsCalendarDate(dateProvider).month;
    }
    static calculateFirstPaymentDate(month, firstPaymentDay, secondPaymentDay, earliestDate, dateProvider) {
        if (!firstPaymentDay || !secondPaymentDay || !month || !earliestDate) {
            return null;
        }
        const paymentCalendarDate = this.getTodayAsCalendarDate(dateProvider);
        // If the selected payment month is in the past, go to the next year.
        if (month < paymentCalendarDate.month) {
            paymentCalendarDate.year++;
        }
        // Start off with the selected month and the first payment day.
        paymentCalendarDate.month = month;
        paymentCalendarDate.day = firstPaymentDay;
        while (paymentCalendarDate.toDate() < earliestDate) {
            if (paymentCalendarDate.day === firstPaymentDay) {
                // If the first day is ineligible, try the second day.
                paymentCalendarDate.day = secondPaymentDay;
            }
            else {
                // If the second day is ineligible, bump the month and go back to the first day.
                paymentCalendarDate.day = firstPaymentDay;
                if (paymentCalendarDate.month === 12) {
                    paymentCalendarDate.month = 1;
                    paymentCalendarDate.year++;
                }
                else {
                    paymentCalendarDate.month++;
                }
            }
        }
        return paymentCalendarDate.toDate();
    }
    static getFirstPaymentDisabledDays(dayBuffer) {
        const result = [];
        if (dayBuffer > 0) {
            // If the buffer is 6 days, disable 26/27/28/29/30/31.
            // 31 - 6 + 1 = 26. Add one back to get exactly 6 days.
            let startIndex = MAX_DAYS - dayBuffer + 1;
            while (startIndex <= MAX_DAYS) {
                result.push(startIndex);
                startIndex++;
            }
        }
        return result;
    }
    static getSecondPaymentDisabledDays(dayBuffer, firstDay) {
        const result = [];
        if (dayBuffer > 0) {
            let startIndex = 1;
            // If the first day is null (not picked yet) behave as if the first were picked
            const endIndex = dayBuffer + (firstDay || 1) - 1;
            while (startIndex <= endIndex) {
                result.push(startIndex);
                startIndex++;
            }
            // If the first day is the 4th and we need 6 buffer days, then we need to disable days 30 and 31
            // If the first day is null, leave the end of the month available.
            if (firstDay && firstDay < dayBuffer) {
                const wrappedDaysToDisable = dayBuffer - firstDay;
                for (let i = 0; i < wrappedDaysToDisable; i++) {
                    result.push(MAX_DAYS - i);
                }
            }
        }
        return result.sort();
    }
    static getTodayAsCalendarDate(dateProvider) {
        return CalendarDate.fromDate(dateProvider.getFIStartOfDay());
    }
}

class ScheduleOptionsComponent extends BaseTextComponent {
    constructor(fb, modalService, windowService, dateProvider, textService) {
        super(textService, 'ui-workflows-schedule-options');
        this.fb = fb;
        this.modalService = modalService;
        this.windowService = windowService;
        this.dateProvider = dateProvider;
        this.textService = textService;
        /**
        * Allowed schedule options to present in the schedule dropdown.
        * At least one must be provided. If only one is provided, it is visually hidden.
        **/
        this.scheduleOptions = [];
        /**
        * Customizable label for schedule dropdown. Default is "Send".
        **/
        this.scheduleLabel = '';
        /**
        * Customizable tooltip for schedule dropdown. Default is blank (no tooltip).
        **/
        this.scheduleTooltip = '';
        /**
        * Allowed frequency options
        **/
        this.frequencyOptions = [];
        /**
        * A warning message to display beneath the frequency dropdown.
        **/
        this.frequencyWarningMessage = '';
        /**
        * Allowed options for paying schedule fee
        **/
        this.feeAccountOptions = [];
        /**
        * Set to true to lock every form field.
        **/
        this.locked = false;
        /**
        * Disables start date holidays
        **/
        this.startDateDisableHolidays = false;
        /**
        * Disables start date weekends
        **/
        this.startDateDisableWeekends = false;
        /**
        * The earliest possible start date.
        **/
        this.startDateMinDate = null;
        /**
        * A success message to display beneath the start date.
        **/
        this.startDateSuccessMessage = '';
        /**
        * Optional messaging about the selected date.
        **/
        this.startDateSelectedDateText = '';
        /**
        * Controls optional messaging about lead days before or after the selected start date.
        **/
        this.startDateLeadDays = -1;
        /**
        * Optional messaging about about lead days.
        **/
        this.startDateLeadDaysMessage = '';
        /**
        * Lead days by default are calculated before the selected date,
        * but can be enabled for after the selected date.
        **/
        this.leadDaysAreAfterSelectedDate = false;
        /**
        * Controls optional messaging about a marked date
        **/
        this.startDateMarkedDate = null;
        /**
        * Optional messaging about a marked date.
        **/
        this.startDateMarkedDateText = '';
        /**
        * Control visibility of the start date option.
        * Only applied when the selected frequency is ONE_TIME_FUTURE.
        * Note: the result is considered invalid as no start date is selected.
        **/
        this.startDateHidden = false;
        /**
        * Array of Holidays used to prevent selection
        **/
        this.holidays = [];
        /**
        * Array of allowed RecurringEndingType. An empty array means all are valid.
        **/
        this.endingTypes = [];
        /**
        * The maximum number when RecurringEndingType AFTER_NUMBER is selected
        **/
        this.maxNumberRecurring = -1;
        /**
        * Control visibility of the fallback options.
        **/
        this.showFallbackTypes = false;
        /**
        * The initial value of the frequency dropdown.
        **/
        this.initialFrequencyValue = '';
        /**
        * The initial value of the start date field.
        **/
        this.initialStartDateValue = '';
        /**
        * The initial value of the first day field (TWO_DAYS_A_MONTH only).
        **/
        this.initialFirstDayValue = null;
        /**
        * The initial value of the second day field (TWO_DAYS_A_MONTH only).
        **/
        this.initialSecondDayValue = null;
        /**
        * The initial value of the start month field (TWO_DAYS_A_MONTH only).
        **/
        this.initialStartMonthValue = null;
        /**
        * The initial value of the ending field.
        **/
        this.initialEndingValue = null;
        /**
        * The initial value of the ending date field.
        **/
        this.initialEndingDateValue = '';
        /**
        * The initial value of the ending number field.
        **/
        this.initialEndingNumberValue = null;
        /**
        * The initial value of the fee account dropdown.
        **/
        this.initialFeeAccountValue = '';
        /**
        * The initial value of the recurring fallback radio buttons.
        **/
        this.initialFallbackValue = null;
        /**
        *  Emitted when the schedule changes.
        **/
        this.scheduleChanged = new EventEmitter();
        /**
        *  Emitted when the frequency changes.
        **/
        this.frequencyChanged = new EventEmitter();
        /**
        *  Emitted when the start date changes.
        **/
        this.startDateChanged = new EventEmitter();
        /**
        *  Emitted when the start date action is clicked.
        **/
        this.startDateActionButtonClicked = new EventEmitter();
        // Schedule form is always presented
        this.scheduleFormRows = [];
        this.selectedScheduleOption = null;
        this.selectedFeeAccount = null;
        // Frequency form is presented in a modal in mobile (launched by workflow button)
        this.showFrequencyForm = false;
        this.frequencyFormRows = [];
        this.selectedFrequencyOption = null;
        this.firstDayValue = null;
        this.secondDayValue = null;
        this.startMonthValue = null;
        this.mobileFrequencyButtonErrorMessage = '';
        // Frequency form presented in the modal
        this.hasOpenedMobileModal = false;
        this.modalClosedBySubmission = false;
        // Fallback Form - not always enabled
        this.fallbackFormRows = [];
        this.isMobile = false;
        this.mobileFrequencyButtonForm = this.fb.group({
            scheduleOptionSummary: [[], Validators.compose(this.mobileButtonValidators)],
        });
        this.windowService.windowSize$.pipe(this.takeUntilDestroyed()).subscribe(windowSize => {
            this.isMobile = windowSize.isMobile;
            this.updateMobileFrequencyButtonForm();
        });
    }
    ngOnChanges(changes) {
        if (changes.scheduleOptions && this.scheduleOptions.length > 0) {
            // Reset flags and let selection events update these
            this.selectedScheduleOption = null;
            this.selectedFeeAccount = null;
            this.buildScheduleFormRows();
        }
        if (changes.frequencyOptions && this.frequencyOptions.length > 0) {
            // Reset flags and let selection events update these
            this.selectedFrequencyOption = null;
            this.buildFrequencyFormRows();
        }
        if (changes.showFallbackTypes) {
            this.buildFallbackFormRows();
        }
        // If any of these change, we need to update the start date field.
        const startDateValidationChanged = changes.startDateDisableHolidays ||
            changes.startDateDisableWeekends ||
            changes.startDateMinDate;
        if (startDateValidationChanged) {
            this.updateStartDateValidation(true);
        }
        const isOneTimeFuture = this.selectedFrequencyOption?.type === FrequencyType.ONE_TIME_FUTURE;
        if (changes.startDateHidden && this.startDateField && isOneTimeFuture) {
            this.startDateField.visible = !this.startDateHidden;
            this.updateMobileFrequencyButtonForm();
        }
        // These messages are display only, so we just need to set them on the form field.
        const scheduleMessagingChanged = changes.scheduleTooltip || changes.scheduleLabel;
        if (scheduleMessagingChanged && this.scheduleDropdownField) {
            this.scheduleDropdownField.tooltip = this.scheduleTooltip || '';
            this.scheduleDropdownField.label = this.scheduleLabel || this.text.scheduleLabel;
        }
        if (this.startDateField) {
            this.startDateField.successMessage = this.startDateSuccessMessage;
            this.startDateField.selectedDateText = this.startDateSelectedDateText;
            if (this.startDateLeadDays > -1 && this.startDateLeadDaysMessage) {
                if (this.leadDaysAreAfterSelectedDate) {
                    this.startDateField.daysAfter = this.startDateLeadDays;
                    this.startDateField.afterDateText = this.startDateLeadDaysMessage;
                }
                else {
                    this.startDateField.daysPrior = this.startDateLeadDays;
                    this.startDateField.priorDateText = this.startDateLeadDaysMessage;
                }
            }
            if (this.startDateMarkedDate && this.startDateMarkedDateText) {
                this.startDateField.markedDate = this.startDateMarkedDate;
                this.startDateField.markedDateText = this.startDateMarkedDateText;
            }
        }
        if (changes.frequencyWarningMessage && this.frequencyDropdownField) {
            this.frequencyDropdownField.warningMessage = this.frequencyWarningMessage;
        }
    }
    /* Build Schedule Form */
    buildScheduleFormRows() {
        const validScheduleOptions = this.scheduleOptions.filter(o => this.isValidScheduleOption(o));
        const initialScheduleOption = this.getInitialScheduleOption(validScheduleOptions);
        const scheduleValue = initialScheduleOption?.id || '';
        const scheduleLabel = this.scheduleLabel || this.text.scheduleLabel;
        this.scheduleDropdownField = new TemplateDropdownField('schedule', scheduleLabel, scheduleValue, true);
        this.scheduleDropdownField.errorMessage = this.text.requiredError;
        this.scheduleDropdownField.tooltip = this.scheduleTooltip || '';
        this.scheduleDropdownField.groups = [this.getScheduleDropdownGroup(validScheduleOptions)];
        // Hide the dropdown if there is only one option
        this.scheduleDropdownField.visible = validScheduleOptions.length > 1;
        const feeAccountValue = this.initialFeeAccountValue || '';
        this.feeAccountDropdownField = new TemplateDropdownField('feeAccount', '', feeAccountValue, true);
        this.feeAccountDropdownField.errorMessage = this.text.requiredError;
        this.feeAccountDropdownField.groups = this.feeAccountOptions;
        this.feeAccountDropdownField.visible = false;
        this.onScheduleChanged(initialScheduleOption);
        const scheduleRow = new FormRendererRow([this.scheduleDropdownField]);
        const feeAccountRow = new FormRendererRow([this.feeAccountDropdownField]);
        this.scheduleFormRows = [
            scheduleRow,
            feeAccountRow
        ];
    }
    getInitialScheduleOption(allValidOptions) {
        // Look for a specified default option.
        const validDefaultOptions = allValidOptions.filter(o => o.isDefault);
        if (validDefaultOptions.length > 0) {
            return validDefaultOptions[0];
        }
        // Otherwise return the first option.
        return allValidOptions.length > 0 ? allValidOptions[0] : null;
    }
    isValidScheduleOption(option) {
        return !!(option.label && option.id);
    }
    getScheduleDropdownGroup(allValidOptions) {
        const dropdownOptions = allValidOptions.map(o => {
            const data = new ContentTemplateData();
            data.icon = o.icon;
            data.topLeft = o.label;
            data.topRight = o.fee > 0 ? NumberUtils.formatCurrency(o.fee) : '';
            data.bottomLeft = o.description;
            const dropdownOption = new TemplateDropdownOption(o.id, data);
            dropdownOption.object = o;
            return dropdownOption;
        });
        // Single group with a flat list
        return new TemplateGroup(dropdownOptions);
    }
    /* Schedule Form Events */
    onScheduleFormSelection(event) {
        switch (event.fieldName) {
            case 'schedule':
                this.onScheduleChanged(event.singleSelectValue);
                break;
            case 'feeAccount':
                this.selectedFeeAccount = event.singleSelectValue || null;
                break;
        }
    }
    onScheduleChanged(selectedOption) {
        this.selectedScheduleOption = selectedOption;
        if (selectedOption.feeAccountRequired && this.feeAccountOptions.length > 0) {
            this.feeAccountDropdownField.visible = true;
            const feeAccountLabel = format(this.text.feeAccountLabel, { fee: NumberUtils.formatCurrency(selectedOption.fee) });
            this.feeAccountDropdownField.label = feeAccountLabel;
        }
        else {
            this.feeAccountDropdownField.visible = false;
        }
        // Update visibility on frequency rows
        const frequencyFormWasHidden = !this.showFrequencyForm;
        this.showFrequencyForm = selectedOption.frequencyRequired;
        // If the mobile frequency button form has appeared, make sure the frequency is up to date by calling
        // onFrequencyChanged, which also emits to the parent, and then update the button form.
        if (this.isMobile && frequencyFormWasHidden && this.showFrequencyForm) {
            if (this.selectedFrequencyOption) {
                this.onFrequencyChanged(this.selectedFrequencyOption.id);
            }
            this.updateMobileFrequencyButtonForm();
        }
        this.scheduleChanged.emit(selectedOption);
    }
    /* Build Frequency Form */
    buildFrequencyFormRows() {
        const validFrequencyOptions = this.frequencyOptions.filter(o => this.isValidFrequencyOption(o));
        const initialFrequencyOption = this.getInitialFrequencyOption(validFrequencyOptions);
        const frequencyValue = initialFrequencyOption?.id || '';
        this.frequencyDropdownField = new DropdownField('frequency', this.text.frequencyLabel, frequencyValue, true);
        this.frequencyDropdownField.errorMessage = this.text.requiredError;
        this.frequencyDropdownField.iconLeft = 'schedule';
        this.frequencyDropdownField.mobileAutoOpen = true;
        this.frequencyDropdownField.options = this.getFrequencyDropdownOptions(validFrequencyOptions);
        this.frequencyDropdownField.warningMessage = this.frequencyWarningMessage;
        let startDateValue = this.initialStartDateValue || '';
        this.startDateField = new DatepickerField('startDate', '', startDateValue, true);
        this.startDateField.iconLeft = 'today';
        this.startDateField.holidays = this.holidays;
        this.startDateField.errorMessage = this.text.requiredError;
        this.startDateField.successMessage = this.startDateSuccessMessage;
        this.updateStartDateValidation(false);
        const endingOptions = this.getEndingOptions();
        let endingValue = this.initialEndingValue || '';
        if (endingValue && !endingOptions.some(o => o.value === endingValue)) {
            endingValue = '';
        }
        this.endingDropdownField = new DropdownField('ending', this.text.endingLabel, endingValue, true);
        this.endingDropdownField.visible = false;
        this.endingDropdownField.errorMessage = this.text.requiredError;
        this.endingDropdownField.iconLeft = 'event';
        this.endingDropdownField.options = endingOptions;
        const endingNumberValue = this.initialEndingNumberValue || null;
        this.endingNumberField = new NumberInputField('endingNumber', this.text.endingNumberLabel, endingNumberValue, true);
        this.endingNumberField.visible = false;
        this.endingNumberField.min = 2; // Must select 2 or more
        this.endingNumberField.errorMessage = this.text.endingNumberError;
        if (this.maxNumberRecurring >= this.endingNumberField.min) {
            this.endingNumberField.max = this.maxNumberRecurring;
            this.endingNumberField.errorMessage = format(this.text.endingNumberWithMaxError, { maxEndingNumber: NumberUtils.formatNumber(this.maxNumberRecurring) });
        }
        const endingDateValue = this.initialEndingDateValue || '';
        this.endingDateField = new DatepickerField('endingDate', this.text.endingDateLabel, endingDateValue, true);
        this.endingDateField.visible = false;
        this.endingDateField.holidays = this.holidays; // Holidays are always the same
        this.endingDateField.errorMessage = this.text.requiredError;
        this.endingDateField.mobileAutoOpen = !this.initialEndingDateValue;
        this.updateEndingDateValidation(false, startDateValue);
        const frequencyAndStartRow = new FormRendererRow([this.frequencyDropdownField, this.startDateField]);
        const twiceAMonthRows = this.getTwiceAMonthFormRows();
        const endingRow = new FormRendererRow([this.endingDropdownField, this.endingNumberField, this.endingDateField]);
        endingRow.threeColumns = false; // Even though there are 3 fields, only a max of 2 will ever display
        this.frequencyFormRows = [
            frequencyAndStartRow,
            ...twiceAMonthRows,
            endingRow
        ];
        // If there's an initial frequency option, call into the handler for the frequency dropdown.
        // This initializes the frequency form for mobile (even though it isn't visible, as the button form is present)
        // and also emits a change event for parent components. On desktop, we just need to refresh the visibilities.
        if (this.isMobile && initialFrequencyOption) {
            this.onFrequencyChanged(initialFrequencyOption.id);
            this.updateMobileFrequencyButtonForm();
        }
        else if (!this.isMobile && initialFrequencyOption) {
            this.setFrequencyFieldVisibility(initialFrequencyOption);
        }
    }
    isValidFrequencyOption(option) {
        if (!option.label || !option.id || !option.type) {
            return false;
        }
        // startDateLabel required for all except TWO_DAYS_A_MONTH
        if (option.type !== FrequencyType.TWO_DAYS_A_MONTH) {
            return !!option.startDateLabel;
        }
        // TWO_DAYS_A_MONTH has some special requirements
        if (option.type === FrequencyType.TWO_DAYS_A_MONTH) {
            return !!option.firstDayLabel && !!option.secondDayLabel;
        }
        return true;
    }
    getInitialFrequencyOption(allValidOptions) {
        if (this.initialFrequencyValue) {
            const match = allValidOptions.find(o => o.id === this.initialFrequencyValue);
            if (match) {
                return match;
            }
        }
        if (this.selectedFrequencyOption) {
            return this.selectedFrequencyOption;
        }
        // On mobile, do not auto-pick the first option as it looks really odd in the workflow button.
        if (this.isMobile) {
            return null;
        }
        // If there is no match, pick the first option
        return allValidOptions.length > 0 ? allValidOptions[0] : null;
    }
    getFrequencyDropdownOptions(allValidOptions) {
        return allValidOptions.map(o => new DropdownOption(o.label, o.id));
    }
    getTwiceAMonthFormRows() {
        this.twiceAMonthGroup = new FormRendererGroup();
        this.firstDayField = new NumberInputField('firstDay', '', this.initialFirstDayValue, true);
        this.firstDayField.dayOfMonthPicker = true;
        this.firstDayField.errorMessage = this.text.requiredError;
        this.secondDayField = new NumberInputField('secondDay', '', this.initialSecondDayValue, true);
        this.secondDayField.dayOfMonthPicker = true;
        this.secondDayField.errorMessage = this.text.requiredError;
        const startMonthValue = TwoDaysAMonthHelper.getMonthValue(this.initialStartMonthValue, this.dateProvider);
        this.startMonthField = new DropdownField('startMonth', this.text.startMonthLabel, startMonthValue, true);
        this.startMonthField.options = TwoDaysAMonthHelper.getMonthOptions(this.text);
        this.startMonthField.errorMessage = this.text.requiredError;
        return [
            new FormRendererRow([this.firstDayField, this.secondDayField], this.twiceAMonthGroup),
            new FormRendererRow([this.startMonthField], this.twiceAMonthGroup),
        ];
    }
    getAllowedEndingTypes() {
        const allEndings = [RecurringEndingType.NEVER, RecurringEndingType.AFTER_NUMBER, RecurringEndingType.ON_DATE];
        return this.endingTypes?.length > 0 ? this.endingTypes : allEndings;
    }
    getEndingOptions() {
        return this.getAllowedEndingTypes().map(ending => {
            let label = this.text.neverEndingOptionLabel;
            if (ending === RecurringEndingType.AFTER_NUMBER) {
                label = this.text.afterNumberEndingOptionLabel;
            }
            else if (ending === RecurringEndingType.ON_DATE) {
                label = this.text.onDateEndingOptionLabel;
            }
            return new DropdownOption(label, ending);
        });
    }
    updateStartDateValidation(updateValidity) {
        if (!this.startDateField) {
            return;
        }
        this.startDateField.disableHolidays = this.startDateDisableHolidays;
        this.startDateField.disableWeekends = this.startDateDisableWeekends;
        this.startDateField.minDate = this.getMinStartDate();
        if (updateValidity) {
            this.startDateField.updateValueAndValidity();
        }
    }
    getMinStartDate() {
        // If no start date is provided, use today.
        return this.startDateMinDate ? new Date(this.startDateMinDate) : this.dateProvider.getFIStartOfDay();
    }
    updateEndingDateValidation(updateValidity, startDateValue, addMonth = false) {
        if (!this.endingDateField) {
            return;
        }
        let dateValue = this.getMinStartDate();
        // If it comes from the start date field, it's a string. But other times it's a date object.
        if (startDateValue && typeof startDateValue === 'string') {
            dateValue = DateUtils.parseFIDate(startDateValue);
        }
        else if (startDateValue && typeof startDateValue === 'object') {
            dateValue = new Date(startDateValue);
        }
        // In most cases, the min end date needs to be one day after the start date.
        // In TWO_DAYS_A_MONTH, it needs to be a full month.
        if (addMonth) {
            this.endingDateField.minDate = DateUtils.addMonths(dateValue, 1);
        }
        else {
            this.endingDateField.minDate = DateUtils.addDays(dateValue, 1);
        }
        if (updateValidity) {
            this.endingDateField.updateValueAndValidity();
        }
        // If formRenderer is currently visible, and endDate has a value, show form validation.
        // The field may have been invalidated
        const endDateFormField = this.frequencyForm?.form.get('endingDate') || null;
        if (endDateFormField?.value) {
            FormUtils.showControlValidation(endDateFormField);
        }
    }
    /* Frequency Form Events */
    onFrequencyFormSelection(event) {
        switch (event.fieldName) {
            case 'frequency':
                this.onFrequencyChanged(event.singleSelectValue);
                break;
            case 'ending':
                this.onEndingChanged(event.singleSelectValue);
                break;
            case 'startDate':
                this.onStartDateChanged(event.singleSelectValue);
                break;
            case 'endingDate':
                this.onEndingDateChanged(event.singleSelectValue);
                break;
            case 'startMonth':
                this.startMonthValue = event.singleSelectValue;
                this.calculateTwoDaysAMonthStartDate();
                break;
            case 'firstDay':
                this.onFirstDayChanged(event.singleSelectValue);
                this.calculateTwoDaysAMonthStartDate();
                break;
            case 'secondDay':
                this.secondDayValue = event.singleSelectValue;
                this.calculateTwoDaysAMonthStartDate();
                break;
        }
    }
    onFrequencyChanged(selectedId) {
        this.selectedFrequencyOption = this.frequencyOptions.find(fo => fo.id === selectedId) || null;
        this.setFrequencyFieldVisibility(this.selectedFrequencyOption);
        this.frequencyChanged.emit(this.selectedFrequencyOption);
    }
    setFrequencyFieldVisibility(option) {
        const type = option?.type || null;
        switch (type) {
            case FrequencyType.ONE_TIME_FUTURE:
                this.showStartDateField(option);
                this.twiceAMonthGroup.visible = false;
                this.hideRecurringFields();
                break;
            case FrequencyType.RECURRING:
                this.showStartDateField(option);
                this.twiceAMonthGroup.visible = false;
                this.showRecurringFields();
                break;
            case FrequencyType.TWO_DAYS_A_MONTH:
                this.startDateField.visible = false;
                this.showTwiceAMonthFields(option);
                // Two days a month is a recurring type, and needs the same fields
                this.showRecurringFields();
                break;
            default:
                // This is rare but it does happen on mobile if the user launches the modal,
                // but closes the occurs dropdown instead of making a selection.
                // Hide all the dynamic fields.
                this.startDateField.visible = false;
                this.twiceAMonthGroup.visible = false;
                this.hideRecurringFields();
                break;
        }
    }
    onEndingChanged(ending) {
        const invalidEnding = ending && !this.getAllowedEndingTypes().includes(ending);
        if (!ending || ending === RecurringEndingType.NEVER || invalidEnding) {
            this.endingNumberField.visible = false;
            this.endingDateField.visible = false;
        }
        else if (ending === RecurringEndingType.AFTER_NUMBER) {
            this.endingNumberField.visible = true;
            this.endingDateField.visible = false;
        }
        else if (ending === RecurringEndingType.ON_DATE) {
            this.endingNumberField.visible = false;
            this.endingDateField.visible = true;
        }
    }
    onStartDateChanged(startDate) {
        if (startDate && DateUtils.isDateValid(startDate)) {
            this.updateEndingDateValidation(true, startDate);
            this.startDateChanged.emit(startDate);
        }
        else {
            this.startDateChanged.emit('');
        }
    }
    onEndingDateChanged(endingDate) {
        if (endingDate && DateUtils.isDateValid(endingDate)) {
            this.endingDateField.mobileAutoOpen = false;
        }
    }
    onFirstDayChanged(day) {
        this.firstDayValue = day;
        const dayBuffer = this.selectedFrequencyOption?.dayBuffer || 0;
        const dayBufferMessage = this.selectedFrequencyOption?.dayBufferMessage || '';
        if (day) {
            this.secondDayField.markedDay = day;
            this.secondDayField.markedDayLabel = this.selectedFrequencyOption?.firstDayDescription || '';
        }
        if (dayBuffer > 0) {
            const disabledDays = TwoDaysAMonthHelper.getSecondPaymentDisabledDays(dayBuffer, day);
            this.secondDayField.disabledPickerDays = disabledDays;
            if (dayBufferMessage) {
                this.secondDayField.disabledDaysText = format(dayBufferMessage, { days: dayBuffer });
            }
            if (this.secondDayValue && this.secondDayField.disabledPickerDays.includes(this.secondDayValue)) {
                this.secondDayField.value = null;
                this.secondDayField.updateValueAndValidity();
            }
        }
        else {
            this.secondDayField.disabledPickerDays = [];
            this.secondDayField.disabledDaysText = '';
            this.secondDayField.updateValueAndValidity();
        }
    }
    calculateTwoDaysAMonthStartDate() {
        const minStartDate = this.getMinStartDate();
        const paymentDate = TwoDaysAMonthHelper.calculateFirstPaymentDate(this.startMonthValue, this.firstDayValue, this.secondDayValue, minStartDate, this.dateProvider);
        if (paymentDate) {
            const formattedDate = DateUtils.getDateFormatString(paymentDate, 'MMMM DD, YYYY');
            // Success message goes away when the form field is locked
            this.startMonthField.successMessage = `${this.text.firstDateMessage}: ${formattedDate}`;
            this.updateEndingDateValidation(true, paymentDate, true);
        }
        else {
            this.startMonthField.successMessage = '';
            this.updateEndingDateValidation(true, minStartDate, true);
        }
    }
    /* Frequency Visibility Helper Methods */
    hideRecurringFields() {
        this.endingDropdownField.visible = false;
        this.endingNumberField.visible = false;
        this.endingDateField.visible = false;
        if (this.fallbackField) {
            this.fallbackField.visible = false;
        }
    }
    showRecurringFields() {
        // Showing this dropdown will trigger a selection event which will show corresponding ending fields
        this.endingDropdownField.visible = true;
        if (this.fallbackField) {
            this.fallbackField.visible = true;
        }
    }
    showStartDateField(frequency) {
        this.startDateField.label = frequency.startDateLabel;
        this.startDateField.actionButtonLabel = frequency.startDateActionButtonLabel;
        this.startDateField.actionButtonIcon = frequency.startDateActionButtonIcon;
        this.startDateField.actionFn = this.emitStartDateActionButtonClick.bind(this);
        this.startDateField.disableAllExceptFifteenthAndLastDay = frequency.startDateDisableAllExceptFifteenthAndLastDay;
        this.startDateField.disableAllExceptFirstDayOfMonth = frequency.startDateDisableAllExceptFirstDayOfMonth;
        this.startDateField.disableAllExceptLastDayOfMonth = frequency.startDateDisableAllExceptLastDayOfMonth;
        if (frequency.type === FrequencyType.ONE_TIME_FUTURE) {
            this.startDateField.visible = !this.startDateHidden;
        }
        else {
            this.startDateField.visible = true;
        }
        // Need to refresh validation since the frequency disabled dates may have changed.
        this.startDateField.updateValueAndValidity();
    }
    emitStartDateActionButtonClick() {
        this.startDateActionButtonClicked.emit();
    }
    showTwiceAMonthFields(frequency) {
        this.firstDayField.label = frequency.firstDayLabel;
        this.firstDayField.disabledPickerDays = TwoDaysAMonthHelper.getFirstPaymentDisabledDays(frequency.dayBuffer);
        this.firstDayField.selectedDayLabel = frequency.firstDayDescription;
        this.secondDayField.label = frequency.secondDayLabel;
        this.secondDayField.selectedDayLabel = frequency.secondDayDescription;
        this.twiceAMonthGroup.visible = true;
    }
    /* Mobile Frequency Button Form Events */
    mobileWorkflowInitiated() {
        if (this.hasOpenedMobileModal) {
            // Turn off auto-open of the frequency dropdown since the user has previously opened the modal
            this.frequencyDropdownField.mobileAutoOpen = false;
        }
        this.hasOpenedMobileModal = true;
        this.modalService.openMobileOnlyModal(this.frequencyModal);
    }
    submitModalWorkflow(formGroup) {
        if (formGroup.invalid) {
            return;
        }
        // Set this to true so we don't update the mobile button form again
        this.modalClosedBySubmission = true;
        this.updateMobileFrequencyButtonForm();
        this.modalService.closeMostRecentMobileOnlyModal();
    }
    onModalClose() {
        // Handle the scenario where the user uses the modal close button and not the submit button.
        if (!this.modalClosedBySubmission) {
            this.updateMobileFrequencyButtonForm();
        }
        this.modalClosedBySubmission = false; // Reset this for next time
    }
    updateMobileFrequencyButtonForm() {
        // This method is called by a number of different scenarios, and should only execute when:
        // actually on mobile, showing the frequency form, and the frequency form rows have been built
        if (!this.isMobile || !this.showFrequencyForm || this.frequencyFormRows.length === 0) {
            return;
        }
        const optionSummaryField = this.mobileFrequencyButtonForm.get('scheduleOptionSummary');
        const summaries = [];
        // Get current values by building a result (which aggregates all values).
        // Use these values to build out the summary button.
        const currentValues = this.buildResult();
        if (currentValues && currentValues.option?.frequencyRequired && this.selectedFrequencyOption) {
            const frequencyDisplay = this.frequencyDropdownField.options.find(o => o.value === this.selectedFrequencyOption.id).label;
            summaries.push(new WorkflowButtonSummary(this.frequencyDropdownField.iconLeft, `${this.text.frequencyLabel}: ${frequencyDisplay}`));
            if (!this.startDateIsCurrentlyHidden) {
                const startLabel = this.selectedFrequencyOption.type === FrequencyType.TWO_DAYS_A_MONTH
                    ? this.text.firstDateMessage
                    : this.selectedFrequencyOption.startDateLabel;
                const startDateDisplay = `${startLabel}: ${currentValues.startDate}`;
                summaries.push(new WorkflowButtonSummary(this.startDateField.iconLeft, startDateDisplay));
            }
            if (this.selectedFrequencyHasRecurringFields) {
                let endingValue = '';
                const selectedEnding = currentValues.ending;
                if (selectedEnding === RecurringEndingType.NEVER) {
                    endingValue = this.text.neverEndingOptionLabel;
                }
                else if (selectedEnding === RecurringEndingType.ON_DATE) {
                    endingValue = currentValues.endingDate;
                }
                else if (selectedEnding === RecurringEndingType.AFTER_NUMBER) {
                    const endingNumber = currentValues.endingNumber;
                    if (!!endingNumber && endingNumber > 0) {
                        endingValue = format(this.text.endingNumberFormattedMessage, { endingNumber: NumberUtils.formatNumber(endingNumber) });
                    }
                }
                summaries.push(new WorkflowButtonSummary(this.endingDropdownField.iconLeft, `${this.endingDropdownField.label}: ${endingValue}`));
            }
        }
        optionSummaryField.setValue(summaries);
        if (this.hasOpenedMobileModal) {
            // Only show validation if the user has previously launched the modal via the button
            FormUtils.showControlValidation(optionSummaryField);
        }
        optionSummaryField.updateValueAndValidity();
    }
    get mobileButtonValidators() {
        // Used for the mobile workflow button
        return [
            Validators.required,
            this.mobileButtonValidator.bind(this)
        ];
    }
    mobileButtonValidator(control) {
        const errors = {};
        // The button is required to have a value, so we only need to check if there are missing fields.
        // Exclude the fallback from the frequency validation so the mobile button error state is kept separate
        // from the fallback form.
        const result = this.buildResult();
        const invalid = result ? !result.areFrequencySelectionsValid(false) : true;
        // There is one scenario where we ignore the invalid state, which is when start date is hidden.
        if (this.selectedFrequencyOption && invalid && !this.startDateIsCurrentlyHidden) {
            errors['missing_fields'] = true;
            this.mobileFrequencyButtonErrorMessage = this.text.missingFieldsError;
            return errors;
        }
        this.mobileFrequencyButtonErrorMessage = this.text.requiredError;
        return null;
    }
    /* Fallback Form */
    buildFallbackFormRows() {
        if (this.showFallbackTypes && this.fallbackFormRows.length === 0) {
            this.fallbackField = new RadioButtonsField('fallback', this.text.fallbackLabel, this.initialFallbackValue, true);
            this.fallbackField.errorMessage = this.text.requiredError;
            this.fallbackField.fullWidth = true;
            this.fallbackField.vertical = true;
            const priorDayOption = new RadioButtonOption(this.text.priorDayFallbackOptionLabel, RecurringFallbackType.PRIOR_DAY);
            const nextDayOption = new RadioButtonOption(this.text.nextDayFallbackOptionLabel, RecurringFallbackType.NEXT_DAY);
            this.fallbackField.options = [priorDayOption, nextDayOption];
            // Start off as hidden, and let the frequency form events show this.
            this.fallbackField.visible = false;
            this.fallbackFormRows = [new FormRendererRow([this.fallbackField])];
        }
    }
    /* Validation and Result */
    validate() {
        let buildResult = true;
        // Validate all visible forms
        if (this.scheduleForm.form.invalid) {
            FormUtils.showFormValidation(this.scheduleForm.form);
            buildResult = false;
        }
        if (this.showFrequencyForm) {
            if (this.isMobile && this.mobileFrequencyButtonForm.invalid) {
                FormUtils.showFormValidation(this.mobileFrequencyButtonForm);
                buildResult = false;
            }
            if (!this.isMobile && this.frequencyForm?.form.invalid) {
                FormUtils.showFormValidation(this.frequencyForm.form);
                buildResult = false;
            }
        }
        if (this.fallbackForm && this.fallbackForm.form.invalid) {
            FormUtils.showFormValidation(this.fallbackForm.form);
            buildResult = false;
        }
        if (buildResult) {
            return this.buildResult();
        }
        return null;
    }
    buildResult() {
        const result = new ScheduleOptionsResult(this.showFallbackTypes);
        if (this.selectedScheduleOption) {
            result.option = this.selectedScheduleOption;
            result.feeAccount = this.selectedScheduleOption.feeAccountRequired ? this.selectedFeeAccount : null;
            if (this.selectedScheduleOption.frequencyRequired && this.selectedFrequencyOption) {
                result.frequency = this.selectedFrequencyOption;
                const frequencyForm = this.frequencyForm?.form;
                if (frequencyForm) {
                    const startDateField = frequencyForm.get('startDate');
                    result.startDate = startDateField?.valid ? startDateField.value : '';
                    const startMonthField = frequencyForm.get('startMonth');
                    result.startMonth = startMonthField?.valid ? startMonthField.value : null;
                    const firstDayField = frequencyForm.get('firstDay');
                    result.firstDay = firstDayField?.valid ? firstDayField.value : null;
                    const secondDayField = frequencyForm.get('secondDay');
                    result.secondDay = secondDayField?.valid ? secondDayField.value : null;
                    const endingField = frequencyForm.get('ending');
                    result.ending = endingField?.valid ? endingField.value : null;
                    const endingDateField = frequencyForm.get('endingDate');
                    result.endingDate = endingDateField?.valid ? endingDateField.value : '';
                    const endingNumberField = frequencyForm.get('endingNumber');
                    result.endingNumber = endingNumberField?.valid ? endingNumberField.value : null;
                }
                else {
                    // If we can't read from the form, try to read from the fields.
                    result.startDate = this.startDateField.value;
                    result.startMonth = this.startMonthField.value;
                    result.firstDay = this.firstDayField.value;
                    result.secondDay = this.secondDayField.value;
                    result.ending = this.endingDropdownField.value;
                    result.endingDate = this.endingDateField.value;
                    result.endingNumber = this.endingNumberField.value;
                }
                if (this.locked && this.initialStartDateValue) {
                    // If the component is locked, preserve the original start date passed in.
                    // This is mostly to prevent TWO_DAYS_A_MONTH from recalculating the start date.
                    result.startDate = this.initialStartDateValue;
                }
                else if (this.selectedFrequencyOption.type === FrequencyType.TWO_DAYS_A_MONTH) {
                    // In this case, the start date is calculated
                    const minStartDate = this.getMinStartDate();
                    const calculatedStartDate = TwoDaysAMonthHelper.calculateFirstPaymentDate(result.startMonth, result.firstDay, result.secondDay, minStartDate, this.dateProvider);
                    if (calculatedStartDate) {
                        result.startDate = DateUtils.getFIDateFormatString(calculatedStartDate, 'MM/DD/YYYY');
                    }
                }
                else if (this.startDateIsCurrentlyHidden) {
                    // Start date is hidden, so make sure no start date is emitted out.
                    // Even though hiding this field is a feature, it's technically an invalid schedule.
                    result.startDate = '';
                }
                if (this.showFallbackTypes && this.fallbackForm && this.selectedFrequencyHasRecurringFields) {
                    result.fallback = this.fallbackForm.form.get('fallback').value || null;
                }
            }
        }
        return result;
    }
    get startDateIsCurrentlyHidden() {
        if (this.selectedFrequencyOption) {
            return this.selectedFrequencyOption.type === FrequencyType.ONE_TIME_FUTURE && this.startDateHidden;
        }
        return false;
    }
    get selectedFrequencyHasRecurringFields() {
        if (this.selectedFrequencyOption) {
            return this.selectedFrequencyOption.type === FrequencyType.RECURRING || this.selectedFrequencyOption.type === FrequencyType.TWO_DAYS_A_MONTH;
        }
        return false;
    }
    getDefaultText() {
        return {
            // Schedule Dropdown
            scheduleLabel: 'Send',
            // Frequency Dropdown
            frequencyLabel: 'Occurs',
            scheduleOptionsLabel: 'Select frequency',
            // Two Days A Month
            startMonthLabel: 'Starts in',
            firstDateMessage: 'First payment',
            month1Label: 'January',
            month2Label: 'February',
            month3Label: 'March',
            month4Label: 'April',
            month5Label: 'May',
            month6Label: 'June',
            month7Label: 'July',
            month8Label: 'August',
            month9Label: 'September',
            month10Label: 'October',
            month11Label: 'November',
            month12Label: 'December',
            // Ending Dropdown
            endingLabel: 'Ending',
            neverEndingOptionLabel: 'Never',
            afterNumberEndingOptionLabel: 'After a number of payments',
            onDateEndingOptionLabel: 'On a specific date',
            // Ending Fields
            endingNumberLabel: 'Number of payments',
            endingDateLabel: 'Ends on',
            endingNumberFormattedMessage: 'After {{ endingNumber }} payments',
            endingNumberError: 'Required. Must be greater than 1',
            endingNumberWithMaxError: 'Required. Must be greater than 1 and less than {{ maxEndingNumber }}',
            // Fee Dropdown
            feeAccountLabel: 'Pay {{ fee }} fee from',
            // Fallback Radio Buttons
            fallbackLabel: 'If scheduled on non-business day, use:',
            priorDayFallbackOptionLabel: 'Previous business day',
            nextDayFallbackOptionLabel: 'Following business day',
            // Miscellaneous
            doneButton: 'Done',
            requiredError: 'Required',
            placeholder: 'Select',
            missingFieldsError: 'Missing or invalid fields',
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: ScheduleOptionsComponent, deps: [{ token: i1.UntypedFormBuilder }, { token: i2.ModalService }, { token: i2.WindowService }, { token: i1$1.DateProvider }, { token: i2.TextService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.17", type: ScheduleOptionsComponent, isStandalone: false, selector: "ui-workflows-schedule-options", inputs: { scheduleOptions: "scheduleOptions", scheduleLabel: "scheduleLabel", scheduleTooltip: "scheduleTooltip", frequencyOptions: "frequencyOptions", frequencyWarningMessage: "frequencyWarningMessage", feeAccountOptions: "feeAccountOptions", locked: "locked", startDateDisableHolidays: "startDateDisableHolidays", startDateDisableWeekends: "startDateDisableWeekends", startDateMinDate: "startDateMinDate", startDateSuccessMessage: "startDateSuccessMessage", startDateSelectedDateText: "startDateSelectedDateText", startDateLeadDays: "startDateLeadDays", startDateLeadDaysMessage: "startDateLeadDaysMessage", leadDaysAreAfterSelectedDate: "leadDaysAreAfterSelectedDate", startDateMarkedDate: "startDateMarkedDate", startDateMarkedDateText: "startDateMarkedDateText", startDateHidden: "startDateHidden", holidays: "holidays", endingTypes: "endingTypes", maxNumberRecurring: "maxNumberRecurring", showFallbackTypes: "showFallbackTypes", initialFrequencyValue: "initialFrequencyValue", initialStartDateValue: "initialStartDateValue", initialFirstDayValue: "initialFirstDayValue", initialSecondDayValue: "initialSecondDayValue", initialStartMonthValue: "initialStartMonthValue", initialEndingValue: "initialEndingValue", initialEndingDateValue: "initialEndingDateValue", initialEndingNumberValue: "initialEndingNumberValue", initialFeeAccountValue: "initialFeeAccountValue", initialFallbackValue: "initialFallbackValue" }, outputs: { scheduleChanged: "scheduleChanged", frequencyChanged: "frequencyChanged", startDateChanged: "startDateChanged", startDateActionButtonClicked: "startDateActionButtonClicked" }, viewQueries: [{ propertyName: "scheduleForm", first: true, predicate: ["scheduleForm"], descendants: true }, { propertyName: "frequencyForm", first: true, predicate: ["frequencyForm"], descendants: true }, { propertyName: "fallbackForm", first: true, predicate: ["fallbackForm"], descendants: true }, { propertyName: "frequencyModal", first: true, predicate: ["frequencyModal"], descendants: true, static: true }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "@if (scheduleFormRows.length > 0) {\n    <ui-forms-form-renderer #scheduleForm\n        e2e=\"schedule-type\"\n        [rows]=\"scheduleFormRows\"\n        [locked]=\"locked\"\n        [showNextField]=\"false\"\n        (selection)=\"onScheduleFormSelection($event)\">\n    </ui-forms-form-renderer>\n}\n\n@if (mobileFrequencyButtonForm && showFrequencyForm && isMobile) {\n    <form [formGroup]=\"mobileFrequencyButtonForm\">\n        <ui-forms-workflow-button formControlName=\"scheduleOptionSummary\"\n            [label]=\"text.scheduleOptionsLabel\"\n            [errorMessage]=\"mobileFrequencyButtonErrorMessage\"\n            placeholderIcon=\"schedule\"\n            [placeholder]=\"text.placeholder\"\n            (clicked)=\"mobileWorkflowInitiated()\"\n        ></ui-forms-workflow-button>\n    </form>\n}\n\n@if (!isMobile) {\n    <ng-container [ngTemplateOutlet]=\"frequencyFormTemplate\">\n    </ng-container>\n}\n\n@if (fallbackFormRows.length > 0 && showFrequencyForm && showFallbackTypes) {\n    <ui-forms-form-renderer #fallbackForm\n        e2e=\"schedule-fallback\"\n        [rows]=\"fallbackFormRows\"\n        [locked]=\"locked\"\n        [showNextField]=\"false\"\n        [storeValuesOnDestroy]=\"true\">\n    </ui-forms-form-renderer>\n}\n\n<ng-template #frequencyFormTemplate>\n    @if (showFrequencyForm && frequencyFormRows.length > 0) {\n        <ui-forms-form-renderer #frequencyForm\n            e2e=\"frequency-options\"\n            [rows]=\"frequencyFormRows\"\n            [locked]=\"locked\"\n            [showNextField]=\"isMobile\"\n            [storeValuesOnDestroy]=\"true\"\n            [primaryButtonText]=\"isMobile ? text.doneButton : '' \"\n            (selection)=\"onFrequencyFormSelection($event)\"\n            (primaryButtonClicked)=\"submitModalWorkflow($event)\">\n        </ui-forms-form-renderer>\n    }\n</ng-template>\n\n<ng-template #frequencyModal>\n    <ui-core-modal [title]=\"text.scheduleOptionsLabel\"\n        [useFormRendererButtons]=\"true\"\n        e2e=\"schedule-options\"\n        [lockScrim]=\"true\"\n        (closed)=\"onModalClose()\">\n        <ng-container [ngTemplateOutlet]=\"frequencyFormTemplate\">\n        </ng-container>\n    </ui-core-modal>\n</ng-template>\n", dependencies: [{ kind: "directive", type: i2$1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i2.ModalComponent, selector: "ui-core-modal", inputs: ["headerTemplate", "footerTemplate", "noBodyPadding", "noHeaderBorder", "useFormRendererButtons", "useFooterButtons", "showPrimarySpinner", "useGlassBackground"] }, { kind: "component", type: i4.FormRendererComponent, selector: "ui-forms-form-renderer", inputs: ["rows", "disableButtons", "primaryButtonText", "primaryButtonDisabledText", "primaryButtonIcon", "primaryButtonIconPosition", "secondaryButtonText", "secondaryButtonClearsForm", "secondaryButtonUrl", "secondaryButtonUrlParams", "secondaryButtonUsesExternalUrlNewTab", "secondaryButtonIcon", "secondaryButtonIconPosition", "tertiaryButtonText", "tertiaryButtonIcon", "tertiaryButtonIconPosition", "tertiaryButtonUrl", "tertiaryButtonUrlParams", "tertiaryButtonUsesExternalUrlNewTab", "locked", "loading", "loadingMessage", "storeValuesOnSubmit", "storeValuesOnDestroy", "checkEditedValues", "e2e", "showNextField", "errorMessages", "autoFocus", "marginTop", "marginBottom", "enableBotDetection"], outputs: ["primaryButtonClicked", "secondaryButtonClicked", "tertiaryButtonClicked", "inputChange", "selection", "groupCategoryChange"] }, { kind: "component", type: i4.WorkflowButtonComponent, selector: "ui-forms-workflow-button", inputs: ["placeholderIcon", "placeholder"], outputs: ["clicked"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: ScheduleOptionsComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-workflows-schedule-options', template: "@if (scheduleFormRows.length > 0) {\n    <ui-forms-form-renderer #scheduleForm\n        e2e=\"schedule-type\"\n        [rows]=\"scheduleFormRows\"\n        [locked]=\"locked\"\n        [showNextField]=\"false\"\n        (selection)=\"onScheduleFormSelection($event)\">\n    </ui-forms-form-renderer>\n}\n\n@if (mobileFrequencyButtonForm && showFrequencyForm && isMobile) {\n    <form [formGroup]=\"mobileFrequencyButtonForm\">\n        <ui-forms-workflow-button formControlName=\"scheduleOptionSummary\"\n            [label]=\"text.scheduleOptionsLabel\"\n            [errorMessage]=\"mobileFrequencyButtonErrorMessage\"\n            placeholderIcon=\"schedule\"\n            [placeholder]=\"text.placeholder\"\n            (clicked)=\"mobileWorkflowInitiated()\"\n        ></ui-forms-workflow-button>\n    </form>\n}\n\n@if (!isMobile) {\n    <ng-container [ngTemplateOutlet]=\"frequencyFormTemplate\">\n    </ng-container>\n}\n\n@if (fallbackFormRows.length > 0 && showFrequencyForm && showFallbackTypes) {\n    <ui-forms-form-renderer #fallbackForm\n        e2e=\"schedule-fallback\"\n        [rows]=\"fallbackFormRows\"\n        [locked]=\"locked\"\n        [showNextField]=\"false\"\n        [storeValuesOnDestroy]=\"true\">\n    </ui-forms-form-renderer>\n}\n\n<ng-template #frequencyFormTemplate>\n    @if (showFrequencyForm && frequencyFormRows.length > 0) {\n        <ui-forms-form-renderer #frequencyForm\n            e2e=\"frequency-options\"\n            [rows]=\"frequencyFormRows\"\n            [locked]=\"locked\"\n            [showNextField]=\"isMobile\"\n            [storeValuesOnDestroy]=\"true\"\n            [primaryButtonText]=\"isMobile ? text.doneButton : '' \"\n            (selection)=\"onFrequencyFormSelection($event)\"\n            (primaryButtonClicked)=\"submitModalWorkflow($event)\">\n        </ui-forms-form-renderer>\n    }\n</ng-template>\n\n<ng-template #frequencyModal>\n    <ui-core-modal [title]=\"text.scheduleOptionsLabel\"\n        [useFormRendererButtons]=\"true\"\n        e2e=\"schedule-options\"\n        [lockScrim]=\"true\"\n        (closed)=\"onModalClose()\">\n        <ng-container [ngTemplateOutlet]=\"frequencyFormTemplate\">\n        </ng-container>\n    </ui-core-modal>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i1.UntypedFormBuilder }, { type: i2.ModalService }, { type: i2.WindowService }, { type: i1$1.DateProvider }, { type: i2.TextService }], propDecorators: { scheduleForm: [{
                type: ViewChild,
                args: ['scheduleForm', { static: false }]
            }], frequencyForm: [{
                type: ViewChild,
                args: ['frequencyForm', { static: false }]
            }], fallbackForm: [{
                type: ViewChild,
                args: ['fallbackForm', { static: false }]
            }], frequencyModal: [{
                type: ViewChild,
                args: ['frequencyModal', { static: true }]
            }], scheduleOptions: [{
                type: Input
            }], scheduleLabel: [{
                type: Input
            }], scheduleTooltip: [{
                type: Input
            }], frequencyOptions: [{
                type: Input
            }], frequencyWarningMessage: [{
                type: Input
            }], feeAccountOptions: [{
                type: Input
            }], locked: [{
                type: Input
            }], startDateDisableHolidays: [{
                type: Input
            }], startDateDisableWeekends: [{
                type: Input
            }], startDateMinDate: [{
                type: Input
            }], startDateSuccessMessage: [{
                type: Input
            }], startDateSelectedDateText: [{
                type: Input
            }], startDateLeadDays: [{
                type: Input
            }], startDateLeadDaysMessage: [{
                type: Input
            }], leadDaysAreAfterSelectedDate: [{
                type: Input
            }], startDateMarkedDate: [{
                type: Input
            }], startDateMarkedDateText: [{
                type: Input
            }], startDateHidden: [{
                type: Input
            }], holidays: [{
                type: Input
            }], endingTypes: [{
                type: Input
            }], maxNumberRecurring: [{
                type: Input
            }], showFallbackTypes: [{
                type: Input
            }], initialFrequencyValue: [{
                type: Input
            }], initialStartDateValue: [{
                type: Input
            }], initialFirstDayValue: [{
                type: Input
            }], initialSecondDayValue: [{
                type: Input
            }], initialStartMonthValue: [{
                type: Input
            }], initialEndingValue: [{
                type: Input
            }], initialEndingDateValue: [{
                type: Input
            }], initialEndingNumberValue: [{
                type: Input
            }], initialFeeAccountValue: [{
                type: Input
            }], initialFallbackValue: [{
                type: Input
            }], scheduleChanged: [{
                type: Output
            }], frequencyChanged: [{
                type: Output
            }], startDateChanged: [{
                type: Output
            }], startDateActionButtonClicked: [{
                type: Output
            }] } });

var MicroappMenuType;
(function (MicroappMenuType) {
    MicroappMenuType["SINGLE"] = "single";
    MicroappMenuType["MULTI"] = "multi";
})(MicroappMenuType || (MicroappMenuType = {}));

class MicroappComponent extends BaseTextComponent {
    constructor(injector, router, textService) {
        super(textService, 'ui-workflows-microapp');
        this.injector = injector;
        this.router = router;
        this.textService = textService;
        /**
        * The ID of the microapp. Used for e2e hooks, and also to join mobile dashboard button links to their respective microapp.
        **/
        this.id = '';
        /**
        * The optional title of the microapp.
        **/
        this.title = '';
        /**
        * The optional subtitle of the microapp.
        **/
        this.subtitle = '';
        /**
        * Text of optional primary button.
        **/
        this.primaryButtonText = '';
        /**
        * Screen-reader label to apply to primary button for accessibility.
        *   Read instead of, or in addition to, to the primaryButtonText (depending on device).
        **/
        this.primaryButtonAriaLabel = '';
        /**
        * The url to navigate to on primary button click.
        **/
        this.primaryButtonUrl = '';
        /**
        * Query parameters for the primaryButtonUrl.
        **/
        this.primaryButtonUrlParams = null;
        /**
        * Text of optional additional button OR link.
        **/
        this.additionalButtonText = '';
        /**
        * Screen-reader label to apply to additional button for accessibility.
        *   Read instead of, or in addition to, to the additionalButtonText (depending on device).
        **/
        this.additionalButtonAriaLabel = '';
        /**
        * The url to navigate to on additional button click.
        **/
        this.additionalButtonUrl = '';
        /**
        * Query parameters for the additionalButtonUrl.
        **/
        this.additionalButtonUrlParams = null;
        /**
        * Valid inputs are either 'link' or 'secondary'.
        * However, if layout is set to 'glass-chin', this theme is always 'secondary'.
        **/
        this.additionalButtonTheme = 'link';
        /**
        * The layout of the microapp. Default is the Dashboard style.
        **/
        this.layout = 'default';
        /**
        * If there isn't a "primaryButtonUrl" supplied, this emits when the primary button is clicked.
        **/
        this.primaryButtonClicked = new EventEmitter();
        /**
        * If there isn't a "additionalButtonUrl" supplied, this emits when the additional button is clicked.
        **/
        this.additionalButtonClicked = new EventEmitter();
        /**
        * When the toggle button is clicked, emits the id of the microapp and whether it's enabled.
        **/
        this.toggleButtonClicked = new EventEmitter();
        /**
        * Emits DOM Event when close button is clicked.
        **/
        this.closed = new EventEmitter();
        /**
        * Emits value when microapp menu is changed
        **/
        this.menuValueChange = new EventEmitter();
        this.MicroappMenuType = MicroappMenuType;
        this.menuAriaLabel = '';
        this.updatedPrimaryButtonAriaLabel = '';
        this.updatedAdditionalButtonAriaLabel = '';
        this.isGlassChinLayout = false;
        this.microappButtonUpdatesEnabled = HtmlUtils.isClassOnBody(FeatureFlagClass.MICROAPP_BUTTON_UPDATES);
    }
    ngOnInit() {
        if (this.appContext?.length) {
            const providers = [];
            this.appContext.forEach(provider => {
                providers.push(provider);
            });
            this.appContextInjector = Injector.create({ providers, parent: this.injector });
        }
    }
    ngOnChanges(changes) {
        this.setAriaLabels();
        if (changes.layout) {
            this.isGlassChinLayout = this.layout === 'glass-chin';
        }
    }
    onPrimaryButtonClick() {
        if (this.primaryButtonUrl && this.isGlassChinLayout) {
            HtmlUtils.navigateToUrl(this.primaryButtonUrl, this.router, false, this.primaryButtonUrlParams);
        }
        else {
            this.primaryButtonClicked.emit();
        }
    }
    onAdditionalButtonClick() {
        if (this.additionalButtonUrl && this.isGlassChinLayout) {
            HtmlUtils.navigateToUrl(this.additionalButtonUrl, this.router, false, this.additionalButtonUrlParams);
        }
        else {
            this.additionalButtonClicked.emit();
        }
    }
    editModeToggleClick() {
        this.enabled = !this.enabled;
        this.toggleButtonClicked.emit({ id: this.id, enabled: this.enabled });
    }
    close(event) {
        this.closed.emit(event);
    }
    setAriaLabels() {
        const primaryButtonAriaPrefix = this.primaryButtonAriaLabel || this.title ? `${this.primaryButtonAriaLabel || this.title} - ` : '';
        const additionalButtonAriaPrefix = this.additionalButtonAriaLabel || this.title ? `${this.additionalButtonAriaLabel || this.title} - ` : '';
        this.updatedPrimaryButtonAriaLabel = `${primaryButtonAriaPrefix}${this.primaryButtonText}`;
        this.updatedAdditionalButtonAriaLabel = `${additionalButtonAriaPrefix}${this.additionalButtonText}`;
        if (this.menuType) {
            this.menuAriaLabel = this.title + ' - ' + this.menuLabel;
        }
    }
    getDefaultText() {
        return {
            hideMicroappButtonLabel: 'Hide {{ title }} Microapp',
            showMicroappButtonLabel: 'Show {{ title }} Microapp',
            dragMicroappButtonLabel: 'Drag to Reorder {{ title }} Microapp'
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: MicroappComponent, deps: [{ token: i0.Injector }, { token: i3.Router }, { token: i2.TextService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.17", type: MicroappComponent, isStandalone: false, selector: "ui-workflows-microapp", inputs: { id: "id", title: "title", subtitle: "subtitle", primaryButtonText: "primaryButtonText", primaryButtonAriaLabel: "primaryButtonAriaLabel", primaryButtonUrl: "primaryButtonUrl", primaryButtonUrlParams: "primaryButtonUrlParams", primaryButtonDisabled: "primaryButtonDisabled", primaryButtonDisabledText: "primaryButtonDisabledText", primaryButtonDisabledSpinner: "primaryButtonDisabledSpinner", additionalButtonText: "additionalButtonText", additionalButtonAriaLabel: "additionalButtonAriaLabel", additionalButtonUrl: "additionalButtonUrl", additionalButtonUrlParams: "additionalButtonUrlParams", additionalButtonTheme: "additionalButtonTheme", editMode: "editMode", enabled: "enabled", noContentPadding: "noContentPadding", noContentPaddingBottom: "noContentPaddingBottom", noPadding: "noPadding", showCloseButton: "showCloseButton", layout: "layout", component: "component", menuComponent: "menuComponent", appContext: "appContext", microappLocationContext: "microappLocationContext", menuType: "menuType", menuOptions: "menuOptions", menuValue: "menuValue", menuLabel: "menuLabel" }, outputs: { primaryButtonClicked: "primaryButtonClicked", additionalButtonClicked: "additionalButtonClicked", toggleButtonClicked: "toggleButtonClicked", closed: "closed", menuValueChange: "menuValueChange" }, usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div class=\"microapp-container\" [attr.data-microapp-id]=\"id\" \n  [class.container-elevated]=\"!isGlassChinLayout || microappButtonUpdatesEnabled\"\n  [class.container-inline-size]=\"isGlassChinLayout && microappButtonUpdatesEnabled\"\n  [class.legacy-glass-chin-layout]=\"isGlassChinLayout && !microappButtonUpdatesEnabled\"\n  [class.microapp-edit-mode]=\"editMode\"\n  [class.no-padding]=\"noPadding\">\n  <ui-core-close-button *ngIf=\"showCloseButton && !editMode\" \n    [top]=\"isGlassChinLayout ? 10 : -12\" [right]=\"isGlassChinLayout ? 10 : -10\" [e2e]=\"id\" \n    (closed)=\"close($event)\">\n  </ui-core-close-button>\n  \n  <div *ngIf=\"title\" class=\"microapp-title-container\" [class.mb-2]=\"!isGlassChinLayout || microappButtonUpdatesEnabled\">\n    <div role=\"heading\" aria-level=\"4\">\n      <span class=\"microapp-title text-second microapp-mr\" [innerHTML]=\"title\"></span>\n      <span *ngIf=\"subtitle && !editMode\" class=\"microapp-subtitle text-second\">{{ subtitle }}</span>\n    </div>\n    <div *ngIf=\"editMode\" class=\"microapp-edit-buttons-container\">\n      <ui-core-icon-button [message]=\"enabled ? text.hideMicroappButtonLabel : text.showMicroappButtonLabel\"\n        [icon]=\"enabled ? 'visibility' : 'visibility_off'\" size=\"lg\" class=\"cursor-pointer px-1\" (click)=\"editModeToggleClick()\">\n      </ui-core-icon-button>\n      <ui-core-icon-button [message]=\"text.dragMicroappButtonLabel\" icon=\"drag_indicator\" size=\"lg\" class=\"pl-1\" buttonClass=\"cursor-grab\">\n      </ui-core-icon-button>\n    </div>\n    <div *ngIf=\"!editMode && menuType && menuOptions?.length > 0\" class=\"mr-n2\">\n      <ui-forms-picker *ngIf=\"menuType === MicroappMenuType.SINGLE\"\n        [options]=\"menuOptions\" [value]=\"menuValue\" [label]=\"menuLabel\" [ariaLabel]=\"menuAriaLabel\" display=\"icon\" iconLeft=\"more_vert\" [e2e]=\"id\" \n        (change)=\"menuValueChange.emit($event)\">\n      </ui-forms-picker>\n      <ui-forms-multi-select-picker *ngIf=\"menuType === MicroappMenuType.MULTI\"\n        [options]=\"menuOptions\" [value]=\"menuValue\" [label]=\"menuLabel\" [ariaLabel]=\"menuAriaLabel\" display=\"icon\" iconLeft=\"more_vert\" [e2e]=\"id\" \n        (change)=\"menuValueChange.emit($event)\">\n      </ui-forms-multi-select-picker>\n    </div>\n    <div *ngIf=\"!editMode && menuComponent\">\n      <ng-container *ngComponentOutlet=\"menuComponent; injector: appContextInjector;\"></ng-container>\n    </div>\n  </div>\n  \n  <div class=\"microapp-content\" [class.flush-content]=\"noContentPadding\" [class.flush-bottom]=\"noContentPaddingBottom\">\n    <ng-content></ng-content>\n    <ng-container *ngIf=\"microappLocationContext\">\n      <ng-container *ngComponentOutlet=\"component; injector: appContextInjector; inputs: { microappLocationContext: microappLocationContext }\"></ng-container>\n    </ng-container>\n    <ng-container *ngIf=\"!microappLocationContext\">\n      <ng-container *ngComponentOutlet=\"component; injector: appContextInjector;\"></ng-container>\n    </ng-container>\n  </div>\n\n  @if (isGlassChinLayout && primaryButtonText) {\n    @if (microappButtonUpdatesEnabled) {\n      <div class=\"neutral-secondary-buttons-container\">\n        <div>\n          <ui-core-link *ngIf=\"primaryButtonUrl\"\n            [message]=\"primaryButtonText\"\n            [ariaLabel]=\"updatedPrimaryButtonAriaLabel\"\n            [e2e]=\"id + '_btn-primary'\"\n            [link]=\"primaryButtonUrl\"\n            [urlParams]=\"primaryButtonUrlParams\"\n            theme=\"secondary\"\n            themeGroup=\"neutral\"\n            width=\"full\">\n          </ui-core-link>\n          <ui-core-button *ngIf=\"!primaryButtonUrl\"\n            [message]=\"primaryButtonText\"\n            [ariaLabel]=\"updatedPrimaryButtonAriaLabel\"\n            [e2e]=\"id + '_btn-primary'\"\n            theme=\"secondary\"\n            themeGroup=\"neutral\"\n            width=\"full\"\n            (click)=\"onPrimaryButtonClick()\">\n          </ui-core-button>\n        </div>\n        @if (additionalButtonText) {\n          <div>\n            <ui-core-link *ngIf=\"additionalButtonUrl\"\n              [message]=\"additionalButtonText\"\n              [ariaLabel]=\"updatedAdditionalButtonAriaLabel\"\n              [e2e]=\"id + '_btn-' + additionalButtonTheme\"\n              [link]=\"additionalButtonUrl\"\n              [urlParams]=\"additionalButtonUrlParams\"\n              theme=\"secondary\"\n              themeGroup=\"neutral\"\n              width=\"full\">\n            </ui-core-link>\n            <ui-core-button *ngIf=\"!additionalButtonUrl\"\n              [message]=\"additionalButtonText\"\n              [ariaLabel]=\"updatedAdditionalButtonAriaLabel\"\n              [e2e]=\"id + '_btn-' + additionalButtonTheme\"\n              theme=\"secondary\"\n              themeGroup=\"neutral\"\n              width=\"full\"\n              (click)=\"onAdditionalButtonClick()\">\n            </ui-core-button>\n          </div>\n        }\n      </div>\n    } @else {\n      <ui-core-chin-buttons\n        [primaryButtonAriaLabel]=\"updatedPrimaryButtonAriaLabel\"\n        [primaryButtonE2E]=\"id + '_btn-primary'\"\n        [primaryButtonText]=\"primaryButtonText\"\n        [primaryButtonUrl]=\"primaryButtonUrl\"\n        [primaryButtonUrlParams]=\"primaryButtonUrlParams\"\n        [additionalButtonAriaLabel]=\"updatedAdditionalButtonAriaLabel\" \n        [additionalButtonE2E]=\"id + '_btn-' + additionalButtonTheme\"\n        [additionalButtonText]=\"additionalButtonText\"\n        [additionalButtonUrl]=\"additionalButtonUrl\"\n        [additionalButtonUrlParams]=\"additionalButtonUrlParams\"\n        (primaryButtonClicked)=\"onPrimaryButtonClick()\"\n        (additionalButtonClicked)=\"onAdditionalButtonClick()\">\n      </ui-core-chin-buttons>\n    }\n  } @else {\n    <div *ngIf=\"primaryButtonText\" class=\"microapp-mt\">\n      <ui-core-link *ngIf=\"primaryButtonUrl\"\n        [message]=\"primaryButtonText\" theme=\"primary\" width=\"full\"\n        [disabled]=\"primaryButtonDisabled\"\n        [ariaLabel]=\"updatedPrimaryButtonAriaLabel\" [e2e]=\"id + '_btn-primary' \" \n        [link]=\"primaryButtonUrl\"\n        [urlParams]=\"primaryButtonUrlParams\">\n      </ui-core-link>\n      <ui-core-button *ngIf=\"!primaryButtonUrl\"\n        [message]=\"primaryButtonText\" theme=\"primary\" width=\"full\"\n        [disabled]=\"primaryButtonDisabled\" [disabledMessage]=\"primaryButtonDisabledText\" \n        [showSpinner]=\"primaryButtonDisabledSpinner\" \n        [ariaLabel]=\"updatedPrimaryButtonAriaLabel\" [e2e]=\"id + '_btn-primary' \" \n        (click)=\"onPrimaryButtonClick()\">\n      </ui-core-button>\n    </div>\n    <div *ngIf=\"additionalButtonText\" class=\"text-center microapp-mt\">\n      <ui-core-link *ngIf=\"additionalButtonUrl\"\n        [message]=\"additionalButtonText\" [theme]=\"additionalButtonTheme\" width=\"full\"\n        [ariaLabel]=\"updatedAdditionalButtonAriaLabel\" [e2e]=\"id + '_btn-' + additionalButtonTheme \" \n        [link]=\"additionalButtonUrl\"\n        [urlParams]=\"additionalButtonUrlParams\">\n      </ui-core-link>\n      <ui-core-button *ngIf=\"!additionalButtonUrl\"\n        [message]=\"additionalButtonText\" [theme]=\"additionalButtonTheme\" width=\"full\" \n        [buttonClass]=\"additionalButtonTheme === 'link' ? 'py-0' : ''\"\n        [ariaLabel]=\"updatedAdditionalButtonAriaLabel\" [e2e]=\"id + '_btn-' + additionalButtonTheme \" \n        (click)=\"onAdditionalButtonClick()\">\n      </ui-core-button>\n    </div>\n  }\n\n</div>", styles: [".microapp-container{position:relative}.microapp-container.container-inline-size{container-type:inline-size}:host-context(ui-core-carousel) .microapp-container{border:0;box-shadow:none}.microapp-container.legacy-glass-chin-layout{border-radius:var(--containers-shape);box-shadow:var(--elevation-2);overflow:hidden;padding:0}.microapp-container.no-padding{overflow:hidden;padding:0}.microapp-title-container{display:flex;align-items:center;justify-content:space-between;line-height:normal}.legacy-glass-chin-layout .microapp-title-container{background-color:var(--color-default);padding:var(--container-spacing) var(--container-spacing) 0 var(--container-spacing)}.microapp-title-container ui-forms-picker,.microapp-title-container ui-forms-multi-select-picker{margin-top:-4px;margin-bottom:-2px}.microapp-title{color:var(--color-content-primary);font-weight:var(--type-weight-semibold)}.microapp-subtitle{color:var(--color-content-primary);white-space:nowrap}.microapp-content{flex:auto}.legacy-glass-chin-layout .microapp-content{background-color:var(--color-default);padding:var(--container-spacing)}.microapp-edit-mode .drag-button{cursor:grab}.microapp-edit-mode .microapp-content,.microapp-edit-mode ui-core-link,.microapp-edit-mode ui-core-button{pointer-events:none}.microapp-edit-mode .microapp-edit-buttons-container{display:flex;margin:-4px -9px -3px 0}.min-width-20{min-width:20%}.flush-content{margin:0 calc(var(--container-spacing) * -1)}.flush-bottom{margin-bottom:calc(var(--container-spacing) * -1)}.neutral-secondary-buttons-container{display:flex;flex-direction:column;gap:8px;margin-top:16px}.neutral-secondary-buttons-container>div{width:100%}@container (min-width: 400px){.neutral-secondary-buttons-container{flex-direction:row}.neutral-secondary-buttons-container>div{flex:1}}\n"], dependencies: [{ kind: "directive", type: i2$1.NgComponentOutlet, selector: "[ngComponentOutlet]", inputs: ["ngComponentOutlet", "ngComponentOutletInputs", "ngComponentOutletInjector", "ngComponentOutletEnvironmentInjector", "ngComponentOutletContent", "ngComponentOutletNgModule", "ngComponentOutletNgModuleFactory"], exportAs: ["ngComponentOutlet"] }, { kind: "directive", type: i2$1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i2.ButtonComponent, selector: "ui-core-button", inputs: ["themeGroup", "theme", "message", "icon", "iconPosition", "disabled", "disabledMessage", "showSpinner", "buttonClass", "width", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "ariaLabel", "isFormValid", "e2e", "buttonId"] }, { kind: "component", type: i2.ChinButtonsComponent, selector: "ui-core-chin-buttons", inputs: ["primaryButtonText", "primaryButtonAriaLabel", "primaryButtonUrl", "primaryButtonUrlParams", "primaryButtonE2E", "additionalButtonText", "additionalButtonAriaLabel", "additionalButtonUrl", "additionalButtonUrlParams", "additionalButtonE2E"], outputs: ["primaryButtonClicked", "additionalButtonClicked"] }, { kind: "component", type: i2.CloseButtonComponent, selector: "ui-core-close-button", inputs: ["top", "right", "size", "e2e", "filled"], outputs: ["closed"] }, { kind: "component", type: i2.IconButtonComponent, selector: "ui-core-icon-button", inputs: ["message", "icon", "size", "disabled", "buttonClass", "ariaPressed", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "e2e", "theme", "usesGlassHoverState", "buttonId"] }, { kind: "component", type: i2.LinkComponent, selector: "ui-core-link", inputs: ["themeGroup", "theme", "size", "link", "openLinkInNewTab", "message", "icon", "iconPosition", "disabled", "linkClass", "width", "ariaLabel", "e2e", "urlParams"] }, { kind: "component", type: i4.MultiSelectPickerComponent, selector: "ui-forms-multi-select-picker", inputs: ["value", "options", "display", "searchPlaceholder", "actions"] }, { kind: "component", type: i4.PickerComponent, selector: "ui-forms-picker", inputs: ["value", "options", "display", "actions"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: MicroappComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-workflows-microapp', template: "<div class=\"microapp-container\" [attr.data-microapp-id]=\"id\" \n  [class.container-elevated]=\"!isGlassChinLayout || microappButtonUpdatesEnabled\"\n  [class.container-inline-size]=\"isGlassChinLayout && microappButtonUpdatesEnabled\"\n  [class.legacy-glass-chin-layout]=\"isGlassChinLayout && !microappButtonUpdatesEnabled\"\n  [class.microapp-edit-mode]=\"editMode\"\n  [class.no-padding]=\"noPadding\">\n  <ui-core-close-button *ngIf=\"showCloseButton && !editMode\" \n    [top]=\"isGlassChinLayout ? 10 : -12\" [right]=\"isGlassChinLayout ? 10 : -10\" [e2e]=\"id\" \n    (closed)=\"close($event)\">\n  </ui-core-close-button>\n  \n  <div *ngIf=\"title\" class=\"microapp-title-container\" [class.mb-2]=\"!isGlassChinLayout || microappButtonUpdatesEnabled\">\n    <div role=\"heading\" aria-level=\"4\">\n      <span class=\"microapp-title text-second microapp-mr\" [innerHTML]=\"title\"></span>\n      <span *ngIf=\"subtitle && !editMode\" class=\"microapp-subtitle text-second\">{{ subtitle }}</span>\n    </div>\n    <div *ngIf=\"editMode\" class=\"microapp-edit-buttons-container\">\n      <ui-core-icon-button [message]=\"enabled ? text.hideMicroappButtonLabel : text.showMicroappButtonLabel\"\n        [icon]=\"enabled ? 'visibility' : 'visibility_off'\" size=\"lg\" class=\"cursor-pointer px-1\" (click)=\"editModeToggleClick()\">\n      </ui-core-icon-button>\n      <ui-core-icon-button [message]=\"text.dragMicroappButtonLabel\" icon=\"drag_indicator\" size=\"lg\" class=\"pl-1\" buttonClass=\"cursor-grab\">\n      </ui-core-icon-button>\n    </div>\n    <div *ngIf=\"!editMode && menuType && menuOptions?.length > 0\" class=\"mr-n2\">\n      <ui-forms-picker *ngIf=\"menuType === MicroappMenuType.SINGLE\"\n        [options]=\"menuOptions\" [value]=\"menuValue\" [label]=\"menuLabel\" [ariaLabel]=\"menuAriaLabel\" display=\"icon\" iconLeft=\"more_vert\" [e2e]=\"id\" \n        (change)=\"menuValueChange.emit($event)\">\n      </ui-forms-picker>\n      <ui-forms-multi-select-picker *ngIf=\"menuType === MicroappMenuType.MULTI\"\n        [options]=\"menuOptions\" [value]=\"menuValue\" [label]=\"menuLabel\" [ariaLabel]=\"menuAriaLabel\" display=\"icon\" iconLeft=\"more_vert\" [e2e]=\"id\" \n        (change)=\"menuValueChange.emit($event)\">\n      </ui-forms-multi-select-picker>\n    </div>\n    <div *ngIf=\"!editMode && menuComponent\">\n      <ng-container *ngComponentOutlet=\"menuComponent; injector: appContextInjector;\"></ng-container>\n    </div>\n  </div>\n  \n  <div class=\"microapp-content\" [class.flush-content]=\"noContentPadding\" [class.flush-bottom]=\"noContentPaddingBottom\">\n    <ng-content></ng-content>\n    <ng-container *ngIf=\"microappLocationContext\">\n      <ng-container *ngComponentOutlet=\"component; injector: appContextInjector; inputs: { microappLocationContext: microappLocationContext }\"></ng-container>\n    </ng-container>\n    <ng-container *ngIf=\"!microappLocationContext\">\n      <ng-container *ngComponentOutlet=\"component; injector: appContextInjector;\"></ng-container>\n    </ng-container>\n  </div>\n\n  @if (isGlassChinLayout && primaryButtonText) {\n    @if (microappButtonUpdatesEnabled) {\n      <div class=\"neutral-secondary-buttons-container\">\n        <div>\n          <ui-core-link *ngIf=\"primaryButtonUrl\"\n            [message]=\"primaryButtonText\"\n            [ariaLabel]=\"updatedPrimaryButtonAriaLabel\"\n            [e2e]=\"id + '_btn-primary'\"\n            [link]=\"primaryButtonUrl\"\n            [urlParams]=\"primaryButtonUrlParams\"\n            theme=\"secondary\"\n            themeGroup=\"neutral\"\n            width=\"full\">\n          </ui-core-link>\n          <ui-core-button *ngIf=\"!primaryButtonUrl\"\n            [message]=\"primaryButtonText\"\n            [ariaLabel]=\"updatedPrimaryButtonAriaLabel\"\n            [e2e]=\"id + '_btn-primary'\"\n            theme=\"secondary\"\n            themeGroup=\"neutral\"\n            width=\"full\"\n            (click)=\"onPrimaryButtonClick()\">\n          </ui-core-button>\n        </div>\n        @if (additionalButtonText) {\n          <div>\n            <ui-core-link *ngIf=\"additionalButtonUrl\"\n              [message]=\"additionalButtonText\"\n              [ariaLabel]=\"updatedAdditionalButtonAriaLabel\"\n              [e2e]=\"id + '_btn-' + additionalButtonTheme\"\n              [link]=\"additionalButtonUrl\"\n              [urlParams]=\"additionalButtonUrlParams\"\n              theme=\"secondary\"\n              themeGroup=\"neutral\"\n              width=\"full\">\n            </ui-core-link>\n            <ui-core-button *ngIf=\"!additionalButtonUrl\"\n              [message]=\"additionalButtonText\"\n              [ariaLabel]=\"updatedAdditionalButtonAriaLabel\"\n              [e2e]=\"id + '_btn-' + additionalButtonTheme\"\n              theme=\"secondary\"\n              themeGroup=\"neutral\"\n              width=\"full\"\n              (click)=\"onAdditionalButtonClick()\">\n            </ui-core-button>\n          </div>\n        }\n      </div>\n    } @else {\n      <ui-core-chin-buttons\n        [primaryButtonAriaLabel]=\"updatedPrimaryButtonAriaLabel\"\n        [primaryButtonE2E]=\"id + '_btn-primary'\"\n        [primaryButtonText]=\"primaryButtonText\"\n        [primaryButtonUrl]=\"primaryButtonUrl\"\n        [primaryButtonUrlParams]=\"primaryButtonUrlParams\"\n        [additionalButtonAriaLabel]=\"updatedAdditionalButtonAriaLabel\" \n        [additionalButtonE2E]=\"id + '_btn-' + additionalButtonTheme\"\n        [additionalButtonText]=\"additionalButtonText\"\n        [additionalButtonUrl]=\"additionalButtonUrl\"\n        [additionalButtonUrlParams]=\"additionalButtonUrlParams\"\n        (primaryButtonClicked)=\"onPrimaryButtonClick()\"\n        (additionalButtonClicked)=\"onAdditionalButtonClick()\">\n      </ui-core-chin-buttons>\n    }\n  } @else {\n    <div *ngIf=\"primaryButtonText\" class=\"microapp-mt\">\n      <ui-core-link *ngIf=\"primaryButtonUrl\"\n        [message]=\"primaryButtonText\" theme=\"primary\" width=\"full\"\n        [disabled]=\"primaryButtonDisabled\"\n        [ariaLabel]=\"updatedPrimaryButtonAriaLabel\" [e2e]=\"id + '_btn-primary' \" \n        [link]=\"primaryButtonUrl\"\n        [urlParams]=\"primaryButtonUrlParams\">\n      </ui-core-link>\n      <ui-core-button *ngIf=\"!primaryButtonUrl\"\n        [message]=\"primaryButtonText\" theme=\"primary\" width=\"full\"\n        [disabled]=\"primaryButtonDisabled\" [disabledMessage]=\"primaryButtonDisabledText\" \n        [showSpinner]=\"primaryButtonDisabledSpinner\" \n        [ariaLabel]=\"updatedPrimaryButtonAriaLabel\" [e2e]=\"id + '_btn-primary' \" \n        (click)=\"onPrimaryButtonClick()\">\n      </ui-core-button>\n    </div>\n    <div *ngIf=\"additionalButtonText\" class=\"text-center microapp-mt\">\n      <ui-core-link *ngIf=\"additionalButtonUrl\"\n        [message]=\"additionalButtonText\" [theme]=\"additionalButtonTheme\" width=\"full\"\n        [ariaLabel]=\"updatedAdditionalButtonAriaLabel\" [e2e]=\"id + '_btn-' + additionalButtonTheme \" \n        [link]=\"additionalButtonUrl\"\n        [urlParams]=\"additionalButtonUrlParams\">\n      </ui-core-link>\n      <ui-core-button *ngIf=\"!additionalButtonUrl\"\n        [message]=\"additionalButtonText\" [theme]=\"additionalButtonTheme\" width=\"full\" \n        [buttonClass]=\"additionalButtonTheme === 'link' ? 'py-0' : ''\"\n        [ariaLabel]=\"updatedAdditionalButtonAriaLabel\" [e2e]=\"id + '_btn-' + additionalButtonTheme \" \n        (click)=\"onAdditionalButtonClick()\">\n      </ui-core-button>\n    </div>\n  }\n\n</div>", styles: [".microapp-container{position:relative}.microapp-container.container-inline-size{container-type:inline-size}:host-context(ui-core-carousel) .microapp-container{border:0;box-shadow:none}.microapp-container.legacy-glass-chin-layout{border-radius:var(--containers-shape);box-shadow:var(--elevation-2);overflow:hidden;padding:0}.microapp-container.no-padding{overflow:hidden;padding:0}.microapp-title-container{display:flex;align-items:center;justify-content:space-between;line-height:normal}.legacy-glass-chin-layout .microapp-title-container{background-color:var(--color-default);padding:var(--container-spacing) var(--container-spacing) 0 var(--container-spacing)}.microapp-title-container ui-forms-picker,.microapp-title-container ui-forms-multi-select-picker{margin-top:-4px;margin-bottom:-2px}.microapp-title{color:var(--color-content-primary);font-weight:var(--type-weight-semibold)}.microapp-subtitle{color:var(--color-content-primary);white-space:nowrap}.microapp-content{flex:auto}.legacy-glass-chin-layout .microapp-content{background-color:var(--color-default);padding:var(--container-spacing)}.microapp-edit-mode .drag-button{cursor:grab}.microapp-edit-mode .microapp-content,.microapp-edit-mode ui-core-link,.microapp-edit-mode ui-core-button{pointer-events:none}.microapp-edit-mode .microapp-edit-buttons-container{display:flex;margin:-4px -9px -3px 0}.min-width-20{min-width:20%}.flush-content{margin:0 calc(var(--container-spacing) * -1)}.flush-bottom{margin-bottom:calc(var(--container-spacing) * -1)}.neutral-secondary-buttons-container{display:flex;flex-direction:column;gap:8px;margin-top:16px}.neutral-secondary-buttons-container>div{width:100%}@container (min-width: 400px){.neutral-secondary-buttons-container{flex-direction:row}.neutral-secondary-buttons-container>div{flex:1}}\n"] }]
        }], ctorParameters: () => [{ type: i0.Injector }, { type: i3.Router }, { type: i2.TextService }], propDecorators: { id: [{
                type: Input
            }], title: [{
                type: Input
            }], subtitle: [{
                type: Input
            }], primaryButtonText: [{
                type: Input
            }], primaryButtonAriaLabel: [{
                type: Input
            }], primaryButtonUrl: [{
                type: Input
            }], primaryButtonUrlParams: [{
                type: Input
            }], primaryButtonDisabled: [{
                type: Input
            }], primaryButtonDisabledText: [{
                type: Input
            }], primaryButtonDisabledSpinner: [{
                type: Input
            }], additionalButtonText: [{
                type: Input
            }], additionalButtonAriaLabel: [{
                type: Input
            }], additionalButtonUrl: [{
                type: Input
            }], additionalButtonUrlParams: [{
                type: Input
            }], additionalButtonTheme: [{
                type: Input
            }], editMode: [{
                type: Input
            }], enabled: [{
                type: Input
            }], noContentPadding: [{
                type: Input
            }], noContentPaddingBottom: [{
                type: Input
            }], noPadding: [{
                type: Input
            }], showCloseButton: [{
                type: Input
            }], layout: [{
                type: Input
            }], component: [{
                type: Input
            }], menuComponent: [{
                type: Input
            }], appContext: [{
                type: Input
            }], microappLocationContext: [{
                type: Input
            }], menuType: [{
                type: Input
            }], menuOptions: [{
                type: Input
            }], menuValue: [{
                type: Input
            }], menuLabel: [{
                type: Input
            }], primaryButtonClicked: [{
                type: Output
            }], additionalButtonClicked: [{
                type: Output
            }], toggleButtonClicked: [{
                type: Output
            }], closed: [{
                type: Output
            }], menuValueChange: [{
                type: Output
            }] } });

class UiWorkflowsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: UiWorkflowsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.17", ngImport: i0, type: UiWorkflowsModule, declarations: [AddressVerificationModalComponent,
            ChatMessageBodyComponent,
            ChatMessageComponent,
            ChatPageComponent,
            ChatWindowComponent,
            ChipEditorComponent,
            ConfirmationModalComponent,
            DataCardComponent,
            EditLabelValueModalComponent,
            EndOfListComponent,
            FundingOptionsComponent,
            ListComponent, ListFormComponent,
            MicroappComponent,
            NotesComponent,
            PaymentOptionsComponent,
            RadioButtonCardsComponent,
            ReasonModalComponent,
            ScheduleOptionsComponent,
            SearchSortFilterComponent,
            TableComponent,
            TableTemplatesDefinitionsComponent,
            // Helper components - not exported
            BulkActionsComponent, ListTemplateComponent, TableActionsComponent], imports: [CommonModule,
            DragDropModule,
            FormsModule,
            NgbModule,
            ReactiveFormsModule,
            UiCoreModule,
            UiFormsModule], exports: [AddressVerificationModalComponent,
            ChatMessageBodyComponent,
            ChatMessageComponent,
            ChatPageComponent,
            ChatWindowComponent,
            ChipEditorComponent,
            ConfirmationModalComponent,
            DataCardComponent,
            EditLabelValueModalComponent,
            FundingOptionsComponent,
            ListComponent, ListFormComponent,
            MicroappComponent,
            NotesComponent,
            PaymentOptionsComponent,
            RadioButtonCardsComponent,
            ReasonModalComponent,
            ScheduleOptionsComponent,
            SearchSortFilterComponent,
            TableComponent,
            TableTemplatesDefinitionsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: UiWorkflowsModule, providers: [
            TableStateService,
            TableTemplatesService
        ], imports: [CommonModule,
            DragDropModule,
            FormsModule,
            NgbModule,
            ReactiveFormsModule,
            UiCoreModule,
            UiFormsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: UiWorkflowsModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        AddressVerificationModalComponent,
                        ChatMessageBodyComponent,
                        ChatMessageComponent,
                        ChatPageComponent,
                        ChatWindowComponent,
                        ChipEditorComponent,
                        ConfirmationModalComponent,
                        DataCardComponent,
                        EditLabelValueModalComponent,
                        EndOfListComponent,
                        FundingOptionsComponent,
                        ListComponent, ListFormComponent,
                        MicroappComponent,
                        NotesComponent,
                        PaymentOptionsComponent,
                        RadioButtonCardsComponent,
                        ReasonModalComponent,
                        ScheduleOptionsComponent,
                        SearchSortFilterComponent,
                        TableComponent,
                        TableTemplatesDefinitionsComponent,
                        // Helper components - not exported
                        BulkActionsComponent, ListTemplateComponent, TableActionsComponent
                    ],
                    imports: [
                        CommonModule,
                        DragDropModule,
                        FormsModule,
                        NgbModule,
                        ReactiveFormsModule,
                        UiCoreModule,
                        UiFormsModule
                    ],
                    exports: [
                        AddressVerificationModalComponent,
                        ChatMessageBodyComponent,
                        ChatMessageComponent,
                        ChatPageComponent,
                        ChatWindowComponent,
                        ChipEditorComponent,
                        ConfirmationModalComponent,
                        DataCardComponent,
                        EditLabelValueModalComponent,
                        FundingOptionsComponent,
                        ListComponent, ListFormComponent,
                        MicroappComponent,
                        NotesComponent,
                        PaymentOptionsComponent,
                        RadioButtonCardsComponent,
                        ReasonModalComponent,
                        ScheduleOptionsComponent,
                        SearchSortFilterComponent,
                        TableComponent,
                        TableTemplatesDefinitionsComponent,
                    ],
                    providers: [
                        TableStateService,
                        TableTemplatesService
                    ]
                }]
        }] });

/*
 * Public API Surface of ui-workflows
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AddressVerificationModalComponent, BaseDataCardItem, BulkAction, BulkActionEvent, BulkActionsComponent, ChatMessage, ChatMessageAction, ChatMessageActionType, ChatMessageBodyComponent, ChatMessageComponent, ChatMessageDirection, ChatMessageReplyActionRole, ChatMessageSenderType, ChatPageAction, ChatPageComponent, ChatSession, ChatWindowComponent, ChatWindowMode, ChipEditorComponent, ColumnFilterList, ColumnFilterOption, ConfirmationModalComponent, ConfirmationModalEvent, DataCardComponent, DataCardDisplayItem, DataCardEditItem, DataCardItemGroup, DataCardModel, DataCardSensitiveItem, DateFilterType, EditLabelValueModalComponent, FrequencyOption, FrequencyType, FundingOptionsComponent, FundingOptionsResult, ListComponent, ListFormComponent, ListFormField, ListFormFieldType, ListFormItem, ListItem, MicroappComponent, MicroappMenuType, NotesComponent, NotesResult, PaymentOption, PaymentOptionType, PaymentOptionsComponent, PaymentOptionsResult, RadioButtonCardOption, RadioButtonCardsComponent, RadioButtonCardsResult, ReasonModalComponent, ReasonModalEvent, RecurringEndingType, RecurringFallbackType, ScheduleOption, ScheduleOptionsComponent, ScheduleOptionsResult, SearchSortFilter, SearchSortFilterComponent, TableAction, TableActionEvent, TableActionsComponent, TableBadgesContext, TableCellContent, TableColumn, TableComponent, TableFilter, TableFilterEvent, TableIconContext, TableRow, TableSortDirection, TableState, TableStateService, TableStickyColumnConfig, TableTemplateType, TableTemplateUtils, TableTemplatesDefinitionsComponent, TableTemplatesService, UiWorkflowsModule };
//# sourceMappingURL=a3-digital-ui-workflows.mjs.map
