import { ConfigurationEventType } from './configuration-event-type.js';
export declare class ConfigurationEvent {
    eventType: ConfigurationEventType;
    data: any;
    constructor(eventType: ConfigurationEventType);
}
