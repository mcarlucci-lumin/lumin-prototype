export class ConfigurationEvent {
    constructor(eventType) {
        this.eventType = eventType;
    }
}
