export declare const globalSettingsKey = "GlobalSettings";
