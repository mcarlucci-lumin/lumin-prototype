import { FeatureFlagMode } from './feature-flag-mode.js';
export class FeatureFlag {
    constructor(id, enabled, mode, extendedData) {
        this.id = id;
        this.enabled = enabled;
        this.mode = mode;
        this.extendedData = extendedData;
        if (!mode) {
            this.mode = FeatureFlagMode.UNKNOWN;
        }
        if (!extendedData) {
            this.extendedData = {};
        }
    }
}
