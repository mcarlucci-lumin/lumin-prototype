export declare enum FeatureFlagMode {
    UNKNOWN = "UNKNOWN",
    GLOBAL = "GLOBAL",
    USERLIST = "USERLIST",
    BETA_USERS = "BETA_USERS"
}
