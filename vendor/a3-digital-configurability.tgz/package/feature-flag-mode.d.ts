export declare enum FeatureFlagMode {
    UNKNOWN = "UNKNOWN",
    GLOBAL = "GLOBAL",
    USERLIST = "USERLIST"
}
