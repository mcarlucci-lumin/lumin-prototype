export const CUSTOMIZATION_DEFINITION_METADATA_KEY = 'CustomizationDefinitionMetadata';
export function customizationDefinition(metadata) {
    return (target) => {
        // store metadata
        Reflect.defineMetadata(CUSTOMIZATION_DEFINITION_METADATA_KEY, metadata, target);
    };
}
