// cap individual property default/overrides to 50kb bytes
export const CONFIGURABLE_PROPERTY_VALUE_MAX_BYTE_LIMIT = 50000;
