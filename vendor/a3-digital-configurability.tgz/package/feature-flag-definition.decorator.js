export function featureFlagDefinition(metadata) {
    return (target) => { };
}
