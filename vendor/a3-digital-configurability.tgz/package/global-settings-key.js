export const globalSettingsKey = 'GlobalSettings';
