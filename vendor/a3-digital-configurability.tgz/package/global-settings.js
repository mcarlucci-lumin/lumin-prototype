var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var GlobalSettings_1;
import { configurableProperty } from './configurable-property.decorator.js';
import { configurableClass } from './configurable-class.decorator.js';
import { globalSettingsKey } from './global-settings-key.js';
import { CONFIGURABLE_PROPERTIES_METADATA_KEY } from './configurable-entity-registry.js';
import { FiType } from './fi-type.js';
import { HostSystem } from './host-system.js';
import { DateUtils } from '@a3-digital/date-utils';
let GlobalSettings = GlobalSettings_1 = class GlobalSettings {
    isBankMode(override) {
        if (override === FiType.CREDIT_UNION) {
            return false;
        }
        if (override === FiType.BANK || this.fiType === FiType.BANK) {
            return true;
        }
        return false;
    }
    get luminConversionDate() {
        if (this._luminConversionDateString) {
            const conversionDate = DateUtils.parseFIDateFormat(this._luminConversionDateString, 'YYYY-MM-DD');
            return conversionDate;
        }
        return null;
    }
    static getConfigPropertiesMetaData() {
        return Reflect.getOwnMetadata(CONFIGURABLE_PROPERTIES_METADATA_KEY, GlobalSettings_1);
    }
};
__decorate([
    configurableProperty({
        name: 'fiName',
        type: 'string',
        description: 'Name of the Financial Institution',
        default: 'Sample FI'
    }),
    __metadata("design:type", String)
], GlobalSettings.prototype, "fiName", void 0);
__decorate([
    configurableProperty({
        name: 'fiNickname',
        type: 'string',
        description: 'Short-form nickname of the Financial Institution, often used in SMS',
        default: 'SFI'
    }),
    __metadata("design:type", String)
], GlobalSettings.prototype, "fiNickname", void 0);
__decorate([
    configurableProperty({
        name: 'fiTimeZone',
        type: 'string',
        description: 'Timezone of the Financial Institution',
        default: 'US/Eastern'
    }),
    __metadata("design:type", String)
], GlobalSettings.prototype, "fiTimeZone", void 0);
__decorate([
    configurableProperty({
        name: 'fiID',
        type: 'string',
        description: 'ID of the Financial Institution',
        default: 'DEMO'
    }),
    __metadata("design:type", String)
], GlobalSettings.prototype, "fiID", void 0);
__decorate([
    configurableProperty({
        name: 'Use Host Routing Number',
        type: 'boolean',
        description: 'When TRUE, the routing number provided by the core will be used. When FALSE, the routing number from global settings will be used.',
        default: false
    }),
    __metadata("design:type", Boolean)
], GlobalSettings.prototype, "useHostRoutingNumber", void 0);
__decorate([
    configurableProperty({
        name: 'routingNumber',
        type: 'string',
        description: 'Routing Number of the Financial Institution',
        default: '123456789'
    }),
    __metadata("design:type", String)
], GlobalSettings.prototype, "routingNumber", void 0);
__decorate([
    configurableProperty({
        name: 'Mask External Account Numbers in FI Admin',
        type: 'boolean',
        description: 'Controls whether external account numbers are masked within the Admin site',
        default: true
    }),
    __metadata("design:type", Boolean)
], GlobalSettings.prototype, "maskExternalAccountNumbersInAdmin", void 0);
__decorate([
    configurableProperty({
        name: 'fiPhoneNumber',
        type: 'string',
        description: 'The customer support phone number for FI',
        default: '844-367-7728'
    }),
    __metadata("design:type", String)
], GlobalSettings.prototype, "fiPhoneNumber", void 0);
__decorate([
    configurableProperty({
        name: 'fiEmail',
        type: 'string',
        description: 'The customer support email for FI',
        default: ''
    }),
    __metadata("design:type", String)
], GlobalSettings.prototype, "fiEmail", void 0);
__decorate([
    configurableProperty({
        name: 'FQDN',
        type: 'string',
        description: 'Fully qualified domain name for the Web SPA (no trailing slash, e.g. uat-demo.lumindigital.com)',
        default: ''
    }),
    __metadata("design:type", String)
], GlobalSettings.prototype, "fqdn", void 0);
__decorate([
    configurableProperty({
        name: 'ADMIN FQDN',
        type: 'string',
        description: 'Fully qualified domain name for the Admin SPA (no trailing slash, e.g. admin.uat-demo.lumindigital.com)',
        default: ''
    }),
    __metadata("design:type", String)
], GlobalSettings.prototype, "adminFqdn", void 0);
__decorate([
    configurableProperty({
        name: 'browserTitle',
        type: 'string',
        description: 'Display format for browser tab title',
        default: '{{{ pageTitle }}}'
    }),
    __metadata("design:type", String)
], GlobalSettings.prototype, "browserTitle", void 0);
__decorate([
    configurableProperty({
        name: 'Supported Languages',
        type: 'array',
        description: 'Languages supported in addition to English such as Spanish ("es")',
        default: []
    }),
    __metadata("design:type", Array)
], GlobalSettings.prototype, "supportedLanguages", void 0);
__decorate([
    configurableProperty({
        name: 'SMS Program Name',
        type: 'string',
        description: 'Add the FI SMS program name at the beginning of each sms message/template we send out.',
        default: 'Sample FI Alerts:',
        tags: ['sms-twilio']
    }),
    __metadata("design:type", String)
], GlobalSettings.prototype, "smsProgramName", void 0);
__decorate([
    configurableProperty({
        name: 'fiType',
        type: 'string',
        description: 'The type of Financial Institution',
        default: 'Credit Union',
        allowedValues: ['Credit Union', 'Bank'],
        tags: ['bank-mode']
    }),
    __metadata("design:type", String)
], GlobalSettings.prototype, "fiType", void 0);
__decorate([
    configurableProperty({
        name: 'fiHostSystem',
        type: 'string',
        description: 'The host system used by the Financial Institution',
        default: 'DEMO',
        allowedValues: ['DEMO', 'CORELATION', 'SYMITAR', 'DNA', 'MISER', 'PHOENIX', 'PREMIER', 'PORTX XP2', 'SILVERLAKE']
    }),
    __metadata("design:type", String)
], GlobalSettings.prototype, "fiHostSystem", void 0);
__decorate([
    configurableProperty({
        name: 'Lumin Conversion (Go-Live) Date',
        type: 'string',
        description: 'Date the FI converted to (aka went live with) Lumin in YYYY-MM-DD format',
        default: ''
    }),
    __metadata("design:type", String)
], GlobalSettings.prototype, "_luminConversionDateString", void 0);
__decorate([
    configurableProperty({
        name: 'Holiday Schedule',
        type: 'json',
        default: [
            { name: 'Christmas Day', date: '2024-12-25' },
            { name: 'Christmas Day', date: '2025-12-25' },
            { name: 'Christmas Day', date: '2026-12-25' },
            { name: 'Christmas Day', date: '2027-12-25' },
            { name: 'Christmas Day', date: '2028-12-25' },
            { name: 'Christmas Day', date: '2029-12-25' },
            { name: 'Columbus Day', date: '2024-10-14' },
            { name: 'Columbus Day', date: '2025-10-13' },
            { name: 'Columbus Day', date: '2026-10-12' },
            { name: 'Columbus Day', date: '2027-10-11' },
            { name: 'Columbus Day', date: '2028-10-09' },
            { name: 'Columbus Day', date: '2029-10-08' },
            { name: 'Independence Day', date: '2024-07-04' },
            { name: 'Independence Day', date: '2025-07-04' },
            { name: 'Independence Day', date: '2026-07-04' },
            { name: 'Independence Day (Observed)', date: '2027-07-05' },
            { name: 'Independence Day', date: '2028-07-04' },
            { name: 'Independence Day', date: '2029-07-04' },
            { name: 'Juneteenth', date: '2024-06-19' },
            { name: 'Juneteenth', date: '2025-06-19' },
            { name: 'Juneteenth', date: '2026-06-19' },
            { name: 'Juneteenth', date: '2027-06-19' },
            { name: 'Juneteenth', date: '2028-06-19' },
            { name: 'Juneteenth', date: '2029-06-19' },
            { name: 'Labor Day', date: '2024-09-02' },
            { name: 'Labor Day', date: '2025-09-01' },
            { name: 'Labor Day', date: '2026-09-07' },
            { name: 'Labor Day', date: '2027-09-06' },
            { name: 'Labor Day', date: '2028-09-04' },
            { name: 'Labor Day', date: '2029-09-03' },
            { name: 'Martin Luther King Jr. Day', date: '2024-01-15' },
            { name: 'Martin Luther King Jr. Day', date: '2025-01-20' },
            { name: 'Martin Luther King Jr. Day', date: '2026-01-19' },
            { name: 'Martin Luther King Jr. Day', date: '2027-01-18' },
            { name: 'Martin Luther King Jr. Day', date: '2028-01-17' },
            { name: 'Martin Luther King Jr. Day', date: '2029-01-15' },
            { name: 'Memorial Day', date: '2024-05-27' },
            { name: 'Memorial Day', date: '2025-05-26' },
            { name: 'Memorial Day', date: '2026-05-25' },
            { name: 'Memorial Day', date: '2027-05-31' },
            { name: 'Memorial Day', date: '2028-05-29' },
            { name: 'Memorial Day', date: '2029-05-28' },
            { name: "New Year's Day", date: '2024-01-01' },
            { name: "New Year's Day", date: '2025-01-01' },
            { name: "New Year's Day", date: '2026-01-01' },
            { name: "New Year's Day", date: '2027-01-01' },
            { name: "New Year's Day", date: '2028-01-01' },
            { name: "New Year's Day", date: '2029-01-01' },
            { name: "Presidents' Day", date: '2024-02-19' },
            { name: "Presidents' Day", date: '2025-02-17' },
            { name: "Presidents' Day", date: '2026-02-16' },
            { name: "Presidents' Day", date: '2027-02-15' },
            { name: "Presidents' Day", date: '2028-02-21' },
            { name: "Presidents' Day", date: '2029-02-19' },
            { name: 'Thanksgiving Day', date: '2024-11-28' },
            { name: 'Thanksgiving Day', date: '2025-11-27' },
            { name: 'Thanksgiving Day', date: '2026-11-26' },
            { name: 'Thanksgiving Day', date: '2027-11-25' },
            { name: 'Thanksgiving Day', date: '2028-11-23' },
            { name: 'Thanksgiving Day', date: '2029-11-22' },
            { name: 'Veterans Day', date: '2024-11-11' },
            { name: 'Veterans Day', date: '2025-11-11' },
            { name: 'Veterans Day', date: '2026-11-11' },
            { name: 'Veterans Day', date: '2027-11-11' },
            { name: 'Veterans Day', date: '2028-11-11' },
            { name: 'Veterans Day (Observed)', date: '2029-11-12' }
        ],
        description: 'Federal Reserve Bank holiday schedule used for determining previous business day calculations.'
    }),
    __metadata("design:type", Array)
], GlobalSettings.prototype, "holidaySchedule", void 0);
GlobalSettings = GlobalSettings_1 = __decorate([
    configurableClass({
        configurationKey: globalSettingsKey,
        displayName: 'Global Settings'
    })
], GlobalSettings);
export { GlobalSettings };
export let globalSettings = new GlobalSettings();
