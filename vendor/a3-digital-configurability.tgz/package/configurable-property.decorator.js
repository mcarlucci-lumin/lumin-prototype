import { ConfigurableEntityRegistry, CONFIGURABLE_PROPERTIES_METADATA_KEY, CONFIGURABLE_CLASS_METADATA_KEY, CONFIGURED_VERSION_SYMBOL } from './configurable-entity-registry.js';
export var ValidationType;
(function (ValidationType) {
    ValidationType["REGEX"] = "REGEX";
})(ValidationType || (ValidationType = {}));
export function configurableProperty(annotation) {
    return function (target, propertyKey) {
        // important - on an instance property, the target parameter will be the prototype of the class created, not the constructor
        // record on constructor for metadata collection
        let classConstructor = target.constructor;
        // use getOwnMetadata since we don't want anything off the prototype chain
        let cpm = Reflect.getOwnMetadata(CONFIGURABLE_PROPERTIES_METADATA_KEY, classConstructor) || {};
        cpm[propertyKey] = annotation;
        Reflect.defineMetadata(CONFIGURABLE_PROPERTIES_METADATA_KEY, cpm, classConstructor);
        // create new descriptor wiring up to default configuration
        let descriptor = {
            configurable: true,
            enumerable: true,
            get() {
                // Check if instance needs (re)configuration
                let registry = ConfigurableEntityRegistry.instance();
                let currentVersion = registry.currentConfigurationVersion;
                if (this[CONFIGURED_VERSION_SYMBOL] !== currentVersion) {
                    // sanity check that class decorator is present
                    let cm = Reflect.getOwnMetadata(CONFIGURABLE_CLASS_METADATA_KEY, this.constructor);
                    if (!cm) {
                        throw Error('Class containing configurableProperty() decorators is missing configurableClass() decorator.');
                    }
                    registry.setActiveConfigurationFor(this);
                }
                return this[`__${propertyKey}`];
            },
            set(value) {
                this[`__${propertyKey}`] = value;
            }
        };
        Object.defineProperty(target, propertyKey, descriptor);
    };
}
