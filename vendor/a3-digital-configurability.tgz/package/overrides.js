export class Overrides {
    constructor() {
        this.meta = { featureFlags: [] };
        this.configurableSettings = {};
    }
}
