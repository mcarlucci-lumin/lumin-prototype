import 'reflect-metadata';
import { ActiveConfiguration } from './active-configuration.js';
export declare const CONFIGURABLE_CLASS_METADATA_KEY = "ConfigurableClassMetadata";
export declare const CONFIGURABLE_PROPERTIES_METADATA_KEY = "ConfigurablePropertiesMetadata";
export declare const EXPORTED_PROPERTIES_METADATA_KEY = "ExportedPropertiesMetadata";
export declare const CONFIGURED_VERSION_SYMBOL: unique symbol;
export declare class ConfigurableEntityRegistry {
    private activeConfiguration;
    private configurationVersion;
    private static _instance;
    static initialize(activeConfig?: ActiveConfiguration): void;
    static uninitialize(): void;
    static instance(): ConfigurableEntityRegistry;
    get currentConfigurationVersion(): number;
    private constructor();
    setActiveConfigurationFor(instance: Object): void;
    private calculateActiveConfigurationFor;
    private applyOverrides;
    private applyDefaults;
}
