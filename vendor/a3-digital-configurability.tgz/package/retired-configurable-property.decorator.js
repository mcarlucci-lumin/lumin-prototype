export function retiredConfigurableProperty(annotation) {
    return function (target, propertyKey) { };
}
