export var SettingsChangeType;
(function (SettingsChangeType) {
    SettingsChangeType["CONFIG"] = "CONFIG";
    SettingsChangeType["FEATURE_FLAG"] = "FEATURE_FLAG";
    SettingsChangeType["REVERTING"] = "REVERTING";
    SettingsChangeType["IMPORT"] = "IMPORT";
    SettingsChangeType["ENHANCED_IMPORT"] = "ENHANCED_IMPORT";
    SettingsChangeType["CONFIG_MIGRATIONS"] = "CONFIG_MIGRATIONS";
    SettingsChangeType["BULK_CONFIG"] = "BULK_CONFIG";
    SettingsChangeType["BULK_FEATURE_FLAG"] = "BULK_FEATURE_FLAG";
    SettingsChangeType["CONFIG_WORKSHEET"] = "CONFIG_WORKSHEET";
})(SettingsChangeType || (SettingsChangeType = {}));
