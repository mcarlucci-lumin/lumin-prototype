import { CONFIGURABLE_CLASS_METADATA_KEY } from './configurable-entity-registry.js';
export function configurableClass(metadata) {
    return (target) => {
        // store metadata
        Reflect.defineMetadata(CONFIGURABLE_CLASS_METADATA_KEY, metadata, target);
    };
}
