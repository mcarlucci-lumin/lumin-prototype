export declare class UserInfo {
    id: string;
    firstName: string;
    lastName: string;
    username: string;
}
