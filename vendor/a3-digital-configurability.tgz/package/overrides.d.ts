import { MetaOverrides } from './meta-overrides.js';
export declare class Overrides {
    meta: MetaOverrides;
    configurableSettings: {
        [key: string]: {
            [key: string]: any;
        };
    };
}
