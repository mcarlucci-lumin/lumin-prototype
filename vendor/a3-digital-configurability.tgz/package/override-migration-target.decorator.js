export function overrideMigrationTarget(annotation) {
    return function (target, propertyKey) { };
}
