export type AdditionalAdminGrant = 'SDK_ALLOW_VIEW' | 'SDK_ALLOW_EDIT';
