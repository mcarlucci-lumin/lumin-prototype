import { CustomizationDefinitionMetadata } from './customization-definition-metadata.js';
export declare const CUSTOMIZATION_DEFINITION_METADATA_KEY = "CustomizationDefinitionMetadata";
export declare function customizationDefinition(metadata: CustomizationDefinitionMetadata): any;
