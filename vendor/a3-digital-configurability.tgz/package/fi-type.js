export var FiType;
(function (FiType) {
    FiType["CREDIT_UNION"] = "Credit Union";
    FiType["BANK"] = "Bank";
})(FiType || (FiType = {}));
