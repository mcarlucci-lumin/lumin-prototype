export interface ConfigurablePropertyRef {
    configurationKey: string;
    property: string;
}
export interface FeatureFlagRef {
    id: string;
}
export type OverrideMigrationCondition = 'CREATE_IF_NONE_EXISTS';
export interface OverrideMigrationSpec {
    condition: OverrideMigrationCondition;
    asOfDate: string;
}
export interface OverrideMigrationTargetMetadata {
    sourceRef?: ConfigurablePropertyRef;
    sourceFeatureFlagRef?: FeatureFlagRef;
    spec: OverrideMigrationSpec;
}
export declare function overrideMigrationTarget(annotation: OverrideMigrationTargetMetadata): any;
