import { FeatureFlagExtendedData } from './feature-flag-extended-data.js';
import { FeatureFlagMode } from './feature-flag-mode.js';
export declare class FeatureFlag {
    id: string;
    enabled: boolean;
    mode?: FeatureFlagMode;
    extendedData?: FeatureFlagExtendedData;
    constructor(id: string, enabled: boolean, mode?: FeatureFlagMode, extendedData?: FeatureFlagExtendedData);
}
