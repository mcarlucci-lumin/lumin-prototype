export class FeatureFlagExtendedData {
}
