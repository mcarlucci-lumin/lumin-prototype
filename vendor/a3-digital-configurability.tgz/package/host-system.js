export var HostSystem;
(function (HostSystem) {
    HostSystem["DEMO"] = "DEMO";
    HostSystem["CORELATION"] = "CORELATION";
    HostSystem["SYMITAR"] = "SYMITAR";
    HostSystem["DNA"] = "DNA";
    HostSystem["MISER"] = "MISER";
    HostSystem["PHOENIX"] = "PHOENIX";
})(HostSystem || (HostSystem = {}));
