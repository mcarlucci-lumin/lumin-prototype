export var FeatureFlagMode;
(function (FeatureFlagMode) {
    FeatureFlagMode["UNKNOWN"] = "UNKNOWN";
    FeatureFlagMode["GLOBAL"] = "GLOBAL";
    FeatureFlagMode["USERLIST"] = "USERLIST";
})(FeatureFlagMode || (FeatureFlagMode = {}));
