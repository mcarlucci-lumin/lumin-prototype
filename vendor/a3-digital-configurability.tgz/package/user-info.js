export class UserInfo {
}
