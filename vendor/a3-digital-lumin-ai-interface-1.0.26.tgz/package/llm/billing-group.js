export var BillingGroup;
(function (BillingGroup) {
    BillingGroup["UNKNOWN"] = "UNKNOWN";
    BillingGroup["AGENT_CHAT"] = "AGENT_CHAT";
    BillingGroup["CMS_MSG_REFINEMENT"] = "CMS_MSG_REFINEMENT";
    BillingGroup["SECURE_MESSAGING"] = "SECURE_MESSAGING";
    BillingGroup["SECURE_FORMS"] = "SECURE_FORMS";
    BillingGroup["USER_SEG_GENERATE_RULES"] = "USER_SEG_GENERATE_RULES";
    BillingGroup["USER_STRUGGLE"] = "USER_STRUGGLE";
    BillingGroup["NAVIGATION_SEARCH"] = "NAVIGATION_SEARCH";
})(BillingGroup || (BillingGroup = {}));
//# sourceMappingURL=billing-group.js.map