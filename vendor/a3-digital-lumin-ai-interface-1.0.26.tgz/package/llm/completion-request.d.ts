import { AttachmentFile } from './attachment-file.js';
import { BillingGroup } from './billing-group.js';
import { ProviderConfig } from './llm-provider-config.js';
import { LuminAiFeature } from './lumin-ai-feature.js';
export interface CompletionRequest {
    systemContext: string;
    prompt: string;
    config: ProviderConfig;
    fallbackProviderList?: ProviderConfig[];
    file?: AttachmentFile;
    featureName?: LuminAiFeature;
    billingGroup?: BillingGroup;
}
