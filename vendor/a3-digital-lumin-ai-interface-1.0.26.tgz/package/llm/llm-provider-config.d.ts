import { LLMProvider } from './llm-provider.js';
export interface ProviderConfig {
    provider: LLMProvider;
    modelName?: string;
    settings?: {
        temperature?: number;
        maxRetries?: number;
        maxTokens?: number;
        maxOutputTokens?: number;
    };
    stopSequences?: string[];
    providerOptions?: Record<string, Record<string, any>>;
}
