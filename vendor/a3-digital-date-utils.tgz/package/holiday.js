export class Holiday {
}
//# sourceMappingURL=holiday.js.map