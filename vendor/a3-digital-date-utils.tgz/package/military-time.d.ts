export declare class MilitaryTime {
    constructor(hour?: number, minute?: number);
    hour: number;
    minute: number;
}
