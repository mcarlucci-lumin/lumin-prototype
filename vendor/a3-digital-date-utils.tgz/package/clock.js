export class Clock {
}
//# sourceMappingURL=clock.js.map