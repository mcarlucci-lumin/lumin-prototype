export declare enum UnitOfTime {
    years = "years",
    months = "months",
    weeks = "weeks",
    days = "days",
    hours = "hours",
    minutes = "minutes",
    seconds = "seconds"
}
