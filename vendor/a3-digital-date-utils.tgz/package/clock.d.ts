export declare abstract class Clock {
    abstract now(): Date;
}
