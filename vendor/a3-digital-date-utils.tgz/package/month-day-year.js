import { DateUtils } from './date-utils.js';
import { globalSettings } from '@a3-digital/configurability';
export class MonthDayYear {
    constructor(month, day, year, timeZone) {
        this.day = day;
        this.month = month;
        this.year = year;
        this.timeZone = timeZone;
    }
    static fromFIDate(date) {
        return this.fromLocalDate(date, globalSettings.fiTimeZone);
    }
    static fromLocalDate(date, timeZone) {
        let mdy = new MonthDayYear(Number(DateUtils.getLocalDateFormatString(date, timeZone, 'MM')), Number(DateUtils.getLocalDateFormatString(date, timeZone, 'DD')), Number(DateUtils.getLocalDateFormatString(date, timeZone, 'YYYY')), timeZone);
        return mdy;
    }
    toDate() {
        return DateUtils.getLocalStartOfDay(this.year, this.month, this.day, this.timeZone);
    }
    toDateString() {
        return DateUtils.getLocalDateFormatString(this.toDate(), this.timeZone, 'MM/DD/YYYY');
    }
}
//# sourceMappingURL=month-day-year.js.map