export class MilitaryTime {
    constructor(hour, minute) {
        this.hour = hour;
        this.minute = minute;
    }
}
//# sourceMappingURL=military-time.js.map