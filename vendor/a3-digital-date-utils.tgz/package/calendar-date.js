import { globalSettings } from '@a3-digital/configurability';
import { MonthDayYear } from './month-day-year.js';
import { DateUtils } from './date-utils.js';
export class CalendarDate {
    constructor(data) {
        if (data) {
            this.month = data.month;
            this.day = data.day;
            this.year = data.year;
        }
    }
    static fromDate(date) {
        const cal = new CalendarDate();
        cal.setDate(date);
        return cal;
    }
    setDate(date) {
        this.month = Number(DateUtils.getFIDateFormatString(date, 'MM'));
        this.day = Number(DateUtils.getFIDateFormatString(date, 'DD'));
        this.year = Number(DateUtils.getFIDateFormatString(date, 'YYYY'));
    }
    toDate() {
        return DateUtils.getFIStartOfDay(this.year, this.month, this.day);
    }
    toMonthDayYear() {
        return new MonthDayYear(this.month, this.day, this.year, globalSettings.fiTimeZone);
    }
    toDateString() {
        return DateUtils.getFIDateFormatString(this.toDate(), 'M/DD/YYYY');
    }
    add(delta, units) {
        let dt = this.toDate();
        switch (units) {
            case 'days':
                dt = DateUtils.addDays(dt, delta);
                break;
            case 'months':
                dt = DateUtils.addMonths(dt, delta);
                break;
            case 'years':
                dt = DateUtils.addMonths(dt, delta * 12);
                break;
        }
        this.setDate(dt);
    }
}
//# sourceMappingURL=calendar-date.js.map