/*
Documentation available at
https://a3digital.atlassian.net/wiki/spaces/DEV/pages/238911509/Date-Utils+working+with+dates+and+timezones+in+TypeScript
*/
import moment from 'moment-timezone';
import { globalSettings } from '@a3-digital/configurability';
import { StringUtils, LANGUAGES } from '@a3-digital/utils';
import { MonthDayYear } from './month-day-year.js';
import { MilitaryTime } from './index.js';
import 'moment/locale/es.js';
export class DateUtils {
    static { this._commonFormats = null; }
    static { this._commonDateFormats = ['M/D/YYYY',
        'MM/DD/YYYY',
        'M/D/YY',
        'MM/DD/YY',
        'YYYY-MM-DD',
        'MMMM D, YYYY',
        'MMM D, YYYY',
        'YYYY-M-D',
    ]; }
    static { this._commonTimeFormats = ['HH:mm',
        'hh:mm A',
        'hh:mm a'
    ]; }
    static getMonthList() {
        moment.locale('en');
        return moment.months();
    }
    static addMonths(date, months) {
        // fi timezone is important here 
        // because special logic is applied by moment
        // when original date is at the end of a month
        // that has more days than the new month
        let m = moment.tz(date, globalSettings.fiTimeZone);
        let adjustedDate = m.add(months, 'month').toDate();
        return adjustedDate;
    }
    static subtractMonths(date, months) {
        let m = moment.tz(date, globalSettings.fiTimeZone);
        let adjustedDate = m.subtract(months, 'month').toDate();
        return adjustedDate;
    }
    static addDays(date, days) {
        const mDate = moment.tz(date, globalSettings.fiTimeZone);
        const adjustedDate = mDate.add(days, 'day').toDate();
        return adjustedDate;
    }
    static subtractDays(date, days) {
        const mDate = moment.tz(date, globalSettings.fiTimeZone);
        const adjustedDate = mDate.subtract(days, 'day').toDate();
        return adjustedDate;
    }
    static addFIBusinessDays(date, days, holidays) {
        for (let i = 0; i < days; i++) {
            date = this.getNextFIBusinessDay(date, holidays);
        }
        return date;
    }
    static subtractFIBusinessDays(date, days, holidays) {
        for (let i = 0; i < days; i++) {
            date = this.getPrevFIBusinessDay(date, holidays);
        }
        return date;
    }
    static isFIBusinessDay(date, holidays) {
        let mdy = MonthDayYear.fromFIDate(date);
        let result = !(DateUtils.dayFallsOnWeekend(mdy) || this.dayFallsOnHoliday(mdy, holidays));
        return result;
    }
    static getPrevFIBusinessDay(date, holidays) {
        date = DateUtils.subtractDays(date, 1);
        while (!DateUtils.isFIBusinessDay(date, holidays)) {
            date = DateUtils.subtractDays(date, 1);
        }
        return date;
    }
    static getNextFIBusinessDay(date, holidays) {
        date = DateUtils.addDays(date, 1);
        while (!DateUtils.isFIBusinessDay(date, holidays)) {
            date = DateUtils.addDays(date, 1);
        }
        return date;
    }
    static addSeconds(date, seconds) {
        let result = new Date(date);
        result.setSeconds(result.getSeconds() + seconds);
        return result;
    }
    static addMilliseconds(date, milliseconds) {
        let result = new Date(date);
        result.setMilliseconds(result.getMilliseconds() + milliseconds);
        return result;
    }
    static addMinutes(date, minutes) {
        let result = new Date(date);
        result.setMinutes(result.getMinutes() + minutes);
        return result;
    }
    static getLocalDateTimeString(date, timeZone, language) {
        return this.getLocalDateFormatString(date, timeZone, 'YYYY-MM-DD HH:mm', language);
    }
    static getLocalDateString(date, timeZone, language) {
        return this.getLocalDateFormatString(date, timeZone, 'YYYY-MM-DD', language);
    }
    static getLocalDateAtTime(currentTime, hours, minutes, timeZone) {
        return this.getLocalDateAtTimeString(currentTime, `${StringUtils.zeroPadNumber(hours, 2)}:${StringUtils.zeroPadNumber(minutes, 2)}`, timeZone);
    }
    static getLocalDate(cal, hours, minutes, timeZone) {
        return this.parseLocalDate(`${cal.year}-${cal.month}-${cal.day} ${StringUtils.zeroPadNumber(hours, 2)}:${StringUtils.zeroPadNumber(minutes, 2)}`, timeZone, 'YYYY-MM-DD HH:mm');
    }
    static getLocalDateAtTimeString(date, timeString, timeZone) {
        let dateStr = `${this.getLocalDateString(date, timeZone)} ${timeString}`;
        let m = moment.tz(dateStr, 'YYYY-MM-DD HH:mm', timeZone);
        return m.toDate();
    }
    static getLocalStartOfDay(year, month, day, timeZone) {
        let dateStr = `${year}-${StringUtils.zeroPadNumber(month, 2)}-${StringUtils.zeroPadNumber(day, 2)} 00:00`;
        let m = moment.tz(dateStr, 'YYYY-MM-DD HH:mm', timeZone);
        return m.toDate();
    }
    static getFIStartOfDay(year, month, day) {
        return this.getLocalStartOfDay(year, month, day, globalSettings.fiTimeZone);
    }
    static getDateAtFITime(date, hours, minutes) {
        return this.getLocalDateAtTime(date, hours, minutes, globalSettings.fiTimeZone);
    }
    static getDateAtFITimeString(date, timeString) {
        return this.getLocalDateAtTimeString(date, timeString, globalSettings.fiTimeZone);
    }
    static getLocalDateFormatString(date, timeZone, format, language) {
        if (date === undefined || date === null) {
            return '';
        }
        if (language === undefined || language === null || !LANGUAGES.find(l => l.code === language.code)) {
            language = LANGUAGES.English;
        }
        let mdate = moment.tz(date, timeZone);
        mdate.locale(language.code);
        return mdate.format(format);
    }
    static getDateFormatString(date, format, language) {
        if (date === undefined || date === null) {
            return '';
        }
        if (language === undefined || language === null || !LANGUAGES.find(l => l.code === language.code)) {
            language = LANGUAGES.English;
        }
        let mdate = moment(date);
        mdate.locale(language.code);
        return mdate.format(format);
    }
    static getFIDateTimeString(date) {
        return this.getLocalDateTimeString(date, globalSettings.fiTimeZone);
    }
    static getFIDateTimeAsMoment() {
        let date = new Date();
        return moment(date).tz(globalSettings.fiTimeZone);
    }
    static parseDateTimeAsMoment(dateText) {
        return moment(dateText);
    }
    static getFIDateString(date) {
        return this.getLocalDateString(date, globalSettings.fiTimeZone);
    }
    static getFIDateFormatString(date, format, language) {
        return this.getLocalDateFormatString(date, globalSettings.fiTimeZone, format, language);
    }
    static fromEpoch(integer) {
        try {
            let m = moment(integer);
            if (!m.isValid()) {
                return null;
            }
            return m.toDate();
        }
        catch (err) {
            return null;
        }
    }
    static getCommonDateTimeFormats() {
        if (this._commonFormats === null) {
            let formats = [];
            // dates first
            for (let fmt of this._commonDateFormats) {
                formats.push(fmt);
            }
            // then date times
            for (let fmt of this._commonDateFormats) {
                for (let tfmt of this._commonTimeFormats) {
                    formats.push(fmt + ' ' + tfmt);
                }
            }
            this._commonFormats = formats;
        }
        return this._commonFormats;
    }
    static isExactDateString(text) {
        // todo make reg ex
        // looking for something that looks like this
        // '2017-12-01T12:00Z'
        if (text && text.length > 10
            && text.endsWith('Z')
            && text.substring(4, 5) === '-'
            && text.indexOf('T') !== -1
            && text.indexOf(':') !== -1) {
            return true;
        }
        else {
            return false;
        }
    }
    static parseFIDate(dateText) {
        try {
            if (this.isExactDateString(dateText)) {
                return this.parseTimeStamp(dateText);
            }
            // moment parsing sucks if you don't use explicit formats
            // try the common types
            let date = null;
            let formats = this.getCommonDateTimeFormats();
            for (let fmt of formats) {
                date = this.parseFIDateFormat(dateText, fmt);
                if (date) {
                    return date;
                }
            }
            return null;
        }
        catch (err) {
            return null;
        }
    }
    static parseTimeStamp(timeStamp) {
        return moment(timeStamp).toDate();
    }
    static parseLocalDate(dateText, timeZone, format) {
        try {
            let m = moment.tz(dateText, format, true, timeZone);
            if (!m.isValid()) {
                return null;
            }
            return m.toDate();
        }
        catch (err) {
            return null;
        }
    }
    static parseFIDateFormat(dateText, format) {
        try {
            let m = moment.tz(dateText, format, true, globalSettings.fiTimeZone);
            if (!m.isValid()) {
                return null;
            }
            return m.toDate();
        }
        catch (err) {
            return null;
        }
    }
    static isFIDateValid(dateText, minValue, maxValue) {
        try {
            let date = this.parseFIDate(dateText);
            if (!date) {
                return false;
            }
            if (minValue && date < minValue) {
                return false;
            }
            if (maxValue && date > maxValue) {
                return false;
            }
            return true;
        }
        catch (err) {
            // invalid date
            return false;
        }
    }
    static isDateValid(dateText, minValue, maxValue) {
        try {
            let date = this.parseFIDate(dateText);
            if (!date) {
                return false;
            }
            if (minValue && date < minValue) {
                return false;
            }
            if (maxValue && date > maxValue) {
                return false;
            }
            return true;
        }
        catch (err) {
            // invalid date
            return false;
        }
    }
    static dayFallsOnWeekend(mdy) {
        let m = moment.tz(mdy.toDate(), mdy.timeZone);
        return m.day() === 0 || m.day() === 6;
    }
    static dayFallsOnHoliday(mdy, holidays) {
        const formattedDateString = DateUtils.getLocalDateFormatString(mdy.toDate(), mdy.timeZone, 'YYYY-MM-DD');
        for (let holiday of holidays) {
            if (holiday.date === formattedDateString) {
                return true;
            }
        }
        return false;
    }
    static isFILastDayOfMonth(date) {
        let m = moment.tz(date, globalSettings.fiTimeZone);
        let startDate = m.clone().startOf('day');
        let endOfMonth = m.clone().endOf('month').startOf('day');
        return startDate.isSame(endOfMonth);
    }
    static isFirstDayOfMonth(date) {
        return date.getDate() === 1;
    }
    static getFirstDayOfWeek(date) {
        let m = moment.tz(date, globalSettings.fiTimeZone);
        return m.startOf('week').toDate();
    }
    static getLastDayOfWeek(date) {
        let m = moment.tz(date, globalSettings.fiTimeZone);
        return m.endOf('week').toDate();
    }
    static getFirstDayOfMonth(date) {
        let m = moment.tz(date, globalSettings.fiTimeZone);
        return m.startOf('month').toDate();
    }
    static getLastDayOfMonth(date) {
        let m = moment.tz(date, globalSettings.fiTimeZone);
        return m.endOf('month').toDate();
    }
    static getFirstDayOfYear(date) {
        let m = moment.tz(date, globalSettings.fiTimeZone);
        return m.startOf('year').toDate();
    }
    static getLastDayOfYear(date) {
        let m = moment.tz(date, globalSettings.fiTimeZone);
        return m.endOf('year').toDate();
    }
    static areSameLocalDay(date1, date2, timeZone) {
        let d1 = this.getLocalDateFormatString(date1, timeZone, 'YYYY-MM-DD');
        let d2 = this.getLocalDateFormatString(date2, timeZone, 'YYYY-MM-DD');
        return d1 === d2;
    }
    static areSameFIDay(date1, date2) {
        let d1 = this.getLocalDateFormatString(date1, globalSettings.fiTimeZone, 'YYYY-MM-DD');
        let d2 = this.getLocalDateFormatString(date2, globalSettings.fiTimeZone, 'YYYY-MM-DD');
        return d1 === d2;
    }
    static dateFromUnixSeconds(seconds) {
        return moment.unix(seconds).toDate();
    }
    static diff(date1, date2, unit) {
        let m1 = moment(date1);
        let m2 = moment(date2);
        return m1.diff(m2, unit);
    }
    static parseJsonWithDates(json, dateFields) {
        let reviverFn = this.getJsonDateReviverFn(dateFields);
        return JSON.parse(json, reviverFn);
    }
    static getJsonDateReviverFn(dateFields) {
        let reviverFn = (key, value) => {
            if (dateFields.indexOf(key) !== -1) {
                return new Date(value);
            }
            else {
                return value;
            }
        };
        return reviverFn;
    }
    // parses 8:12 pm and returns object with hours = 20 and minutes = 12
    static parseTimeOfDay(timeOfDay) {
        try {
            if (!timeOfDay) {
                return null;
            }
            let parts = timeOfDay.split(':');
            if (parts.length !== 2) {
                return null; // invalid
            }
            let mt = new MilitaryTime();
            mt.hour = parseInt(parts[0].trim(), 10);
            let subParts = parts[1].split(' ');
            if (subParts.length === 2 && subParts[1].toUpperCase().startsWith('P') && mt.hour !== 12) {
                mt.hour = mt.hour + 12;
            }
            else if (subParts.length === 2 && subParts[1].toUpperCase().startsWith('A') && mt.hour === 12) {
                mt.hour = 0;
            }
            let minutes = subParts[0].trim();
            mt.minute = minutes === '00' ? 0 : parseInt(StringUtils.trimLeadingZeros(minutes), 10);
            if (mt.hour < 0 || mt.hour > 23) {
                return null; // invalid
            }
            if (mt.minute < 0 || mt.minute > 59) {
                return null; // invalid
            }
            if (isNaN(mt.minute) || isNaN(mt.hour)) {
                return null;
            }
            return mt;
        }
        catch (err) {
            return null; // invalid
        }
    }
    static getLocalDayOfMonth(date, timeZone) {
        let day = DateUtils.getFIDateFormatString(date, 'D');
        return Number(day);
    }
    static getFIDayOfMonth(date) {
        return this.getLocalDayOfMonth(date, globalSettings.fiTimeZone);
    }
    static getLocalMonth(date, timeZone) {
        let month = DateUtils.getFIDateFormatString(date, 'M');
        return Number(month);
    }
    static getFIMonth(date) {
        return this.getLocalMonth(date, globalSettings.fiTimeZone);
    }
    static setFIDayOfMonth(date, dayOfMonth) {
        const m = moment.tz(date, globalSettings.fiTimeZone);
        const adjustedDate = m.set('date', dayOfMonth).toDate();
        return adjustedDate;
    }
    static getFILastDayOfMonth(date) {
        const m = moment.tz(date, globalSettings.fiTimeZone);
        const endOfMonth = m.endOf('month');
        return endOfMonth.date();
    }
    static convertCutoffTimeToFITimeZoneForToday(now, cutoffTimeZone, cutOffTime) {
        const date = DateUtils.getLocalDateAtTime(now, cutOffTime.hour, cutOffTime.minute, cutoffTimeZone);
        const hours = Number(DateUtils.getFIDateFormatString(date, 'HH'));
        const minutes = Number(DateUtils.getFIDateFormatString(date, 'mm'));
        return new MilitaryTime(hours, minutes);
    }
    static convertTwoDigitYearToFourDigitYear(twoDigitYear) {
        const date = moment(twoDigitYear, 'YY');
        const fourDigitYear = date.format('YYYY');
        return fourDigitYear;
    }
    static doDateRangesOverlap(range1_start, range1_end, range2_start, range2_end) {
        let time1_start = range1_start.getTime();
        let time1_end = range1_end.getTime();
        let time2_start = range2_start.getTime();
        let time2_end = range2_end.getTime();
        if (time1_start <= time2_start && time2_start <= time1_end) { // range2 starts in range1
            return true;
        }
        if (time1_start <= time2_end && time2_end <= time1_end) { // range2 ends in range1
            return true;
        }
        if (time2_start < time1_start && time1_end < time2_end) { // range1 occurs in range2
            return true;
        }
        return false;
    }
    static areEqual(date1, date2) {
        if (!date1 || !date2) {
            return false;
        }
        return date1.getTime() === date2.getTime();
    }
    static adjustFutureDateToPast(now, dateToAdjust) {
        if (!dateToAdjust) {
            return dateToAdjust;
        }
        if (dateToAdjust > now) {
            const adjusted = new Date(dateToAdjust);
            adjusted.setFullYear(adjusted.getFullYear() - 100);
            return adjusted;
        }
        return dateToAdjust;
    }
}
//# sourceMappingURL=date-utils.js.map