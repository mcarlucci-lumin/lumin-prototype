import { DateUtils } from './date-utils.js';
import { globalSettings } from '@a3-digital/configurability';
export class DateProvider {
    constructor(clock) {
        this.clock = clock;
    }
    // returns current date
    getDate() {
        return this.clock.now();
    }
    getFIStartOfDay() {
        return DateUtils.getDateAtFITime(this.getDate(), 0, 0);
    }
    getDateAtFITimeToday(hours, minutes) {
        return DateUtils.getDateAtFITime(this.getDate(), hours, minutes);
    }
    getDateAtFITimeStringToday(timeString) {
        return DateUtils.getDateAtFITimeString(this.getDate(), timeString);
    }
    getFIDateString() {
        return DateUtils.getFIDateString(this.getDate());
    }
    getFIDateTimeString() {
        return DateUtils.getFIDateTimeString(this.getDate());
    }
    getFIDateFormatString(format) {
        return DateUtils.getFIDateFormatString(this.getDate(), format);
    }
    getLocalDateString(timeZone) {
        return DateUtils.getLocalDateString(this.getDate(), timeZone);
    }
    getLocalDateTimeString(timeZone) {
        return DateUtils.getLocalDateTimeString(this.getDate(), timeZone);
    }
    isPastTodaysCutOff(cutOffTime, cutOffTimeZone) {
        let cutOff = this.getTodaysCutOffTime(cutOffTime, cutOffTimeZone);
        let time = this.getDate();
        return time > cutOff;
    }
    getTodaysCutOffTime(cutOffTime, cutOffTimeZone) {
        return DateUtils.getLocalDateAtTime(this.getDate(), cutOffTime.hour, cutOffTime.minute, cutOffTimeZone);
    }
    isPastTodaysCutOffInFITimeZone(cutOffTime) {
        let cutOff = this.getTodaysCutOffTime(cutOffTime, globalSettings.fiTimeZone);
        return cutOff > this.getDate();
    }
    getTodaysCutOffTimeForFITimeZone(cutOffTime) {
        return DateUtils.getLocalDateAtTime(this.getDate(), cutOffTime.hour, cutOffTime.minute, globalSettings.fiTimeZone);
    }
    isPastTodaysCutoffForOtherTimeZone(cutOffTime, cutOffTimeZone) {
        const fiCutOff = this.convertCutoffTimeToFITimeZoneForToday(cutOffTimeZone, cutOffTime);
        const fiCutOfftime = this.getDateAtFITimeStringToday(`${fiCutOff.hour}:${fiCutOff.minute}`);
        const time = this.getDate();
        return time > fiCutOfftime;
    }
    convertCutoffTimeToFITimeZoneForToday(cutoffTimeZone, cutOffTime) {
        return DateUtils.convertCutoffTimeToFITimeZoneForToday(this.getDate(), cutoffTimeZone, cutOffTime);
    }
    isInFITimeWindow(timeRange) {
        return this.isInLocalTimeWindow(timeRange, globalSettings.fiTimeZone);
    }
    // HH:MM-HH:MM
    isInLocalTimeWindow(timeRange, timeZone) {
        const regEx = new RegExp(/^\d{2}:\d{2}-\d{2}:\d{2}$/);
        const matches = regEx.exec(timeRange);
        if (!matches || matches.length !== 1) {
            throw Error(`Invalid time range ${timeRange}`);
        }
        const [startTime, endTime] = timeRange.split('-').map(x => x.trim());
        if (!startTime || !endTime) {
            throw Error(`Invalid time range ${timeRange}`);
        }
        const now = this.getDate();
        const start = DateUtils.getLocalDateAtTimeString(now, startTime, timeZone);
        let end = DateUtils.getLocalDateAtTimeString(now, endTime, timeZone);
        if (!end || !start) {
            throw Error(`Invalid time range ${timeRange}`);
        }
        if (end < start) {
            // this range wraps around midnight e.g. 22:00 - 02:00
            // check current time greater than start OR current time less then end 
            // 
            return now >= start || now <= end;
        }
        else {
            // this is a normal range with in a day  e.g. 13:00 - 17:00
            // check that current time greater than start AND current time less than end
            return now >= start && now <= end;
        }
    }
}
//# sourceMappingURL=date-provider.js.map