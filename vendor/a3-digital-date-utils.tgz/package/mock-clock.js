import { Clock } from './clock.js';
export class MockClock extends Clock {
    constructor(systemTime) {
        super();
        this.systemTime = systemTime;
    }
    now() {
        return new Date(this.systemTime.getTime());
    }
    setTime(time) {
        this.systemTime = time;
    }
}
//# sourceMappingURL=mock-clock.js.map