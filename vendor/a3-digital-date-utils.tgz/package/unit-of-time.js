// below comes from https://momentjs.com/docs/#/displaying/difference/
export var UnitOfTime;
(function (UnitOfTime) {
    UnitOfTime["years"] = "years";
    UnitOfTime["months"] = "months";
    UnitOfTime["weeks"] = "weeks";
    UnitOfTime["days"] = "days";
    UnitOfTime["hours"] = "hours";
    UnitOfTime["minutes"] = "minutes";
    UnitOfTime["seconds"] = "seconds";
})(UnitOfTime || (UnitOfTime = {}));
//# sourceMappingURL=unit-of-time.js.map