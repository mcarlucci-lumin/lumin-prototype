import 'reflect-metadata';
import { MessageContext } from '@a3-digital/log-client';
import * as path from 'path';
import * as fs from 'fs';
import { CUSTOMIZATION_DEFINITION_METADATA_KEY } from '@a3-digital/configurability';
import { CustomizationEntry } from './customization-entry.js';
import { Customization } from './customization.js';
export var DiscoveryMode;
(function (DiscoveryMode) {
    DiscoveryMode["PERMISSIVE"] = "PERMISSIVE";
    DiscoveryMode["STRICT"] = "STRICT";
})(DiscoveryMode || (DiscoveryMode = {}));
export async function loadPlugins(customizationsRootPath, container, logger, mode = DiscoveryMode.PERMISSIVE) {
    let messageContext = MessageContext.createNewMessageContext();
    if (fs.existsSync(customizationsRootPath)) {
        logger.info({
            msg: `Customizations root directory found at ${customizationsRootPath}' - beginning customizations discovery and initialization...`,
            messageContext
        });
        // get list of customization directories
        let candidateDirs = fs.readdirSync(customizationsRootPath)
            .filter(file => fs.statSync(path.join(customizationsRootPath, file)).isDirectory());
        if (candidateDirs && candidateDirs.length > 0) {
            let entries = [];
            for await (const candidateDir of candidateDirs) {
                let probeDirPath = path.join(customizationsRootPath, candidateDir);
                logger.info({
                    msg: `Probing for customization ${candidateDir} using path '${probeDirPath}' and discovery mode ${mode}...`,
                    messageContext
                });
                let mod;
                try {
                    // Node.js ESM requires explicit file extensions, try common entry points
                    const commonEntries = ['index.js', 'index.mjs'];
                    let pluginPath = null;
                    for (const fileEntry of commonEntries) {
                        const candidatePath = path.join(probeDirPath, fileEntry);
                        if (fs.existsSync(candidatePath)) {
                            pluginPath = candidatePath;
                            break;
                        }
                    }
                    if (!pluginPath) {
                        throw new Error(`No valid entry point (index.js, index.mjs) found in ${probeDirPath}`);
                    }
                    // Convert to file:// URL for proper ESM import
                    const fileUrl = new URL(`file://${path.resolve(pluginPath)}`).href;
                    mod = await import(fileUrl);
                }
                catch (err) {
                    // no default export in module
                    logger.error({
                        msg: `Customization ${probeDirPath} cannot be loaded as a module due to an error and will be skipped`,
                        messageContext,
                        err
                    });
                    // skip since couldn't be loaded
                    return;
                }
                // iterate through module's exports looking for class with customizationDefinition decorator
                let customizationClass;
                let customizationMetadata;
                Object.getOwnPropertyNames(mod).forEach(name => {
                    let candidate = mod[name];
                    if (typeof candidate !== 'function') {
                        // not a potential customization class definition
                        return;
                    }
                    let meta = Reflect.getMetadata(CUSTOMIZATION_DEFINITION_METADATA_KEY, candidate);
                    if (meta) {
                        customizationMetadata = meta;
                        customizationClass = candidate;
                    }
                });
                let entry;
                if (customizationMetadata &&
                    customizationClass &&
                    // check if extends Customization so that required register() method can be called
                    customizationClass.prototype instanceof Customization) {
                    try {
                        // create instance of customizaton
                        let instance = new customizationClass();
                        entry = new CustomizationEntry(customizationMetadata, instance, customizationMetadata.priority ?? 0);
                    }
                    catch (err) {
                        logger.error({
                            msg: `Customization ${customizationClass.name} instance could not be created due to an error`,
                            messageContext,
                            err
                        });
                    }
                }
                else {
                    logger.info({
                        msg: `Customization ${probeDirPath} does not have an exported class with the required customizationDefinition() decorator and extends Customization`,
                        messageContext
                    });
                }
                if (!entry && mode === DiscoveryMode.PERMISSIVE) {
                    // try legacy customization discovery
                    logger.info({
                        msg: `Mode ${mode} is set attempting legacy customization discovery`,
                        messageContext
                    });
                    let legacyPluginInstance = mod.default();
                    if (legacyPluginInstance) {
                        let metadata = legacyPluginInstance.info();
                        entry = new CustomizationEntry(metadata, legacyPluginInstance, metadata.priority ?? 0);
                    }
                    else {
                        // report not expected default export
                        logger.info({
                            msg: `Customization ${probeDirPath} module.default() did not result in an instance with required info() and register() methods`,
                            messageContext
                        });
                    }
                }
                if (entry) {
                    entries.push(entry);
                    logger.info({
                        msg: `Customization ${candidateDir} using path '${probeDirPath}' loaded successfully`,
                        messageContext
                    });
                }
                else {
                    logger.info({
                        msg: `Customization ${candidateDir} using path '${probeDirPath}' was not loaded succesfully`,
                        messageContext
                    });
                }
            }
            // pass container to each plugin
            entries.sort((a, b) => {
                if (a.priority < b.priority) {
                    return -1;
                }
                if (a.priority > b.priority) {
                    return 1;
                }
                return 0;
            }).forEach((entry) => {
                try {
                    entry.instance.register(container);
                }
                catch (err) {
                    logger.error({
                        err,
                        msg: `Error initializing customization: '${entry.metadata.name}'`,
                        messageContext
                    });
                }
            });
        }
        else {
            logger.info({
                msg: 'No candidate customization directories found ...',
                messageContext
            });
        }
    }
    else {
        logger.info({
            msg: `Directory not found at '${customizationsRootPath}' - skipping customization discovery...`,
            messageContext
        });
    }
}
//# sourceMappingURL=load-plugins.js.map