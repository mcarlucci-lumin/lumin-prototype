export class CustomizationEntry {
    constructor(metadata, instance, priority) {
        this.metadata = metadata;
        this.instance = instance;
        this.priority = priority;
    }
}
//# sourceMappingURL=customization-entry.js.map