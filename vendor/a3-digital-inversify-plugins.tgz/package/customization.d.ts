import { Container } from 'inversify';
export declare abstract class Customization {
    abstract register(container: Container): void;
}
