import { Container } from 'inversify';
export interface Info {
    name: string;
    priority: number;
    version: string;
}
export interface Plugin {
    register(container: Container): void;
    info(): Info;
}
