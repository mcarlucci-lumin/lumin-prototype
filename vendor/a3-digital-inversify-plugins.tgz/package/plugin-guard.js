import { MessageContext } from '@a3-digital/log-client';
import { METADATA_KEY } from 'inversify-express-utils/lib/constants.js';
export function capturePluginGuardSnapshot() {
    const baseControllers = Reflect.getMetadata(METADATA_KEY.controller, Reflect) || [];
    const baseTargetMetadata = new Map(baseControllers.map(c => [c.target, Reflect.getMetadata(METADATA_KEY.controller, c.target)]));
    return { baseControllers, baseTargetMetadata };
}
export function enforcePluginGuardSnapshot(state, logger) {
    const { baseControllers, baseTargetMetadata } = state;
    const updatedControllers = Reflect.getMetadata(METADATA_KEY.controller, Reflect) || [];
    if (baseControllers.length !== updatedControllers.length) {
        const basePaths = new Set(baseControllers.map(c => c.path));
        const addedEntries = updatedControllers.filter(c => !baseControllers.includes(c));
        const conflicting = addedEntries.filter(c => basePaths.has(c.path)).map(c => c.path);
        const newPaths = addedEntries.filter(c => !basePaths.has(c.path)).map(c => c.path);
        const registrationError = new Error('Invalid Plugin Configuration');
        logger.error({
            msg: `SDK plugin attempted to register controllers — service startup aborted.` +
                (conflicting.length ? ` conflictingPaths: [${conflicting.map(p => `'${p}'`).join(', ')}]` : '') +
                (newPaths.length ? ` newPaths: [${newPaths.map(p => `'${p}'`).join(', ')}]` : ''),
            err: registrationError,
            messageContext: MessageContext.createNewMessageContext()
        });
        throw registrationError;
    }
    const tamperedTargets = baseControllers
        .filter(c => Reflect.getMetadata(METADATA_KEY.controller, c.target) !== baseTargetMetadata.get(c.target))
        .map(c => c.target?.name ?? 'unknown');
    if (tamperedTargets.length > 0) {
        const tamperError = new Error('Invalid Plugin Configuration');
        logger.error({
            msg: `SDK plugin tampered with base controller metadata — service startup aborted. tamperedControllers: [${tamperedTargets.map(t => `'${t}'`).join(', ')}]`,
            err: tamperError,
            messageContext: MessageContext.createNewMessageContext()
        });
        throw tamperError;
    }
}
//# sourceMappingURL=plugin-guard.js.map