import { LogClient } from '@a3-digital/log-client';
import type { ControllerMetadata, DecoratorTarget } from 'inversify-express-utils';
interface PluginGuardSnapshot {
    baseControllers: ControllerMetadata[];
    baseTargetMetadata: Map<DecoratorTarget, ControllerMetadata>;
}
export declare function capturePluginGuardSnapshot(): PluginGuardSnapshot;
export declare function enforcePluginGuardSnapshot(state: PluginGuardSnapshot, logger: LogClient): void;
export {};
