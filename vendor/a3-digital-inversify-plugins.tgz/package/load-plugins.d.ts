import 'reflect-metadata';
import { Container } from 'inversify';
import { LogClient } from '@a3-digital/log-client';
export declare enum DiscoveryMode {
    PERMISSIVE = "PERMISSIVE",
    STRICT = "STRICT"
}
export declare function loadPlugins(customizationsRootPath: string, container: Container, logger: LogClient, mode?: DiscoveryMode): Promise<void>;
