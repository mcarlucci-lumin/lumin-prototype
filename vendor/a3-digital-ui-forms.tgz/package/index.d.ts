import * as i0 from '@angular/core';
import { OnInit, EventEmitter, ElementRef, AfterViewChecked, NgZone, AfterViewInit, ChangeDetectorRef, OnChanges, SimpleChanges, Type, TemplateRef, OnDestroy, AfterContentChecked } from '@angular/core';
import * as i47 from '@angular/forms';
import { ControlValueAccessor, ControlContainer, AbstractControl, ValidationErrors, ValidatorFn, UntypedFormGroup, UntypedFormBuilder, NgModel, FormGroup, Validator } from '@angular/forms';
import * as i48 from '@a3-digital/ui-core';
import { BaseTextComponent, DynamicAttribute, TextService, BaseDestroyComponent, WindowService, AttachmentFile, NotificationTheme, LabelValueListItem, TextSize, DescriptionListItem, ImageDisplayMode, ObjectPosition, BadgeModel, NotificationButton, AccountTemplateStatus, AccountTemplateType, BaseMenuState, Action, BaseMenuComponent, FileType, CollapsableComponent, SpacingConfig, HtmlAttributeState, ModalService, ChipListItem } from '@a3-digital/ui-core';
import { State, Country } from '@a3-digital/utils';
import * as rxjs from 'rxjs';
import { Observable, Subject } from 'rxjs';
import * as i46 from '@ng-bootstrap/ng-bootstrap';
import { Placement, NgbDateStruct, NgbDateNativeAdapter } from '@ng-bootstrap/ng-bootstrap';
import { ColorClass } from '@a3-digital/ui-styles';
import { ValidationResult } from '@a3-digital/validation';
import { Holiday, DateProvider } from '@a3-digital/date-utils';
import { Params, Router } from '@angular/router';
import * as i45 from '@angular/common';
import * as i49 from 'ngx-turnstile';

declare abstract class BaseFieldComponent<T> extends BaseTextComponent implements ControlValueAccessor, OnInit {
    protected controlContainer?: ControlContainer;
    class: boolean;
    menuStyles: boolean;
    /**
    * Displays a success themed message
    **/
    successMessage: string;
    /**
    * Displays an info themed message
    **/
    infoMessage: string;
    /**
    * Displays a warning themed message
    **/
    warningMessage: string;
    /**
    * Displays when the field is invalid
    **/
    errorMessage: string;
    get lockedMessage(): string;
    /**
    * Displays when the field is locked
    *  - has a default value that always displays for locked fields
    *  - accepts strings or boolean false - if you don't want any message displayed for a locked field, set this to false - `field.lockedMessage: false`
    **/
    set lockedMessage(value: string);
    /**
    * Required. The label for the form field
    **/
    label: string;
    /**
    * Can be used to visually hide the label. Label should always be provided, and hidden if undesired
    **/
    hideLabel: boolean;
    /**
    * Provides a unique name for the field used by Angular reactive forms.
    * Is used by some form field implementations to access the FormControl.
    * It is used to generate e2e attributes if e2e attribute is not provided.
    **/
    formControlName: string;
    /**
    * Allows for a custom e2e prefix instead of using the form control name.
    **/
    e2e: string;
    /**
    * Specifies whether or not the field should be read-only. Locked fields cannot be modified by the user.
    **/
    locked: boolean;
    /**
    * Content to display in the tooltip popover
    **/
    tooltip: string;
    /**
    * Direction to place the tooltip popover.
    * "auto" (default) will attempt to place the popover where it can be seen (based on container/window bounds)
    * See ng-bootstrap documentation for details - type: Placement
    **/
    tooltipPlacement: 'auto' | 'top' | 'top-left' | 'top-right' | 'bottom' | 'bottom-left' | 'bottom-right' | 'left' | 'left-top' | 'left-bottom' | 'right' | 'right-top' | 'right-bottom';
    /**
    * Emits the new value when the value changes.
    **/
    change: EventEmitter<T>;
    get control(): AbstractControl;
    get controlTouched(): boolean;
    get showControlInvalid(): boolean;
    get required(): boolean;
    private _lockedMessage;
    baseText: any;
    readonly fieldId: string;
    readonly labelId: string;
    e2ePrefix: string;
    e2eField: string;
    value: T;
    onTouched: () => void;
    onChange: (value: T) => void;
    disablePasswordManagers: DynamicAttribute[];
    constructor(textService: TextService, textConfigKey: string, controlContainer?: ControlContainer);
    ngOnInit(): void;
    abstract writeValue(value: T): void;
    registerOnChange(onChangeFunction: (value: T) => any): void;
    registerOnTouched(onTouchedFunction: () => any): void;
    protected writeValueAndEmitChange(value: T): void;
    protected shouldEmitChange(incomingValue: any): boolean;
    stopEvent(event: Event): void;
    private setE2EPrefix;
    private mergeBaseText;
    private getLockedMessage;
    protected controlPasswordManagers(allowed: boolean): void;
    protected getDefaultBaseText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseFieldComponent<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BaseFieldComponent<any>, never, never, { "successMessage": { "alias": "successMessage"; "required": false; }; "infoMessage": { "alias": "infoMessage"; "required": false; }; "warningMessage": { "alias": "warningMessage"; "required": false; }; "errorMessage": { "alias": "errorMessage"; "required": false; }; "lockedMessage": { "alias": "lockedMessage"; "required": false; }; "label": { "alias": "label"; "required": false; }; "hideLabel": { "alias": "hideLabel"; "required": false; }; "formControlName": { "alias": "formControlName"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; "locked": { "alias": "locked"; "required": false; }; "tooltip": { "alias": "tooltip"; "required": false; }; "tooltipPlacement": { "alias": "tooltipPlacement"; "required": false; }; }, { "change": "change"; }, never, never, true, never>;
}

interface BotDetectionConfiguration {
    provider: string;
    enabled: boolean;
}
declare class TurnstileConfiguration implements BotDetectionConfiguration {
    enabled: boolean;
    siteKey: string;
    readonly provider = "turnstile";
    constructor(enabled: boolean, siteKey: string);
}
declare const UI_BOT_DETECTION_PROVIDER = "UI_BOT_DETECTION_PROVIDER";
interface UiBotDetectionProvider {
    getConfiguration(): BotDetectionConfiguration;
    onError(error: string): void;
    onVerification(value: string): void;
}

declare class BotDetectionService {
    protected botDetectionProvider: UiBotDetectionProvider;
    constructor(botDetectionProvider: UiBotDetectionProvider);
    enabled(): boolean;
    getConfig(): BotDetectionConfiguration;
    onError(error: string): void;
    onVerification(value: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BotDetectionService, [{ optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BotDetectionService>;
}

declare class BotDetectionComponent extends BaseFieldComponent<string> {
    textService: TextService;
    private botDetectionService;
    protected controlContainer: ControlContainer;
    private config;
    turnstileSiteKey: string;
    constructor(textService: TextService, botDetectionService: BotDetectionService, controlContainer: ControlContainer);
    private initialize;
    handleTurnstileEvent(value: string, isError: boolean): void;
    writeValue(value: string): void;
    protected getDefaultText(): {
        defaultLabel: string;
        defaultErrorMessage: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<BotDetectionComponent, [null, null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BotDetectionComponent, "ui-forms-bot-detection", never, {}, {}, never, never, false, never>;
}

declare abstract class BaseBooleanFieldComponent extends BaseFieldComponent<boolean> {
    /**
    * Boolean that specifies whether the field is checked.
    **/
    get checked(): boolean;
    set checked(checked: boolean);
    constructor(textService: TextService);
    writeValue(value: boolean): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseBooleanFieldComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BaseBooleanFieldComponent, never, never, { "checked": { "alias": "checked"; "required": false; }; }, {}, never, never, true, never>;
}

declare class CheckboxComponent extends BaseBooleanFieldComponent {
    input: ElementRef;
    /**
    * Boolean to toggle the "indeterminate" state, which can be used to show partial selection
    * within a group of checkboxes.
    **/
    indeterminate: boolean;
    /**
    * Boolean to indicate this is used inside another component.
    * Warning: This is not intended to be used when there is a visible label.
    * The wrapping of the label is affected when isChild is set to true.
    **/
    isChild: boolean;
    /**
    * Optional - secondary text to display next to the label.
    **/
    secondaryLabel: string;
    /**
    * Optional - lines of text to display beneath the label.
    **/
    subtextLines: string[];
    /**
    * ARIA Label attribute (aria-label)
    * Used to replace the button message with more descriptive text, screen-readers will read the ariaLabel, instead of message
    **/
    ariaLabel: string;
    onBlur(): void;
    onInputClick(): void;
    onTouchTargetClick(): void;
    private handleInputClick;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckboxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckboxComponent, "ui-forms-checkbox", never, { "indeterminate": { "alias": "indeterminate"; "required": false; }; "isChild": { "alias": "isChild"; "required": false; }; "secondaryLabel": { "alias": "secondaryLabel"; "required": false; }; "subtextLines": { "alias": "subtextLines"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; }, {}, never, never, false, never>;
}

/**
* A checkbox control on its own, with no label of its own. For hosts that lay out their own text
* alongside it and drive the checked state themselves, so the accessible name has to come from
* ariaLabel.
**/
declare class CheckboxOptionComponent {
    /**
    * Required. Value of the checkbox
    **/
    value: string | number;
    /**
    * Name of the checkbox element. Could be formControlName or fieldId
    **/
    name: string;
    /**
    * The ID of the checkbox.
    **/
    id: string;
    /**
    * Boolean that specifies whether the field is checked. The host owns this state; the control does
    * not toggle itself.
    **/
    checked: boolean;
    /**
    * Show the control in the hover state. For hosts that treat a larger area as the hover target.
    **/
    showHover: boolean;
    /**
    * E2E testing - data-e2e attribute attached to checkbox
    **/
    e2e: string;
    /**
    * ARIA Label attribute (aria-label). Required in practice: with no label rendered, this is the
    * control's only accessible name.
    **/
    ariaLabel: string;
    /**
    *  Emitted when the checkbox is checked or unchecked.
    **/
    selection: EventEmitter<any>;
    /**
    *  Emitted on blur event.
    **/
    blurred: EventEmitter<void>;
    onBlur(): void;
    onSelection(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckboxOptionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckboxOptionComponent, "ui-forms-checkbox-option", never, { "value": { "alias": "value"; "required": false; }; "name": { "alias": "name"; "required": false; }; "id": { "alias": "id"; "required": false; }; "checked": { "alias": "checked"; "required": false; }; "showHover": { "alias": "showHover"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; }, { "selection": "selection"; "blurred": "blurred"; }, never, never, false, never>;
}

declare class ToggleComponent extends BaseBooleanFieldComponent {
    checkboxInput: ElementRef<HTMLInputElement>;
    /**
    * Optional - lines of text to display beneath the label.
    **/
    subtextLines: string[];
    /**
    * Displays spinner, usually during loading
    **/
    showSpinner: boolean;
    /**
    * Displays icon to the right of the label
    **/
    icon: string;
    /**
    * Boolean to allow null values & show "indeterminate" initial state if value is null
    **/
    allowNull: boolean;
    /**
    * Boolean to hide the lock icon when the field is disabled
    **/
    hideLockIcon: boolean;
    inputChanged(event: Event): void;
    inputClicked(event: Event): void;
    writeValue(value: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToggleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToggleComponent, "ui-forms-toggle", never, { "subtextLines": { "alias": "subtextLines"; "required": false; }; "showSpinner": { "alias": "showSpinner"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "allowNull": { "alias": "allowNull"; "required": false; }; "hideLockIcon": { "alias": "hideLockIcon"; "required": false; }; }, {}, never, never, false, never>;
}

declare class FormRowDirective extends BaseDestroyComponent implements AfterViewChecked {
    private elementRef;
    private windowService;
    private ngZone;
    showRowClass: boolean;
    private firstViewChecked;
    private isMobile;
    constructor(elementRef: ElementRef, windowService: WindowService, ngZone: NgZone);
    ngAfterViewChecked(): void;
    private setSpacing;
    private getFormSpacingElements;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormRowDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FormRowDirective, "[uiFormsRow]", never, { "showRowClass": { "alias": "showRowClass"; "required": false; }; }, {}, never, never, false, never>;
}

declare class FormDirective extends BaseDestroyComponent implements AfterViewChecked, AfterViewInit {
    private elementRef;
    private ngZone;
    private windowService;
    class: boolean;
    isLowRes: boolean;
    isMobile: boolean;
    showNextField: boolean;
    autoFocus: boolean;
    isValid: EventEmitter<boolean>;
    private lastEmittedValue;
    constructor(elementRef: ElementRef, ngZone: NgZone, windowService: WindowService);
    ngAfterViewInit(): void;
    ngAfterViewChecked(): void;
    focus(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FormDirective, "[uiForms]", never, { "showNextField": { "alias": "showNextField"; "required": false; }; "autoFocus": { "alias": "autoFocus"; "required": false; }; }, { "isValid": "isValid"; }, never, never, false, never>;
}

interface Address {
    streetAddress: string;
    extraAddress: string;
    city: string;
    state: string;
    countryAlpha2Code: string;
    foreignZipFirst: boolean;
    zipCode: string;
}
declare class AddressField {
    value: string;
    label: string;
    name?: string;
    tooltip?: string;
    maxLength?: number;
    customErrors?: Map<string, string>;
    customValidator: (formControl: AbstractControl) => ValidationErrors | null;
    autocomplete?: string;
    constructor(value?: string);
}
declare class AddressFields {
    addressLine1: AddressField;
    addressLine2: AddressField;
    city: AddressField;
    state: AddressField;
    zipCode: AddressField;
    constructor();
}

declare enum FormRendererFieldType {
    AMOUNT_INPUT = "UI-FORMS-AMOUNT-INPUT",
    CHECKBOX = "UI-FORMS-CHECKBOX",
    CHECKBOX_LIST = "UI-FORMS-CHECKBOX-LIST",
    DATE_INPUT = "UI-FORMS-DATE-INPUT",
    DATEPICKER = "UI-FORMS-DATEPICKER",
    DROPDOWN = "UI-FORMS-DROPDOWN",
    FILE = "UI-FORMS-FILE-INPUT",
    MULTI_SELECT_DROPDOWN = "UI-FORMS-MULTI-SELECT-DROPDOWN",
    MULTI_SELECT_TEMPLATE_DROPDOWN = "UI-FORMS-MULTI-SELECT-TEMPLATE-DROPDOWN",
    NUMBER_INPUT = "UI-FORMS-NUMBER-INPUT",
    PASSWORD_INPUT = "UI-FORMS-PASSWORD-INPUT",
    RADIO_BUTTONS = "UI-FORMS-RADIO-BUTTONS",
    SENSITIVE_INPUT = "UI-FORMS-SENSITIVE-INPUT",
    SLIDER = "UI-FORMS-SLIDER",
    TEMPLATE_DROPDOWN = "UI-FORMS-TEMPLATE-DROPDOWN",
    TEXT_AREA = "UI-FORMS-TEXT-AREA",
    TEXT_INPUT = "UI-FORMS-TEXT-INPUT",
    TOGGLE = "UI-FORMS-TOGGLE",
    BUTTON = "BUTTON",
    DESCRIPTION_LIST = "DESCRIPTION-LIST",
    LABEL_VALUE_LIST = "LABEL-VALUE-LIST",
    LINK = "LINK",
    HEADER = "HEADER",
    HTML = "HTML",
    ICON_BUTTON = "ICON-BUTTON",
    IN_LINE_NOTIFICATION = "IN-LINE-NOTIFICATION",
    TEMPLATE = "TEMPLATE",
    IMAGE = "IMAGE",
    MANAGEMENT_EDITOR = "UI-FORMS-MANAGEMENT-EDITOR"
}

declare abstract class FormRendererField {
    readonly type: FormRendererFieldType;
    constructor(type: FormRendererFieldType);
    abstract halfWidth: boolean;
    abstract fullWidth: boolean;
    name: string;
    private _visible;
    private visibilitySubject;
    visible$: rxjs.Observable<boolean>;
    get visible(): boolean;
    set visible(vis: boolean);
}

interface Cloneable {
    clone(): Cloneable;
}

declare class UploadedFile extends AttachmentFile implements Cloneable {
    clone(): UploadedFile;
}

type FormFieldValue = string | number | boolean | string[] | number[] | UploadedFile[];

declare enum FormFieldUpdateType {
    VALUE_CHANGED = "VALUE_CHANGED",
    NEEDS_UPDATE = "NEEDS_UPDATE",
    SET_FOCUS = "SET_FOCUS",
    REMOVE_VALIDATION = "REMOVE_VALIDATION"
}
declare class FormRendererFieldUpdateEvent {
    field: BaseFormField<FormFieldValue>;
    type: FormFieldUpdateType;
    constructor(field: BaseFormField<FormFieldValue>, type: FormFieldUpdateType);
}

declare abstract class BaseFormField<T extends FormFieldValue> extends FormRendererField {
    label: string;
    required: boolean;
    constructor(type: FormRendererFieldType, initValue: T, label: string, required: boolean);
    halfWidth: boolean;
    fullWidth: boolean;
    private _value;
    get value(): T;
    set value(newValue: T);
    private updateSubject;
    update$: rxjs.Observable<FormFieldUpdateType>;
    locked?: boolean;
    lockedMessage?: string | false;
    successMessage?: string;
    warningMessage?: string;
    infoMessage?: string;
    errorMessage?: string;
    customErrors?: Map<string, string>;
    customValidator: ValidatorFn;
    customValidators: ValidatorFn[];
    tooltip: string;
    tooltipPlacement: Placement;
    hideLabel: boolean;
    e2e: string;
    context: any;
    updateValueAndValidity(): void;
    focus(): void;
    removeValidation(): void;
}

declare class FormRendererRow {
    allFields: FormRendererField[];
    group: FormRendererGroup;
    borderTop: boolean;
    borderBottom: boolean;
    threeColumns: boolean;
    mobileTwoColumns: boolean;
    id: string;
    fieldVisibility$: Observable<FormRendererField>;
    fieldUpdate$: Observable<FormRendererFieldUpdateEvent>;
    fields: FormRendererField[];
    readonly allFormFields: BaseFormField<FormFieldValue>[];
    constructor(allFields: FormRendererField[], group?: FormRendererGroup);
    set visible(vis: boolean);
}

declare class FormRendererGroupSummary {
    id: string;
    category: string;
    formControlNames: string[];
}

declare class FormRendererRowGrouping {
    collapsableMessage: string;
    isCollapsable: boolean;
    id: string;
    category: string;
    rows: FormRendererRow[];
    allFormControlNames: Set<string>;
    bordered: boolean;
    borderTop: boolean;
    expanded: boolean;
    readonly collapsableId: string;
    groupUpdate$: Observable<FormRendererGroupUpdateEvent>;
    private _visible;
    private initialVis;
    get visible(): boolean;
    set visible(vis: boolean);
    constructor(row: FormRendererRow);
    addRow(row: FormRendererRow, positioning?: FormRendererPositioning): void;
    spliceRowById(rowId: string): FormRendererRow;
    setInitialVisibility(): void;
    getSummary(): FormRendererGroupSummary;
}

interface FormRendererPositioning {
    insertAtIndex?: number;
    insertAfterId?: string;
    insertBeforeId?: string;
}

declare enum FormGroupUpdateType {
    REMOVE_GROUP = "REMOVE_GROUP",
    REMOVE_ROW = "REMOVE_ROW",
    ADD_ROW = "ADD_ROW",
    SET_VISIBILITY = "SET_VISIBILITY",
    SET_COLLAPSABLE_MESSAGE = "SET_COLLAPSABLE_MESSAGE"
}
declare class FormRendererGroupUpdateEvent {
    type: FormGroupUpdateType;
    visible: boolean;
    rowId: string;
    row: FormRendererRow;
    positioning: FormRendererPositioning;
    message: string;
    grouping: FormRendererRowGrouping;
    constructor(type: FormGroupUpdateType);
}

declare class FormRendererGroup {
    id: string;
    category: string;
    bordered: boolean;
    borderTop: boolean;
    expanded: boolean;
    private updateSubject;
    update$: rxjs.Observable<FormRendererGroupUpdateEvent>;
    private _visible;
    get visible(): boolean;
    set visible(vis: boolean);
    private _collapsableMessage;
    get collapsableMessage(): string;
    set collapsableMessage(message: string);
    constructor(id?: string);
    remove(): void;
    removeRowById(id: string): void;
    addRow(row: FormRendererRow, positioning?: FormRendererPositioning): void;
}

declare class ValidationCriteria {
    readonly message: string;
    readonly validationFn: (input: string) => boolean;
    theme: NotificationTheme.NEUTRAL | NotificationTheme.SUCCESS | NotificationTheme.ERROR;
    icon: string;
    constructor(message: string, validationFn: (input: string) => boolean);
    evaluate(value: string, showErrors: boolean): boolean;
}

declare enum TextInputFieldType {
    DEFAULT = "DEFAULT",
    CODE = "CODE",
    PHONE = "PHONE",
    INTERNATIONAL_PHONE = "INTERNATIONAL_PHONE",
    ZIP_CODE = "ZIP_CODE",
    POSTAL_CODE = "POSTAL_CODE",
    EMAIL = "EMAIL",
    STATE = "STATE",
    NUMERIC = "NUMERIC"
}

interface MultiSelectOption {
    checked: boolean;
    value: string | number;
}

interface MenuOption extends Cloneable {
    label: string;
    value: string | number;
    icon?: string;
    iconColor?: ColorClass;
    subtext?: string;
    context?: any;
    id: string;
    e2e: string;
    clone(): MenuOption;
}
interface MultiSelectMenuOption extends MenuOption, MultiSelectOption {
}

declare class TextInputOption implements MenuOption {
    label: string;
    value: string;
    icon: string;
    subtext: string;
    secondaryValues: string[];
    id: string;
    e2e: string;
    context: any;
    constructor(label: string, value: string);
    clone(): TextInputOption;
}

declare abstract class TypeaheadFactory<T extends MenuOption> {
    minimumCharactersToType: number;
    emitSelectionOnly: boolean;
    abstract getMenuOptions(typeaheadValue: string): Observable<T[]>;
    sanitizeValue(typeaheadValue: string): string;
}

declare class TextInputCustomMasking {
    allowAlpha: boolean;
    allowDigits: boolean;
    transformToUpperCase: boolean;
    static fromObject(data: any): TextInputCustomMasking;
}

declare class TextInputField extends BaseFormField<string> {
    name: string;
    minLength: number;
    maxLength: number;
    fieldMatches: string;
    numbersOnly: boolean;
    asciiOnly: boolean;
    pattern: string | RegExp;
    fieldType: TextInputFieldType;
    actionButtonIcon: string;
    actionButtonMessage: string;
    actionButtonDisabled: boolean;
    actionButtonDisabledSpinner: boolean;
    actionFn: (value?: string) => void;
    copyToClipboard: boolean;
    copiedFn: (success: boolean) => void;
    autocomplete: string;
    criteria: ValidationCriteria[];
    criteriaDescription: string;
    options: TextInputOption[];
    typeaheadFactory: TypeaheadFactory<TextInputOption>;
    postalCodeCountryAlpha2: string;
    postalCodeRequired: boolean;
    customMasking: TextInputCustomMasking;
    constructor(name: string, label: string, initValue: string, required: boolean);
}

declare class DropdownOption<T extends string | number> implements MenuOption {
    label: string;
    value: T;
    icon: string;
    iconColor: ColorClass;
    id: string;
    e2e: string;
    context: any;
    constructor(label: string, value: T);
    clone(): DropdownOption<T>;
}

declare class LabelValueListField extends FormRendererField {
    items: LabelValueListItem[];
    mobileSingleColumn: boolean;
    readonly halfWidth: boolean;
    fullWidth: boolean;
    onIconRightClick: (item: LabelValueListItem) => void;
    onLinkClick: (item: LabelValueListItem) => void;
    constructor(items: LabelValueListItem[]);
}

interface StandardAddressFormContent {
    rows: FormRendererRow[];
    addressLine1: TextInputField;
    addressLine2: TextInputField;
    city: TextInputField;
    state: TextInputField;
    zipCode: TextInputField;
}
declare class AddressUtils {
    static getStandardAddressRows(addressText: any, states: State[], addressFields?: AddressFields, formRendererGroup?: FormRendererGroup): StandardAddressFormContent;
    static getCityStateZipRow(addressText: any, states: State[], addressFields?: AddressFields, formRendererGroup?: FormRendererGroup): FormRendererRow;
    private static getAddressFields;
    static getStateField(addressText: any, states: State[], stateAddressField: AddressField, required: boolean, halfWidth: boolean): TextInputField;
    static getStateOptions(states: State[]): TextInputOption[];
    static getZipCodeField(addressText: any, zipAddressField: AddressField, required: boolean, halfWidth: boolean, international: boolean): TextInputField;
    static getExperimentalPostalCodeField(addressText: any, postalCodeAddressField: AddressField, required: boolean, halfWidth: boolean): TextInputField;
    static getCountryDropdownOptions(countries: Country[], restrictedCountryCodes: string[], countriesText?: any): DropdownOption<string>[];
    static getInternationalPhoneOptions(countriesText?: any, restrictedCountryCodes?: string[]): TextInputOption[];
    private static getCountryTextInputOption;
    private static getCountryLabel;
    static getLabelValueListField(address: Address, label: string): LabelValueListField;
    static getFormattedAddressLines(address: Address): string[];
    static getFormattedAddressLine(address: Address): string;
}

declare class DateTimeUtils {
    static getTimeOfDayOptions(minuteIncrements: number, valueFormat?: string): DropdownOption<string>[];
    static getLatestTimeOfDayOption(valueFormat?: string): DropdownOption<string> | null;
    private static getDropdownOptionFromDate;
}

type formRendererButtonClick = (formGroup: UntypedFormGroup, rowId: string, groupId: string, buttonIndex?: number) => void;

declare class ButtonField extends FormRendererField {
    message: string;
    onClick: formRendererButtonClick;
    theme: 'secondary' | 'tertiary' | 'link';
    icon: string;
    e2e: string;
    header: string;
    headerMarginClass: string;
    headerSize: TextSize;
    alignWithLabels: boolean;
    bottomMarginClass: string;
    centered: boolean;
    disabled: boolean;
    disabledMessage: string;
    disabledSpinner: boolean;
    removeRowOnClick: boolean;
    removeGroupOnClick: boolean;
    readonly halfWidth: boolean;
    fullWidth: boolean;
    constructor(message: string, onClick: formRendererButtonClick);
}

declare class DescriptionListField extends FormRendererField {
    items: DescriptionListItem[];
    framed: boolean;
    readonly halfWidth: boolean;
    fullWidth: boolean;
    constructor(items: DescriptionListItem[]);
}

declare class HeaderField extends FormRendererField {
    content: string;
    textSize: TextSize;
    subheader: string;
    ariaLevel: 1 | 2 | 3 | 4 | 5 | 6 | null;
    marginClass: string;
    readonly halfWidth: boolean;
    readonly fullWidth: boolean;
    constructor(content: string, textSize?: TextSize);
}

declare class HtmlField extends FormRendererField {
    content: string;
    framed: boolean;
    halfWidth: boolean;
    fullWidth: boolean;
    constructor(content: string);
}

declare class IconButtonField extends FormRendererField {
    message: string;
    icon: string;
    onClick: formRendererButtonClick;
    e2e: string;
    disabled: boolean;
    removeRowOnClick: boolean;
    removeGroupOnClick: boolean;
    alignWithLabels: boolean;
    bottomMarginClass: string;
    halfWidth: boolean;
    fullWidth: boolean;
    constructor(message: string, icon: string, onClick: formRendererButtonClick);
}

declare class ImageField extends FormRendererField {
    path: string;
    altText: string;
    height: number;
    width: number;
    displayMode: ImageDisplayMode;
    objectPosition: ObjectPosition;
    badges: BadgeModel[];
    borderRadius: boolean;
    halfWidth: boolean;
    fullWidth: boolean;
    constructor(path: string, altText: string, height: number);
}

declare class InLineNotificationField extends FormRendererField {
    message: string;
    header: string;
    bulletList: string[];
    theme: NotificationTheme;
    customIcon: string;
    buttons: NotificationButton[];
    onButtonClick: formRendererButtonClick;
    showCloseButton: boolean;
    onClose: (() => void) | null;
    readonly halfWidth: boolean;
    readonly fullWidth: boolean;
    constructor(message: string);
}

declare class LinkField extends FormRendererField {
    message: string;
    link: string;
    theme: 'primary' | 'secondary' | 'tertiary' | 'link';
    icon: string;
    e2e: string;
    header: string;
    headerMarginClass: string;
    headerSize: TextSize;
    alignWithLabels: boolean;
    bottomMarginClass: string;
    centered: boolean;
    disabled: boolean;
    openLinkInNewTab: boolean;
    readonly halfWidth: boolean;
    fullWidth: boolean;
    constructor(message: string, link: string);
}

declare enum TemplateType {
    ACCOUNT = "ACCOUNT",
    CARD = "CARD",
    CONTENT = "CONTENT"
}
declare abstract class BaseTemplateData {
    readonly type: TemplateType;
    constructor(type: TemplateType);
    abstract matchesFilter(filter: string): boolean;
}

declare class TemplateField extends FormRendererField {
    templateData: BaseTemplateData;
    isOutlined: boolean;
    readonly halfWidth: boolean;
    fullWidth: boolean;
    constructor(templateData: BaseTemplateData, isOutlined: boolean);
}

declare class AmountInputField extends BaseFormField<number> {
    name: string;
    min: number;
    max: number;
    decimalPlaces: number;
    hideIcon: boolean;
    constructor(name: string, label: string, initValue: number, required: boolean);
}

declare class CheckboxField extends BaseFormField<boolean> {
    name: string;
    requiredTrue: boolean;
    secondaryLabel: string;
    subtextLines: string[];
    constructor(name: string, label: string, initValue: boolean);
}

declare class CheckboxListOption implements Cloneable, MultiSelectOption {
    label: string;
    value: string | number;
    checked: boolean;
    locked: boolean;
    headerStaticText: string;
    infoMessage: string;
    topRightText: string;
    secondaryLabel: string;
    subtextLines: string[];
    tooltip: string;
    e2e: string;
    id: string;
    constructor(label: string, value: string | number, checked?: boolean);
    clone(): CheckboxListOption;
}

declare class CheckboxListField extends BaseFormField<string[] | number[]> {
    name: string;
    options: CheckboxListOption[];
    display: 'list' | 'card' | 'grid';
    showSelectAll: boolean;
    selectAllSubtextLines: string[];
    selectAllLabel: string;
    selectAllTooltip: string;
    showGroupHeaders: boolean;
    showSearch: boolean;
    collapsedByDefault: boolean;
    constructor(name: string, label: string, initValue: string[] | number[], required: boolean);
}

declare enum DateInputFieldType {
    EXPIRATION_DATE = "EXPIRATION_DATE",
    YEAR = "YEAR"
}

declare class DateInputField extends BaseFormField<string> {
    name: string;
    disablePastDates: boolean;
    disableFutureDates: boolean;
    fieldType: DateInputFieldType;
    constructor(name: string, label: string, initValue: string, required: boolean);
}

declare class DatepickerField extends BaseFormField<string> {
    name: string;
    actionButtonIcon: string;
    actionButtonLabel: string;
    actionFn: () => void;
    afterDateText: string;
    allowToday: boolean;
    daysAfter: number;
    daysPrior: number;
    disableAllExceptFirstDayOfMonth: boolean;
    disableAllExceptLastDayOfMonth: boolean;
    disableAllExceptFifteenthAndLastDay: boolean;
    disabledDaysOfMonth: Array<number>;
    disabledDaysText: string;
    disableFutureDates: boolean;
    disableHolidays: boolean;
    disablePastDates: boolean;
    disableWeekends: boolean;
    hideCalendar: boolean;
    holidays: Array<Holiday>;
    iconLeft: string;
    markedDate: Date;
    markedDateText: string;
    maxDate: Date;
    minDate: Date;
    mobileDoneButtonLabel: string;
    placeholder: string;
    priorDateText: string;
    selectedDateText: string;
    mobileAutoOpen: boolean;
    constructor(name: string, label: string, initValue: string, required: boolean);
}

declare class AccountTemplateData extends BaseTemplateData {
    icon: string;
    iconColorClass: string;
    iconBackgroundClass: string;
    imageUrl: string;
    iconAsImage: boolean;
    topLeft: string | number;
    topLeftClass: string;
    topLeftFormatCurrency: boolean;
    e2eTopLeft: string;
    topRight: string | number;
    topRightClass: string;
    topRightFormatCurrency: boolean;
    e2eTopRight: string;
    bottomLeft: string | number;
    bottomLeftClass: string;
    bottomLeftFormatCurrency: boolean;
    e2eBottomLeft: string;
    bottomRight: string | number;
    bottomRightClass: string;
    bottomRightFormatCurrency: boolean;
    e2eBottomRight: string;
    accountStatus: AccountTemplateStatus;
    accountType: AccountTemplateType;
    accountTypeUsesLeftCorner: boolean;
    constructor();
    matchesFilter(filter: string): boolean;
}

declare class CardTemplateData extends BaseTemplateData {
    icon: string;
    iconBackgroundClass: string;
    cardImageUrl: string;
    top: string | number;
    topClass: string;
    e2eTop: string;
    bottom: string | number;
    bottomClass: string;
    e2eBottom: string;
    constructor();
    matchesFilter(filter: string): boolean;
}

declare class ContentTemplateData extends BaseTemplateData {
    icon: string;
    iconColorClass: string;
    imageUrl: string;
    iconAsImage: boolean;
    iconAsImageBackgroundClass: string;
    topLeft: string;
    topLeftClass: string;
    e2eTopLeft: string;
    topRight: string;
    e2eTopRight: string;
    bottomLeft: string;
    e2eBottomLeft: string;
    bottomRight: string;
    e2eBottomRight: string;
    constructor();
    matchesFilter(filter: string): boolean;
}

declare abstract class BaseFormMenuState extends BaseMenuState {
    close: (markAsTouched?: boolean) => void;
    readonly actionsGroupId: string;
    options: MenuOption[];
    visibleOptions: MenuOption[];
    hasNoOptions: boolean;
    hasNoVisibleOptions: boolean;
    hasVisibleOptions: boolean;
    constructor(isDrawerOnMobile: boolean, idPrefix: string, actions: Action[], options: MenuOption[]);
    protected sanitizeFilterValue(value: string): string;
    protected filterOptions(sanitizedValue: string, allOptions: MenuOption[], matchOnSubtext: boolean): MenuOption[];
    protected setVisibleOptions(visibleOptions: MenuOption[]): void;
    protected initOptions(sortByLabel: boolean, useValueAsSuffix?: boolean): void;
}

declare abstract class BaseFormMenuComponent extends BaseMenuComponent {
    selectedOptionId: string;
    abstract menuState: BaseFormMenuState;
    allowEmojis: boolean;
    menuIconsOnRight: boolean;
    constructor(textService: TextService, textConfigKey: string, isDrawerOnMobile: boolean);
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseFormMenuComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BaseFormMenuComponent, never, never, { "selectedOptionId": { "alias": "selectedOptionId"; "required": false; }; "menuState": { "alias": "menuState"; "required": false; }; "allowEmojis": { "alias": "allowEmojis"; "required": false; }; "menuIconsOnRight": { "alias": "menuIconsOnRight"; "required": false; }; }, {}, never, never, true, never>;
}

declare abstract class BaseMenuFieldComponent<T extends number | string | string[]> extends BaseFieldComponent<T> implements OnInit {
    protected windowService: WindowService;
    protected controlContainer: ControlContainer;
    labelElement: ElementRef;
    toggleContainer: ElementRef;
    typeaheadInput: ElementRef;
    menuContainer: ElementRef;
    menuComponent: BaseFormMenuComponent;
    abstract menuState: BaseMenuState;
    menuIsOpen: boolean;
    readonly menuId: string;
    isMobile: boolean;
    menuSelectionRequired: boolean;
    get activeDescendantId(): string;
    constructor(windowService: WindowService, textService: TextService, textConfigKey: string, controlContainer: ControlContainer);
    ngOnInit(): void;
    protected get menuElement(): ElementRef;
    protected get toggleElement(): ElementRef;
    private onDocumentClick;
    private handleScrolling;
    abstract close(markAsTouched: boolean): void;
    abstract open(scrollToSelected: boolean): void;
    protected onClose(): void;
    protected onOpen(): void;
    toggleMenu(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseMenuFieldComponent<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BaseMenuFieldComponent<any>, never, never, {}, {}, never, never, true, never>;
}

declare abstract class BaseDropdownComponent<T extends number | string | string[]> extends BaseMenuFieldComponent<T> implements OnInit {
    protected ngZone: NgZone;
    protected controlContainer: ControlContainer;
    private isMultiSelect;
    /**
    * Custom placeholder text that appears when no value is selected.
    * Default text should be provided per dropdown implementation.
    **/
    placeholder: string;
    /**
    * Optional. Auto opens the mobile drawer.
    **/
    mobileAutoOpen: boolean;
    get iconRight(): string;
    constructor(windowService: WindowService, textService: TextService, textConfigKey: string, ngZone: NgZone, controlContainer: ControlContainer, isMultiSelect: boolean);
    ngOnInit(): void;
    abstract get hasValue(): boolean;
    abstract onComboboxClick(): void;
    onLabelClick(): void;
    protected writeValueAndEmitChange(value: T): void;
    protected shouldEmitChange(incomingValue: T): boolean;
    private multiSelectWriteValueAndEmitChange;
    private multiSelectShouldEmitChange;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseDropdownComponent<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BaseDropdownComponent<any>, never, never, { "placeholder": { "alias": "placeholder"; "required": false; }; "mobileAutoOpen": { "alias": "mobileAutoOpen"; "required": false; }; }, {}, never, never, true, never>;
}

declare class DropdownAction implements Action {
    action?: () => void;
    icon: string;
    text: string;
    url?: string;
    externalUrlNewTab?: boolean;
    urlQueryParams?: Params;
    e2e: string;
    id: string;
}

declare class MultiSelectState<T extends string[] | number[]> {
    options: MultiSelectOption[];
    allChecked: boolean;
    indeterminate: boolean;
    readonly count: number;
    visibleOptionsAllChecked: boolean;
    visibleOptionsIndeterminate: boolean;
    visibleCount: number;
    visibleCountFormatted: string;
    private visibleOptions;
    constructor(options: MultiSelectOption[], value: T);
    onWriteValue(value: T): void;
    getNewValueOnOptionChange(option: MultiSelectOption, checked: boolean): T;
    getNewValueOnSelectAllChange(checked: boolean): T;
    getNewValueOnSelectAllVisibleChange(checked: boolean): T;
    onVisibleOptionsChange(visibleOptions: MultiSelectOption[]): void;
    private setFlags;
}

declare class ListMenuState extends BaseFormMenuState {
    private comboboxId;
    private changeDetector;
    private ngZone;
    readonly selectAllId: string;
    showSelectAll: boolean;
    selectAllChecked: boolean;
    selectAllIndeterminate: boolean;
    private multiSelectState;
    readonly clearActionId: string;
    showClearAction: boolean;
    readonly searchInputId: string;
    readonly searchClearId: string;
    readonly showSearch: boolean;
    searchTerm: string;
    constructor(comboboxId: string, changeDetector: ChangeDetectorRef, ngZone: NgZone, idPrefix: string, options: MenuOption[] | MultiSelectMenuOption[], actions: Action[]);
    enableMultiSelect(multiSelectState: MultiSelectState<string[] | number[]>): void;
    setClearActionVisibility(show: boolean): void;
    private setFocusableIds;
    onComboboxKeyDown(event: KeyboardEvent, isMobile: boolean, menuIsOpen: boolean): void;
    onComboboxKeyUp(event: KeyboardEvent): void;
    onMenuItemKeyDown(itemId: string, event: KeyboardEvent, isMobile: boolean): void;
    onMenuSearchKeyDown(event: KeyboardEvent, isMobile: boolean): void;
    onMenuInit(isMobile: boolean, idToFocus?: string): void;
    onMenuSearch(searchTerm: string): void;
    private focusCombobox;
    protected focusElementById(id: string, isMobile: boolean, isMenuInit?: boolean): void;
    private focusIsOnSearchElement;
    private isIdSearchRelated;
    protected setVisibleOptions(visibleOptions: MenuOption[]): void;
    static getEmptyState(): ListMenuState;
}

declare class MenuSelectionEvent<T extends MenuOption> {
    formControlName: string;
    option: T;
    emitSelectionOnly: boolean;
    constructor(option: T, formControlName: string);
}

declare class DropdownComponent<T extends string | number> extends BaseDropdownComponent<T> implements OnChanges {
    protected ngZone: NgZone;
    private router;
    private changeDetector;
    protected controlContainer: ControlContainer;
    combobox: ElementRef;
    /**
    * Non-interactive icon that displays to the left of the input
    **/
    iconLeft: string;
    /**
    * If enabled, the selected menu option icon will appear in iconLeft.
    * If there is no selection or the option does not have an icon, iconLeft will be used.
    **/
    showMenuOptionAsIconLeft: boolean;
    /**
    * Options to present to the user
    **/
    options: DropdownOption<T>[];
    /**
    * Custom message displayed when dropdown has no options.
    * Default is "No options available".
    **/
    noOptionsMessage: string;
    /**
    * Groups of actions to present to the user
    **/
    actions: DropdownAction[];
    /**
    * The icon to show to the right of an optional "action" button.
    **/
    actionButtonIcon: string;
    /**
    * The message to show on an optional "action" button.
    **/
    actionButtonMessage: string;
    /**
    * Hides the action button message visually, but keeps it as an aria-label for accessibility.
    **/
    actionButtonMessageHidden: boolean;
    /**
    * Disables the "action" button.
    **/
    actionButtonDisabled: boolean;
    /**
    * Show a spinner in the "action" button when disabled.
    **/
    actionButtonDisabledSpinner: boolean;
    /**
    * Controls the position of icons in the dropdown menu.
    * By default icons will appear on the right side of the menu.
    **/
    menuIconsOnRight: boolean;
    /**
    * Enable emoji support for icons in the menu and in the iconLeft position.
    **/
    allowEmojis: boolean;
    /**
    * Emits if the user clicks the optional "action" button.
    * Value emitted is the current value of the field.
    **/
    actionButtonClick: EventEmitter<T>;
    /**
    * Emits a clone of the option that was selected from the menu last.
    * Note: this emits prior to the change event, which emits the value of the field.
    **/
    menuSelection: EventEmitter<MenuSelectionEvent<DropdownOption<T>>>;
    menuState: ListMenuState;
    selectedOptionId: string;
    private selectedOption;
    comboboxText: string;
    clearActionText: string;
    actualIconLeft: string;
    actualIconLeftIsEmoji: boolean;
    actualIconLeftColor: ColorClass;
    get hasValue(): boolean;
    constructor(windowService: WindowService, textService: TextService, ngZone: NgZone, router: Router, changeDetector: ChangeDetectorRef, controlContainer: ControlContainer);
    ngOnChanges(changes: SimpleChanges): void;
    writeValue(value: T): void;
    onButtonClick(): void;
    actionClicked(): void;
    onClearOptionalDropdown(): void;
    onComboboxKeyDown(event: KeyboardEvent): void;
    onComboboxKeyUp(event: KeyboardEvent): void;
    onComboboxClick(): void;
    onOptionClick(option: DropdownOption<T>): void;
    onActionClick(action: DropdownAction): void;
    open(): void;
    close(markAsTouched: boolean): void;
    private setComboboxText;
    private setClearActionVisibility;
    private setActualIconLeft;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<DropdownComponent<any>, [null, null, null, null, null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DropdownComponent<any>, "ui-forms-dropdown", never, { "iconLeft": { "alias": "iconLeft"; "required": false; }; "showMenuOptionAsIconLeft": { "alias": "showMenuOptionAsIconLeft"; "required": false; }; "options": { "alias": "options"; "required": false; }; "noOptionsMessage": { "alias": "noOptionsMessage"; "required": false; }; "actions": { "alias": "actions"; "required": false; }; "actionButtonIcon": { "alias": "actionButtonIcon"; "required": false; }; "actionButtonMessage": { "alias": "actionButtonMessage"; "required": false; }; "actionButtonMessageHidden": { "alias": "actionButtonMessageHidden"; "required": false; }; "actionButtonDisabled": { "alias": "actionButtonDisabled"; "required": false; }; "actionButtonDisabledSpinner": { "alias": "actionButtonDisabledSpinner"; "required": false; }; "menuIconsOnRight": { "alias": "menuIconsOnRight"; "required": false; }; "allowEmojis": { "alias": "allowEmojis"; "required": false; }; }, { "actionButtonClick": "actionButtonClick"; "menuSelection": "menuSelection"; }, never, never, false, never>;
}

declare class MultiSelectDropdownOption implements MultiSelectMenuOption {
    label: string;
    value: string;
    icon: string;
    id: string;
    checked: boolean;
    e2e: string;
    context: any;
    constructor(label: string, value: string);
    clone(): MultiSelectDropdownOption;
}

declare class MultiSelectDropdownComponent extends BaseDropdownComponent<string[]> implements OnChanges {
    protected ngZone: NgZone;
    private router;
    private changeDetector;
    protected controlContainer: ControlContainer;
    combobox: ElementRef;
    /**
    * Non-interactive icon that displays to the left of the input
    **/
    iconLeft: string;
    /**
    * Options to present to the user
    **/
    options: MultiSelectDropdownOption[];
    /**
    * Groups of actions to present to the user
    **/
    actions: DropdownAction[];
    /**
    * The icon to show to the right of an optional "action" button.
    **/
    actionButtonIcon: string;
    /**
    * The message to show on an optional "action" button.
    **/
    actionButtonMessage: string;
    /**
    * Hides the action button message visually, but keeps it as an aria-label for accessibility.
    **/
    actionButtonMessageHidden: boolean;
    /**
    * Disables the "action" button.
    **/
    actionButtonDisabled: boolean;
    /**
    * Show a spinner in the "action" button when disabled.
    **/
    actionButtonDisabledSpinner: boolean;
    /**
    * Controls the position of icons in the dropdown menu.
    * By default icons will appear on the right side of the menu.
    **/
    menuIconsOnRight: boolean;
    /**
    * Emits a clone of the option that was selected from the menu last.
    * Note: this emits prior to the change event, which emits the value of the field.
    **/
    menuSelection: EventEmitter<MenuSelectionEvent<MultiSelectDropdownOption>>;
    /**
    * Emits if the user clicks the optional "action" button.
    * Value emitted is the current value of the field.
    **/
    actionButtonClick: EventEmitter<string[]>;
    menuState: ListMenuState;
    multiSelectState: MultiSelectState<string[]>;
    placeholderText: string;
    get hasValue(): boolean;
    constructor(windowService: WindowService, textService: TextService, ngZone: NgZone, router: Router, changeDetector: ChangeDetectorRef, controlContainer: ControlContainer);
    ngOnChanges(changes: SimpleChanges): void;
    private get stateOptions();
    writeValue(value: string[]): void;
    private setPlaceholder;
    onButtonClick(): void;
    actionClicked(): void;
    onComboboxKeyDown(event: KeyboardEvent): void;
    onComboboxKeyUp(event: KeyboardEvent): void;
    onComboboxClick(): void;
    selectAll(): void;
    selectAllVisible(): void;
    onActionClick(action: DropdownAction): void;
    onOptionClick(option: MultiSelectDropdownOption): void;
    open(): void;
    close(markAsTouched: boolean): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<MultiSelectDropdownComponent, [null, null, null, null, null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MultiSelectDropdownComponent, "ui-forms-multi-select-dropdown", never, { "iconLeft": { "alias": "iconLeft"; "required": false; }; "options": { "alias": "options"; "required": false; }; "actions": { "alias": "actions"; "required": false; }; "actionButtonIcon": { "alias": "actionButtonIcon"; "required": false; }; "actionButtonMessage": { "alias": "actionButtonMessage"; "required": false; }; "actionButtonMessageHidden": { "alias": "actionButtonMessageHidden"; "required": false; }; "actionButtonDisabled": { "alias": "actionButtonDisabled"; "required": false; }; "actionButtonDisabledSpinner": { "alias": "actionButtonDisabledSpinner"; "required": false; }; "menuIconsOnRight": { "alias": "menuIconsOnRight"; "required": false; }; }, { "menuSelection": "menuSelection"; "actionButtonClick": "actionButtonClick"; }, never, never, false, never>;
}

declare class TemplateDropdownOption<T extends BaseTemplateData> implements Cloneable {
    value: string;
    templateData: T;
    id: string;
    e2e: string;
    object: any;
    isSelectable: boolean;
    ineligibleMessage: string;
    constructor(value: string, templateData: T);
    matchesFilter(filter: string): boolean;
    setAsIneligible(message: string): void;
    clone(): TemplateDropdownOption<T>;
}

declare class TemplateGroup<T extends BaseTemplateData> implements Cloneable {
    options: TemplateDropdownOption<T>[];
    id: string;
    name: string;
    readOnly: boolean;
    constructor(options: TemplateDropdownOption<T>[]);
    setOptionIds(fieldId: string, groupIndex: number): void;
    clone(): TemplateGroup<T>;
}

declare class AmountRangeMenuState extends BaseMenuState {
    constructor(idPrefix: string);
    protected focusElementById: () => void;
    onComboboxKeyDown(event: KeyboardEvent, isMobile: boolean, menuIsOpen: boolean): void;
    onComboboxKeyUp(event: KeyboardEvent): void;
    static getEmptyState(): AmountRangeMenuState;
}

declare class AmountRangeMenuComponent extends BaseMenuComponent implements OnChanges {
    private fb;
    fromValue: number;
    toValue: number;
    menuState: AmountRangeMenuState;
    closed: EventEmitter<void>;
    amountRangeChanged: EventEmitter<number[]>;
    form: UntypedFormGroup;
    constructor(fb: UntypedFormBuilder, textService: TextService);
    ngOnChanges(changes: SimpleChanges): void;
    get errorMessage(): string;
    applyRange(): void;
    private amountRangeInputValidator;
    close(): void;
    closeKeyDown(event: KeyboardEvent): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<AmountRangeMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AmountRangeMenuComponent, "ui-forms-amount-range-menu", never, { "fromValue": { "alias": "fromValue"; "required": false; }; "toValue": { "alias": "toValue"; "required": false; }; "menuState": { "alias": "menuState"; "required": false; }; }, { "closed": "closed"; "amountRangeChanged": "amountRangeChanged"; }, never, never, false, never>;
}

declare class StandaloneModelOptions {
    name: string;
    standalone: boolean;
    updateOn: 'change' | 'blur' | 'submit';
    constructor(name: string);
}
declare abstract class BaseStandaloneComponent<T> extends BaseTextComponent {
    class: boolean;
    /**
    * Allows for a custom e2e prefix.
    **/
    set e2e(e2e: string);
    abstract value: T;
    /**
    * Emits the new value when the value changes.
    **/
    change: EventEmitter<T>;
    readonly fieldId: string;
    e2ePrefix: string;
    modelOptions: StandaloneModelOptions;
    constructor(textService: TextService, textConfigKey: string);
    stopEvent(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseStandaloneComponent<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BaseStandaloneComponent<any>, never, never, { "e2e": { "alias": "e2e"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, { "change": "change"; }, never, never, true, never>;
}

declare abstract class BaseStandaloneMenuComponent<T extends number | string | string[] | number[]> extends BaseStandaloneComponent<T> {
    protected windowService: WindowService;
    combobox: ElementRef;
    toggleContainer: ElementRef;
    typeaheadInput: ElementRef;
    menuComponent: BaseFormMenuComponent;
    abstract menuState: BaseFormMenuState;
    menuIsOpen: boolean;
    readonly menuId: string;
    isMobile: boolean;
    get activeDescendantId(): string;
    constructor(windowService: WindowService, textService: TextService, textConfigKey: string);
    protected get menuElement(): ElementRef;
    protected get toggleElement(): ElementRef;
    private onDocumentClick;
    private handleScrolling;
    open(): void;
    close(): void;
    toggleMenu(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseStandaloneMenuComponent<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BaseStandaloneMenuComponent<any>, never, never, {}, {}, never, never, true, never>;
}

declare abstract class BaseStandaloneDropdownComponent<T extends number | string | string[] | number[]> extends BaseStandaloneMenuComponent<T> {
    inlineStyles: boolean;
    maxWidthStyle: boolean;
    /**
    * Label displayed inside the dropdown toggle.
    **/
    label: string;
    /**
    * Changes the colors of the dropdown toggle.
    **/
    theme: 'primary' | 'white';
    /**
    * Non-interactive icon that displays to the left of the input.
    * If display is 'icon', this icon may be used instead of the default.
    **/
    iconLeft: string;
    /**
    * The max width of the toggle in pixels. The menu will always be this width, but the toggle may be smaller.
    **/
    desktopMaxWidth: number;
    /**
    * Label used to describe the dropdown toggle for screen-readers. Only necessary if more context is needed, will be used by screen-readers instead of label.
    **/
    ariaLabel: string;
    menuState: ListMenuState;
    readonly labelId: string;
    get iconRight(): string;
    constructor(windowService: WindowService, textService: TextService, textConfigKey: string);
    abstract get hasValue(): boolean;
    onButtonClick(): void;
    onComboboxKeyDown(event: KeyboardEvent): void;
    onComboboxKeyUp(event: KeyboardEvent): void;
    onComboboxClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseStandaloneDropdownComponent<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BaseStandaloneDropdownComponent<any>, never, never, { "label": { "alias": "label"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "iconLeft": { "alias": "iconLeft"; "required": false; }; "desktopMaxWidth": { "alias": "desktopMaxWidth"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; }, {}, never, never, true, never>;
}

declare class AmountRangeComponent extends BaseStandaloneDropdownComponent<string[]> implements OnChanges {
    protected windowService: WindowService;
    textService: TextService;
    /**
    * Set the value externally.
    **/
    value: string[];
    /**
    * Visual presentation of content within the toggle
    *  - 'selection' shows the label and selected option. Toggle width may change and cause layout shifting.
    *  - 'label' shows the label only. Toggle width is fixed.
    *  - 'icon' shows iconLeft only. If iconLeft is not configured, defaults to vertical dots. Toggle width is fixed.
    **/
    display: 'selection' | 'label' | 'icon';
    /**
    * Non-interactive icon that displays to the left of the input
    **/
    iconLeft: string;
    /**
    * ARIA Described-by content to add to picker button label
    * Used to give more context to the input for screen-readers
    **/
    ariaDescription: string;
    menuState: any;
    amountRange: string;
    fromValue: number;
    toValue: number;
    private _decimalPlaces;
    iconOnly: boolean;
    get hasValue(): boolean;
    constructor(windowService: WindowService, textService: TextService);
    ngOnChanges(changes: SimpleChanges): void;
    setAmountRange(event: number[]): void;
    private setAmountRangeValues;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<AmountRangeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AmountRangeComponent, "ui-forms-amount-range", never, { "value": { "alias": "value"; "required": false; }; "display": { "alias": "display"; "required": false; }; "iconLeft": { "alias": "iconLeft"; "required": false; }; "ariaDescription": { "alias": "ariaDescription"; "required": false; }; }, {}, never, never, false, never>;
}

declare class CollapsablePickerOption<T extends ContentTemplateData> implements MenuOption {
    label: string;
    value: string;
    templateData: T;
    id: string;
    e2e: string;
    object: any;
    visible: boolean;
    constructor(label: string, value: string, templateData: T);
    clone(): CollapsablePickerOption<T>;
}

declare class TemplateMenuState extends BaseFormMenuState {
    private comboboxId;
    private changeDetector;
    private ngZone;
    constructor(comboboxId: string, changeDetector: ChangeDetectorRef, ngZone: NgZone, idPrefix: string, options: MenuOption[], actions: Action[]);
    private setFocusableIds;
    onComboboxKeyDown(event: KeyboardEvent, isMobile: boolean, menuIsOpen: boolean): void;
    onComboboxKeyUp(event: KeyboardEvent): void;
    onMenuItemKeyDown(itemId: string, event: KeyboardEvent, isMobile: boolean): void;
    onMenuInit(isMobile: boolean, idToFocus?: string): void;
    private focusCombobox;
    protected focusElementById(id: string, isMobile: boolean, isMenuInit?: boolean): void;
    static getEmptyState(): TemplateMenuState;
}

declare class CollapsablePickerComponent<T extends ContentTemplateData> extends BaseStandaloneComponent<string> implements OnChanges {
    protected windowService: WindowService;
    private changeDetector;
    private ngZone;
    /**
    * Set the value externally.
    **/
    value: string;
    /**
    * Required. Options to display
    **/
    options: CollapsablePickerOption<T>[];
    /**
     * Shows the selected option text as bold
     */
    selectedOptionTextIsBold: boolean;
    /**
    * Emits the object associated with the template option when selected.
    * If there is no object, the value of the option will be emitted.
    **/
    selection: EventEmitter<any>;
    collapsed: boolean;
    selectedOption: CollapsablePickerOption<T>;
    selectedTemplateData: ContentTemplateData;
    hasValue: boolean;
    isMobile: boolean;
    menuIsOpen: boolean;
    menuState: TemplateMenuState;
    constructor(windowService: WindowService, textService: TextService, changeDetector: ChangeDetectorRef, ngZone: NgZone);
    ngOnChanges(): void;
    toggleCollapsed(): void;
    open(): void;
    close(): void;
    onTemplateClick(option: CollapsablePickerOption<T>): void;
    onOptionKeyDown(option: MenuOption, event: KeyboardEvent): void;
    onComboboxClick(): void;
    onComboboxKeyDown(event: KeyboardEvent): void;
    onComboboxKeyUp(event: KeyboardEvent): void;
    private setSelectedOption;
    private setMenuState;
    private emitTemplateSelection;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<CollapsablePickerComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CollapsablePickerComponent<any>, "ui-forms-collapsable-picker", never, { "value": { "alias": "value"; "required": false; }; "options": { "alias": "options"; "required": false; }; "selectedOptionTextIsBold": { "alias": "selectedOptionTextIsBold"; "required": false; }; }, { "selection": "selection"; }, never, never, false, never>;
}

declare class SearchInputComponent extends BaseStandaloneComponent<string> implements OnChanges, AfterViewInit {
    ngModel: NgModel;
    input: ElementRef;
    /**
    * Set the value externally.
    **/
    value: string;
    /**
    * The maximum amount of character input allowed.
    **/
    maxLength: number;
    /**
    * Custom placeholder text that appears when no value is entered.
    * Default placeholder text is "Search"
    **/
    placeholder: string;
    /**
    * Display size of the input field
    **/
    size: 'sm' | 'lg';
    /**
    * Set to true to automatically focus the search input after the component is initialized. Defaults to false.
    **/
    autoFocus: boolean;
    /**
    * Set to true to disable input & buttons
    **/
    locked: boolean;
    /**
    * Customizable id
    **/
    inputId: string;
    /**
    * Customizable id
    **/
    clearButtonId: string;
    /**
    * Boolean to indicate this is a search sub-component
    **/
    isSearchBar: boolean;
    /**
    * Emits when the search input is focused or blurred (loses focus)
    **/
    inputHasFocus: EventEmitter<boolean>;
    hasValue: boolean;
    modelValue: string;
    sizeClass: string;
    private subscription;
    private skipNextEmit;
    constructor(textService: TextService);
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    private buildObservable;
    private sanitizeInputValue;
    clearInputValue(event?: Event): void;
    setFocusOnInput(): void;
    onFocusChange(hasFocus: boolean): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SearchInputComponent, "ui-forms-search-input", never, { "value": { "alias": "value"; "required": false; }; "maxLength": { "alias": "maxLength"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "size": { "alias": "size"; "required": false; }; "autoFocus": { "alias": "autoFocus"; "required": false; }; "locked": { "alias": "locked"; "required": false; }; "inputId": { "alias": "inputId"; "required": false; }; "clearButtonId": { "alias": "clearButtonId"; "required": false; }; "isSearchBar": { "alias": "isSearchBar"; "required": false; }; }, { "inputHasFocus": "inputHasFocus"; }, never, never, false, never>;
}

declare class MultiSelectPickerOption<T extends string | number> implements MultiSelectMenuOption {
    label: string;
    value: T;
    id: string;
    checked: boolean;
    e2e: string;
    constructor(label: string, value: T);
    clone(): MultiSelectPickerOption<T>;
}

declare class MultiSelectPickerComponent<T extends string[] | number[]> extends BaseStandaloneDropdownComponent<T> implements OnChanges {
    private changeDetector;
    private ngZone;
    private router;
    /**
    * Set the value externally.
    **/
    value: T;
    /**
    * Options to present to the user
    **/
    options: MultiSelectPickerOption<string | number>[];
    /**
    * Visual presentation of content within the toggle
    *  - 'selection' shows the label, first selected option, and count of remaining options. Toggle width may change and cause layout shifting.
    *  - 'label' shows the label and a count of total selected options. Toggle width is fixed.
    *  - 'icon' shows iconLeft only. If iconLeft is not configured, defaults to vertical dots. Toggle width is fixed.
    **/
    display: 'selection' | 'label' | 'icon';
    /**
    * Optional search placeholder text that appears when no value is entered. If empty, defaults to "Search"
    **/
    searchPlaceholder: string;
    /**
    * Groups of actions to present to the user
    **/
    actions: DropdownAction[];
    multiSelectState: MultiSelectState<T>;
    hasValue: boolean;
    private internalValue;
    iconOnly: boolean;
    firstOptionLabel: string;
    optionsCount: string;
    constructor(windowService: WindowService, textService: TextService, changeDetector: ChangeDetectorRef, ngZone: NgZone, router: Router);
    ngOnChanges(changes: SimpleChanges): void;
    private get stateOptions();
    private setInternalValue;
    private setComboboxContent;
    selectAll(): void;
    selectAllVisible(): void;
    onOptionClick(option: MultiSelectPickerOption<string | number>): void;
    onActionClick(action: DropdownAction): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<MultiSelectPickerComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MultiSelectPickerComponent<any>, "ui-forms-multi-select-picker", never, { "value": { "alias": "value"; "required": false; }; "options": { "alias": "options"; "required": false; }; "display": { "alias": "display"; "required": false; }; "searchPlaceholder": { "alias": "searchPlaceholder"; "required": false; }; "actions": { "alias": "actions"; "required": false; }; }, {}, never, never, false, never>;
}

declare class PickerOption<T extends string | number> implements MenuOption {
    label: string;
    value: T;
    id: string;
    e2e: string;
    constructor(label: string, value: T);
    clone(): PickerOption<T>;
}

declare class PickerComponent<T extends string | number> extends BaseStandaloneDropdownComponent<T> implements OnChanges {
    private changeDetector;
    private ngZone;
    private router;
    /**
    * Set the value externally.
    **/
    value: T;
    /**
    * Options to present to the user
    **/
    options: PickerOption<T>[];
    /**
    * Visual presentation of content within the toggle
    *  - 'selection' shows the label and selected option. Toggle width may change and cause layout shifting.
    *  - 'label' shows the label only. Toggle width is fixed.
    *  - 'icon' shows iconLeft only. If iconLeft is not configured, defaults to vertical dots. Toggle width is fixed.
    **/
    display: 'selection' | 'label' | 'icon';
    /**
    * Groups of actions to present to the user
    **/
    actions: DropdownAction[];
    hasValue: boolean;
    selectedOptionId: string;
    private internalValue;
    private selectedOption;
    iconOnly: boolean;
    selectedOptionLabel: string;
    constructor(windowService: WindowService, textService: TextService, changeDetector: ChangeDetectorRef, ngZone: NgZone, router: Router);
    ngOnChanges(changes: SimpleChanges): void;
    private get stateOptions();
    private setSelectedOption;
    private getValueFromOption;
    private setComboboxContent;
    onOptionClick(option: PickerOption<T>): void;
    onActionClick(action: DropdownAction): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<PickerComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PickerComponent<any>, "ui-forms-picker", never, { "value": { "alias": "value"; "required": false; }; "options": { "alias": "options"; "required": false; }; "display": { "alias": "display"; "required": false; }; "actions": { "alias": "actions"; "required": false; }; }, {}, never, never, false, never>;
}

declare class WorkflowInputOption implements MenuOption {
    label: string;
    value: string;
    id: string;
    e2e: string;
    constructor(label: string, value?: string);
    clone(): WorkflowInputOption;
}

declare class TypeaheadMenuState extends BaseFormMenuState {
    private typeaheadInputHasFocus;
    private typeaheadValueSubject;
    private closeMenuAfterValueChanges;
    private readonly isMobile;
    constructor(idPrefix: string, options: MenuOption[], componentDestroyed$: Subject<boolean>, factory?: TypeaheadFactory<MenuOption>);
    private setFocusableIds;
    private setUpObservable;
    onComboboxKeyDown(event: KeyboardEvent, unusedIsMobile: boolean, menuIsOpen: boolean): void;
    onComboboxKeyUp(event: KeyboardEvent): void;
    onComboboxFocusChange(hasFocus: boolean, returningFocus?: boolean): void;
    onComboboxValueChange(typeaheadValue: string, closeMenu: boolean): void;
    private updateAfterSettingVisibleOptions;
    protected focusElementById(id: string, unusedIsMobile: boolean, isMenuInit?: boolean): void;
    static getEmptyState(): TypeaheadMenuState;
}

declare class WorkflowInputComponent extends BaseStandaloneMenuComponent<string> implements OnChanges {
    input: ElementRef;
    /**
    * Set the value externally.
    **/
    value: string;
    /**
    * Customizable id
    **/
    inputId: string;
    /**
    * Optional placeholder
    **/
    placeholder: string;
    /**
    * Hidden label to apply to input
    **/
    ariaLabel: string;
    /**
    * Label id if a visible label is elsewhere
    **/
    labelId: string;
    /**
    * The max length of the input
    **/
    maxLength: number;
    /**
    * Optional regular expression used to prevent invalid characters from being entered
    **/
    invalidCharactersRegex: string | RegExp;
    /**
    * When enabled, input values will be translated to lowercase characters
    **/
    lowercaseOnly: boolean;
    /**
    * When enabled, paste events will be intercepted and bubbled up as Angular events
    **/
    disablePaste: boolean;
    /**
    * When enabled, enter key will submit the value and reset the input.
    * By default, the change event emits on keypress.
    **/
    submitOnEnter: boolean;
    /**
    * Array of typeahead options that a user may select from (but are not required).
    **/
    options: WorkflowInputOption[];
    /**
    * Enable this to let a parent component manage the dropdown-container class
    **/
    hideDropdownContainer: boolean;
    /**
    * Enable this to add a gap between the menu and the dropdown-container
    **/
    desktopMenuGap: boolean;
    change: EventEmitter<string>;
    submitted: EventEmitter<string>;
    pasted: EventEmitter<string>;
    inputValue: string;
    isTypeaheadMenu: boolean;
    menuState: TypeaheadMenuState;
    constructor(windowService: WindowService, textService: TextService);
    ngOnChanges(changes: SimpleChanges): void;
    onClipboardPaste(event: ClipboardEvent): void;
    onInputKeyDown(event: KeyboardEvent): void;
    onInputKeyUp(event: KeyboardEvent): void;
    onInput(inputValue: string): void;
    onFocusChange(hasFocus: boolean): void;
    setFocusOnInput(): void;
    private get inputHasFocus();
    onOptionClick(option: WorkflowInputOption): void;
    private submitValue;
    stopEvent(event: Event): void;
    private sanitizeValue;
    protected getDefaultText(): {};
    static ɵfac: i0.ɵɵFactoryDeclaration<WorkflowInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WorkflowInputComponent, "ui-forms-workflow-input", never, { "value": { "alias": "value"; "required": false; }; "inputId": { "alias": "inputId"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "labelId": { "alias": "labelId"; "required": false; }; "maxLength": { "alias": "maxLength"; "required": false; }; "invalidCharactersRegex": { "alias": "invalidCharactersRegex"; "required": false; }; "lowercaseOnly": { "alias": "lowercaseOnly"; "required": false; }; "disablePaste": { "alias": "disablePaste"; "required": false; }; "submitOnEnter": { "alias": "submitOnEnter"; "required": false; }; "options": { "alias": "options"; "required": false; }; "hideDropdownContainer": { "alias": "hideDropdownContainer"; "required": false; }; "desktopMenuGap": { "alias": "desktopMenuGap"; "required": false; }; }, { "change": "change"; "submitted": "submitted"; "pasted": "pasted"; }, never, never, false, never>;
}

declare class TemplateDropdownMenuState extends BaseMenuState {
    private comboboxId;
    private changeDetector;
    private ngZone;
    private selectAllId?;
    readonly searchInputId: string;
    readonly searchClearId: string;
    readonly showSearch: boolean;
    searchTerm: string;
    options: TemplateDropdownOption<BaseTemplateData>[];
    visibleOptions: TemplateDropdownOption<BaseTemplateData>[];
    get hasNoOptions(): boolean;
    get hasNoVisibleOptions(): boolean;
    get hasVisibleOptions(): boolean;
    close: (markAsTouched?: boolean) => void;
    constructor(comboboxId: string, changeDetector: ChangeDetectorRef, ngZone: NgZone, idPrefix: string, options: TemplateDropdownOption<BaseTemplateData>[], actions: DropdownAction[], selectAllId?: string);
    updateOptions(options: TemplateDropdownOption<BaseTemplateData>[]): void;
    onComboboxKeyDown(event: KeyboardEvent, isMobile: boolean, menuIsOpen: boolean): void;
    onComboboxKeyUp(event: KeyboardEvent): void;
    onMenuItemKeyDown(itemId: string, event: KeyboardEvent, isMobile: boolean): void;
    onMenuSearchKeyDown(event: KeyboardEvent, isMobile: boolean): void;
    onMenuInit(isMobile: boolean, idToFocus?: string | null): void;
    onMenuSearch(searchTerm: string): void;
    protected focusElementById(id: string, isMobile: boolean, isMenuInit?: boolean): void;
    private setFocusableIds;
    private setVisibleOptions;
    private sanitizeTerm;
    private focusCombobox;
    private focusIsOnSearchElement;
    private isIdSearchRelated;
    static getEmptyState(): TemplateDropdownMenuState;
}

declare class MultiSelectTemplateDropdownComponent<T extends BaseTemplateData> extends BaseDropdownComponent<string[]> implements OnChanges {
    protected ngZone: NgZone;
    private router;
    private changeDetector;
    protected controlContainer: ControlContainer;
    combobox: ElementRef;
    searchComponent: SearchInputComponent;
    closeButton: ElementRef;
    mobileContainer: ElementRef;
    /**
    * Groups of options to present to the user
    **/
    groups: TemplateGroup<T>[];
    /**
    * Groups of actions to present to the user
    **/
    actions: DropdownAction[];
    /**
    * The icon to show to the right of an optional "action" button.
    **/
    actionButtonIcon: string;
    /**
    * The message to show on an optional "action" button.
    **/
    actionButtonMessage: string;
    /**
    * Hides the action button message visually, but keeps it as an aria-label for accessibility.
    **/
    actionButtonMessageHidden: boolean;
    /**
    * Disables the "action" button.
    **/
    actionButtonDisabled: boolean;
    /**
    * Show a spinner in the "action" button when disabled.
    **/
    actionButtonDisabledSpinner: boolean;
    /**
    * An optional text override for the message to show when all available options are read-only.
    **/
    allOptionsAreReadOnlyMsg: string;
    /**
    * Custom message displayed when dropdown has no options.
    * Default is "No options available".
    **/
    noOptionsMessage: string;
    /**
    * Emits the object(s) associated with the template option(s) when selected.
    **/
    selection: EventEmitter<TemplateDropdownOption<T>[]>;
    /**
    * Emits if the user clicks the optional "action" button.
    * Value emitted is the current value of the field.
    **/
    actionButtonClick: EventEmitter<string[]>;
    comboboxTemplateData: BaseTemplateData;
    options: TemplateDropdownOption<T>[];
    selectedOptions: TemplateDropdownOption<T>[];
    private lockedFromAllReadOnlyOptions;
    actionsGroupId: string;
    readonly selectAllId = "multiTemplateSelectAll";
    menuState: TemplateDropdownMenuState;
    get hasValue(): boolean;
    trackByGroupId(_index: number, group: TemplateGroup<T>): string;
    get visibleGroups(): TemplateGroup<T>[];
    constructor(windowService: WindowService, textService: TextService, ngZone: NgZone, router: Router, changeDetector: ChangeDetectorRef, controlContainer: ControlContainer);
    ngOnChanges(changes: SimpleChanges): void;
    private allOptionsAreReadOnly;
    private setFlatListOfOptions;
    private buildMenuState;
    private setComboboxTemplate;
    writeValue(values: string[]): void;
    onButtonClick(): void;
    actionClicked(): void;
    onComboboxKeyDown(event: KeyboardEvent): void;
    closeKeyDown(event: KeyboardEvent): void;
    onComboboxKeyUp(event: KeyboardEvent): void;
    onComboboxClick(): void;
    selectAll(): void;
    private selectAllVisible;
    get allVisibleSelected(): boolean;
    get selectAllIndeterminate(): boolean;
    private selectOption;
    isSelected(optionId: string): boolean;
    onActionClick(action: DropdownAction): void;
    onOptionClick(group: TemplateGroup<T>, option: TemplateDropdownOption<T>): void;
    open(): void;
    close(markAsTouched: boolean): void;
    onItemKeyDown(group: TemplateGroup<T>, item: TemplateDropdownOption<T> | DropdownAction | null, event: KeyboardEvent): void;
    private emitTemplateSelection;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<MultiSelectTemplateDropdownComponent<any>, [null, null, null, null, null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MultiSelectTemplateDropdownComponent<any>, "ui-forms-multi-select-template-dropdown", never, { "groups": { "alias": "groups"; "required": false; }; "actions": { "alias": "actions"; "required": false; }; "actionButtonIcon": { "alias": "actionButtonIcon"; "required": false; }; "actionButtonMessage": { "alias": "actionButtonMessage"; "required": false; }; "actionButtonMessageHidden": { "alias": "actionButtonMessageHidden"; "required": false; }; "actionButtonDisabled": { "alias": "actionButtonDisabled"; "required": false; }; "actionButtonDisabledSpinner": { "alias": "actionButtonDisabledSpinner"; "required": false; }; "allOptionsAreReadOnlyMsg": { "alias": "allOptionsAreReadOnlyMsg"; "required": false; }; "noOptionsMessage": { "alias": "noOptionsMessage"; "required": false; }; }, { "selection": "selection"; "actionButtonClick": "actionButtonClick"; }, never, never, false, never>;
}

declare class TemplateDropdownComponent<T extends BaseTemplateData> extends BaseDropdownComponent<string> implements OnChanges {
    protected ngZone: NgZone;
    private router;
    private changeDetector;
    protected controlContainer: ControlContainer;
    combobox: ElementRef;
    searchComponent: SearchInputComponent;
    /**
    * Groups of options to present to the user
    **/
    groups: TemplateGroup<T>[];
    /**
    * Groups of actions to present to the user
    **/
    actions: DropdownAction[];
    /**
    * The icon to show to the right of an optional "action" button.
    **/
    actionButtonIcon: string;
    /**
    * The message to show on an optional "action" button.
    **/
    actionButtonMessage: string;
    /**
    * Hides the action button message visually, but keeps it as an aria-label for accessibility.
    **/
    actionButtonMessageHidden: boolean;
    /**
    * Disables the "action" button.
    **/
    actionButtonDisabled: boolean;
    /**
    * Show a spinner in the "action" button when disabled.
    **/
    actionButtonDisabledSpinner: boolean;
    /**
    * Custom message displayed when dropdown has no options.
    * Default is "No options available".
    **/
    noOptionsMessage: string;
    /**
    * Emits the object associated with the template option when selected.
    * If there is no object, the value of the option will be emitted.
    **/
    selection: EventEmitter<any>;
    /**
    * Emits if the user clicks the optional "action" button.
    * Value emitted is the current value of the field.
    **/
    actionButtonClick: EventEmitter<string>;
    comboboxTemplateData: BaseTemplateData;
    menuState: TemplateDropdownMenuState;
    protected selectedOption: TemplateDropdownOption<T>;
    selectedOptionId: string;
    scrolledOptionId: string;
    private options;
    actionsGroupId: string;
    get hasValue(): boolean;
    trackByGroupId(_index: number, group: TemplateGroup<T>): string;
    constructor(windowService: WindowService, textService: TextService, ngZone: NgZone, router: Router, changeDetector: ChangeDetectorRef, controlContainer: ControlContainer);
    ngOnChanges(changes: SimpleChanges): void;
    get visibleGroups(): TemplateGroup<T>[];
    private buildMenuState;
    private setFlatListOfOptions;
    private updateValueAfterOptionsChanged;
    private setComboboxTemplate;
    writeValue(value: string): void;
    onButtonClick(): void;
    actionClicked(): void;
    private hasOptions;
    onComboboxKeyDown(event: KeyboardEvent): void;
    closeKeyDown(event: KeyboardEvent): void;
    onComboboxKeyUp(event: KeyboardEvent): void;
    onComboboxClick(): void;
    private setSelectedOption;
    onActionClick(action: DropdownAction): void;
    onOptionClick(option: TemplateDropdownOption<T>): void;
    open(scrollToSelected: boolean): void;
    close(markAsTouched: boolean): void;
    onItemKeyDown(item: TemplateDropdownOption<T> | DropdownAction, event: KeyboardEvent): void;
    private emitTemplateSelection;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<TemplateDropdownComponent<any>, [null, null, null, null, null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TemplateDropdownComponent<any>, "ui-forms-template-dropdown", never, { "groups": { "alias": "groups"; "required": false; }; "actions": { "alias": "actions"; "required": false; }; "actionButtonIcon": { "alias": "actionButtonIcon"; "required": false; }; "actionButtonMessage": { "alias": "actionButtonMessage"; "required": false; }; "actionButtonMessageHidden": { "alias": "actionButtonMessageHidden"; "required": false; }; "actionButtonDisabled": { "alias": "actionButtonDisabled"; "required": false; }; "actionButtonDisabledSpinner": { "alias": "actionButtonDisabledSpinner"; "required": false; }; "noOptionsMessage": { "alias": "noOptionsMessage"; "required": false; }; }, { "selection": "selection"; "actionButtonClick": "actionButtonClick"; }, never, never, false, never>;
}

declare class TemplateRendererComponent<T extends BaseTemplateData> {
    /**
    * The data to render
    **/
    templateData: T;
    /**
    * Triggers disabled effects
    **/
    disabled: boolean;
    /**
    * If disabled, a message to explain why
    **/
    disabledMessage: string;
    /**
    * When set to true, will allow text to wrap, top align content.
    * When false, will truncate or nowrap text and center align content.
    **/
    allowExpansion: boolean;
    /**
    * When set to true, will show animation on hover.
    **/
    showHoverAnimation: boolean;
    TemplateType: typeof TemplateType;
    static ɵfac: i0.ɵɵFactoryDeclaration<TemplateRendererComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TemplateRendererComponent<any>, "ui-forms-template-renderer", never, { "templateData": { "alias": "templateData"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "disabledMessage": { "alias": "disabledMessage"; "required": false; }; "allowExpansion": { "alias": "allowExpansion"; "required": false; }; "showHoverAnimation": { "alias": "showHoverAnimation"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ContentTemplateComponent {
    /**
    * The icon to show on the leftmost section of the content template.
    **/
    icon: string;
    /**
    * The class used to control the color of the icon.
    **/
    iconColorClass: string;
    /**
    * If an image is desired, the URL of the image. This overrides the icon.
    **/
    imageUrl: string;
    /**
    * If enabled, uses an icon in place of an image with the same size/shape as the image.
    **/
    iconAsImage: boolean;
    /**
    * If iconAsImage is enabled, this class is used to control the background of the icon.
    **/
    iconAsImageBackgroundClass: string;
    /**
    * The string intended to display in the top left corner.
    **/
    topLeft: string;
    /**
    * Class(es) to apply directly to top left element.
    **/
    topLeftClass: string;
    /**
    * E2E testing - data-e2e attribute attached to top left element
    **/
    e2eTopLeft: string;
    /**
    * The string intended to display in the top right corner.
    **/
    topRight: string;
    /**
    * E2E testing - data-e2e attribute attached to top right element
    **/
    e2eTopRight: string;
    /**
    * The string intended to display in the bottom left corner.
    **/
    bottomLeft: string;
    /**
    * E2E testing - data-e2e attribute attached to bottom left element
    **/
    e2eBottomLeft: string;
    /**
    * The string intended to display in the bottom right corner.
    **/
    bottomRight: string;
    /**
    * E2E testing - data-e2e attribute attached to bottom right element
    **/
    e2eBottomRight: string;
    /**
    * Shows the template in a disabled state.
    **/
    disabled: boolean;
    /**
    * When set to true, will allow text to wrap, top align content.
    * When false, will truncate or nowrap text and center align content.
    **/
    allowExpansion: boolean;
    /**
    * If true, hover animation will show
    **/
    showHoverAnimation: boolean;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<ContentTemplateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ContentTemplateComponent, "ui-forms-content-template", never, { "icon": { "alias": "icon"; "required": false; }; "iconColorClass": { "alias": "iconColorClass"; "required": false; }; "imageUrl": { "alias": "imageUrl"; "required": false; }; "iconAsImage": { "alias": "iconAsImage"; "required": false; }; "iconAsImageBackgroundClass": { "alias": "iconAsImageBackgroundClass"; "required": false; }; "topLeft": { "alias": "topLeft"; "required": false; }; "topLeftClass": { "alias": "topLeftClass"; "required": false; }; "e2eTopLeft": { "alias": "e2eTopLeft"; "required": false; }; "topRight": { "alias": "topRight"; "required": false; }; "e2eTopRight": { "alias": "e2eTopRight"; "required": false; }; "bottomLeft": { "alias": "bottomLeft"; "required": false; }; "e2eBottomLeft": { "alias": "e2eBottomLeft"; "required": false; }; "bottomRight": { "alias": "bottomRight"; "required": false; }; "e2eBottomRight": { "alias": "e2eBottomRight"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "allowExpansion": { "alias": "allowExpansion"; "required": false; }; "showHoverAnimation": { "alias": "showHoverAnimation"; "required": false; }; }, {}, never, never, false, never>;
}

declare class DropdownField<T extends string | number> extends BaseFormField<T> {
    name: string;
    options: DropdownOption<T>[];
    iconLeft: string;
    placeholder: string;
    mobileAutoOpen: boolean;
    actions: DropdownAction[];
    menuIconsOnRight: boolean;
    noOptionsMessage: string;
    allowEmojis: boolean;
    showMenuOptionAsIconLeft: boolean;
    actionButtonIcon: string;
    actionButtonMessage: string;
    actionButtonMessageHidden: boolean;
    actionButtonDisabled: boolean;
    actionButtonDisabledSpinner: boolean;
    actionFn?: (value?: string | number) => void;
    constructor(name: string, label: string, initValue: T, required: boolean);
}

declare class FileInputUtils {
    static resizeImage(dataURL: string, { maxHeight, maxWidth, quality }?: ResizeOptions): Promise<string>;
    private static createImageFromDataUrl;
}
interface ResizeOptions {
    maxHeight?: number;
    maxWidth?: number;
    quality?: number;
}

declare class FileInputField extends BaseFormField<UploadedFile[]> {
    name: string;
    allowedFileTypes: FileType[];
    allowMultiple: boolean;
    buttonText: string;
    display: 'button' | 'dropbox' | 'capture';
    encodeBase64: boolean;
    fileType: 'image' | 'file';
    icon: string;
    imageHeight: number;
    imageWidth: number;
    maxSizeMbs: number;
    maxFileCount: number;
    showFileInfoMessage: boolean;
    showRemoveImageIconButton: boolean;
    resizeOptions: ResizeOptions;
    onNativeCaptureClick: () => void;
    constructor(name: string, label: string, initValue: UploadedFile[], required: boolean);
}

declare enum ManagementEditorFieldType {
    HTML = "HTML",
    JSON = "JSON"
}
declare class ManagementEditorField extends BaseFormField<string> {
    name: string;
    editorType: ManagementEditorFieldType;
    editorComponent: Type<ManagementEditor<string>>;
    readonly halfWidth: boolean;
    readonly fullWidth: boolean;
    htmlEditorAllowVideos: boolean;
    htmlEditorSanitize: boolean;
    htmlEditorShowCharactersRemaining: boolean;
    htmlEditorMaxLength: number;
    htmlEditorActions: Action[];
    htmlEditorActionsMenuIcon: string;
    htmlEditorActionsMenuText: string;
    htmlEditorFooterTemplate: TemplateRef<void> | null;
    htmlEditorIsLoading: boolean;
    textSelected: ((event: ManagementEditorSelectionEvent) => void) | null;
    jsonEditorShowEditToggle: boolean;
    jsonEditorStringArrayOnly: boolean;
    constructor(name: string, label: string, initValue: string, required: boolean, editorType: ManagementEditorFieldType, editorComponent: Type<ManagementEditor<string>>);
    private readonly _textSelectedCallback;
    get componentInputs(): object;
}

declare class MultiSelectDropdownField extends BaseFormField<string[]> {
    name: string;
    options: MultiSelectDropdownOption[];
    iconLeft: string;
    placeholder: string;
    mobileAutoOpen: boolean;
    actions: DropdownAction[];
    menuIconsOnRight: boolean;
    actionButtonIcon: string;
    actionButtonMessage: string;
    actionButtonMessageHidden: boolean;
    actionButtonDisabled: boolean;
    actionButtonDisabledSpinner: boolean;
    actionFn?: (value?: string[]) => void;
    constructor(name: string, label: string, initValue: string[], required: boolean);
}

declare class MultiSelectTemplateDropdownField<T extends BaseTemplateData> extends BaseFormField<string[]> {
    name: string;
    groups: TemplateGroup<T>[];
    actions: DropdownAction[];
    allOptionsAreReadOnlyMsg: string;
    placeholder: string;
    actionButtonIcon: string;
    actionButtonMessage: string;
    actionButtonMessageHidden: boolean;
    actionButtonDisabled: boolean;
    actionButtonDisabledSpinner: boolean;
    actionFn?: (value?: string[]) => void;
    constructor(name: string, label: string, initValue: string[], required: boolean);
}

declare class NumberInputField extends BaseFormField<number> {
    name: string;
    min: number;
    max: number;
    dayOfMonthPicker: boolean;
    disabledPickerDays: number[];
    disabledDaysText: string;
    markedDay: number;
    markedDayLabel: string;
    selectedDayLabel: string;
    decimalPlaces: number;
    constructor(name: string, label: string, initValue: number, required: boolean);
}

declare class PasswordInputField extends BaseFormField<string> {
    name: string;
    fieldMatches: string;
    minLength: number;
    maxLength: number;
    passwordRequirement: RegExp[];
    criteria: ValidationCriteria[];
    criteriaDescription: string;
    passwordStrengthMedium: RegExp[];
    passwordStrengthStrong: RegExp[];
    constructor(name: string, label: string, initValue: string, required: boolean);
}

declare class RadioButtonOption {
    label: string;
    value: string | number;
    checked: boolean;
    constructor(label: string, value: string | number, checked?: boolean);
    subtextLines: string[];
    isSelectable: boolean;
    tooltip?: string;
    _ariaLabel?: string;
}

declare class RadioButtonsField<T extends string | number> extends BaseFormField<T> {
    name: string;
    options: RadioButtonOption[];
    vertical: boolean;
    constructor(name: string, label: string, initValue: T, required: boolean);
}

declare enum SensitiveInputFieldType {
    EIN_ID = "EIN_ID",// Employer Identification Number mask - 12-34568789 (Business Tax ID)
    DEFAULT = "DEFAULT",
    SSN_FULL = "SSN_FULL",// Social Security Number mask - 123-45-6789
    SSN_LAST4 = "SSN_LAST4",
    SSN_LAST5 = "SSN_LAST5",
    SSN_LAST6 = "SSN_LAST6",
    TAX_ID = "TAX_ID",// EIN or SSN_FULL or 9-digits accepted, no mask, dashes allowed & validated
    PIN = "PIN",
    CVV = "CVV"
}

declare class SensitiveInputField extends BaseFormField<string> {
    name: string;
    fieldType: SensitiveInputFieldType;
    fieldMatches: string;
    minLength: number;
    maxLength: number;
    pattern: string | RegExp;
    constructor(name: string, label: string, initValue: string, required: boolean);
}

declare class SliderField extends BaseFormField<number> {
    name: string;
    min: number;
    max: number;
    step: number | 'any';
    showThumbBubble: boolean;
    showValueInHeader: boolean;
    showAmountInput: boolean;
    formatValue: (value: number) => string;
    constructor(name: string, label: string, initValue: number, required: boolean);
}

declare class TemplateDropdownField<T extends BaseTemplateData> extends BaseFormField<string> {
    name: string;
    groups: TemplateGroup<T>[];
    actions: DropdownAction[];
    mobileAutoOpen: boolean;
    placeholder: string;
    actionButtonIcon: string;
    actionButtonMessage: string;
    actionButtonMessageHidden: boolean;
    actionButtonDisabled: boolean;
    actionButtonDisabledSpinner: boolean;
    actionFn?: (value?: string) => void;
    constructor(name: string, label: string, initValue: string, required: boolean);
}

declare class TextAreaField extends BaseFormField<string> {
    name: string;
    collapsable: boolean;
    minLength: number;
    maxLength: number;
    asciiOnly: boolean;
    pattern: string | RegExp;
    preventNewLines: boolean;
    rows: number;
    showCharactersRemaining: boolean;
    constructor(name: string, label: string, initValue: string, required: boolean);
}

declare class ToggleField extends BaseFormField<boolean> {
    name: string;
    requiredTrue: boolean;
    subtextLines: string[];
    allowNull: boolean;
    constructor(name: string, label: string, initValue: boolean | null);
}

declare class FormRendererGroupCategoryEvent {
    category: string;
    groupIds: string[];
    constructor(category: string, ids: string[]);
}

declare class FormRendererInputEvent {
    value: any;
    groupId: string;
    isEdited: boolean;
    fieldName: string;
    fieldContext: any;
    optionContext: any;
    constructor(field: BaseFormField<any>, value: any, groupId: string);
}

declare class FormRendererSelectionEvent {
    groupId: string;
    singleSelectValue: any;
    multiSelectValues: any[];
    isEdited: boolean;
    fieldName: string;
    fieldContext: any;
    optionContext: any;
    constructor(field: BaseFormField<any>, groupId: string);
}

declare class FormRendererTemplateValue {
    value: string;
    object: any;
    constructor(value: string, object: any);
}

declare enum FormRendererValidatorType {
    FORM_VALIDATOR = "formValidator",
    MAX = "max",
    MIN = "min",
    MIN_LENGTH = "minlength",
    NUMBERS_ONLY = "numbersOnly",
    PATTERN = "pattern",
    REQUIRED = "required"
}

declare class FormRendererComponent extends BaseTextComponent implements OnChanges, OnDestroy, AfterContentChecked {
    private fb;
    private windowService;
    private changeDetector;
    private botDetectionService;
    collapsableGroups: CollapsableComponent[];
    contentContainer: ElementRef;
    /**
    * Rows containing form fields or content.
    **/
    rows: FormRendererRow[];
    /**
    * Set to true to disable buttons.
    **/
    disableButtons: boolean;
    /**
    * The text of the primary button.
    **/
    primaryButtonText: string;
    /**
    * The text of the primary button in its disabled state.
    **/
    primaryButtonDisabledText: string;
    /**
    * The icon of the primary button.
    **/
    primaryButtonIcon: string;
    /**
    * Position of the icon of the primary button.
    **/
    primaryButtonIconPosition: 'left' | 'right';
    /**
    * The text of the (optional) secondary button.
    **/
    secondaryButtonText: string;
    /**
    * The secondary button resets the form on click.
    **/
    secondaryButtonClearsForm: boolean;
    /**
    * An optional URL to navigate to on secondary button click.
    **/
    secondaryButtonUrl: string;
    /**
    * Optional query parameters for the secondaryButtonUrl.
    **/
    secondaryButtonUrlParams: Params;
    /**
    * If true, the secondary button's external link will open in a new tab.
    **/
    secondaryButtonUsesExternalUrlNewTab: boolean;
    /**
    * The icon of the secondary button.
    **/
    secondaryButtonIcon: string;
    /**
    * Position of the icon of the secondary button.
    **/
    secondaryButtonIconPosition: 'left' | 'right';
    /**
    * The text of the tertiary button.
    **/
    tertiaryButtonText: string;
    /**
    * The icon of the tertiary button.
    **/
    tertiaryButtonIcon: string;
    /**
    * Position of the icon of the tertiary button.
    **/
    tertiaryButtonIconPosition: 'left' | 'right';
    /**
    * An optional URL to navigate to on tertiary button click.
    **/
    tertiaryButtonUrl: string;
    /**
    * Optional query parameters for the tertiaryButtonUrl.
    **/
    tertiaryButtonUrlParams: Params;
    /**
    * If true, the tertiary button's external link will open in a new tab.
    **/
    tertiaryButtonUsesExternalUrlNewTab: boolean;
    /**
    * Set to true to lock every form field.
    **/
    locked: boolean;
    /**
    * Shows a loading spinner while there are no rows.
    **/
    loading: boolean;
    /**
    * A custom loading message. Default is: Loading...
    **/
    loadingMessage: string;
    /**
    * Set this to true to copy form values back to the form row fields when the user
    * attempts to submit the field. This is helpful when transitioning back to the form
    * from a review page.
    **/
    storeValuesOnSubmit: boolean;
    /**
    * Set this to true to copy form values back to the form row fields when this
    * component is destroyed. This is helpful when working with forms inside modals.
    **/
    storeValuesOnDestroy: boolean;
    /**
    * Set this to true to track values that have changed from the initial values.
    * There is a minor performance cost to this feature, so only turn it on if needed.
    * When enabled, this feature can be used with some public helper methods:
    * hasEditedValues - returns a boolean if any fields have been edited.
    * resetEditedValues - reset the edited values by internally using the current values as the initial values.
    * Warning: this feature does not work with groups.
    **/
    checkEditedValues: boolean;
    /**
    * E2E testing - this value is used to generate e2e hooks across this component.
    **/
    e2e: string;
    /**
    * Shows the next invalid field that the user must interact with.
    **/
    showNextField: boolean;
    /**
    * Error messages to display. Typically used for server-side validation.
    **/
    errorMessages: string[];
    /**
    * Set this to true to automatically focus the first field when the form loads
    **/
    autoFocus: boolean;
    /**
    * Set this to true to add top margin to the button group
    **/
    marginTop: boolean;
    /**
    * Set this to true to add bottom margin to the button group
    **/
    marginBottom: boolean;
    /**
    * Set this to true to enable bot detection.
    **/
    enableBotDetection: boolean;
    /**
    * Emits when primary button is clicked.
    **/
    primaryButtonClicked: EventEmitter<UntypedFormGroup>;
    /**
    * Emits when secondary button is clicked.
    **/
    secondaryButtonClicked: EventEmitter<UntypedFormGroup>;
    /**
    * Emits when tertiary button is clicked.
    **/
    tertiaryButtonClicked: EventEmitter<UntypedFormGroup>;
    /**
    * Emits when free form input components are changed.
    * Such as text inputs, number inputs, etc.
    **/
    inputChange: EventEmitter<FormRendererInputEvent>;
    /**
    * Emits when objects are selected from components that provide finite selectable options.
    * Such as dropdowns, radio buttons, checkboxes, day picker, datepicker, etc.
    **/
    selection: EventEmitter<FormRendererSelectionEvent>;
    /**
    * Emits when categorized groups are added, removed, initialized or visibility changes.
    **/
    groupCategoryChange: EventEmitter<FormRendererGroupCategoryEvent>;
    form: UntypedFormGroup;
    formId: string;
    isMobile: boolean;
    e2ePrefix: string;
    showFormButtons: boolean;
    groups: FormRendererRowGrouping[];
    dynamicContentClass: string;
    botDetectionControlName: string;
    FormRendererFieldType: typeof FormRendererFieldType;
    TextSize: typeof TextSize;
    private updateSubscription;
    private formInputChanged;
    private matchedFields;
    private initialValues;
    private editedFields;
    private lastMenuSelection;
    private managementEditorFields;
    private get containsManagementEditor();
    constructor(fb: UntypedFormBuilder, windowService: WindowService, textService: TextService, changeDetector: ChangeDetectorRef, botDetectionService: BotDetectionService);
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterContentChecked(): void;
    ngOnDestroy(): void;
    private createFormInputChangedObservable;
    private resetForm;
    private buildForm;
    private handleGroupUpdateEvent;
    private handleFieldUpdateEvent;
    private addRowToForm;
    private setVisibleFieldsForRow;
    private addFieldToForm;
    private removeRowFromForm;
    private updateFormField;
    private setFocusOnFormField;
    private copyValuesToRows;
    submitForm(): void;
    private expandGroupsWithInvalidFields;
    secondaryButtonClick(): void;
    tertiaryButtonClick(): void;
    buttonFieldClicked(field: ButtonField | IconButtonField, row: FormRendererRow, grouping: FormRendererRowGrouping): void;
    inLineNotificationClicked(field: InLineNotificationField, row: FormRendererRow, grouping: FormRendererRowGrouping, buttonIndex: number): void;
    inLineNotificationClosed(field: InLineNotificationField): void;
    labelValueListClicked(field: LabelValueListField, eventType: string, item: LabelValueListItem): void;
    inputChanged(field: BaseFormField<any>, value: any, grouping: FormRendererRowGrouping): void;
    singleSelectChanged(field: BaseFormField<any>, value: any, grouping: FormRendererRowGrouping): void;
    multiSelectChanged(field: BaseFormField<any>, values: any[], grouping: FormRendererRowGrouping): void;
    onMenuSelection(field: BaseFormField<any>, event: MenuSelectionEvent<any>, grouping: FormRendererRowGrouping, singleSelect: boolean): void;
    private hydrateEvent;
    private valueIsUnset;
    private valueIsEdited;
    getErrorMessage(field: BaseFormField<FormFieldValue>): string;
    private addFieldMatch;
    private updateFieldMatches;
    private addInitialValue;
    protected getDefaultText(): any;
    getField(fieldName: string): FormRendererField;
    getGroupSummaries(): FormRendererGroupSummary[];
    getRowsInGroup(groupId: string): FormRendererRow[];
    getFormControlNamesInGroup(groupId: string): string[];
    getRowById(rowId: string): FormRendererRow;
    addGroup(rows: FormRendererRow[], group: FormRendererGroup, positioning?: FormRendererPositioning): void;
    private emitCategorizedGroups;
    hasEditedValues(): boolean;
    resetEditedValues(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormRendererComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormRendererComponent, "ui-forms-form-renderer", never, { "rows": { "alias": "rows"; "required": false; }; "disableButtons": { "alias": "disableButtons"; "required": false; }; "primaryButtonText": { "alias": "primaryButtonText"; "required": false; }; "primaryButtonDisabledText": { "alias": "primaryButtonDisabledText"; "required": false; }; "primaryButtonIcon": { "alias": "primaryButtonIcon"; "required": false; }; "primaryButtonIconPosition": { "alias": "primaryButtonIconPosition"; "required": false; }; "secondaryButtonText": { "alias": "secondaryButtonText"; "required": false; }; "secondaryButtonClearsForm": { "alias": "secondaryButtonClearsForm"; "required": false; }; "secondaryButtonUrl": { "alias": "secondaryButtonUrl"; "required": false; }; "secondaryButtonUrlParams": { "alias": "secondaryButtonUrlParams"; "required": false; }; "secondaryButtonUsesExternalUrlNewTab": { "alias": "secondaryButtonUsesExternalUrlNewTab"; "required": false; }; "secondaryButtonIcon": { "alias": "secondaryButtonIcon"; "required": false; }; "secondaryButtonIconPosition": { "alias": "secondaryButtonIconPosition"; "required": false; }; "tertiaryButtonText": { "alias": "tertiaryButtonText"; "required": false; }; "tertiaryButtonIcon": { "alias": "tertiaryButtonIcon"; "required": false; }; "tertiaryButtonIconPosition": { "alias": "tertiaryButtonIconPosition"; "required": false; }; "tertiaryButtonUrl": { "alias": "tertiaryButtonUrl"; "required": false; }; "tertiaryButtonUrlParams": { "alias": "tertiaryButtonUrlParams"; "required": false; }; "tertiaryButtonUsesExternalUrlNewTab": { "alias": "tertiaryButtonUsesExternalUrlNewTab"; "required": false; }; "locked": { "alias": "locked"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; "loadingMessage": { "alias": "loadingMessage"; "required": false; }; "storeValuesOnSubmit": { "alias": "storeValuesOnSubmit"; "required": false; }; "storeValuesOnDestroy": { "alias": "storeValuesOnDestroy"; "required": false; }; "checkEditedValues": { "alias": "checkEditedValues"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; "showNextField": { "alias": "showNextField"; "required": false; }; "errorMessages": { "alias": "errorMessages"; "required": false; }; "autoFocus": { "alias": "autoFocus"; "required": false; }; "marginTop": { "alias": "marginTop"; "required": false; }; "marginBottom": { "alias": "marginBottom"; "required": false; }; "enableBotDetection": { "alias": "enableBotDetection"; "required": false; }; }, { "primaryButtonClicked": "primaryButtonClicked"; "secondaryButtonClicked": "secondaryButtonClicked"; "tertiaryButtonClicked": "tertiaryButtonClicked"; "inputChange": "inputChange"; "selection": "selection"; "groupCategoryChange": "groupCategoryChange"; }, never, ["*"], false, never>;
}

declare class FormFieldStacker {
    private fieldsPerRow;
    constructor(fieldsPerRow: number);
    private formRows;
    private tempFormFieldStack;
    addNewFormField(field: FormRendererField, ignoreStackerRules?: boolean): void;
    addNewFormRow(): void;
    getFormRows(): FormRendererRow[];
}

declare class FormUtils {
    static get defaultBotDetectionName(): string;
    static getBotDetectionValue(formGroup: UntypedFormGroup): string;
    static get defaultMaxLength(): number;
    static get largestPossibleMax(): number;
    static get smallestPossibleMin(): number;
    static showFormValidation(formGroup: UntypedFormGroup, containerId?: string, updateValueAndValidity?: boolean): void;
    private static showFormValidationRecursive;
    static showControlValidation(control: AbstractControl, updateValueAndValidity?: boolean): void;
    static removeFormValidation(formGroup: UntypedFormGroup): void;
    static updateValueAndValidity(formGroup: UntypedFormGroup): void;
    static removeControlValidation(control: AbstractControl): void;
    static focusFirstField(formElement: HTMLElement): void;
    static focusSpecificField(formElement: HTMLElement, name: string): void;
    static getAllFormControlElements(formElement: HTMLElement, includeLocked?: boolean): NodeListOf<Element>;
    static focusOnFirstError(containerId?: string): void;
    private static findAndFocusElement;
    private static getFocusableFieldElement;
    static createFormValidator(validator: (value: any) => ValidationResult, error?: string): ValidatorFn;
    static buildDropdownOptionsFromEnum<T>(textOptions: object, enumType: T): DropdownOption<string>[];
}

declare class FormSpacingUtils {
    static getSpacingConfig(element: Element): SpacingConfig;
}

declare class FieldValidationComponent {
    fieldId: string;
    locked: boolean;
    errorMessage: string;
    infoMessage: string;
    successMessage: string;
    warningMessage: string;
    ariaInputName: string;
    criteria: ValidationCriteria[];
    criteriaDescription: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<FieldValidationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FieldValidationComponent, "ui-forms-field-validation", never, { "fieldId": { "alias": "fieldId"; "required": false; }; "locked": { "alias": "locked"; "required": false; }; "errorMessage": { "alias": "errorMessage"; "required": false; }; "infoMessage": { "alias": "infoMessage"; "required": false; }; "successMessage": { "alias": "successMessage"; "required": false; }; "warningMessage": { "alias": "warningMessage"; "required": false; }; "ariaInputName": { "alias": "ariaInputName"; "required": false; }; "criteria": { "alias": "criteria"; "required": false; }; "criteriaDescription": { "alias": "criteriaDescription"; "required": false; }; }, {}, never, ["*"], false, never>;
}

declare class LabelTooltipsComponent extends BaseTextComponent {
    /**
    * Required. The label of the form field
    **/
    label: string;
    /**
    * Label text to display in front of tooltip icon (optional)
    **/
    locked: boolean;
    /**
    * Displays when the field is locked
    **/
    lockedMessage: string;
    /**
    * Text content to display in the tooltip popover bubble
    **/
    tooltip: string;
    /**
    * Direction to place the tooltip popover.
    **/
    tooltipPlacement: 'auto' | 'top' | 'top-left' | 'top-right' | 'bottom' | 'bottom-left' | 'bottom-right' | 'left' | 'left-top' | 'left-bottom' | 'right' | 'right-top' | 'right-bottom';
    /**
    * E2E testing - this value is used to generate e2e hooks across this component.
    **/
    e2e: string;
    /**
     * Class(es) to apply to the tooltip popover.
     */
    tooltipClass: string;
    constructor(textService: TextService);
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<LabelTooltipsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LabelTooltipsComponent, "ui-forms-label-tooltips", never, { "label": { "alias": "label"; "required": false; }; "locked": { "alias": "locked"; "required": false; }; "lockedMessage": { "alias": "lockedMessage"; "required": false; }; "tooltip": { "alias": "tooltip"; "required": false; }; "tooltipPlacement": { "alias": "tooltipPlacement"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; "tooltipClass": { "alias": "tooltipClass"; "required": false; }; }, {}, never, never, false, never>;
}

declare class WorkflowButtonSummary implements Cloneable {
    icon: string;
    message: string;
    constructor(icon: string, message: string);
    clone(): WorkflowButtonSummary;
}

declare abstract class BaseArrayFieldComponent<T extends Array<Cloneable> | string[] | number[]> extends BaseFieldComponent<T> {
    protected controlContainer: ControlContainer;
    constructor(textService: TextService, textConfigKey: string, controlContainer: ControlContainer);
    get hasValue(): boolean;
    protected writeValueAndEmitChange(value: T): void;
    protected shouldEmitChange(incomingValue: T): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseArrayFieldComponent<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BaseArrayFieldComponent<any>, never, never, {}, {}, never, never, true, never>;
}

declare class WorkflowButtonComponent extends BaseArrayFieldComponent<WorkflowButtonSummary[]> {
    placeholderIcon: string;
    placeholder: string;
    clicked: EventEmitter<void>;
    ariaLabel: string;
    summaryLines: number;
    constructor(textService: TextService);
    writeValue(value: any): void;
    emitClicked(): void;
    private setAriaLabel;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<WorkflowButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WorkflowButtonComponent, "ui-forms-workflow-button", never, { "placeholderIcon": { "alias": "placeholderIcon"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; }, { "clicked": "clicked"; }, never, never, false, never>;
}

interface ManagementEditor<T> {
    successMessage: string;
    warningMessage: string;
    infoMessage: string;
    errorMessage: string;
    lockedMessage: string;
    label: string;
    hideLabel: boolean;
    controlName: string;
    e2e: string;
    locked: boolean;
    tooltip: string;
    tooltipPlacement: string;
    change: EventEmitter<T>;
}

interface ManagementEditorSelectionEvent {
    text: string;
    html: string;
    index: number;
    length: number;
}

declare function formValidator(validator: (value: any) => ValidationResult, error?: string): ValidatorFn;
declare function conditionalValidator(condition: () => boolean, validator: ValidatorFn): ValidatorFn;

declare enum Autocomplete {
    USERNAME = "username",
    CURRENT_PASSWORD = "current-password",
    NEW_PASSWORD = "new-password",
    ONE_TIME_CODE = "one-time-code",
    EMAIL = "email",
    PHONE = "tel",
    MOBILE_PHONE = "mobile tel",
    ADDRESS_LINE1 = "address-line1",
    ADDRESS_LINE2 = "address-line2",
    CITY = "address-level2",
    STATE = "address-level1",
    ZIP_CODE = "postal-code",
    PROVINCE = "address-level1",
    POSTAL_CODE = "postal-code",// Same as domestic zip code
    FIRST_NAME = "given-name",
    LAST_NAME = "family-name",
    CVV = "cc-csc",
    ON = "on",
    OFF = "off"
}

declare const DEFAULT_MAX_LENGTH = 500;
declare const DEFAULT_TEXT_AREA_ROWS = 3;
declare const DEFAULT_MAX_NUMBER = 9999999999999;
declare const DEFAULT_MAX_AMOUNT = 99999999.99;
declare const DEFAULT_LOCKED_MESSAGE = "DEFAULT_LOCKED_MESSAGE";
declare const DEFAULT_TEXT_DEBOUNCE_TIME = 300;

declare class CalendarComponent implements OnInit {
    private readonly adapter;
    private readonly dateProvider;
    private readonly elementRef;
    picker: ElementRef;
    dayOfMonthOnly: boolean;
    isCompactMode: boolean;
    actionButtonIcon: string;
    actionButtonLabel: string;
    ariaSelectedLabel: string;
    afterDateText: string;
    allowToday: boolean;
    private daysAfter;
    private daysPrior;
    disabledDaysText: string;
    disableFutureDates: boolean;
    disableHolidays: boolean;
    disablePastDates: boolean;
    disableWeekends: boolean;
    displayMonths: number;
    hasRangeValue: boolean;
    private holidays;
    isDateRange: boolean;
    isMobile: boolean;
    markedDateText: string;
    maxDate: NgbDateStruct;
    minDate: NgbDateStruct;
    mobileDoneButtonLabel: string;
    priorDateText: string;
    selectedDateText: string;
    maxDayOfMonth: number;
    minDayOfMonth: number;
    actionButtonClick: EventEmitter<Event>;
    mobileDoneButtonClick: EventEmitter<void>;
    inputValueChange: EventEmitter<string | number>;
    toggleCalendar: EventEmitter<boolean>;
    e2e: string;
    e2ePrefix: string;
    ariaDateValue: string;
    ariaDateLive: string;
    showLegend: boolean;
    private _markedDate;
    set markedDate(value: NgbDateStruct | number);
    get markedDate(): NgbDateStruct;
    private _disableAllExceptFirstDayOfMonth;
    set disableAllExceptFirstDayOfMonth(value: boolean);
    get disableAllExceptFirstDayOfMonth(): boolean;
    private _disableAllExceptLastDayOfMonth;
    set disableAllExceptLastDayOfMonth(value: boolean);
    get disableAllExceptLastDayOfMonth(): boolean;
    private _disableAllExceptFifteenthAndLastDay;
    set disableAllExceptFifteenthAndLastDay(value: boolean);
    get disableAllExceptFifteenthAndLastDay(): boolean;
    private _disabledDaysOfMonth;
    set disabledDaysOfMonth(value: number[]);
    get disabledDaysOfMonth(): number[];
    private _value;
    set inputValue(value: string);
    get inputValue(): string;
    displaySelectedDate: NgbDateStruct;
    displayRelativeDate: NgbDateStruct;
    hoveredDate: NgbDateStruct;
    hoveredDateValue: Date;
    markedDateValue: Date;
    rangeStartValue: NgbDateStruct;
    rangeEndValue: NgbDateStruct;
    selectedDate: NgbDateStruct;
    selectedDateValue: Date;
    private todayDate;
    private hoveredRelativeDate;
    private relativeDate;
    private focusTargets;
    private targetsObserver;
    constructor(adapter: NgbDateNativeAdapter, dateProvider: DateProvider, elementRef: ElementRef);
    isDisabled: (date: NgbDateStruct) => boolean;
    handleKeyDown(e: KeyboardEvent): void;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    toggleCalendarDropdown(force?: boolean): void;
    onDatepickerChange(event: Event): void;
    onDateSelection(date: NgbDateStruct): void;
    onHover(date: NgbDateStruct): void;
    leaveHover(): void;
    onActionButtonClick(event: Event): void;
    onMobileDoneButtonClick(): void;
    onKeyDown(event: KeyboardEvent): void;
    isSelectedDateHovered: (date: any) => boolean;
    isRelativeDateHovered: (date: any) => boolean;
    isSelectedDate: (date: any) => boolean;
    isRelativeDate: (date: any) => boolean;
    isToday: (date: any) => boolean;
    isMarkedDate: (date: any) => boolean;
    isInDateRange(date: NgbDateStruct): boolean;
    private updateDateVariables;
    private isPastDate;
    private subtractDaysFromDate;
    private addDaysToDate;
    private isPastMax;
    private isBeforeMin;
    private isBeforeStartDate;
    private isDisabledDayOfMonth;
    private getIsDisabledFn;
    private updateDisabledDates;
    private updateMarkedDate;
    private updateSelectedDate;
    private dayFocused;
    private getDayOfMonthDateStruct;
    private findFocusTargets;
    private setFocusTargets;
    private shiftFocus;
    private setFocus;
    private getNextFocusIndex;
    private updateDayTarget;
    private updateNavOrder;
    private checkRange;
    static ɵfac: i0.ɵɵFactoryDeclaration<CalendarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CalendarComponent, "ui-forms-calendar", never, { "dayOfMonthOnly": { "alias": "dayOfMonthOnly"; "required": false; }; "actionButtonIcon": { "alias": "actionButtonIcon"; "required": false; }; "actionButtonLabel": { "alias": "actionButtonLabel"; "required": false; }; "ariaSelectedLabel": { "alias": "ariaSelectedLabel"; "required": false; }; "afterDateText": { "alias": "afterDateText"; "required": false; }; "allowToday": { "alias": "allowToday"; "required": false; }; "daysAfter": { "alias": "daysAfter"; "required": false; }; "daysPrior": { "alias": "daysPrior"; "required": false; }; "disabledDaysText": { "alias": "disabledDaysText"; "required": false; }; "disableFutureDates": { "alias": "disableFutureDates"; "required": false; }; "disableHolidays": { "alias": "disableHolidays"; "required": false; }; "disablePastDates": { "alias": "disablePastDates"; "required": false; }; "disableWeekends": { "alias": "disableWeekends"; "required": false; }; "displayMonths": { "alias": "displayMonths"; "required": false; }; "hasRangeValue": { "alias": "hasRangeValue"; "required": false; }; "holidays": { "alias": "holidays"; "required": false; }; "isDateRange": { "alias": "isDateRange"; "required": false; }; "isMobile": { "alias": "isMobile"; "required": false; }; "markedDateText": { "alias": "markedDateText"; "required": false; }; "maxDate": { "alias": "maxDate"; "required": false; }; "minDate": { "alias": "minDate"; "required": false; }; "mobileDoneButtonLabel": { "alias": "mobileDoneButtonLabel"; "required": false; }; "priorDateText": { "alias": "priorDateText"; "required": false; }; "selectedDateText": { "alias": "selectedDateText"; "required": false; }; "maxDayOfMonth": { "alias": "maxDayOfMonth"; "required": false; }; "minDayOfMonth": { "alias": "minDayOfMonth"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; "markedDate": { "alias": "markedDate"; "required": false; }; "disableAllExceptFirstDayOfMonth": { "alias": "disableAllExceptFirstDayOfMonth"; "required": false; }; "disableAllExceptLastDayOfMonth": { "alias": "disableAllExceptLastDayOfMonth"; "required": false; }; "disableAllExceptFifteenthAndLastDay": { "alias": "disableAllExceptFifteenthAndLastDay"; "required": false; }; "disabledDaysOfMonth": { "alias": "disabledDaysOfMonth"; "required": false; }; "inputValue": { "alias": "inputValue"; "required": false; }; }, { "actionButtonClick": "actionButtonClick"; "mobileDoneButtonClick": "mobileDoneButtonClick"; "inputValueChange": "inputValueChange"; "toggleCalendar": "toggleCalendar"; }, never, never, false, never>;
}

declare class CalendarMenuState extends BaseMenuState {
    constructor(idPrefix: string);
    protected focusElementById: () => void;
    onComboboxKeyDown(event: KeyboardEvent, isMobile: boolean, menuIsOpen: boolean): void;
    onComboboxKeyUp(event: KeyboardEvent): void;
    static getEmptyState(): CalendarMenuState;
}

declare class CalendarMenuComponent extends BaseMenuComponent {
    menuState: CalendarMenuState;
    allowToday: boolean;
    ariaSelectedLabel: string;
    closeButtonAriaLabel: string;
    disableFutureDates: boolean;
    disablePastDates: boolean;
    hasRangeValue: boolean;
    inputValue: string;
    isDateRange: boolean;
    markedDate: NgbDateStruct;
    markedDateText: string;
    maxDate: Date;
    minDate: Date;
    mobileDoneButtonLabel: string;
    selectedDateText: string;
    mobileDoneButtonClick: EventEmitter<Event>;
    inputValueChange: EventEmitter<string>;
    toggleCalendar: EventEmitter<boolean>;
    constructor();
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<CalendarMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CalendarMenuComponent, "ui-forms-calendar-menu", never, { "menuState": { "alias": "menuState"; "required": false; }; "allowToday": { "alias": "allowToday"; "required": false; }; "ariaSelectedLabel": { "alias": "ariaSelectedLabel"; "required": false; }; "closeButtonAriaLabel": { "alias": "closeButtonAriaLabel"; "required": false; }; "disableFutureDates": { "alias": "disableFutureDates"; "required": false; }; "disablePastDates": { "alias": "disablePastDates"; "required": false; }; "hasRangeValue": { "alias": "hasRangeValue"; "required": false; }; "inputValue": { "alias": "inputValue"; "required": false; }; "isDateRange": { "alias": "isDateRange"; "required": false; }; "markedDate": { "alias": "markedDate"; "required": false; }; "markedDateText": { "alias": "markedDateText"; "required": false; }; "maxDate": { "alias": "maxDate"; "required": false; }; "minDate": { "alias": "minDate"; "required": false; }; "mobileDoneButtonLabel": { "alias": "mobileDoneButtonLabel"; "required": false; }; "selectedDateText": { "alias": "selectedDateText"; "required": false; }; }, { "mobileDoneButtonClick": "mobileDoneButtonClick"; "inputValueChange": "inputValueChange"; "toggleCalendar": "toggleCalendar"; }, never, never, false, never>;
}

declare enum MaskType {
    PHONE = "PHONE",// (555) 555-5555
    INTERNATIONAL_PHONE = "INTERNATIONAL_PHONE",// +223 1234567890123 (NON-US), or +1 (555) 555-5555 (US)
    SSN = "SSN",// 123-45-6789
    EIN = "EIN",// 12-3456789
    NUMERIC = "NUMERIC",// 0-9, no length restrictions, can lead with 0
    NUMERIC_NINE = "NUMERIC_NINE",// 0-9, max length of 9, typically used by sensitive input
    EXPIRATION_DATE = "EXPIRATION_DATE",// MM/YYYY
    DATEPICKER = "DATEPICKER",// MM/DD/YYYY
    ZIP_CODE = "ZIP_CODE",// 12345-1234
    POSTAL_CODE = "POSTAL_CODE",// Depends on country
    YEAR = "YEAR",// YYYY
    STATE = "STATE",// VA, two upper case letters
    NUMBER = "NUMBER",// An actual number, can be positive only or allow negative values. Defaults to whole but can allow decimals.
    CUSTOM = "CUSTOM",// A custom combination based on provided Mask Options
    NONE = ""
}
declare class MaskResult {
    value: string;
    constructor(value?: string);
    countries: Country[];
}
declare class MaskOptions {
    country: Country;
    allowNegativeNumbers: boolean;
    decimalPlaces: number;
    allowAlpha: boolean;
    allowDigits: boolean;
    transformToUpperCase: boolean;
    get isDomestic(): boolean;
}

declare class DateInputComponent extends BaseFieldComponent<string> implements OnChanges {
    textService: TextService;
    protected controlContainer: ControlContainer;
    /**
    * If enabled, dates before today will be disabled.
    **/
    disablePastDates: boolean;
    /**
    * If enabled, dates after today will be disabled.
    **/
    disableFutureDates: boolean;
    /**
    * Type of date input field which defaults to expiration date.
    **/
    fieldType: DateInputFieldType;
    typeErrorMessage: string;
    maxLength: number;
    maskType: MaskType;
    readonly inputMode: string;
    inputPattern: string;
    placeholder: string;
    constructor(textService: TextService, controlContainer: ControlContainer);
    ngOnChanges(changes: SimpleChanges): void;
    private setFieldProps;
    writeValue(value: string): void;
    validate(control: AbstractControl): ValidationErrors | null;
    private getFullDateString;
    private getNowDate;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<DateInputComponent, [null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DateInputComponent, "ui-forms-date-input", never, { "disablePastDates": { "alias": "disablePastDates"; "required": false; }; "disableFutureDates": { "alias": "disableFutureDates"; "required": false; }; "fieldType": { "alias": "fieldType"; "required": false; }; }, {}, never, never, false, never>;
}

declare class DatepickerComponent extends BaseDropdownComponent<string> implements OnChanges {
    protected windowService: WindowService;
    textService: TextService;
    private changeDetector;
    private readonly dateProvider;
    protected controlContainer: ControlContainer;
    input: ElementRef;
    rightButton: ElementRef;
    /**
    * Icon to display on Action button
    **/
    actionButtonIcon: string;
    /**
    * Label of Action button
    **/
    actionButtonLabel: string;
    /**
    * Footer text describing the After date value (e.g. "Delivers by" date)
    **/
    afterDateText: string;
    /**
    * Boolean to allow today's date to be selected
    * Used in conjunction with 'disableFutureDates' or 'disablePastDates' to determine if today is selectable
    **/
    allowToday: boolean;
    /**
    * Number of days after hovered date to highlight (e.g. highlight "Delivers by" {x} days after)
    *   (only used if "daysPrior" is not defined)
    **/
    daysAfter: number;
    /**
    * Number of days prior to hovered date to highlight (e.g. highlight "Sends On" {x} days prior)
    **/
    daysPrior: number;
    /**
    * Allows only the first day of the month to be selected (e.g. - "First day of the month" ACH frequency)
    **/
    disableAllExceptFirstDayOfMonth: boolean;
    /**
    * Allows only the last day of the month to be selected (e.g. - "Last day of the month" ACH frequency)
    **/
    disableAllExceptLastDayOfMonth: boolean;
    /**
    * Allows only the last day of the month, or the 15th, to be selected (e.g. - "15th and end of month" ACH frequency)
    **/
    disableAllExceptFifteenthAndLastDay: boolean;
    /**
    * List of days of month to disable (numbered days, e.g. - [1, 15] will disable the 1st and 15th of each month)
    **/
    disabledDaysOfMonth: number[];
    /**
    * Footer text describing disabled dates
    **/
    disabledDaysText: string;
    /**
    * Allows only past dates to be selected (e.g. - birthdays)
    **/
    disableFutureDates: boolean;
    /**
    * Disable selection of any holidays provided in 'holidays[]' input
    **/
    disableHolidays: boolean;
    /**
    * Allows only future dates to be selected (e.g. - travel plans, scheduled payments)
    **/
    disablePastDates: boolean;
    /**
    * Allows only weekdays to be selected (e.g. - scheduled bill payments, transfers)
    **/
    disableWeekends: boolean;
    /**
    * Boolean to allow the calendar popup to be hidden
    **/
    hideCalendar: boolean;
    /**
    * Array of Holidays used to prevent selection or help calculate send-on/deliver-by dates
    **/
    holidays: Holiday[];
    /**
    * Non-interactive icon that displays to the left of the input
    **/
    iconLeft: string;
    /**
    * Date to show as marked in picker, and in footer text (e.g. - bill due date)
    **/
    markedDate: Date;
    /**
    * Footer text describing the marked date value (e.g. "eBill Due" date)
    **/
    markedDateText: string;
    /**
    * Maximum/latest allowed Date
    * Note: Date inputs should be initialized with DateProvider.getFIStartOfDay() to ensure consistent timezones & validation
    **/
    maxDate: Date;
    /**
     * Minimum/earliest allowed Date
     * Note: Date inputs should be initialized with DateProvider.getFIStartOfDay() to ensure consistent timezones & validation
     **/
    minDate: Date;
    /**
    * Label of mobile "done" button
    **/
    mobileDoneButtonLabel: string;
    /**
    * Input placeholder text (default is MM/DD/YYYY)
    **/
    placeholder: string;
    /**
    * Footer text describing the Prior date value (e.g. "Sends On" date)
    **/
    priorDateText: string;
    /**
    * Footer text describing the Selected date value
    * Selected date is used to calculate the daysAfter/daysPrior values on hover & after selection
    **/
    selectedDateText: string;
    /**
    * Event emitted by Action button
    **/
    actionButtonClick: EventEmitter<Event>;
    menuState: any;
    ariaLabel: string;
    markedDateStruct: NgbDateStruct;
    maxDateStruct: NgbDateStruct;
    maxDateValue: Date;
    maxLength: number;
    minDateStruct: NgbDateStruct;
    minDateValue: Date;
    mobilePicker: boolean;
    placeHolderText: string;
    private todayDate;
    private tomorrowDate;
    dateErrorMessage: string;
    maskType: MaskType;
    get hasValue(): boolean;
    constructor(windowService: WindowService, textService: TextService, changeDetector: ChangeDetectorRef, ngZone: NgZone, dateProvider: DateProvider, controlContainer: ControlContainer);
    ngOnChanges(): void;
    writeValue(value: any): void;
    validate(control: AbstractControl): ValidationErrors | null;
    onComboboxClick(): void;
    open(): void;
    close(markAsTouched: boolean): void;
    toggleDefaultCalDropdown(): void;
    onActionButtonClick(event: any): void;
    closePickerFocus(): void;
    onInputBlur(): void;
    onButtonBlur(): void;
    onKeyDown(event: KeyboardEvent): void;
    private initDateValues;
    private getMaxDate;
    private getMinDate;
    private setAriaLabel;
    private normalizeDateTime;
    protected getDefaultText(): any;
    protected onTextUpdate(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DatepickerComponent, [null, null, null, null, null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DatepickerComponent, "ui-forms-datepicker", never, { "actionButtonIcon": { "alias": "actionButtonIcon"; "required": false; }; "actionButtonLabel": { "alias": "actionButtonLabel"; "required": false; }; "afterDateText": { "alias": "afterDateText"; "required": false; }; "allowToday": { "alias": "allowToday"; "required": false; }; "daysAfter": { "alias": "daysAfter"; "required": false; }; "daysPrior": { "alias": "daysPrior"; "required": false; }; "disableAllExceptFirstDayOfMonth": { "alias": "disableAllExceptFirstDayOfMonth"; "required": false; }; "disableAllExceptLastDayOfMonth": { "alias": "disableAllExceptLastDayOfMonth"; "required": false; }; "disableAllExceptFifteenthAndLastDay": { "alias": "disableAllExceptFifteenthAndLastDay"; "required": false; }; "disabledDaysOfMonth": { "alias": "disabledDaysOfMonth"; "required": false; }; "disabledDaysText": { "alias": "disabledDaysText"; "required": false; }; "disableFutureDates": { "alias": "disableFutureDates"; "required": false; }; "disableHolidays": { "alias": "disableHolidays"; "required": false; }; "disablePastDates": { "alias": "disablePastDates"; "required": false; }; "disableWeekends": { "alias": "disableWeekends"; "required": false; }; "hideCalendar": { "alias": "hideCalendar"; "required": false; }; "holidays": { "alias": "holidays"; "required": false; }; "iconLeft": { "alias": "iconLeft"; "required": false; }; "markedDate": { "alias": "markedDate"; "required": false; }; "markedDateText": { "alias": "markedDateText"; "required": false; }; "maxDate": { "alias": "maxDate"; "required": false; }; "minDate": { "alias": "minDate"; "required": false; }; "mobileDoneButtonLabel": { "alias": "mobileDoneButtonLabel"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "priorDateText": { "alias": "priorDateText"; "required": false; }; "selectedDateText": { "alias": "selectedDateText"; "required": false; }; }, { "actionButtonClick": "actionButtonClick"; }, never, never, false, never>;
}

declare class DateRangeComponent extends BaseStandaloneDropdownComponent<string[]> implements OnChanges {
    protected windowService: WindowService;
    textService: TextService;
    private changeDetector;
    private readonly dateProvider;
    combobox: ElementRef;
    /**
    * Set the value externally.
    **/
    value: string[];
    /**
    * Boolean to allow today's date to be selected
    **/
    allowToday: boolean;
    /**
    * The max width of the toggle in pixels. The menu will always be this width, but the toggle may be smaller.
    **/
    desktopMaxWidth: number;
    /**
    * Allows only past dates to be selected (e.g. - birthdays)
    **/
    disableFutureDates: boolean;
    /**
    * Allows only future dates to be selected (e.g. - travel plans, scheduled payments)
    **/
    disablePastDates: boolean;
    /**
    * Visual presentation of content within the toggle
    *  - 'selection' shows the label and selected option. Toggle width may change and cause layout shifting.
    *  - 'label' shows the label only. Toggle width is fixed.
    *  - 'icon' shows iconLeft only. If iconLeft is not configured, defaults to vertical dots. Toggle width is fixed.
    **/
    display: 'selection' | 'label' | 'icon';
    /**
    * Non-interactive icon that displays to the left of the input
    **/
    iconLeft: string;
    /**
    * Maximum/latest allowed Date
    **/
    maxDate: Date;
    /**
     * Minimum/earliest allowed Date
     **/
    minDate: Date;
    /**
    * Label of mobile "done" button
    **/
    mobileDoneButtonLabel: string;
    /**
    * Input placeholder text (default is MM/DD/YYYY)
    **/
    placeholder: string;
    /**
    * Changes the colors of the dropdown toggle.
    **/
    theme: 'primary' | 'white';
    /**
    * ARIA Described-by content to add to picker button label
    * Used to give more context to the input for screen-readers
    **/
    ariaDescription: string;
    dateErrorMessage: string;
    endValue: string;
    iconOnly: boolean;
    maxDateStruct: NgbDateStruct;
    maxDateValue: Date;
    maxLength: number;
    menuState: any;
    minDateStruct: NgbDateStruct;
    minDateValue: Date;
    selectedRange: string;
    startValue: string;
    startDateStruct: NgbDateStruct;
    private todayDate;
    private tomorrowDate;
    maskType: MaskType;
    get hasValue(): boolean;
    constructor(windowService: WindowService, textService: TextService, changeDetector: ChangeDetectorRef, dateProvider: DateProvider);
    ngOnChanges(changes: SimpleChanges): void;
    setValue(value: any): void;
    private setDependentDateValues;
    toggleDefaultCalDropdown(force?: boolean): void;
    open(): void;
    close(): void;
    private getMaxDate;
    private getMinDate;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<DateRangeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DateRangeComponent, "ui-forms-date-range", never, { "value": { "alias": "value"; "required": false; }; "allowToday": { "alias": "allowToday"; "required": false; }; "desktopMaxWidth": { "alias": "desktopMaxWidth"; "required": false; }; "disableFutureDates": { "alias": "disableFutureDates"; "required": false; }; "disablePastDates": { "alias": "disablePastDates"; "required": false; }; "display": { "alias": "display"; "required": false; }; "iconLeft": { "alias": "iconLeft"; "required": false; }; "maxDate": { "alias": "maxDate"; "required": false; }; "minDate": { "alias": "minDate"; "required": false; }; "mobileDoneButtonLabel": { "alias": "mobileDoneButtonLabel"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "ariaDescription": { "alias": "ariaDescription"; "required": false; }; }, {}, never, never, false, never>;
}

declare class FileInputComponent extends BaseArrayFieldComponent<UploadedFile[]> implements OnChanges, AfterViewInit {
    textService: TextService;
    private windowService;
    private ngZone;
    private element;
    private changeDetector;
    protected controlContainer: ControlContainer;
    overflowHidden: boolean;
    buttonRaised: boolean;
    fileUploadInput: ElementRef;
    inputButton: ElementRef;
    inputBox: ElementRef;
    /**
    * Visual presentation of input
    *  - 'button' is a small button input (default)
    *  - 'dropbox' is a larger block element with drag-n-drop upload support
    *  - 'capture' is a larger button capable of triggering native device image capturing
    **/
    display: 'button' | 'dropbox' | 'capture';
    /**
    * Type of file expected (determines icons, text, and allowedFileTypes)
    **/
    fileType: 'image' | 'file';
    /**
    * Array of file types/extensions allowed to be uploaded
    * (over-rides types assumed by `fileType` Input)
    **/
    allowedFileTypes: FileType[];
    /**
    * Boolean to determine if multiple files can be input at once
    **/
    allowMultiple: boolean;
    /**
    * Icon that renders differently per display mode:
    * - 'button': to the left of the button
    * - 'dropbox': in center of upload dropbox
    * - 'capture': in center of the button
    **/
    icon: string;
    /**
    * Height of expected image, in pixels.
    *  Used to set size of image dropbox for previewing image in proper dimensions, both imageHeight & imageWidth need to be set
    *  (dropbox will be resized to maintain aspect ratio if full width/height isn't available in the page)
    **/
    imageHeight: number;
    /**
    * Width of expected image, in pixels.
    *  Used to set size of image dropbox for previewing image in proper dimensions, both imageHeight & imageWidth need to be set
    *  (dropbox will be resized to maintain aspect ratio if full width/height isn't available in the page)
    **/
    imageWidth: number;
    /**
    * Text of button (used in 'button' display and 'capture' display)
    **/
    buttonText: string;
    /**
    * Number (in MBs) of maximum allowed file size
    **/
    maxSizeMbs: number;
    /**
    * Number of files allowed at once in allowMultiple mode - default value of 0 means: no maximum
    **/
    maxFileCount: number;
    /**
    * Options to pass to the resizing utils
    * We often want to resize unnecessarily large images for performance/storage, but the recommended size will vary
    * Expects a ResizeOptions object containing maxHeight and/or maxWidth
    **/
    resizeOptions: ResizeOptions;
    /**
    * Boolean to encode all uploaded files as base64, regardless of file type
    **/
    encodeBase64: boolean;
    /**
    * Boolean to show spinner
    *  (indicate loading/processing status)
    **/
    showSpinner: boolean;
    /**
    * Boolean to show a generated info message.
    * If infoMessage is provided, or display is set to 'capture', the generated message will not be shown.
    **/
    showFileInfoMessage: boolean;
    /**
    * Boolean to show a button with only an icon instead of a full button with message when removing an image.
    * For dropbox only.
    **/
    showRemoveImageIconButton: boolean;
    /**
    * Event emitted by file input
    **/
    fileLoaded: EventEmitter<UploadedFile>;
    /**
    * Event emitted when user initiates an upload in 'capture' mode.
    * Only emitted on native mobile apps.
    **/
    nativeCaptureClicked: EventEmitter<void>;
    allowUpload: boolean;
    iconValue: string;
    dragOver: boolean;
    fileErrorMessage: string;
    fileInfoMessage: string;
    fileName: string;
    fileWarningMessage: string;
    imagePreview: string;
    hasImagePreview: boolean;
    imageAspectRatioStyle: string;
    isMobile: boolean;
    isSingleImage: boolean;
    loading: boolean;
    uploadedFiles: UploadedFile[];
    private isCapture;
    get isLocked(): boolean;
    get isLoading(): boolean;
    constructor(textService: TextService, windowService: WindowService, ngZone: NgZone, element: ElementRef, changeDetector: ChangeDetectorRef, controlContainer: ControlContainer);
    onResize(): void;
    ngOnChanges(): void;
    ngAfterViewInit(): void;
    writeValue(value: UploadedFile[]): void;
    validate(control: AbstractControl): ValidationErrors | null;
    onFileInput(event: any): void;
    promptForFile(event?: Event): void;
    removeFile(file?: UploadedFile): void;
    private handleDragEvent;
    private handleFileInput;
    private handleFile;
    private emitFile;
    private isFileAllowed;
    private isFileSizeAllowed;
    private isFileLengthAllowed;
    private setFileMessage;
    private setAllowedTypes;
    private getAllowedExtensionsText;
    private setDisplayModeFlags;
    private setFieldIcon;
    private hasImageSize;
    private setImagePreview;
    private allowPreview;
    private adjustImageSize;
    private processFileValue;
    private checkFileCount;
    private setInputStyles;
    private setFileInfoMessage;
    onDragOver(evt: any): void;
    onDragLeave(evt: any): void;
    onDrop(evt: any): void;
    captureButtonClicked(): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileInputComponent, [null, null, null, null, null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FileInputComponent, "ui-forms-file-input", never, { "display": { "alias": "display"; "required": false; }; "fileType": { "alias": "fileType"; "required": false; }; "allowedFileTypes": { "alias": "allowedFileTypes"; "required": false; }; "allowMultiple": { "alias": "allowMultiple"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "imageHeight": { "alias": "imageHeight"; "required": false; }; "imageWidth": { "alias": "imageWidth"; "required": false; }; "buttonText": { "alias": "buttonText"; "required": false; }; "maxSizeMbs": { "alias": "maxSizeMbs"; "required": false; }; "maxFileCount": { "alias": "maxFileCount"; "required": false; }; "resizeOptions": { "alias": "resizeOptions"; "required": false; }; "encodeBase64": { "alias": "encodeBase64"; "required": false; }; "showSpinner": { "alias": "showSpinner"; "required": false; }; "showFileInfoMessage": { "alias": "showFileInfoMessage"; "required": false; }; "showRemoveImageIconButton": { "alias": "showRemoveImageIconButton"; "required": false; }; }, { "fileLoaded": "fileLoaded"; "nativeCaptureClicked": "nativeCaptureClicked"; }, never, never, false, never>;
}

declare class ListItemHeader {
    headerText: string;
    visible: boolean;
    constructor(headerText: string, visible: boolean);
}

declare class CheckboxListComponent<T extends string[] | number[]> extends BaseArrayFieldComponent<T> implements OnChanges {
    textService: TextService;
    protected controlContainer: ControlContainer;
    /**
    * All options to present.
    * Note: if more than 200 options are provided, the component will turn on card mode with search.
    **/
    options: CheckboxListOption[];
    /**
    * Visual presentation of checkboxes
    * - 'list' shows a plain list of checkboxes
    * - 'card' shows a rounded container of checkboxes, with header, borders, & supporting scroll/search
    * - 'grid' shows a two colummn grid. The select all checkbox is not available in this display mode.
    **/
    display: 'list' | 'card' | 'grid';
    /**
    * If enabled, shows a select all checkbox at the top of the list. (not available in 'grid' display mode)
    **/
    showSelectAll: boolean;
    /**
    * If showSelectAll is enabled, these lines of text will display beneath the label.
    **/
    selectAllSubtextLines: string[];
    /**
    * Label that defaults to "Select All" unless overidden
    **/
    selectAllLabel: string;
    /**
    * Text to display in the Select All tooltip popover
    **/
    selectAllTooltip: string;
    /**
    * If enabled, shows a search input when the checkbox list contains more than 15 items & display is 'card'
    **/
    showSearch: boolean;
    /**
    * If enabled, shows a header above groups of options when those options have headerStaticText & display is 'card'
    **/
    showGroupHeaders: boolean;
    /**
    * If enabled, the list initially displays collapsed. Only applies when display is 'card'. Defaults to false.
    **/
    collapsedByDefault: boolean;
    /**
    * Emits the new collapsed state whenever the user toggles a 'card' display's collapsed header.
    **/
    collapsedChange: EventEmitter<boolean>;
    isList: boolean;
    isCard: boolean;
    isGrid: boolean;
    isNested: boolean;
    listItemClasses: string;
    collapsed: boolean;
    collapsableButtonClass: string;
    listItemHeaders: ListItemHeader[];
    showScroll: boolean;
    showSearchField: boolean;
    selectedCountText: string;
    uid: string;
    private collapsableButtonClassDefault;
    private initialCollapsedStateApplied;
    private selectedCount;
    private totalCount;
    private selectedLockedCount;
    showSearchNotification: boolean;
    multiSelectState: MultiSelectState<T>;
    visibleOptions: CheckboxListOption[];
    HtmlAttributeStateEnum: typeof HtmlAttributeState;
    private enabledOptions;
    constructor(textService: TextService, controlContainer: ControlContainer);
    ngOnChanges(changes: SimpleChanges): void;
    writeValue(value: T): void;
    toggleCollapsed(): void;
    selectAll(checked: boolean): void;
    onCheckboxChange(option: CheckboxListOption, checked: boolean): void;
    doSearch(searchTerm: string): void;
    private setVisibleOptions;
    private updateValue;
    private setListDisplay;
    private updateCardState;
    private populateListItemHeaders;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckboxListComponent<any>, [null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckboxListComponent<any>, "ui-forms-checkbox-list", never, { "options": { "alias": "options"; "required": false; }; "display": { "alias": "display"; "required": false; }; "showSelectAll": { "alias": "showSelectAll"; "required": false; }; "selectAllSubtextLines": { "alias": "selectAllSubtextLines"; "required": false; }; "selectAllLabel": { "alias": "selectAllLabel"; "required": false; }; "selectAllTooltip": { "alias": "selectAllTooltip"; "required": false; }; "showSearch": { "alias": "showSearch"; "required": false; }; "showGroupHeaders": { "alias": "showGroupHeaders"; "required": false; }; "collapsedByDefault": { "alias": "collapsedByDefault"; "required": false; }; }, { "collapsedChange": "collapsedChange"; }, never, never, false, never>;
}

declare enum FormModalButtonType {
    PRIMARY = "PRIMARY",
    SECONDARY = "SECONDARY",
    TERTIARY = "TERTIARY",
    CLOSE = "CLOSE"
}
declare class FormModalClickEvent {
    buttonType: FormModalButtonType;
    form: FormGroup | null;
    constructor(buttonType?: FormModalButtonType, form?: FormGroup | null);
}

declare class FormModalComponent extends BaseTextComponent {
    private modalService;
    protected textService: TextService;
    PRIMARY: FormModalButtonType;
    SECONDARY: FormModalButtonType;
    TERTIARY: FormModalButtonType;
    formModal: TemplateRef<any>;
    private formRenderer;
    private unsavedChangesModal;
    /**
    * Required modal title.
    **/
    title: string;
    /**
    * Optional primary button text. Default is "Submit"
    **/
    primaryButtonText: string;
    /**
    * Optional primary button disabled text. Default is "Submitting..."
    **/
    primaryButtonDisabledText: string;
    /**
    * Whether or not the primary button should dismiss all modals.
    **/
    primaryButtonDismissesAllModals: boolean;
    /**
    * Optional secondary button text. Default is "Cancel"
    **/
    secondaryButtonText: string;
    /**
    * The text of the tertiary button.
    **/
    tertiaryButtonText: string;
    /**
    * The icon of the tertiary button.
    **/
    tertiaryButtonIcon: string;
    /**
    * Will show a normal modal when false, and an enhanced modal when true. Default is false.
    **/
    useEnhancedModal: boolean;
    /**
    * When true, will automatically dismiss modal after the primary button click. Default is true.
    * When false, it will emit the event but keep the modal open. This is intended for uses when we
    * want the modal to remain open if an api call returns an error. In these cases, we need to close the
    * modal manually in our click event handler.
    **/
    closeAfterSubmitting: boolean;
    /**
    * E2E testing - this value is used to generate e2e hooks across this component.
    **/
    e2e: string;
    /**
    * Set to true to prevent the modal from closing when the scrim (backdrop) is clicked or when
    * the ESC key is pressed. The modal can only be dismissed via its close (X), cancel, or submit
    * buttons, or programmatically (e.g. modalService.dismissAll()).
    *
    * Use this for modals where closing mid-flow is not allowed (e.g. a required step that must complete).
    * For warning about unsaved form changes, use confirmUnsavedChanges instead.
    * Avoid setting both lockScrim and confirmUnsavedChanges to true — they have overlapping but
    * subtly different behavior and are not designed to be used together.
    **/
    lockScrim: boolean;
    /**
    * Set to true to show an unsaved changes confirmation when the user attempts to close the modal
    * via the close (X) button, scrim click, ESC key, or cancel button, and the form is dirty.
    * If the form has not been modified, the modal closes normally without a confirmation.
    *
    * Use this for form modals where the user could lose unsaved work.
    * For modals where closing mid-flow must be completely prevented, use lockScrim instead.
    * Avoid setting both confirmUnsavedChanges and lockScrim to true — they are not designed to be used together.
    **/
    confirmUnsavedChanges: boolean;
    readonly checkUnsavedChangesHandler: any;
    /**
    * Emits when free form input components are changed.
    * Such as text inputs, number inputs, etc.
    **/
    inputChange: EventEmitter<FormRendererInputEvent>;
    /**
    * Emits when objects are selected from components that provide finite selectable options.
    * Such as dropdowns, radio buttons, checkboxes, day picker, datepicker, etc.
    **/
    selection: EventEmitter<FormRendererSelectionEvent>;
    /**
    * Emits when categorized groups are added, removed, initialized or visibility changes.
    **/
    groupCategoryChange: EventEmitter<FormRendererGroupCategoryEvent>;
    /**
    * Emits when Confirm, Cancel, or close buttons are clicked. Includes form value when there is one.
    **/
    clicked: EventEmitter<FormModalClickEvent>;
    private modalIntentionallyClosed;
    submitButtonText: string;
    submitButtonDisabledText: string;
    cancelButtonText: string;
    formattedRows: FormRendererRow[];
    constructor(modalService: ModalService, textService: TextService);
    show(formRows: FormRendererRow[]): void;
    private makeFieldsFullWidth;
    onFormSelection(event: FormRendererSelectionEvent): void;
    onFormInputChange(event: FormRendererInputEvent): void;
    onFormGroupCategoryChange(event: FormRendererGroupCategoryEvent): void;
    onButtonClick(buttonType: FormModalButtonType, form?: FormGroup): Promise<void>;
    private checkUnsavedChanges;
    modalClosed(): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormModalComponent, "ui-forms-modal", never, { "title": { "alias": "title"; "required": false; }; "primaryButtonText": { "alias": "primaryButtonText"; "required": false; }; "primaryButtonDisabledText": { "alias": "primaryButtonDisabledText"; "required": false; }; "primaryButtonDismissesAllModals": { "alias": "primaryButtonDismissesAllModals"; "required": false; }; "secondaryButtonText": { "alias": "secondaryButtonText"; "required": false; }; "tertiaryButtonText": { "alias": "tertiaryButtonText"; "required": false; }; "tertiaryButtonIcon": { "alias": "tertiaryButtonIcon"; "required": false; }; "useEnhancedModal": { "alias": "useEnhancedModal"; "required": false; }; "closeAfterSubmitting": { "alias": "closeAfterSubmitting"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; "lockScrim": { "alias": "lockScrim"; "required": false; }; "confirmUnsavedChanges": { "alias": "confirmUnsavedChanges"; "required": false; }; }, { "inputChange": "inputChange"; "selection": "selection"; "groupCategoryChange": "groupCategoryChange"; "clicked": "clicked"; }, never, never, false, never>;
}

declare class AmountInputComponent extends BaseFieldComponent<number> {
    protected controlContainer: ControlContainer;
    private ngZone;
    textService: TextService;
    private windowService;
    input: ElementRef;
    /**
    * The number of decimal places to show.
    **/
    set decimalPlaces(value: number);
    get decimalPlaces(): number;
    private _decimalPlaces;
    /**
    * The minimum number allowed.
    **/
    min: number;
    /**
    * Hide the left currency icon
    **/
    hideIcon: boolean;
    /**
     * Allow styling for empty field state. Only used for Amount Range Component.
    **/
    allowEmptyField: boolean;
    private currentUiState;
    private invalidRegEx;
    private numberKeys;
    private validKeys;
    formattedValue: string;
    ghostText: string;
    isMobile: boolean;
    protected maskedSpecialKeys: string[];
    protected ctrlKeysAllowed: string[];
    protected cmdKeysAllowed: string[];
    get decimalFormat(): string;
    get hasValue(): boolean;
    constructor(controlContainer: ControlContainer, ngZone: NgZone, textService: TextService, windowService: WindowService);
    writeValue(value: any): void;
    private rollBackNativeElement;
    private updateDisplay;
    onDesktopKeyDown(event: KeyboardEvent): void;
    onDesktopInput(event: Event | any): void;
    handleMouseup(event: MouseEvent): void;
    handlePaste(event: ClipboardEvent): void;
    onMobileKeyDown(event: KeyboardEvent): void;
    onMobileInput(event: Event | any): void;
    private handleMobileDigitKey;
    private handleMobileBackspace;
    private getValueAsNumber;
    private getValueAsWholeNumber;
    private convertNumberStringToDecimalNumber;
    private isReferringFiniteNumber;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<AmountInputComponent, [{ optional: true; }, null, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AmountInputComponent, "ui-forms-amount-input", never, { "decimalPlaces": { "alias": "decimalPlaces"; "required": false; }; "min": { "alias": "min"; "required": false; }; "hideIcon": { "alias": "hideIcon"; "required": false; }; "allowEmptyField": { "alias": "allowEmptyField"; "required": false; }; }, {}, never, ["*"], false, never>;
}

declare enum NUMBER_INPUT_STATE {
    INVALID = "INVALID",
    PENDING = "PENDING",
    VALID = "VALID",
    VALID_NEEDS_UPDATE = "VALID_NEEDS_UPDATE"
}
declare class MaskDirective implements OnChanges {
    private readonly input;
    uiFormsMask: MaskType;
    unmaskedValue: string | number;
    maskIsTypeahead: boolean;
    maskOptions: MaskOptions;
    numberInputState: EventEmitter<NUMBER_INPUT_STATE>;
    maskResult: MaskResult;
    private inputElement;
    private inputHasFocus;
    private lastValidCharTyped;
    constructor(input: ElementRef);
    onKeyDown(event: KeyboardEvent): void;
    onFocus(): void;
    onBlur(): void;
    onInput(): void;
    ngOnChanges(changes: SimpleChanges): void;
    private maskInputValue;
    private isInvalidNumberState;
    private isPendingNumberState;
    private maskFormValue;
    private getUnmaskedValueAsString;
    static ɵfac: i0.ɵɵFactoryDeclaration<MaskDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MaskDirective, "[uiFormsMask]", never, { "uiFormsMask": { "alias": "uiFormsMask"; "required": false; }; "unmaskedValue": { "alias": "unmaskedValue"; "required": false; }; "maskIsTypeahead": { "alias": "maskIsTypeahead"; "required": false; }; "maskOptions": { "alias": "maskOptions"; "required": false; }; }, { "numberInputState": "numberInputState"; }, never, never, false, never>;
}

declare class NumberInputComponent extends BaseDropdownComponent<number> implements OnChanges {
    private changeDetector;
    protected controlContainer: ControlContainer;
    input: ElementRef;
    rightButton: ElementRef;
    /**
    * The minimum number allowed. If below zero, negative numbers will be allowed.
    **/
    min: number;
    /**
    * The maximum number allowed.
    **/
    max: number;
    /**
    * Boolean to show day-of-month picker
    **/
    dayOfMonthPicker: boolean;
    /**
    * Number array of days of month to disable in the picker ([1, 15] will disable the 1st and 15th)
    **/
    disabledPickerDays: number[];
    /**
    * Number of day to indicate as marked in picker, and in footer text
    **/
    markedDay: number;
    /**
    * Text to label marked date in footer (i.e. - First Payment Day)
    **/
    markedDayLabel: string;
    /**
    * Text to label currently selected date in footer
    **/
    selectedDayLabel: string;
    /**
    * Footer text describing disabled dates
    **/
    disabledDaysText: string;
    /**
    * The number of decimal places to show.
    * The max is 10, values above this will be treated as 10.
    **/
    decimalPlaces: number;
    readonly maskType = MaskType.NUMBER;
    maskOptions: MaskOptions;
    ariaLabel: string;
    menuState: BaseFormMenuState;
    actualMin: number;
    actualMax: number;
    actualErrorMessage: string;
    inputPattern: string;
    inputMode: string;
    inputStep: number;
    maskableValue: string;
    private maskState;
    constructor(windowService: WindowService, textService: TextService, ngZone: NgZone, changeDetector: ChangeDetectorRef, controlContainer: ControlContainer);
    ngOnChanges(changes: SimpleChanges): void;
    writeValue(value: any): void;
    private get allowDecimals();
    private setFlagsAndMaskOptions;
    writeCalendarValue(value: any): void;
    get hasValue(): boolean;
    handleMaskState(state: NUMBER_INPUT_STATE): void;
    validate(control: AbstractControl): ValidationErrors | null;
    toggleDefaultCalDropdown(): void;
    onComboboxClick(): void;
    closeKeyDown(event: KeyboardEvent): void;
    open(): void;
    close(markAsTouched: boolean): void;
    private setAriaLabel;
    onInputBlur(): void;
    onButtonBlur(): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<NumberInputComponent, [null, null, null, null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NumberInputComponent, "ui-forms-number-input", never, { "min": { "alias": "min"; "required": false; }; "max": { "alias": "max"; "required": false; }; "dayOfMonthPicker": { "alias": "dayOfMonthPicker"; "required": false; }; "disabledPickerDays": { "alias": "disabledPickerDays"; "required": false; }; "markedDay": { "alias": "markedDay"; "required": false; }; "markedDayLabel": { "alias": "markedDayLabel"; "required": false; }; "selectedDayLabel": { "alias": "selectedDayLabel"; "required": false; }; "disabledDaysText": { "alias": "disabledDaysText"; "required": false; }; "decimalPlaces": { "alias": "decimalPlaces"; "required": false; }; }, {}, never, never, false, never>;
}

declare class RadioButtonsComponent<T extends string | number> extends BaseFieldComponent<T> {
    protected controlContainer: ControlContainer;
    /**
    * Required. The radio button options.
    * Each option must specify the "label" and "value" properties.
    * Optional properties: "checked" (boolean) field, and "subtextLines" (string array).
    **/
    options: RadioButtonOption[];
    /**
    * Boolean to toggle display of radio buttons in a vertical column.
    * On mobile, it is vertical by default.
    **/
    vertical: boolean;
    optionAriaLabels: string[];
    constructor(textService: TextService, controlContainer: ControlContainer);
    ngOnInit(): void;
    onBlur(): void;
    selectOption(event: any, option: RadioButtonOption): void;
    writeValue(value: any): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<RadioButtonsComponent<any>, [null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RadioButtonsComponent<any>, "ui-forms-radio-buttons", never, { "options": { "alias": "options"; "required": false; }; "vertical": { "alias": "vertical"; "required": false; }; }, {}, never, never, false, never>;
}

declare class RadioButtonOptionComponent {
    /**
    * The label to show next to the radio button
    **/
    label: string;
    /**
    * Required. Value of the radio button
    **/
    value: string | number;
    /**
    * Name of the radio button element. Could be formControlName or fieldId
    **/
    name: string;
    /**
    * The ID of the radio button.
    **/
    id: string;
    /**
    * Boolean that specifies whether the field is checked.
    **/
    checked: boolean;
    /**
    * Boolean to toggle disabled style for radio button
    **/
    locked: boolean;
    /**
    * Boolean. When true, lays out the label with a trailing content slot (the projected ng-content)
    * on the far side of the label, wrapping below when space is tight. Defaults to false for the
    * standard layout.
    **/
    hasTrailingContent: boolean;
    /**
    * Class(es) to apply to the label.
    **/
    labelClasses: string;
    /**
    * Boolean is true if first radio button in group. For data-form-focus.
    **/
    isFirst: boolean;
    /**
    * Show the option in the hover state.
    **/
    showHover: boolean;
    /**
    * Content to display in the tooltip popover
    **/
    tooltip: string;
    /**
    * Allow focus of label & inner input element, necessary for accessibility.
    **/
    hasInput: boolean;
    /**
    * E2E testing - data-e2e attribute attached to radio button
    **/
    e2e: string;
    /**
    * ARIA Label attribute (aria-label)
    * Used to replace the button message with more descriptive text, screen-readers will read the ariaLabel, instead of message
    **/
    ariaLabel: string;
    /**
    * ARIA Described By attribute (aria-describedby)
    * Used to link additional information to the radio button
    **/
    ariaDescribedBy: string;
    /**
    * The description text to show under the label.
    **/
    description: string;
    /**
    *  Emitted when the radio button is selected.
    **/
    selection: EventEmitter<any>;
    /**
    *  Emitted on blur event.
    **/
    blurred: EventEmitter<void>;
    onBlur(): void;
    onSelection(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RadioButtonOptionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RadioButtonOptionComponent, "ui-forms-radio-button-option", never, { "label": { "alias": "label"; "required": false; }; "value": { "alias": "value"; "required": false; }; "name": { "alias": "name"; "required": false; }; "id": { "alias": "id"; "required": false; }; "checked": { "alias": "checked"; "required": false; }; "locked": { "alias": "locked"; "required": false; }; "hasTrailingContent": { "alias": "hasTrailingContent"; "required": false; }; "labelClasses": { "alias": "labelClasses"; "required": false; }; "isFirst": { "alias": "isFirst"; "required": false; }; "showHover": { "alias": "showHover"; "required": false; }; "tooltip": { "alias": "tooltip"; "required": false; }; "hasInput": { "alias": "hasInput"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "ariaDescribedBy": { "alias": "ariaDescribedBy"; "required": false; }; "description": { "alias": "description"; "required": false; }; }, { "selection": "selection"; "blurred": "blurred"; }, never, ["*"], false, never>;
}

declare class SliderComponent extends BaseFieldComponent<number> implements Validator, OnChanges, OnInit {
    protected controlContainer: ControlContainer;
    /**
    * The minimum value the slider can be dragged to.
    **/
    min: number;
    /**
    * The maximum value the slider can be dragged to.
    **/
    max: number;
    /**
    * The granularity that the thumb control will traverse the track with.
    * Use the special value 'any' for a continuous (smooth) slider with no stepping constraint.
    **/
    step: number | 'any';
    /**
    * Controls the display of the value bubble above the thumb on hover/focus/drag. Default is false.
    **/
    showThumbBubble: boolean;
    /**
    * Controls the display of the current value on the right side of the header. Default is false.
    * If `showAmountInput` is true, the header value will not be visible.
    **/
    showValueInHeader: boolean;
    /**
    * Formats a raw numeric value into the string shown in the header value, thumb bubble, and range labels.
    * Defaults to a plain number. Pass a formatter to display e.g. currency: (v) => NumberUtils.formatCurrency(v).
    **/
    formatValue: (value: number) => string;
    /**
    * Controls the display of an editable amount input above the track. Default is true.
    * Its display is formatted with `formatValue` (so the input, thumb bubble, header, and labels all match).
    * When the amount input is displayed, it replaces the header value (`showValueInHeader`).
    **/
    showAmountInput: boolean;
    private amountInput;
    isAmountInputFocused: boolean;
    private amountEditBuffer;
    private onValidatorChange;
    private lastNumericValue;
    constructor(textService: TextService, controlContainer: ControlContainer);
    ngOnInit(): void;
    /**
    * The current value as a percentage (0-100) of the min/max range.
    * Used to position the visual fill and thumb over the native input.
    **/
    get percent(): number;
    /**
    * The current value formatted for display in the header and thumb bubble.
    **/
    get displayValue(): string;
    /**
    * The text shown in the amount input: the live edit buffer while focused, the formatted value otherwise.
    * The buffer is held constant during typing so the cursor stays put; the typed text is read on blur.
    **/
    get amountInputDisplay(): string;
    onAmountInputFocus(): void;
    private toEditableAmount;
    onAmountInputBlur(text: string): void;
    private parseAmount;
    onInput(value: string): void;
    writeValue(value: number | null): void;
    onBlur(): void;
    ngOnChanges(changes: SimpleChanges): void;
    validate(control: AbstractControl): ValidationErrors | null;
    registerOnValidatorChange(fn: () => void): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<SliderComponent, [null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SliderComponent, "ui-forms-slider", never, { "min": { "alias": "min"; "required": false; }; "max": { "alias": "max"; "required": false; }; "step": { "alias": "step"; "required": false; }; "showThumbBubble": { "alias": "showThumbBubble"; "required": false; }; "showValueInHeader": { "alias": "showValueInHeader"; "required": false; }; "formatValue": { "alias": "formatValue"; "required": false; }; "showAmountInput": { "alias": "showAmountInput"; "required": false; }; }, {}, never, never, false, never>;
}

declare enum PasswordType {
    PASSWORD = "password",
    TEXT = "text"
}

declare enum PasswordStrength {
    STRONG = 100,
    MEDIUM = 60,
    WEAK = 10,
    NONE = 0
}

declare class PasswordInputComponent extends BaseFieldComponent<string> implements OnInit, OnChanges {
    protected controlContainer: ControlContainer;
    class: boolean;
    /**
    * Number to enforce maximum length of allowed input
    **/
    maxLength: number;
    /**
    * LEGACY: Array of Regular Expressions to test whether a password is considered valid
    **/
    passwordRequirement: RegExp[];
    /**
    * Array of Validation Criteria to test whether the form value is considered valid.
    **/
    criteria: ValidationCriteria[];
    /**
    * Message that displays above the rendered Validation Criteria.
    **/
    criteriaDescription: string;
    /**
    * Array of Regular Expressions to test whether a password is considered "Medium" strength
    **/
    passwordStrengthMedium: RegExp[];
    /**
    * Array of Regular Expressions to test whether a password is considered "Strong" strength
    **/
    passwordStrengthStrong: RegExp[];
    PasswordType: typeof PasswordType;
    passwordType: PasswordType;
    iconRight: string;
    strengthInfoMessage: string;
    strengthWarningMessage: string;
    strengthSuccessMessage: string;
    showPasswordStrength: boolean;
    passwordStrength: PasswordStrength;
    passwordStrengthClass: string;
    passwordStrengthDescription: string;
    constructor(textService: TextService, controlContainer: ControlContainer);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    private get legacyUI();
    private evaluateCriteria;
    onBlur(): void;
    validate(control: AbstractControl): ValidationErrors | null;
    writeValue(value: string): void;
    toggleVisibility(): void;
    private setIconRight;
    private evaluatePasswordStrength;
    private checkPasswordStrengthComponent;
    private checkPasswordStrength;
    private buildPasswordStrengthMessage;
    private getPasswordStrength;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<PasswordInputComponent, [null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PasswordInputComponent, "ui-forms-password-input", never, { "maxLength": { "alias": "maxLength"; "required": false; }; "passwordRequirement": { "alias": "passwordRequirement"; "required": false; }; "criteria": { "alias": "criteria"; "required": false; }; "criteriaDescription": { "alias": "criteriaDescription"; "required": false; }; "passwordStrengthMedium": { "alias": "passwordStrengthMedium"; "required": false; }; "passwordStrengthStrong": { "alias": "passwordStrengthStrong"; "required": false; }; }, {}, never, never, false, never>;
}

declare class SensitiveInputComponent extends BaseFieldComponent<string> {
    protected controlContainer: ControlContainer;
    class: boolean;
    input: ElementRef;
    /**
    * Type of sensitive input field. Defaults to 'normal', which uses a show/hide toggle with no masking.
    * Specific types can be used to mask SSN & enforce length (number of digits) expected.
    **/
    fieldType: SensitiveInputFieldType;
    /**
    * The maximum amount of character input allowed in the text field.
    **/
    maxLength: number;
    SensitiveInputFieldType: typeof SensitiveInputFieldType;
    iconRight: string;
    inputMode: string;
    inputPattern: string;
    inputType: PasswordType;
    maskType: MaskType;
    typeMaxLength: number;
    validLength: number;
    autocomplete: string;
    private validationRegex;
    constructor(textService: TextService, controlContainer: ControlContainer);
    ngOnChanges(): void;
    validate(control: AbstractControl): ValidationErrors | null;
    writeValue(value: string): void;
    toggleVisibility(): void;
    get inPasswordMode(): boolean;
    private setIconRight;
    private setFieldProps;
    private setMasking;
    private isTextType;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<SensitiveInputComponent, [null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SensitiveInputComponent, "ui-forms-sensitive-input", never, { "fieldType": { "alias": "fieldType"; "required": false; }; "maxLength": { "alias": "maxLength"; "required": false; }; }, {}, never, never, false, never>;
}

declare class TextAreaIconButton {
    icon: string;
    ariaLabel: string;
    position: 'left' | 'right';
    disabled: boolean;
    constructor(icon: string, ariaLabel: string, position?: 'left' | 'right', disabled?: boolean);
}

declare class TextAreaComponent extends BaseFieldComponent<string> implements OnChanges {
    textService: TextService;
    protected controlContainer: ControlContainer;
    textarea: ElementRef;
    /**
    * Whether or not the text area is collapsable.
    **/
    collapsable: boolean;
    /**
    * The maximum amount of character input allowed within the text area.
    **/
    maxLength: number;
    /**
    * The maximum number of rows the text area can expand to.
    * When set, the text area will auto-resize from the initial row count up to this value.
    * A value of 0 disables auto-resize.
    **/
    maxRows: number;
    /**
    * Placeholder text displayed when the text area is empty.
    **/
    placeholder: string;
    /**
    * Whether or not to prevent input of new lines. Often used in payment "note" fields.
    **/
    preventNewLines: boolean;
    /**
    * The amount of rows to show within the text area. Three is the default.
    **/
    rows: number;
    /**
    * If true, this takes over the 'info', 'success' and 'warning' messages,
    * so don't enable this if you need any of those messages to display.
    **/
    showCharactersRemaining: boolean;
    /**
    * Array of icon buttons to display below the text area.
    **/
    iconButtons: TextAreaIconButton[];
    /**
    * Chips to display above the text area, e.g. context tags. Each renders with a remove button;
    * see chipRemoved. The chip list's own label is always visually hidden - see chipsLabel to set
    * its accessible name.
    **/
    chips: ChipListItem[];
    /**
    * Accessible name for the (visually hidden) chip list label when chips are shown.
    **/
    chipsLabel: string;
    /**
    * Emits when an icon button is clicked.
    **/
    iconButtonClicked: EventEmitter<TextAreaIconButton>;
    /**
    * Emits the chip when its remove button is clicked.
    **/
    chipRemoved: EventEmitter<ChipListItem>;
    iconButtonsLeft: TextAreaIconButton[];
    iconButtonsRight: TextAreaIconButton[];
    isCollapsed: boolean;
    private autoResizeMaxHeight;
    constructor(textService: TextService, controlContainer: ControlContainer);
    ngOnChanges(changes: SimpleChanges): void;
    onKeyDown(event: KeyboardEvent): void;
    onInput(event: Event | any): void;
    writeValue(value: string): void;
    private autoResize;
    private calculateMaxHeight;
    onIconButtonClick(icon: TextAreaIconButton): void;
    collapsedChanged(collapsed: boolean): void;
    private updateCharactersRemaining;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextAreaComponent, [null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TextAreaComponent, "ui-forms-text-area", never, { "collapsable": { "alias": "collapsable"; "required": false; }; "maxLength": { "alias": "maxLength"; "required": false; }; "maxRows": { "alias": "maxRows"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "preventNewLines": { "alias": "preventNewLines"; "required": false; }; "rows": { "alias": "rows"; "required": false; }; "showCharactersRemaining": { "alias": "showCharactersRemaining"; "required": false; }; "iconButtons": { "alias": "iconButtons"; "required": false; }; "chips": { "alias": "chips"; "required": false; }; "chipsLabel": { "alias": "chipsLabel"; "required": false; }; }, { "iconButtonClicked": "iconButtonClicked"; "chipRemoved": "chipRemoved"; }, never, never, false, never>;
}

declare class TextInputComponent extends BaseMenuFieldComponent<string> implements OnChanges {
    private ngZone;
    private changeDetector;
    protected controlContainer: ControlContainer;
    input: ElementRef;
    maskDirective: MaskDirective;
    /**
    * The maximum amount of character input allowed in the text field.
    **/
    maxLength: number;
    /**
    * Type of text input field which defaults to a simple text input.
    * Specific types can be used to collect certain types of values, such as domestic phone numbers,
    * domestic zip codes, emails, codes, etc.
    **/
    fieldType: TextInputFieldType;
    /**
    * The icon to show to the right of an optional "action" button.
    **/
    actionButtonIcon: string;
    /**
    * The message to show on an optional "action" button.
    **/
    actionButtonMessage: string;
    /**
    * Disables the "action" button.
    **/
    actionButtonDisabled: boolean;
    /**
    * Show a spinner in the "action" button when disabled.
    **/
    actionButtonDisabledSpinner: boolean;
    /**
    * When true, renders a copy-to-clipboard button using ui-core-copy-to-clipboard-button
    * alongside the input (and to the left of the action button if one is present). The
    * field's label is passed through as the button's accessibility label suffix
    * (e.g. "Copy to Clipboard: Account Number").
    *
    * The button is always visible while this flag is true and is automatically disabled
    * when the field has no value — clicking has no effect on an empty field, and the
    * button becomes interactive as soon as the value is populated.
    **/
    copyToClipboard: boolean;
    /**
    * Array of Validation Criteria to test whether the form value is considered valid.
    **/
    criteria: ValidationCriteria[];
    /**
    * Message that displays above the rendered Validation Criteria.
    **/
    criteriaDescription: string;
    /**
    * Array of options that a user may select from (but are not required).
    * These are only eligible for field type DEFAULT, INTERNATIONAL PHONE and STATE.
    * DEFAULT - options are presented as a typeahead
    * INTERNATIONAL PHONE - options are launched by toggle in left of input
    * STATE - options are presented as a typeahead
    **/
    options: TextInputOption[];
    /**
    * An optional factory for generating dynamic typeahead menu options.
    * This is only supported with the DEFAULT field type.
    * If a list of options are provided, the factory is not used.
    **/
    typeaheadFactory: TypeaheadFactory<TextInputOption>;
    /**
    * String used to define autocomplete attribute
    * supported values: https://developer.mozilla.org/en-US/docs/Web/HTML/Attributes/autocomplete#values
    **/
    autocomplete: string;
    /**
    * Used to set the validation for international postal codes.
    * Defaults to US zip code.
    **/
    postalCodeCountryAlpha2: string;
    /**
    * Used to require a postal code for the field, if the country code allows postal codes.
    * If the country code does not allow postal codes, empty values will be allowed.
    **/
    postalCodeRequired: boolean;
    /**
    * Allows for custom masking behaviors with the default text input field type.
    * Can be used when there is no appropriate field type.
    **/
    customMasking: TextInputCustomMasking;
    /**
    * Emits if the user clicks the optional "action" button.
    * Value emitted is the current value of the field.
    **/
    actionButtonClick: EventEmitter<string>;
    /**
    * Emits after a copy-to-clipboard attempt completes when `copyToClipboard` is true.
    * Payload is the success boolean from the inner ui-core-copy-to-clipboard-button.
    * Wire this to log audit events at the call site.
    **/
    copied: EventEmitter<boolean>;
    /**
    * Emits a clone of the option that was selected from the menu last.
    * Note: this emits prior to the change event, which emits the value of the field.
    **/
    menuSelection: EventEmitter<MenuSelectionEvent<TextInputOption>>;
    readonly toggleId: string;
    private readonly numRegex;
    private readonly defaultCountry;
    private postalCodeCountry;
    typeErrorMessage: string;
    typeInfoMessage: string;
    typeMaxLength: number;
    iconLeft: string;
    allowOptions: boolean;
    optionMenuToggleIcon: string;
    optionMenuToggleIconIsEmoji: boolean;
    letterSpacing: boolean;
    maskType: MaskType;
    maskOptions: MaskOptions;
    inputMode: string;
    inputPattern: string;
    visibleGhostText: string;
    hiddenGhostText: string;
    optionMatch: TextInputOption;
    private selectedOption;
    isTypeaheadMenu: boolean;
    private isDynamicTypeaheadMenu;
    menuState: ListMenuState | TypeaheadMenuState;
    private returningInputFocus;
    constructor(windowService: WindowService, textService: TextService, ngZone: NgZone, changeDetector: ChangeDetectorRef, controlContainer: ControlContainer);
    ngOnChanges(changes: SimpleChanges): void;
    private initializeInternationalPhoneMenu;
    private initializeTypeaheadMenu;
    private setFieldUI;
    private setFieldProps;
    private setCountryMaskOptions;
    private setCustomMaskOptions;
    private allowPasswordManagersPerAutocomplete;
    private evaluateCriteria;
    onFocus(): void;
    onBlur(event: FocusEvent): void;
    onInputKeyDown(event: KeyboardEvent): void;
    onInputKeyUp(event: KeyboardEvent): void;
    validate(control: AbstractControl): ValidationErrors | null;
    private isValidPostalCode;
    writeValue(value: string): void;
    actionClicked(): void;
    private findBestInternationalPhoneMatch;
    open(): void;
    close(markAsTouched: boolean): void;
    onOptionClick(option: TextInputOption): void;
    onToggleKeyDown(event: KeyboardEvent): void;
    onToggleKeyUp(event: KeyboardEvent): void;
    private setGhostText;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextInputComponent, [null, null, null, null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TextInputComponent, "ui-forms-text-input", never, { "maxLength": { "alias": "maxLength"; "required": false; }; "fieldType": { "alias": "fieldType"; "required": false; }; "actionButtonIcon": { "alias": "actionButtonIcon"; "required": false; }; "actionButtonMessage": { "alias": "actionButtonMessage"; "required": false; }; "actionButtonDisabled": { "alias": "actionButtonDisabled"; "required": false; }; "actionButtonDisabledSpinner": { "alias": "actionButtonDisabledSpinner"; "required": false; }; "copyToClipboard": { "alias": "copyToClipboard"; "required": false; }; "criteria": { "alias": "criteria"; "required": false; }; "criteriaDescription": { "alias": "criteriaDescription"; "required": false; }; "options": { "alias": "options"; "required": false; }; "typeaheadFactory": { "alias": "typeaheadFactory"; "required": false; }; "autocomplete": { "alias": "autocomplete"; "required": false; }; "postalCodeCountryAlpha2": { "alias": "postalCodeCountryAlpha2"; "required": false; }; "postalCodeRequired": { "alias": "postalCodeRequired"; "required": false; }; "customMasking": { "alias": "customMasking"; "required": false; }; }, { "actionButtonClick": "actionButtonClick"; "copied": "copied"; "menuSelection": "menuSelection"; }, never, never, false, never>;
}

declare class ListMenuComponent extends BaseFormMenuComponent implements OnInit {
    searchComponent: SearchInputComponent;
    noOptionsMessage: string;
    clearSelectionLabel: string;
    multiSelectState: MultiSelectState<string[] | number[]>;
    menuState: ListMenuState;
    menuBorder: 'none' | 'full' | 'default';
    searchPlaceholder: string;
    closed: EventEmitter<void>;
    selection: EventEmitter<MenuOption>;
    action: EventEmitter<Action>;
    allSelected: EventEmitter<void>;
    allVisibleSelected: EventEmitter<void>;
    selectionCleared: EventEmitter<void>;
    clearAction: Action;
    selectAllOption: MenuOption;
    showKeyboardPlaceholder: boolean;
    constructor(textService: TextService);
    ngOnInit(): void;
    close(): void;
    onOptionClick(option: MenuOption): void;
    onActionClick(action: Action): void;
    onSearchClick(): void;
    onOptionKeyDown(option: MenuOption, event: KeyboardEvent): void;
    onActionKeyDown(action: Action, event: KeyboardEvent): void;
    onSearchKeyDown(event: KeyboardEvent): void;
    closeKeyDown(event: KeyboardEvent): void;
    onSearchFocusChange(hasFocus: boolean): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListMenuComponent, "ui-forms-list-menu", never, { "noOptionsMessage": { "alias": "noOptionsMessage"; "required": false; }; "clearSelectionLabel": { "alias": "clearSelectionLabel"; "required": false; }; "multiSelectState": { "alias": "multiSelectState"; "required": false; }; "menuState": { "alias": "menuState"; "required": false; }; "menuBorder": { "alias": "menuBorder"; "required": false; }; "searchPlaceholder": { "alias": "searchPlaceholder"; "required": false; }; }, { "closed": "closed"; "selection": "selection"; "action": "action"; "allSelected": "allSelected"; "allVisibleSelected": "allVisibleSelected"; "selectionCleared": "selectionCleared"; }, never, never, false, never>;
}

declare class MenuOptionComponent {
    hostClass: string;
    allowEmojis: boolean;
    menuIconsOnRight: boolean;
    e2ePrefix: string;
    option: MenuOption;
    static ɵfac: i0.ɵɵFactoryDeclaration<MenuOptionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MenuOptionComponent, "ui-forms-menu-option", never, { "allowEmojis": { "alias": "allowEmojis"; "required": false; }; "menuIconsOnRight": { "alias": "menuIconsOnRight"; "required": false; }; "e2ePrefix": { "alias": "e2ePrefix"; "required": false; }; "option": { "alias": "option"; "required": false; }; }, {}, never, never, false, never>;
}

declare class TypeaheadMenuComponent extends BaseFormMenuComponent {
    menuState: TypeaheadMenuState;
    selection: EventEmitter<MenuOption>;
    menuHeight: number;
    constructor();
    ngOnChanges(changes: SimpleChanges): void;
    onOptionClick(option: MenuOption): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<TypeaheadMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TypeaheadMenuComponent, "ui-forms-typeahead-menu", never, { "menuState": { "alias": "menuState"; "required": false; }; }, { "selection": "selection"; }, never, never, false, never>;
}

declare class UiFormsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UiFormsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UiFormsModule, [typeof AmountInputComponent, typeof AmountRangeMenuComponent, typeof AmountRangeComponent, typeof BotDetectionComponent, typeof CalendarComponent, typeof CalendarMenuComponent, typeof CheckboxComponent, typeof CheckboxListComponent, typeof CheckboxOptionComponent, typeof CollapsablePickerComponent, typeof ContentTemplateComponent, typeof DateInputComponent, typeof DatepickerComponent, typeof DateRangeComponent, typeof DropdownComponent, typeof FieldValidationComponent, typeof FileInputComponent, typeof FormDirective, typeof FormModalComponent, typeof FormRendererComponent, typeof FormRowDirective, typeof LabelTooltipsComponent, typeof MultiSelectDropdownComponent, typeof MultiSelectPickerComponent, typeof MultiSelectTemplateDropdownComponent, typeof NumberInputComponent, typeof PasswordInputComponent, typeof PickerComponent, typeof RadioButtonOptionComponent, typeof RadioButtonsComponent, typeof SearchInputComponent, typeof SensitiveInputComponent, typeof SliderComponent, typeof TemplateDropdownComponent, typeof TemplateRendererComponent, typeof TextAreaComponent, typeof TextInputComponent, typeof ToggleComponent, typeof WorkflowButtonComponent, typeof WorkflowInputComponent, typeof ListMenuComponent, typeof MaskDirective, typeof MenuOptionComponent, typeof TypeaheadMenuComponent], [typeof i45.CommonModule, typeof i46.NgbModule, typeof i47.ReactiveFormsModule, typeof i47.FormsModule, typeof i48.UiCoreModule, typeof i49.NgxTurnstileModule], [typeof AmountInputComponent, typeof AmountRangeMenuComponent, typeof AmountRangeComponent, typeof BotDetectionComponent, typeof CalendarComponent, typeof CheckboxComponent, typeof CheckboxListComponent, typeof CheckboxOptionComponent, typeof CollapsablePickerComponent, typeof ContentTemplateComponent, typeof DateInputComponent, typeof DatepickerComponent, typeof DateRangeComponent, typeof DropdownComponent, typeof FieldValidationComponent, typeof FileInputComponent, typeof FormDirective, typeof FormModalComponent, typeof FormRendererComponent, typeof FormRowDirective, typeof LabelTooltipsComponent, typeof MultiSelectDropdownComponent, typeof MultiSelectPickerComponent, typeof MultiSelectTemplateDropdownComponent, typeof NumberInputComponent, typeof PasswordInputComponent, typeof PickerComponent, typeof RadioButtonOptionComponent, typeof RadioButtonsComponent, typeof SearchInputComponent, typeof SensitiveInputComponent, typeof SliderComponent, typeof TemplateDropdownComponent, typeof TemplateRendererComponent, typeof TextAreaComponent, typeof TextInputComponent, typeof ToggleComponent, typeof WorkflowButtonComponent, typeof WorkflowInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UiFormsModule>;
}

export { AccountTemplateData, AddressField, AddressFields, AddressUtils, AmountInputComponent, AmountInputField, AmountRangeComponent, AmountRangeMenuComponent, Autocomplete, BaseFormField, BaseTemplateData, BotDetectionComponent, ButtonField, CalendarComponent, CalendarMenuComponent, CardTemplateData, CheckboxComponent, CheckboxField, CheckboxListComponent, CheckboxListField, CheckboxListOption, CheckboxOptionComponent, CollapsablePickerComponent, CollapsablePickerOption, ContentTemplateComponent, ContentTemplateData, DEFAULT_LOCKED_MESSAGE, DEFAULT_MAX_AMOUNT, DEFAULT_MAX_LENGTH, DEFAULT_MAX_NUMBER, DEFAULT_TEXT_AREA_ROWS, DEFAULT_TEXT_DEBOUNCE_TIME, DateInputComponent, DateInputField, DateInputFieldType, DateRangeComponent, DateTimeUtils, DatepickerComponent, DatepickerField, DescriptionListField, DropdownAction, DropdownComponent, DropdownField, DropdownOption, FieldValidationComponent, FileInputComponent, FileInputField, FileInputUtils, FormDirective, FormFieldStacker, FormModalButtonType, FormModalClickEvent, FormModalComponent, FormRendererComponent, FormRendererField, FormRendererFieldType, FormRendererGroup, FormRendererGroupCategoryEvent, FormRendererGroupSummary, FormRendererInputEvent, FormRendererRow, FormRendererSelectionEvent, FormRendererTemplateValue, FormRendererValidatorType, FormRowDirective, FormSpacingUtils, FormUtils, HeaderField, HtmlField, IconButtonField, ImageField, InLineNotificationField, LabelTooltipsComponent, LabelValueListField, LinkField, ManagementEditorField, ManagementEditorFieldType, MenuSelectionEvent, MultiSelectDropdownComponent, MultiSelectDropdownField, MultiSelectDropdownOption, MultiSelectPickerComponent, MultiSelectPickerOption, MultiSelectTemplateDropdownComponent, MultiSelectTemplateDropdownField, NumberInputComponent, NumberInputField, PasswordInputComponent, PasswordInputField, PickerComponent, PickerOption, RadioButtonOption, RadioButtonOptionComponent, RadioButtonsComponent, RadioButtonsField, SearchInputComponent, SensitiveInputComponent, SensitiveInputField, SensitiveInputFieldType, SliderComponent, SliderField, TemplateDropdownComponent, TemplateDropdownField, TemplateDropdownOption, TemplateField, TemplateGroup, TemplateRendererComponent, TextAreaComponent, TextAreaField, TextAreaIconButton, TextInputComponent, TextInputCustomMasking, TextInputField, TextInputFieldType, TextInputOption, ToggleComponent, ToggleField, TurnstileConfiguration, TypeaheadFactory, UI_BOT_DETECTION_PROVIDER, UiFormsModule, UploadedFile, ValidationCriteria, WorkflowButtonComponent, WorkflowButtonSummary, WorkflowInputComponent, WorkflowInputOption, conditionalValidator, formValidator };
export type { Address, Cloneable, FormRendererPositioning, ManagementEditor, ManagementEditorSelectionEvent, StandardAddressFormContent, UiBotDetectionProvider };
//# sourceMappingURL=index.d.ts.map
