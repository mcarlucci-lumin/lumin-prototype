import * as i0 from '@angular/core';
import { EventEmitter, Output, Input, Component, HostBinding, Directive, Optional, ViewChild, ElementRef, ViewChildren, NgModule } from '@angular/core';
import * as i1 from '@a3-digital/ui-core';
import { BaseTextComponent, HtmlUtils, PageActionItem, SpacingUtils, UuidUtils, UiCoreModule } from '@a3-digital/ui-core';
import * as i2 from '@angular/forms';
import { Validators, FormGroupDirective, ControlContainer, UntypedFormControl, FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import * as i5 from '@a3-digital/ui-forms';
import { FormUtils, DEFAULT_MAX_LENGTH, DropdownOption, FormSpacingUtils, UiFormsModule } from '@a3-digital/ui-forms';
import { NumberUtils } from '@a3-digital/utils';
import QuillVideo from 'quill/formats/video';
import { Attributor } from 'parchment';
import Link from 'quill/formats/link';
import Quill from 'quill';
import * as i3 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i4 from 'ngx-quill';
import { QuillModule } from 'ngx-quill';
import * as i4$1 from '@angular/cdk/drag-drop';
import { moveItemInArray, DragDropModule } from '@angular/cdk/drag-drop';
import * as i4$2 from 'ngx-monaco-editor-v2';
import { MonacoEditorModule } from 'ngx-monaco-editor-v2';
import { marked } from 'marked';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

class HeaderComponent {
    constructor() {
        /**
        * Required. Title text
        **/
        this.title = '';
        /**
        * Optional. Subtitle text that displays in-line, to the right of the title
        **/
        this.subtitle = '';
        /**
        * Optional. Array of badges (max of 5) to be displayed in-line with the title text.
        **/
        this.badges = [];
        /**
        * Optional. Description text that displays below the title.
        * Allows rich text html.
        **/
        this.description = '';
        /**
        * Optional. Array of Page Action Items
        **/
        this.pageActions = [];
        /**
        * Optional. Sets the page actions more menu button icon. Defaults to three vertical dots.
        **/
        this.pageActionsMenuIcon = '';
        /**
        * Optional. Sets the page actions more menu button text. Defaults to 'More'.
        **/
        this.pageActionsMenuText = '';
        /**
        * Optional. When true and there are 3 or more page actions, two of the actions will show outside the More dropdown menu.
        **/
        this.showTwoActionsOutsideMenu = false;
        /**
        * Optional. Array of Breadcrumb Items
        **/
        this.breadcrumbs = [];
        /**
        * Optional. If set, a back button will display instead of breadcrumbs.
        **/
        this.backButtonUrl = '';
        /**
        * Optional. The text to display in the back button. Defaults to empty string.
        **/
        this.backButtonText = '';
        /**
        * Emitted when the back button is clicked.
        * This is only the case when backButtonUrl is not provided and therefore the back button is a true button.
        **/
        this.onBackButtonClick = new EventEmitter();
    }
    backButtonClick() {
        this.onBackButtonClick.emit(true);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: HeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.17", type: HeaderComponent, isStandalone: false, selector: "ui-management-header", inputs: { title: "title", subtitle: "subtitle", badges: "badges", description: "description", pageActions: "pageActions", pageActionsMenuIcon: "pageActionsMenuIcon", pageActionsMenuText: "pageActionsMenuText", showTwoActionsOutsideMenu: "showTwoActionsOutsideMenu", breadcrumbs: "breadcrumbs", backButtonUrl: "backButtonUrl", backButtonText: "backButtonText" }, outputs: { onBackButtonClick: "onBackButtonClick" }, ngImport: i0, template: "<div class=\"mb-6\" uiCoreReplayUnmask>\n    @if (breadcrumbs?.length > 0) {\n        <div class=\"mb-2\">\n            <ui-core-breadcrumbs [breadcrumbs]=\"breadcrumbs\"></ui-core-breadcrumbs>\n        </div>\n    } @else if (breadcrumbs?.length === 0 && backButtonText) {\n        <div>\n            <ui-core-back-button [url]=\"backButtonUrl\" [message]=\"backButtonText\" (onClick)=\"backButtonClick()\" e2e=\"header\"></ui-core-back-button>\n        </div>\n    }\n    \n    \n    <div class=\"d-flex justify-content-between\">\n        <div class=\"title-container d-flex\">\n            <h1 class=\"color-brand-neutral mb-md-0\">\n                <span>{{ title }}</span>\n                @if (subtitle) {\n                    <span class=\"color-gray-700 ml-2\">{{ subtitle }}</span>\n                }\n            </h1>\n            @if (badges?.length > 0) {\n                <div class=\"badge-list\">\n                    <ui-core-badge-list [items]=\"badges\" [marginTop]=\"false\" [max]=\"5\"></ui-core-badge-list>\n                </div>\n            }\n        </div>\n\n        @if (pageActions?.length > 0) {\n            <div class=\"pl-2\">\n                <ui-core-page-actions \n                    [actions]=\"pageActions\" \n                    [showTwoOutsideMenu]=\"showTwoActionsOutsideMenu\"\n                    [moreMenuIcon]=\"pageActionsMenuIcon\" \n                    [moreMenuButtonText]=\"pageActionsMenuText\">\n                </ui-core-page-actions>\n            </div>\n        }\n    </div>\n    \n    @if (description) {\n        <ui-core-safe-html [content]=\"description\" containerClass=\"color-gray-800 mt-1\"></ui-core-safe-html>\n    }\n</div>", styles: [".title-container{flex-wrap:wrap;gap:.75rem;padding-top:.5rem}.title-container h1{margin-bottom:0}.badge-list{margin-top:.125rem}\n"], dependencies: [{ kind: "component", type: i1.BackButtonComponent, selector: "ui-core-back-button", inputs: ["message", "url", "e2e"], outputs: ["onClick"] }, { kind: "component", type: i1.BadgeListComponent, selector: "ui-core-badge-list", inputs: ["items", "marginTop", "max", "rightAlign"] }, { kind: "component", type: i1.BreadcrumbsComponent, selector: "ui-core-breadcrumbs", inputs: ["breadcrumbs"] }, { kind: "component", type: i1.PageActionsComponent, selector: "ui-core-page-actions", inputs: ["withinModal", "withinNav", "showTwoOutsideMenu", "alignLeft", "moreMenuIcon", "moreMenuButtonText", "actions"] }, { kind: "component", type: i1.SafeHtmlComponent, selector: "ui-core-safe-html", inputs: ["content", "mode", "containerClass"] }, { kind: "directive", type: i1.ReplayUnmaskDirective, selector: "[uiCoreReplayUnmask]" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: HeaderComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-management-header', template: "<div class=\"mb-6\" uiCoreReplayUnmask>\n    @if (breadcrumbs?.length > 0) {\n        <div class=\"mb-2\">\n            <ui-core-breadcrumbs [breadcrumbs]=\"breadcrumbs\"></ui-core-breadcrumbs>\n        </div>\n    } @else if (breadcrumbs?.length === 0 && backButtonText) {\n        <div>\n            <ui-core-back-button [url]=\"backButtonUrl\" [message]=\"backButtonText\" (onClick)=\"backButtonClick()\" e2e=\"header\"></ui-core-back-button>\n        </div>\n    }\n    \n    \n    <div class=\"d-flex justify-content-between\">\n        <div class=\"title-container d-flex\">\n            <h1 class=\"color-brand-neutral mb-md-0\">\n                <span>{{ title }}</span>\n                @if (subtitle) {\n                    <span class=\"color-gray-700 ml-2\">{{ subtitle }}</span>\n                }\n            </h1>\n            @if (badges?.length > 0) {\n                <div class=\"badge-list\">\n                    <ui-core-badge-list [items]=\"badges\" [marginTop]=\"false\" [max]=\"5\"></ui-core-badge-list>\n                </div>\n            }\n        </div>\n\n        @if (pageActions?.length > 0) {\n            <div class=\"pl-2\">\n                <ui-core-page-actions \n                    [actions]=\"pageActions\" \n                    [showTwoOutsideMenu]=\"showTwoActionsOutsideMenu\"\n                    [moreMenuIcon]=\"pageActionsMenuIcon\" \n                    [moreMenuButtonText]=\"pageActionsMenuText\">\n                </ui-core-page-actions>\n            </div>\n        }\n    </div>\n    \n    @if (description) {\n        <ui-core-safe-html [content]=\"description\" containerClass=\"color-gray-800 mt-1\"></ui-core-safe-html>\n    }\n</div>", styles: [".title-container{flex-wrap:wrap;gap:.75rem;padding-top:.5rem}.title-container h1{margin-bottom:0}.badge-list{margin-top:.125rem}\n"] }]
        }], propDecorators: { title: [{
                type: Input
            }], subtitle: [{
                type: Input
            }], badges: [{
                type: Input
            }], description: [{
                type: Input
            }], pageActions: [{
                type: Input
            }], pageActionsMenuIcon: [{
                type: Input
            }], pageActionsMenuText: [{
                type: Input
            }], showTwoActionsOutsideMenu: [{
                type: Input
            }], breadcrumbs: [{
                type: Input
            }], backButtonUrl: [{
                type: Input
            }], backButtonText: [{
                type: Input
            }], onBackButtonClick: [{
                type: Output
            }] } });

class HtmlEditorAction {
    constructor() {
        this.showSpinner = false;
        /**
         * If true, the html-editor will automatically show a loading overlay
         * when this action is triggered. The overlay will hide when the Promise resolves/rejects.
         * Note: Only works with Promise-based actions. Synchronous actions are ignored to avoid flicker.
         */
        this.showLoadingOverlay = false;
    }
}

const DEFAULT_LOCKED_MESSAGE = 'DEFAULT_LOCKED_MESSAGE';
class BaseEditorComponent extends BaseTextComponent {
    get lockedMessage() {
        return this.locked ? this.getLockedMessage() : undefined;
    }
    /**
    * Displays when the field is locked
    *  - has a default value that always displays for locked fields
    *  - accepts strings or boolean false - if you don't want any message displayed for a locked field, set this to false - `field.lockedMessage: false`
    **/
    set lockedMessage(value) {
        this._lockedMessage = value;
    }
    get control() {
        if (this.controlContainer && this.controlName && !this._control) {
            // Editors wrap a reactive form control, so the control container is actually the parent
            // form group directive.
            this._control = this.controlContainer.form?.get(this.controlName) || null;
        }
        return this._control;
    }
    get value() {
        return this.control?.value;
    }
    get showControlInvalid() {
        return this.controlTouched && !this.control?.valid;
    }
    get required() {
        return this.control?.hasValidator(Validators.required);
    }
    constructor(textService, textConfigKey, controlContainer) {
        super(textService, textConfigKey);
        this.controlContainer = controlContainer;
        // These are not ideal, but it lets us reuse the global form styles.
        // Under the covers, there is a reactive form control from a third-party library that we are wrapping.
        // Our ui cares about touched and invalid states, so need to pull those from the form control
        // and then re-apply them here.
        this.mimicFormField = true;
        this.managementEditor = true;
        this.controlTouched = false;
        this.controlInvalid = false;
        this.controlValid = false;
        /**
        * Displays a success themed message
        **/
        this.successMessage = '';
        /**
        * Displays an info themed message
        **/
        this.infoMessage = '';
        /**
        * Displays a warning themed message
        **/
        this.warningMessage = '';
        /**
        * Displays when the field is invalid
        **/
        this.errorMessage = '';
        /**
        * Required. The label for the form field
        **/
        this.label = '';
        /**
        * Can be used to visually hide the label. Label should always be provided, and hidden if undesired
        **/
        this.hideLabel = false;
        /**
        * Allows for a custom e2e prefix instead of using the form control name.
        **/
        this.e2e = '';
        /**
        * Specifies whether or not the field should be read-only. Locked fields cannot be modified by the user.
        **/
        this.locked = false;
        /**
        * Content to display in the tooltip popover
        **/
        this.tooltip = '';
        /**
        * Direction to place the tooltip popover.
        * "auto" (default) will attempt to place the popover where it can be seen (based on container/window bounds)
        * See ng-bootstrap documentation for details - type: Placement
        **/
        this.tooltipPlacement = 'auto';
        /**
        * Emits the new value when the value changes.
        **/
        this.change = new EventEmitter();
        this._control = null;
        this.baseText = {};
        // Used for e2e hooks. e2e hooks should be the prefix, plus a short but descriptive hook for the element.
        this.e2ePrefix = '';
        this.e2eField = '';
        // Used to apply custom validators and corresponding error messages.
        this.appliedValidators = [];
        this.hasBeenInitialized = false;
        this.customErrorMessage = '';
        this.errorMessageMap = new Map();
        if (textService) {
            textService.getText$('ui-management-base-editor', this.getDefaultBaseText())
                .pipe(this.takeUntilDestroyed())
                .subscribe((x) => {
                if (x) {
                    this.mergeBaseText(x);
                }
            });
        }
        else {
            this.mergeBaseText(this.getDefaultBaseText());
        }
        // FieldId is used to link the form field element to other elements, such as the label.
        this.fieldId = HtmlUtils.generateRandomId();
        this.labelId = this.fieldId + '_label';
    }
    ngOnInit() {
        this.setE2EPrefix();
        if (this.control) {
            this.updateValidators('onInit');
            this.control.statusChanges
                .pipe(this.takeUntilDestroyed())
                .subscribe(() => {
                // We normally don't use the dirty state, but the editors tend to be complex/tall.
                // Showing invalid state on change or on touched.
                this.controlTouched = this.control?.touched || this.control?.dirty || false;
                this.controlInvalid = this.control?.invalid || false;
                this.controlValid = this.control?.valid || false;
                if (this.controlInvalid && this.control.errors && this.errorMessageMap.size > 0) {
                    this.customErrorMessage = '';
                    for (let customError of this.errorMessageMap) {
                        if (this.control.errors[customError[0]]) {
                            this.customErrorMessage = customError[1];
                        }
                    }
                }
            });
            // Note: when this emits, the value has not actually been written to the control yet.
            // this.control.value will be different!!
            this.control.valueChanges
                .pipe(this.takeUntilDestroyed())
                .subscribe((value) => {
                this.onValueChange(value);
                this.change.emit(value);
            });
        }
    }
    ngOnDestroy() {
        super.ngOnDestroy();
        this.updateValidators('onDestroy');
    }
    updateValidators(source, onChangesUpdate = true) {
        if (!this.control) {
            return;
        }
        switch (source) {
            case 'onInit':
                // onInit should only happen one time.
                // Apply any validators at this time.
                if (!this.hasBeenInitialized) {
                    this.hasBeenInitialized = true;
                    this.setValidators();
                }
                break;
            case 'onChanges':
                if (this.hasBeenInitialized) {
                    // Check to see if any validator has actually been added/removed.
                    const currentValidatorNames = this.appliedValidators.map((x) => x.name);
                    const newValidators = this.getValidators() || [];
                    const newValidatorNames = newValidators.map((x) => x.name);
                    const validatorsChanged = this.validatorsChanged(currentValidatorNames, newValidatorNames);
                    if (validatorsChanged) {
                        this.removeValidators();
                        this.setValidators();
                        if (onChangesUpdate) {
                            this.control.updateValueAndValidity(); // Refresh the control
                        }
                    }
                }
                break;
            case 'onDestroy':
                // Remove any and all validators
                this.removeValidators();
                break;
        }
    }
    setValidators() {
        this.appliedValidators = this.getValidators() || [];
        if (this.appliedValidators.length > 0) {
            this.control.addValidators(this.appliedValidators);
        }
    }
    removeValidators() {
        if (this.appliedValidators.length > 0) {
            this.control.removeValidators(this.appliedValidators);
            this.appliedValidators = [];
        }
    }
    validatorsChanged(oldNames, newNames) {
        // If the lengths are different, they are different.
        if (oldNames.length !== newNames.length) {
            return true;
        }
        // If the lengths are the same, but the names are different, they are different.
        return oldNames.some((x) => !newNames.includes(x));
    }
    setE2EPrefix() {
        this.e2ePrefix = HtmlUtils.formatE2EPrefix(this.e2e || this.controlName);
        this.e2eField = this.e2ePrefix + 'field';
    }
    mergeBaseText(baseText) {
        this.text = Object.assign(this.text, baseText);
    }
    getLockedMessage() {
        if (this._lockedMessage === false) {
            return '';
        }
        if (this._lockedMessage === DEFAULT_LOCKED_MESSAGE || !this._lockedMessage) {
            return this.text.defaultLockedMessage;
        }
        return this._lockedMessage;
    }
    onValueChange(value) {
        // Optional, can be overridden by implementations.
        // This is useful for non-validation related changes, such as extra messaging or state management.
    }
    getValidators() {
        // Optional, can be overridden by implementations.
        // Validators must not have a dependency on "this". Custom error messages can be wired by returning
        // an error key and providing a matching error message in the map.
        return [];
    }
    getDefaultBaseText() {
        return {
            defaultLockedMessage: 'This field can\’t be changed',
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: BaseEditorComponent, deps: "invalid", target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.17", type: BaseEditorComponent, isStandalone: true, inputs: { successMessage: "successMessage", infoMessage: "infoMessage", warningMessage: "warningMessage", errorMessage: "errorMessage", lockedMessage: "lockedMessage", label: "label", hideLabel: "hideLabel", controlName: "controlName", e2e: "e2e", locked: "locked", tooltip: "tooltip", tooltipPlacement: "tooltipPlacement" }, outputs: { change: "change" }, host: { properties: { "class.ui-form-control": "this.mimicFormField", "class.ui-management-editor": "this.managementEditor", "class.ng-touched": "this.controlTouched", "class.ng-invalid": "this.controlInvalid", "class.ng-valid": "this.controlValid", "attr.data-control-name": "this.controlName", "class.form-locked": "this.locked", "attr.data-e2e": "this.e2eField" } }, usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: BaseEditorComponent, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: i1.TextService }, { type: undefined }, { type: i2.ControlContainer }], propDecorators: { mimicFormField: [{
                type: HostBinding,
                args: ['class.ui-form-control']
            }], managementEditor: [{
                type: HostBinding,
                args: ['class.ui-management-editor']
            }], controlTouched: [{
                type: HostBinding,
                args: ['class.ng-touched']
            }], controlInvalid: [{
                type: HostBinding,
                args: ['class.ng-invalid']
            }], controlValid: [{
                type: HostBinding,
                args: ['class.ng-valid']
            }], successMessage: [{
                type: Input
            }], infoMessage: [{
                type: Input
            }], warningMessage: [{
                type: Input
            }], errorMessage: [{
                type: Input
            }], lockedMessage: [{
                type: Input
            }], label: [{
                type: Input
            }], hideLabel: [{
                type: Input
            }], controlName: [{
                type: HostBinding,
                args: ['attr.data-control-name']
            }, {
                type: Input
            }], e2e: [{
                type: Input
            }], locked: [{
                type: Input
            }, {
                type: HostBinding,
                args: ['class.form-locked']
            }], tooltip: [{
                type: Input
            }], tooltipPlacement: [{
                type: Input
            }], change: [{
                type: Output
            }], e2eField: [{
                type: HostBinding,
                args: ['attr.data-e2e']
            }] } });

// Override Quill video embed handling that returns href instead of video iframe to content
// https://github.com/slab/quill/issues/4186
// Out of the box, Quill will strip out non-whitelisted attributes such as referrerpolicy.
// Create the Attributor per these docs: https://github.com/slab/parchment/blob/main/README.md#attributor
const ReferrerPolicyAttributor = new Attributor('referrerpolicy', 'referrerpolicy');
class IFrameVideo extends QuillVideo {
    html() {
        if (this.attributes) {
            this.attributes.attribute(ReferrerPolicyAttributor, 'strict-origin-when-cross-origin');
        }
        const { video } = this.value();
        return `<iframe class="ql-video" frameborder="0" allowfullscreen="true" src="${video}"></iframe>`;
    }
}

// Override Quill link handling to prevent local URLs from being targeted to new windows
class LocalLink extends Link {
    static create(value) {
        // catch newly created links
        const node = Link.create(value);
        value = Link.sanitize(value);
        node.setAttribute('href', value);
        if (HtmlUtils.isRouterUrl(value)) {
            node.removeAttribute('target');
        }
        return node;
    }
    format(name, value) {
        // catch existing links on edit
        super.format(name, value);
        if (HtmlUtils.isRouterUrl(value)) {
            this['domNode'].removeAttribute('target');
        }
    }
}

function linkUrlsAreValid(control) {
    const value = control?.value || '';
    // Should return matches like: href="sample"
    const hrefInstances = value.match(/href="[^"]*"/g);
    const hrefUrls = hrefInstances?.map(href => href.replace(/"/g, '').replace('href=', '')) || [];
    if (hrefUrls.some(url => !HtmlUtils.isRouterUrl(url) && !HtmlUtils.isExternalUrl(url))) {
        return { invalidHref: true };
    }
    return null;
}

// Register customizations to Quill
Quill.register(LocalLink, true);
Quill.register(IFrameVideo, true);
class HtmlEditorComponent extends BaseEditorComponent {
    constructor(textService, controlContainer) {
        super(textService, 'ui-management-html-editor', controlContainer);
        this.textService = textService;
        /**
        * If enabled, a button will be displayed to allow the user to insert videos.
        **/
        this.allowVideos = false;
        /**
        * By default, run the DOM sanitizer on html content. If you trust the content, you can disable this.
        **/
        this.sanitize = true;
        /**
        * If true, this takes over the 'info', 'success' and 'warning' messages,
        * so don't enable this if you need any of those messages to display.
        **/
        this.showCharactersRemaining = false;
        /**
        * The maximum amount of character input allowed in the text field.
        **/
        this.maxLength = FormUtils.defaultMaxLength;
        /**
        * Actions to render in the toolbar.
        **/
        this.actions = [];
        /**
        * Optional. Sets the page actions more menu button icon. Defaults to three vertical dots.
        **/
        this.pageActionsMenuIcon = '';
        /**
        * Optional. The message to display in the loading overlay. 40 character limit for messages.
        **/
        this.loadingOverlayMessage = 'Loading...';
        /**
        * Optional. The size of the spinner in the loading overlay.
        **/
        this.loadingOverlaySpinnerSize = 'sm';
        /**
        * Optional. Sets the page actions more menu button text. Defaults to 'More'.
        **/
        this.pageActionsMenuText = '';
        this.hasActions = false;
        this.pageActions = [];
        this.isLoading = false;
        // Set up custom error messages for validators
        this.setMaxLengthErrorMessage();
        this.errorMessageMap.set('invalidHref', this.text.invalidLinkErrorMessage);
    }
    ngOnChanges(changes) {
        if (changes.maxLength && this.control) {
            this.setMaxLengthErrorMessage();
            this.updateValidators('onChanges');
        }
        if (changes.actions) {
            this.hasActions = this.actions && this.actions.length > 0;
            this.pageActions = this.actions.map(action => {
                const item = new PageActionItem();
                item.text = action.text;
                item.action = this.wrapActionWithLoadingOverlay(action);
                item.icon = action.icon;
                item.id = action.id;
                item.e2e = action.e2e;
                item.disabled = action.disabled;
                item.disabledMessage = action.disabledMessage;
                item.showSpinner = action.showSpinner;
                return item;
            });
        }
    }
    setMaxLengthErrorMessage() {
        if (this.value) {
            const excessCount = NumberUtils.formatNumber(this.value.length - this.maxLength);
            const msg = `${excessCount} ${this.text.charactersRemainingErrorMessage}`;
            // maxlength is a built-in validator
            this.errorMessageMap.set('maxlength', msg);
        }
    }
    wrapActionWithLoadingOverlay(action) {
        if (!action.showLoadingOverlay) {
            return action.action;
        }
        return () => {
            const result = action.action();
            // Only show overlay for Promise-based actions to avoid flicker
            if (result instanceof Promise) {
                this.isLoading = true;
                result
                    .then(() => {
                    this.isLoading = false;
                })
                    .catch(() => {
                    this.isLoading = false;
                });
            }
            // Synchronous actions are ignored - overlay would just flicker
        };
    }
    onBlur() {
        if (this.control) {
            this.control.markAsTouched();
            this.control.updateValueAndValidity();
        }
    }
    onValueChange(value) {
        if (this.showCharactersRemaining) {
            this.updateCharactersRemaining(value);
        }
        this.setMaxLengthErrorMessage();
    }
    updateCharactersRemaining(value) {
        this.successMessage = '';
        this.warningMessage = '';
        this.infoMessage = '';
        const currentLength = value ? value.length : 0;
        // Show the appropriate icon and message depending on how many characters are left.
        // If they went negative, the custom validation will show the error message.
        if (currentLength < this.maxLength) {
            const remainingCount = NumberUtils.formatNumber(this.maxLength - currentLength);
            this.infoMessage = `${remainingCount} ${this.text.defaultCharactersRemaining}`;
        }
        else if (currentLength === this.maxLength) {
            this.warningMessage = `0 ${this.text.defaultCharactersRemaining}`;
        }
    }
    getValidators() {
        return [
            Validators.maxLength(this.maxLength),
            linkUrlsAreValid
        ];
    }
    getDefaultText() {
        return {
            defaultCharactersRemaining: 'character(s) remaining',
            charactersRemainingErrorMessage: 'character(s) over the limit',
            invalidLinkErrorMessage: 'Invalid link url(s). External link urls must begin with a valid protocol (http://, https://, etc.). Internal links must begin with a forward slash (/example).',
            // Placeholder matches default from quill
            placeholder: 'Insert text here...',
            // Toolbar button titles
            boldTitle: 'Bold',
            italicTitle: 'Italic',
            underlineTitle: 'Underline',
            decreaseIndentTitle: 'Decrease Indent',
            increaseIndentTitle: 'Increase Indent',
            leftAlignTitle: 'Left Align',
            centerAlignTitle: 'Center Align',
            rightAlignTitle: 'Right Align',
            justifyTitle: 'Justify',
            bulletedListTitle: 'Bulleted List',
            numberedListTitle: 'Numbered List',
            linkTitle: 'Insert Link',
            videoTitle: 'Embed Video',
            clearFormattingTitle: 'Clear Formatting',
            // Custom Actions
            actionTitle: 'Actions'
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: HtmlEditorComponent, deps: [{ token: i1.TextService }, { token: i2.ControlContainer, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.17", type: HtmlEditorComponent, isStandalone: false, selector: "ui-management-html-editor", inputs: { allowVideos: "allowVideos", sanitize: "sanitize", showCharactersRemaining: "showCharactersRemaining", maxLength: "maxLength", actions: "actions", pageActionsMenuIcon: "pageActionsMenuIcon", loadingOverlayMessage: "loadingOverlayMessage", loadingOverlaySpinnerSize: "loadingOverlaySpinnerSize", pageActionsMenuText: "pageActionsMenuText" }, usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div class=\"label-container\">\n    <label *ngIf=\"!hideLabel\" uiCoreReplayUnmask [for]=\"fieldId\" [id]=\"labelId\">\n        {{ label }}\n        <ui-forms-label-tooltips\n            [label]=\"label\"\n            [locked]=\"locked\"\n            [lockedMessage]=\"lockedMessage\"\n            [tooltip]=\"tooltip\"\n            [tooltipPlacement]=\"tooltipPlacement\"\n            [e2e]=\"e2ePrefix\"\n        ></ui-forms-label-tooltips>\n    </label>\n</div>\n\n<div class=\"container-form\" \n     [uiLoadingOverlay]=\"isLoading\"\n     [loadingMessage]=\"loadingOverlayMessage\"\n     [loadingSpinnerSize]=\"loadingOverlaySpinnerSize\"\n     data-form-focus=\"focus-editable-content\">\n    <quill-editor [readOnly]=\"locked\" [sanitize]=\"sanitize\" bounds=\"self\" [placeholder]=\"text.placeholder\" \n        [formControlName]=\"controlName\" [required]=\"required\"\n        (onBlur)=\"onBlur()\">\n        <div quill-editor-toolbar uiCoreReplayUnmask>\n            <span class=\"ql-formats\">\n                <button class=\"ql-bold\" [title]=\"text.boldTitle\"></button>\n                <button class=\"ql-italic\" [title]=\"text.italicTitle\"></button>\n                <button class=\"ql-underline\" [title]=\"text.underlineTitle\"></button>\n            </span>\n            <span class=\"ql-formats\">\n                <select class=\"ql-header\">\n                    <option value=\"1\"></option>\n                    <option value=\"2\"></option>\n                    <option value=\"3\"></option>\n                    <option value=\"4\"></option>\n                    <option value=\"5\"></option>\n                    <option value=\"6\"></option>\n                    <option selected=\"selected\"></option>\n                </select>\n            </span>\n            <span class=\"ql-formats\">\n                <button class=\"ql-indent\" value=\"-1\" [title]=\"text.decreaseIndentTitle\"></button>\n                <button class=\"ql-indent\" value=\"+1\" [title]=\"text.increaseIndentTitle\"></button>\n            </span>\n            <span class=\"ql-formats\">\n                <button class=\"ql-align\" value=\"\" [title]=\"text.leftAlignTitle\"></button>\n                <button class=\"ql-align\" value=\"center\" [title]=\"text.centerAlignTitle\"></button>\n                <button class=\"ql-align\" value=\"right\" [title]=\"text.rightAlignTitle\"></button>\n                <button class=\"ql-align\" value=\"justify\" [title]=\"text.justifyTitle\"></button>\n            </span>\n            <span class=\"ql-formats\">\n                <button class=\"ql-list\" value=\"bullet\" [title]=\"text.bulletedListTitle\"></button>\n                <button class=\"ql-list\" value=\"ordered\" [title]=\"text.numberedListTitle\"></button>\n            </span>\n            <span class=\"ql-formats\">\n                <button class=\"ql-link\" [title]=\"text.linkTitle\"></button>\n                <button *ngIf=\"allowVideos\" class=\"ql-video\" [title]=\"text.videoTitle\"></button>\n                <button class=\"ql-clean\" [title]=\"text.clearFormattingTitle\"></button>\n            </span>\n        </div>\n    </quill-editor>\n\n    <div *ngIf=\"hasActions\" class=\"html-editor-actions\">\n        <ui-core-page-actions [actions]=\"pageActions\"\n            [alignLeft]=\"true\" [showTwoOutsideMenu]=\"true\" [withinModal]=\"true\"\n            [moreMenuIcon]=\"pageActionsMenuIcon\" [moreMenuButtonText]=\"pageActionsMenuText\">\n        </ui-core-page-actions>\n    </div>\n</div>\n\n<ui-forms-field-validation *ngIf=\"controlName\"\n  [ariaInputName]=\"label\"\n  [errorMessage]=\"customErrorMessage || errorMessage\"\n  [infoMessage]=\"infoMessage\"\n  [successMessage]=\"successMessage\"\n  [warningMessage]=\"warningMessage\"\n  [fieldId]=\"fieldId\"\n  [locked]=\"locked\">\n</ui-forms-field-validation>", styles: [".container-form{display:flex;flex-direction:column;height:290px;min-height:100px;overflow:hidden;padding:0;resize:vertical}.container-form:has(.html-editor-actions){min-height:150px}.container-form quill-editor{display:flex!important;flex-direction:column;flex-grow:1;min-height:0}.container-form .html-editor-actions{padding:0 14px}\n"], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "component", type: i4.QuillEditorComponent, selector: "quill-editor" }, { kind: "directive", type: i2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i1.PageActionsComponent, selector: "ui-core-page-actions", inputs: ["withinModal", "withinNav", "showTwoOutsideMenu", "alignLeft", "moreMenuIcon", "moreMenuButtonText", "actions"] }, { kind: "directive", type: i1.LoadingOverlayDirective, selector: "[uiLoadingOverlay]", inputs: ["uiLoadingOverlay", "loadingMessage", "loadingSpinnerSize"] }, { kind: "directive", type: i1.ReplayUnmaskDirective, selector: "[uiCoreReplayUnmask]" }, { kind: "component", type: i5.FieldValidationComponent, selector: "ui-forms-field-validation", inputs: ["fieldId", "locked", "errorMessage", "infoMessage", "successMessage", "warningMessage", "ariaInputName", "criteria", "criteriaDescription"] }, { kind: "component", type: i5.LabelTooltipsComponent, selector: "ui-forms-label-tooltips", inputs: ["label", "locked", "lockedMessage", "tooltip", "tooltipPlacement", "e2e", "tooltipClass"] }], viewProviders: [
            {
                provide: ControlContainer,
                useExisting: FormGroupDirective
            }
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: HtmlEditorComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-management-html-editor', viewProviders: [
                        {
                            provide: ControlContainer,
                            useExisting: FormGroupDirective
                        }
                    ], template: "<div class=\"label-container\">\n    <label *ngIf=\"!hideLabel\" uiCoreReplayUnmask [for]=\"fieldId\" [id]=\"labelId\">\n        {{ label }}\n        <ui-forms-label-tooltips\n            [label]=\"label\"\n            [locked]=\"locked\"\n            [lockedMessage]=\"lockedMessage\"\n            [tooltip]=\"tooltip\"\n            [tooltipPlacement]=\"tooltipPlacement\"\n            [e2e]=\"e2ePrefix\"\n        ></ui-forms-label-tooltips>\n    </label>\n</div>\n\n<div class=\"container-form\" \n     [uiLoadingOverlay]=\"isLoading\"\n     [loadingMessage]=\"loadingOverlayMessage\"\n     [loadingSpinnerSize]=\"loadingOverlaySpinnerSize\"\n     data-form-focus=\"focus-editable-content\">\n    <quill-editor [readOnly]=\"locked\" [sanitize]=\"sanitize\" bounds=\"self\" [placeholder]=\"text.placeholder\" \n        [formControlName]=\"controlName\" [required]=\"required\"\n        (onBlur)=\"onBlur()\">\n        <div quill-editor-toolbar uiCoreReplayUnmask>\n            <span class=\"ql-formats\">\n                <button class=\"ql-bold\" [title]=\"text.boldTitle\"></button>\n                <button class=\"ql-italic\" [title]=\"text.italicTitle\"></button>\n                <button class=\"ql-underline\" [title]=\"text.underlineTitle\"></button>\n            </span>\n            <span class=\"ql-formats\">\n                <select class=\"ql-header\">\n                    <option value=\"1\"></option>\n                    <option value=\"2\"></option>\n                    <option value=\"3\"></option>\n                    <option value=\"4\"></option>\n                    <option value=\"5\"></option>\n                    <option value=\"6\"></option>\n                    <option selected=\"selected\"></option>\n                </select>\n            </span>\n            <span class=\"ql-formats\">\n                <button class=\"ql-indent\" value=\"-1\" [title]=\"text.decreaseIndentTitle\"></button>\n                <button class=\"ql-indent\" value=\"+1\" [title]=\"text.increaseIndentTitle\"></button>\n            </span>\n            <span class=\"ql-formats\">\n                <button class=\"ql-align\" value=\"\" [title]=\"text.leftAlignTitle\"></button>\n                <button class=\"ql-align\" value=\"center\" [title]=\"text.centerAlignTitle\"></button>\n                <button class=\"ql-align\" value=\"right\" [title]=\"text.rightAlignTitle\"></button>\n                <button class=\"ql-align\" value=\"justify\" [title]=\"text.justifyTitle\"></button>\n            </span>\n            <span class=\"ql-formats\">\n                <button class=\"ql-list\" value=\"bullet\" [title]=\"text.bulletedListTitle\"></button>\n                <button class=\"ql-list\" value=\"ordered\" [title]=\"text.numberedListTitle\"></button>\n            </span>\n            <span class=\"ql-formats\">\n                <button class=\"ql-link\" [title]=\"text.linkTitle\"></button>\n                <button *ngIf=\"allowVideos\" class=\"ql-video\" [title]=\"text.videoTitle\"></button>\n                <button class=\"ql-clean\" [title]=\"text.clearFormattingTitle\"></button>\n            </span>\n        </div>\n    </quill-editor>\n\n    <div *ngIf=\"hasActions\" class=\"html-editor-actions\">\n        <ui-core-page-actions [actions]=\"pageActions\"\n            [alignLeft]=\"true\" [showTwoOutsideMenu]=\"true\" [withinModal]=\"true\"\n            [moreMenuIcon]=\"pageActionsMenuIcon\" [moreMenuButtonText]=\"pageActionsMenuText\">\n        </ui-core-page-actions>\n    </div>\n</div>\n\n<ui-forms-field-validation *ngIf=\"controlName\"\n  [ariaInputName]=\"label\"\n  [errorMessage]=\"customErrorMessage || errorMessage\"\n  [infoMessage]=\"infoMessage\"\n  [successMessage]=\"successMessage\"\n  [warningMessage]=\"warningMessage\"\n  [fieldId]=\"fieldId\"\n  [locked]=\"locked\">\n</ui-forms-field-validation>", styles: [".container-form{display:flex;flex-direction:column;height:290px;min-height:100px;overflow:hidden;padding:0;resize:vertical}.container-form:has(.html-editor-actions){min-height:150px}.container-form quill-editor{display:flex!important;flex-direction:column;flex-grow:1;min-height:0}.container-form .html-editor-actions{padding:0 14px}\n"] }]
        }], ctorParameters: () => [{ type: i1.TextService }, { type: i2.ControlContainer, decorators: [{
                    type: Optional
                }] }], propDecorators: { allowVideos: [{
                type: Input
            }], sanitize: [{
                type: Input
            }], showCharactersRemaining: [{
                type: Input
            }], maxLength: [{
                type: Input
            }], actions: [{
                type: Input
            }], pageActionsMenuIcon: [{
                type: Input
            }], loadingOverlayMessage: [{
                type: Input
            }], loadingOverlaySpinnerSize: [{
                type: Input
            }], pageActionsMenuText: [{
                type: Input
            }] } });

class DragAndDropListItem {
}

class DragAndDropListResult {
    constructor(isValid, listItems = []) {
        this.isValid = isValid;
        this.listItems = listItems;
    }
}

class DragAndDropListComponent extends BaseTextComponent {
    constructor(formBuilder, textService) {
        super(textService, 'ui-management-drag-and-drop-list');
        this.formBuilder = formBuilder;
        /**
        * Required. The array of items (of class DragAndDropListItem) to render in a list.
        **/
        this.listItems = [];
        /**
        * If a dropdown is needed, an array of DropdownOptions must be provided.
        **/
        this.dropdownOptions = [];
        /**
        * The maximum number of items allowed in the list. Once this max is reached, the "Add" button will be disabled.
        **/
        this.maxItemCount = 99;
        /**
        * When enabled, all items will be allowed to be removed.
        **/
        this.allowAllItemRemoval = false;
        /**
        * An optional error message to show if there are no items in the list.
        **/
        this.noItemsErrorMessage = '';
        /**
        * Emits the row's DragAndDropListItem when an action button is clicked, which allows the parent component to handle the action.
        **/
        this.onItemActionClick = new EventEmitter();
        /**
        * Emits the index of the new DragAndDropListItem when the "Add" button is clicked.
        **/
        this.onItemAddClick = new EventEmitter();
        /**
        * Emits the index of the deleted DragAndDropListItem when the "Remove" button is clicked.
        **/
        this.onItemRemoveClick = new EventEmitter();
        /**
        * Emits an object with a value and index of the changed DragAndDropListItem.
        **/
        this.onItemDropdownChange = new EventEmitter();
        /**
        * Emits the array of DragAndDropListItems after the user drags and drops an item into a different position.
        **/
        this.onItemMove = new EventEmitter();
        this.currentDropdownIndex = 0;
    }
    ngOnInit() {
        this.form = this.formBuilder.group({});
        if (this.dropdownOptions?.length) {
            for (let listItem of this.listItems) {
                const control = new UntypedFormControl(listItem.dropdownValue, Validators.required);
                listItem.dropdownOptions = this.getDropdownOptions(listItem);
                listItem.formControlIndex = this.currentDropdownIndex++;
                this.form.addControl(`dropdown${listItem.formControlIndex}`, control);
            }
        }
        this.setActualMaxItemCount();
    }
    onDropdownChange(value, index) {
        const listItem = this.listItems[index];
        listItem.actionDisabled = value !== 0 && !value;
        listItem.dropdownValue = value;
        this.recalculateDropdowns();
        this.onItemDropdownChange.emit({ value, index });
    }
    addNewListItem() {
        const control = new UntypedFormControl(null, Validators.required);
        this.form.addControl(`dropdown${++this.currentDropdownIndex}`, control);
        const newListItem = new DragAndDropListItem();
        newListItem.actionDisabled = this.actionButtonDisabledForNewItems;
        newListItem.formControlIndex = this.currentDropdownIndex;
        newListItem.dropdownOptions = this.getDropdownOptions(newListItem);
        this.listItems.push(newListItem);
        this.onItemAddClick.emit(this.listItems.length - 1);
    }
    removeListItem(item, index) {
        this.onItemRemoveClick.emit(index);
        this.listItems.splice(index, 1);
        this.form.removeControl(`dropdown${item.formControlIndex}`);
        this.recalculateDropdowns();
    }
    onListItemAction(item) {
        this.onItemActionClick.emit(item);
    }
    onListItemDrop(event) {
        if (event.previousIndex !== event.currentIndex) {
            moveItemInArray(this.listItems, event.previousIndex, event.currentIndex);
            this.onItemMove.emit(this.listItems);
        }
    }
    validate() {
        if (this.form.invalid) {
            FormUtils.showFormValidation(this.form);
            return new DragAndDropListResult(false);
        }
        return new DragAndDropListResult(true, this.listItems);
    }
    recalculateDropdowns() {
        for (let listItem of this.listItems) {
            listItem.dropdownOptions = this.getUniqueListItemDropdownOptions(listItem);
        }
    }
    getDropdownOptions(item) {
        return this.dropdownOptionsShouldBeUnique ? this.getUniqueListItemDropdownOptions(item) : this.dropdownOptions;
    }
    getUniqueListItemDropdownOptions(item) {
        return this.dropdownOptions.filter(option => option.value === item.dropdownValue || !this.listItems.some(i => i.dropdownValue === option.value));
    }
    setActualMaxItemCount() {
        if (this.dropdownOptionsShouldBeUnique) {
            this.actualMaxItemCount = this.maxItemCount > this.dropdownOptions.length ? this.dropdownOptions.length : this.maxItemCount;
        }
        else {
            this.actualMaxItemCount = this.maxItemCount;
        }
    }
    getDefaultText() {
        return {
            dropdownAriaLabel: 'Dropdown',
            defaultDropdownErrorMessage: 'Required',
            defaultListItemPrefix: 'Item',
            removeButtonLabel: 'Remove'
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: DragAndDropListComponent, deps: [{ token: i2.FormBuilder }, { token: i1.TextService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.17", type: DragAndDropListComponent, isStandalone: false, selector: "ui-management-drag-and-drop-list", inputs: { listItems: "listItems", listItemPrefix: "listItemPrefix", dropdownOptions: "dropdownOptions", dropdownOptionsShouldBeUnique: "dropdownOptionsShouldBeUnique", dropdownErrorMessage: "dropdownErrorMessage", actionButtonDisabledForNewItems: "actionButtonDisabledForNewItems", addButtonLabel: "addButtonLabel", maxItemCount: "maxItemCount", allowAllItemRemoval: "allowAllItemRemoval", noItemsErrorMessage: "noItemsErrorMessage" }, outputs: { onItemActionClick: "onItemActionClick", onItemAddClick: "onItemAddClick", onItemRemoveClick: "onItemRemoveClick", onItemDropdownChange: "onItemDropdownChange", onItemMove: "onItemMove" }, usesInheritance: true, ngImport: i0, template: "<form [formGroup]=\"form\" cdkDropList (cdkDropListDropped)=\"onListItemDrop($event)\">\n    <div *ngFor=\"let item of listItems; let i=index; let last=last;\" cdkDrag\n        class=\"drag-and-drop-list-item border-top\" [class.border-bottom]=\"last\">\n        <div class=\"item-prefix-cell mr-3\">\n            {{ listItemPrefix || text.defaultListItemPrefix }} {{ i + 1 }}\n        </div>\n        <div *ngIf=\"dropdownOptions.length === 0\" class=\"d-flex justify-content-center flex-column mr-1\">\n            <div class=\"d-inline-flex align-items-center\">\n                <ui-core-icon *ngIf=\"item.labelIcon\" class=\"mr-1 d-inline-flex align-items-center\"\n                    [icon]=\"item.labelIcon\">\n                </ui-core-icon>\n                <span class=\"text-semibold\">{{ item.label }}</span>\n            </div>\n            <div *ngIf=\"item.message\" class=\"text-clamp-2 text-caption mt-1\">\n                {{ item.message }}\n            </div>\n        </div>\n        <div *ngIf=\"dropdownOptions.length\" class=\"dropdown-container\">\n            <ui-forms-dropdown\n                class=\"my-2 form-control-validation-m-0\"\n                [errorMessage]=\"dropdownErrorMessage || text.defaultDropdownErrorMessage\"\n                [formControlName]=\"'dropdown' + item.formControlIndex\" \n                [hideLabel]=\"true\" \n                [label]=\"text.defaultListItemPrefix + ' ' + (i + 1) + ' ' + text.dropdownAriaLabel\"\n                [options]=\"item.dropdownOptions\" \n                (change)=\"onDropdownChange($event, i)\">\n            </ui-forms-dropdown>\n        </div>\n        <div class=\"buttons-container mr-2\">\n            <ui-core-badge *ngIf=\"item.badgeLabel\" \n                class=\"mr-7\" \n                [message]=\"item.badgeLabel\" \n                theme=\"success\">\n            </ui-core-badge>\n            <ui-core-button *ngIf=\"!item.hideRemoveButton\"\n                buttonClass=\"mr-3\"\n                [disabled]=\"listItems.length === 1 && !allowAllItemRemoval\"\n                icon=\"remove_circle\"\n                [message]=\"text.removeButtonLabel\"\n                (click)=\"removeListItem(item, i)\">\n            </ui-core-button>\n            <ui-core-button *ngIf=\"item.actionButtonLabel\"\n                buttonClass=\"mr-3\"\n                [disabled]=\"item.actionDisabled\"\n                [icon]=\"item.actionButtonIcon\"\n                [message]=\"item.actionButtonLabel\"\n                (click)=\"onListItemAction(item)\">\n            </ui-core-button>\n            <ui-core-icon class=\"drag-icon\" icon=\"drag_indicator\" size=\"xl\">\n            </ui-core-icon>\n        </div>\n    </div>\n    <ui-core-in-line-notification *ngIf=\"listItems.length === 0 && noItemsErrorMessage\"\n        theme=\"error\" [message]=\"noItemsErrorMessage\">\n    </ui-core-in-line-notification>\n    <div *ngIf=\"addButtonLabel\" class=\"mt-2\">\n        <ui-core-button \n            [disabled]=\"listItems?.length >= actualMaxItemCount\" \n            icon=\"add_circle\" \n            [message]=\"addButtonLabel\" \n            (click)=\"addNewListItem()\">\n        </ui-core-button>\n    </div>\n</form>", styles: [".drag-and-drop-list-item{background:var(--neutral-bg-color);display:flex;min-height:5rem}.drag-and-drop-list-item:hover{cursor:grab}.drag-and-drop-list-item:active{cursor:grabbing}.item-prefix-cell{background-color:var(--gray-100);font-weight:var(--font-weight-semibold);display:flex;align-items:center;justify-content:center;min-width:5.563rem}.dropdown-container{flex:1 1 auto;max-width:25rem}.buttons-container{display:flex;align-items:center;margin-left:auto}.drag-icon{margin-top:10px}.cdk-drag-placeholder{opacity:.3;border-bottom:1px solid var(--stroke-medium);border-left:none;border-right:none;border-top:none}.cdk-drag-preview{border-bottom:1px solid var(--stroke-medium);opacity:.8}\n"], dependencies: [{ kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i4$1.CdkDropList, selector: "[cdkDropList], cdk-drop-list", inputs: ["cdkDropListConnectedTo", "cdkDropListData", "cdkDropListOrientation", "id", "cdkDropListLockAxis", "cdkDropListDisabled", "cdkDropListSortingDisabled", "cdkDropListEnterPredicate", "cdkDropListSortPredicate", "cdkDropListAutoScrollDisabled", "cdkDropListAutoScrollStep", "cdkDropListElementContainer", "cdkDropListHasAnchor"], outputs: ["cdkDropListDropped", "cdkDropListEntered", "cdkDropListExited", "cdkDropListSorted"], exportAs: ["cdkDropList"] }, { kind: "directive", type: i4$1.CdkDrag, selector: "[cdkDrag]", inputs: ["cdkDragData", "cdkDragLockAxis", "cdkDragRootElement", "cdkDragBoundary", "cdkDragStartDelay", "cdkDragFreeDragPosition", "cdkDragDisabled", "cdkDragConstrainPosition", "cdkDragPreviewClass", "cdkDragPreviewContainer", "cdkDragScale"], outputs: ["cdkDragStarted", "cdkDragReleased", "cdkDragEnded", "cdkDragEntered", "cdkDragExited", "cdkDragDropped", "cdkDragMoved"], exportAs: ["cdkDrag"] }, { kind: "directive", type: i2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i1.BadgeComponent, selector: "ui-core-badge", inputs: ["message", "framed", "theme", "type", "centered", "icon", "iconPosition"] }, { kind: "component", type: i1.ButtonComponent, selector: "ui-core-button", inputs: ["themeGroup", "theme", "message", "icon", "iconPosition", "disabled", "disabledMessage", "showSpinner", "buttonClass", "width", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "ariaLabel", "isFormValid", "e2e", "buttonId"] }, { kind: "component", type: i1.IconComponent, selector: "ui-core-icon", inputs: ["icon", "size", "colorClass", "allowEmojis", "ariaLabel", "alignWithText"] }, { kind: "component", type: i1.InLineNotificationComponent, selector: "ui-core-in-line-notification", inputs: ["header", "message", "bulletList", "theme", "customIcon", "buttons", "showCloseButton"], outputs: ["onButtonClick", "onClose"] }, { kind: "component", type: i5.DropdownComponent, selector: "ui-forms-dropdown", inputs: ["iconLeft", "showMenuOptionAsIconLeft", "options", "noOptionsMessage", "actions", "menuIconsOnRight", "allowEmojis"], outputs: ["onMenuSelection"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: DragAndDropListComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-management-drag-and-drop-list', template: "<form [formGroup]=\"form\" cdkDropList (cdkDropListDropped)=\"onListItemDrop($event)\">\n    <div *ngFor=\"let item of listItems; let i=index; let last=last;\" cdkDrag\n        class=\"drag-and-drop-list-item border-top\" [class.border-bottom]=\"last\">\n        <div class=\"item-prefix-cell mr-3\">\n            {{ listItemPrefix || text.defaultListItemPrefix }} {{ i + 1 }}\n        </div>\n        <div *ngIf=\"dropdownOptions.length === 0\" class=\"d-flex justify-content-center flex-column mr-1\">\n            <div class=\"d-inline-flex align-items-center\">\n                <ui-core-icon *ngIf=\"item.labelIcon\" class=\"mr-1 d-inline-flex align-items-center\"\n                    [icon]=\"item.labelIcon\">\n                </ui-core-icon>\n                <span class=\"text-semibold\">{{ item.label }}</span>\n            </div>\n            <div *ngIf=\"item.message\" class=\"text-clamp-2 text-caption mt-1\">\n                {{ item.message }}\n            </div>\n        </div>\n        <div *ngIf=\"dropdownOptions.length\" class=\"dropdown-container\">\n            <ui-forms-dropdown\n                class=\"my-2 form-control-validation-m-0\"\n                [errorMessage]=\"dropdownErrorMessage || text.defaultDropdownErrorMessage\"\n                [formControlName]=\"'dropdown' + item.formControlIndex\" \n                [hideLabel]=\"true\" \n                [label]=\"text.defaultListItemPrefix + ' ' + (i + 1) + ' ' + text.dropdownAriaLabel\"\n                [options]=\"item.dropdownOptions\" \n                (change)=\"onDropdownChange($event, i)\">\n            </ui-forms-dropdown>\n        </div>\n        <div class=\"buttons-container mr-2\">\n            <ui-core-badge *ngIf=\"item.badgeLabel\" \n                class=\"mr-7\" \n                [message]=\"item.badgeLabel\" \n                theme=\"success\">\n            </ui-core-badge>\n            <ui-core-button *ngIf=\"!item.hideRemoveButton\"\n                buttonClass=\"mr-3\"\n                [disabled]=\"listItems.length === 1 && !allowAllItemRemoval\"\n                icon=\"remove_circle\"\n                [message]=\"text.removeButtonLabel\"\n                (click)=\"removeListItem(item, i)\">\n            </ui-core-button>\n            <ui-core-button *ngIf=\"item.actionButtonLabel\"\n                buttonClass=\"mr-3\"\n                [disabled]=\"item.actionDisabled\"\n                [icon]=\"item.actionButtonIcon\"\n                [message]=\"item.actionButtonLabel\"\n                (click)=\"onListItemAction(item)\">\n            </ui-core-button>\n            <ui-core-icon class=\"drag-icon\" icon=\"drag_indicator\" size=\"xl\">\n            </ui-core-icon>\n        </div>\n    </div>\n    <ui-core-in-line-notification *ngIf=\"listItems.length === 0 && noItemsErrorMessage\"\n        theme=\"error\" [message]=\"noItemsErrorMessage\">\n    </ui-core-in-line-notification>\n    <div *ngIf=\"addButtonLabel\" class=\"mt-2\">\n        <ui-core-button \n            [disabled]=\"listItems?.length >= actualMaxItemCount\" \n            icon=\"add_circle\" \n            [message]=\"addButtonLabel\" \n            (click)=\"addNewListItem()\">\n        </ui-core-button>\n    </div>\n</form>", styles: [".drag-and-drop-list-item{background:var(--neutral-bg-color);display:flex;min-height:5rem}.drag-and-drop-list-item:hover{cursor:grab}.drag-and-drop-list-item:active{cursor:grabbing}.item-prefix-cell{background-color:var(--gray-100);font-weight:var(--font-weight-semibold);display:flex;align-items:center;justify-content:center;min-width:5.563rem}.dropdown-container{flex:1 1 auto;max-width:25rem}.buttons-container{display:flex;align-items:center;margin-left:auto}.drag-icon{margin-top:10px}.cdk-drag-placeholder{opacity:.3;border-bottom:1px solid var(--stroke-medium);border-left:none;border-right:none;border-top:none}.cdk-drag-preview{border-bottom:1px solid var(--stroke-medium);opacity:.8}\n"] }]
        }], ctorParameters: () => [{ type: i2.FormBuilder }, { type: i1.TextService }], propDecorators: { listItems: [{
                type: Input
            }], listItemPrefix: [{
                type: Input
            }], dropdownOptions: [{
                type: Input
            }], dropdownOptionsShouldBeUnique: [{
                type: Input
            }], dropdownErrorMessage: [{
                type: Input
            }], actionButtonDisabledForNewItems: [{
                type: Input
            }], addButtonLabel: [{
                type: Input
            }], maxItemCount: [{
                type: Input
            }], allowAllItemRemoval: [{
                type: Input
            }], noItemsErrorMessage: [{
                type: Input
            }], onItemActionClick: [{
                type: Output
            }], onItemAddClick: [{
                type: Output
            }], onItemRemoveClick: [{
                type: Output
            }], onItemDropdownChange: [{
                type: Output
            }], onItemMove: [{
                type: Output
            }] } });

class JsonDiffComponent extends BaseTextComponent {
    constructor(textService) {
        super(textService, 'ui-management-json-diff');
        /**
        * String label of previous/first/left diff pane
        **/
        this.previousDiffTitle = '';
        /**
        * String label of current/second/right diff pane
        **/
        this.currentDiffTitle = '';
        /**
        * Height of diff-view - requires a fixed height for the editor to measure & size-to, minimum 200
        **/
        this.height = 200;
        this.diffOptions = {
            automaticLayout: true,
            folding: true,
            language: 'json',
            readOnly: true,
            scrollBeyondLastLine: false
        };
    }
    ngOnChanges() {
        this.previousDiffData = this.buildMonacoDiffModel(this.previousData);
        this.currentDiffData = this.buildMonacoDiffModel(this.currentData);
    }
    buildMonacoDiffModel(value) {
        return {
            language: 'application/json',
            code: JSON.stringify(value, null, 4)
        };
    }
    getDefaultText() {
        return {
            previousDiffTitle: 'Previous:',
            currentDiffTitle: 'Selected:'
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: JsonDiffComponent, deps: [{ token: i1.TextService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.17", type: JsonDiffComponent, isStandalone: false, selector: "ui-management-json-diff", inputs: { previousData: "previousData", currentData: "currentData", previousDiffTitle: "previousDiffTitle", currentDiffTitle: "currentDiffTitle", height: "height" }, usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div class=\"json-header\">\n  <h5>{{ previousDiffTitle || text.previousDiffTitle }}</h5>\n  <h5>{{ currentDiffTitle || text.currentDiffTitle }}</h5>\n</div>\n<div class=\"json-wrapper\" [ngStyle]=\"{ 'height': height + 'px' }\">\n  <ngx-monaco-diff-editor [options]=\"diffOptions\" [originalModel]=\"previousDiffData\" [modifiedModel]=\"currentDiffData\" class=\"h-100\"></ngx-monaco-diff-editor>\n</div>\n", styles: [".json-header{display:flex;margin-top:8px}.json-header h5{margin-bottom:0;text-align:center;width:50%}.json-wrapper{margin-top:8px;overflow:auto;resize:vertical}\n"], dependencies: [{ kind: "directive", type: i3.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "component", type: i4$2.DiffEditorComponent, selector: "ngx-monaco-diff-editor", inputs: ["options", "originalModel", "modifiedModel"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: JsonDiffComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-management-json-diff', template: "<div class=\"json-header\">\n  <h5>{{ previousDiffTitle || text.previousDiffTitle }}</h5>\n  <h5>{{ currentDiffTitle || text.currentDiffTitle }}</h5>\n</div>\n<div class=\"json-wrapper\" [ngStyle]=\"{ 'height': height + 'px' }\">\n  <ngx-monaco-diff-editor [options]=\"diffOptions\" [originalModel]=\"previousDiffData\" [modifiedModel]=\"currentDiffData\" class=\"h-100\"></ngx-monaco-diff-editor>\n</div>\n", styles: [".json-header{display:flex;margin-top:8px}.json-header h5{margin-bottom:0;text-align:center;width:50%}.json-wrapper{margin-top:8px;overflow:auto;resize:vertical}\n"] }]
        }], ctorParameters: () => [{ type: i1.TextService }], propDecorators: { previousData: [{
                type: Input
            }], currentData: [{
                type: Input
            }], previousDiffTitle: [{
                type: Input
            }], currentDiffTitle: [{
                type: Input
            }], height: [{
                type: Input
            }] } });

function isValidJSON(control) {
    const value = control?.value || '';
    if (value) {
        try {
            JSON.parse(value);
        }
        catch (e) {
            // An error means this is invalid JSON.
            return { invalidJSON: true };
        }
    }
    return null;
}
function isValidArrayOfStrings(control) {
    const value = control?.value || '';
    let jsonObject = null;
    if (value) {
        try {
            jsonObject = JSON.parse(control.value);
        }
        catch (e) {
            // An error means this is invalid JSON.
            return { invalidJSON: true };
        }
    }
    if (!jsonObject || !Array.isArray(jsonObject)) {
        return { invalidArray: true };
    }
    if (jsonObject.some((v) => typeof v !== 'string')) {
        return { invalidArrayOfStrings: true };
    }
    return null;
}

const MIN_HEIGHT$1 = 100;
const INITIAL_HEIGHT$1 = 200;
class JsonEditorComponent extends BaseEditorComponent {
    constructor(textService, controlContainer) {
        super(textService, 'ui-management-json-editor', controlContainer);
        this.textService = textService;
        /**
        * Height of editor - requires a fixed height for the editor to measure & size-to, minimum 100
        **/
        this.height = INITIAL_HEIGHT$1;
        /**
        * Display editor as read-only initially, but allow edit on button click
        **/
        this.showEditToggle = false;
        /**
        * When used as part of a form, this will enforce the JSON value is an array of strings
        **/
        this.stringArrayOnly = false;
        this.editorOptions = {
            automaticLayout: true,
            folding: true,
            language: 'json',
            readOnly: false,
            scrollBeyondLastLine: false,
        };
        this.readOnly = false;
        this.readOnlyValue = '';
        this.heightStyles = {};
        this.initialHeight = '';
        this.minHeight = MIN_HEIGHT$1 + 'px';
        this.setInitialHeight(INITIAL_HEIGHT$1);
        // Set up custom error messages for validators
        this.errorMessageMap.set('invalidJSON', this.text.invalidJSONErrorMessage);
        this.errorMessageMap.set('invalidArray', this.text.invalidArrayErrorMessage);
        this.errorMessageMap.set('invalidArrayOfStrings', this.text.invalidStringArrayErrorMessage);
    }
    ngOnChanges(changes) {
        this.setReadonlyValue();
        this.locked = this.locked || !this.controlName;
        const newReadOnlyValue = this.showEditToggle || this.locked;
        // Do not set height here, as it will be set in ngAfterViewInit
        const updateValidation = this.setReadonlyFlag(newReadOnlyValue, false);
        if (changes.stringArrayOnly || updateValidation) {
            this.updateValidators('onChanges');
        }
    }
    ngAfterViewInit() {
        if (this.readOnly && !this.readOnlyValue) {
            this.readOnlyValue = this.value;
        }
        // The default height is set once by the constructor.
        // Wait for content to load, then set the height from the input.
        // Note: since we are letting the user resize content, not going to respect the height input
        // via ngOnChanges.
        this.setInitialHeight(this.height);
    }
    setInitialHeight(height) {
        const heightInPx = (!height || height < MIN_HEIGHT$1 ? MIN_HEIGHT$1 : height) + 'px';
        if (heightInPx === this.initialHeight) {
            return;
        }
        // Used by the scrollbox
        this.initialHeight = heightInPx;
        // Used by the editor
        this.heightStyles = {
            height: this.initialHeight,
            minHeight: this.minHeight
        };
    }
    edit() {
        const updateValidation = this.setReadonlyFlag(false, true);
        if (updateValidation) {
            // Technically not onChanges, but we want to look for any changed validators and re-apply them,
            // which is what onChanges does. But in this instance, we don't need to call updateValueAndValidity.
            // This is because the monaco component will load in, and wire up the form controls, which runs validation.
            // Calling updateValueAndValidity causes expensive json validation to run excessively.
            this.updateValidators('onChanges', false);
        }
    }
    setReadonlyFlag(newValue, setHeight) {
        const readOnlyStateChanged = newValue !== this.readOnly;
        if (readOnlyStateChanged) {
            this.readOnly = newValue;
            this.editorOptions.readOnly = newValue;
            // Grab the current height of the container, and use it as the initial height.
            // This will keep the two modes in sync with one another (scrollbox vs editor).
            if (setHeight && this.resizeContainer?.nativeElement) {
                const actualHeight = this.resizeContainer.nativeElement.clientHeight;
                this.setInitialHeight(actualHeight);
            }
        }
        // When the component is in readonly state, we do not apply validators (parsing json can be expensive).
        // If readonly stage changed, and we are no longer readonly, we need to apply validators.
        return readOnlyStateChanged && !this.readOnly;
    }
    setReadonlyValue() {
        if (this.controlName) {
            this.readOnlyValue = this.value || '';
        }
        else if (this.data) {
            this.readOnlyValue = JSON.stringify(this.data, null, 2) || '';
        }
        else {
            this.readOnlyValue = '';
        }
    }
    onValueChange(value) {
        this.readOnlyValue = value;
    }
    getValidators() {
        if (this.readOnly) {
            return [];
        }
        // To avoid parsing JSON strings in multiple validators, apply only one or the other at a time.
        if (this.stringArrayOnly) {
            return [isValidArrayOfStrings];
        }
        return [isValidJSON];
    }
    getDefaultText() {
        return {
            editButtonLabel: 'Edit',
            invalidJSONErrorMessage: 'Must be valid JSON',
            invalidArrayErrorMessage: 'Must be a valid JSON array',
            invalidStringArrayErrorMessage: 'Array may only contain string values'
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: JsonEditorComponent, deps: [{ token: i1.TextService }, { token: i2.ControlContainer, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.17", type: JsonEditorComponent, isStandalone: false, selector: "ui-management-json-editor", inputs: { data: "data", height: "height", showEditToggle: "showEditToggle", stringArrayOnly: "stringArrayOnly" }, viewQueries: [{ propertyName: "resizeContainer", first: true, predicate: ["resizeContainer"], descendants: true }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div class=\"label-container\"\n  [class.justify-content-between]=\"showEditToggle && !locked && !hideLabel\"\n  [class.justify-content-end]=\"showEditToggle && !locked && hideLabel\">\n  <label *ngIf=\"!hideLabel\" uiCoreReplayUnmask [for]=\"fieldId\" [id]=\"labelId\">\n    {{ label }}\n    <ui-forms-label-tooltips\n        [label]=\"label\"\n        [locked]=\"locked\"\n        [lockedMessage]=\"lockedMessage\"\n        [tooltip]=\"tooltip\"\n        [tooltipPlacement]=\"tooltipPlacement\"\n        [e2e]=\"e2ePrefix\"\n    ></ui-forms-label-tooltips>\n  </label>\n  <div *ngIf=\"showEditToggle && !locked\">\n    <ui-core-button (click)=\"edit()\" [message]=\"text.editButtonLabel\" icon=\"edit\" [class.invisible]=\"!readOnly\" buttonClass=\"py-0\"></ui-core-button>\n  </div>\n</div>\n\n<div [class.mt-1]=\"(showEditToggle && !locked) || (label && !hideLabel)\" #resizeContainer>\n    <ui-core-scrollbox *ngIf=\"readOnly\" [content]=\"readOnlyValue\" [codeView]=\"true\" [locked]=\"locked\"\n        [height]=\"initialHeight\" [minHeight]=\"minHeight\">\n    </ui-core-scrollbox>\n    <div *ngIf=\"!readOnly\" class=\"json-wrapper-resize\" [ngStyle]=\"heightStyles\">\n        <div class=\"h-100 container-form\">\n            <ngx-monaco-editor [formControlName]=\"controlName\" [options]=\"editorOptions\" class=\"h-100\"></ngx-monaco-editor>\n        </div>\n    </div>\n</div>\n\n<ui-forms-field-validation *ngIf=\"controlName && !readOnly && !locked\"\n  [ariaInputName]=\"label\"\n  [errorMessage]=\"customErrorMessage || errorMessage\"\n  [infoMessage]=\"infoMessage\"\n  [successMessage]=\"successMessage\"\n  [warningMessage]=\"warningMessage\"\n  [fieldId]=\"fieldId\"\n  [locked]=\"locked\">\n</ui-forms-field-validation>\n", styles: [".json-wrapper-resize{overflow:auto;resize:vertical}.container-form{padding:12px 0}\n"], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i3.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "component", type: i4$2.EditorComponent, selector: "ngx-monaco-editor", inputs: ["options", "model"] }, { kind: "directive", type: i2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i1.ButtonComponent, selector: "ui-core-button", inputs: ["themeGroup", "theme", "message", "icon", "iconPosition", "disabled", "disabledMessage", "showSpinner", "buttonClass", "width", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "ariaLabel", "isFormValid", "e2e", "buttonId"] }, { kind: "component", type: i1.ScrollboxComponent, selector: "ui-core-scrollbox", inputs: ["content", "emitScroll", "message", "ariaLabel", "codeView", "locked", "e2e", "height", "minHeight"], outputs: ["scrolled"] }, { kind: "directive", type: i1.ReplayUnmaskDirective, selector: "[uiCoreReplayUnmask]" }, { kind: "component", type: i5.FieldValidationComponent, selector: "ui-forms-field-validation", inputs: ["fieldId", "locked", "errorMessage", "infoMessage", "successMessage", "warningMessage", "ariaInputName", "criteria", "criteriaDescription"] }, { kind: "component", type: i5.LabelTooltipsComponent, selector: "ui-forms-label-tooltips", inputs: ["label", "locked", "lockedMessage", "tooltip", "tooltipPlacement", "e2e", "tooltipClass"] }], viewProviders: [
            {
                provide: ControlContainer,
                useExisting: FormGroupDirective
            }
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: JsonEditorComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-management-json-editor', viewProviders: [
                        {
                            provide: ControlContainer,
                            useExisting: FormGroupDirective
                        }
                    ], template: "<div class=\"label-container\"\n  [class.justify-content-between]=\"showEditToggle && !locked && !hideLabel\"\n  [class.justify-content-end]=\"showEditToggle && !locked && hideLabel\">\n  <label *ngIf=\"!hideLabel\" uiCoreReplayUnmask [for]=\"fieldId\" [id]=\"labelId\">\n    {{ label }}\n    <ui-forms-label-tooltips\n        [label]=\"label\"\n        [locked]=\"locked\"\n        [lockedMessage]=\"lockedMessage\"\n        [tooltip]=\"tooltip\"\n        [tooltipPlacement]=\"tooltipPlacement\"\n        [e2e]=\"e2ePrefix\"\n    ></ui-forms-label-tooltips>\n  </label>\n  <div *ngIf=\"showEditToggle && !locked\">\n    <ui-core-button (click)=\"edit()\" [message]=\"text.editButtonLabel\" icon=\"edit\" [class.invisible]=\"!readOnly\" buttonClass=\"py-0\"></ui-core-button>\n  </div>\n</div>\n\n<div [class.mt-1]=\"(showEditToggle && !locked) || (label && !hideLabel)\" #resizeContainer>\n    <ui-core-scrollbox *ngIf=\"readOnly\" [content]=\"readOnlyValue\" [codeView]=\"true\" [locked]=\"locked\"\n        [height]=\"initialHeight\" [minHeight]=\"minHeight\">\n    </ui-core-scrollbox>\n    <div *ngIf=\"!readOnly\" class=\"json-wrapper-resize\" [ngStyle]=\"heightStyles\">\n        <div class=\"h-100 container-form\">\n            <ngx-monaco-editor [formControlName]=\"controlName\" [options]=\"editorOptions\" class=\"h-100\"></ngx-monaco-editor>\n        </div>\n    </div>\n</div>\n\n<ui-forms-field-validation *ngIf=\"controlName && !readOnly && !locked\"\n  [ariaInputName]=\"label\"\n  [errorMessage]=\"customErrorMessage || errorMessage\"\n  [infoMessage]=\"infoMessage\"\n  [successMessage]=\"successMessage\"\n  [warningMessage]=\"warningMessage\"\n  [fieldId]=\"fieldId\"\n  [locked]=\"locked\">\n</ui-forms-field-validation>\n", styles: [".json-wrapper-resize{overflow:auto;resize:vertical}.container-form{padding:12px 0}\n"] }]
        }], ctorParameters: () => [{ type: i1.TextService }, { type: i2.ControlContainer, decorators: [{
                    type: Optional
                }] }], propDecorators: { resizeContainer: [{
                type: ViewChild,
                args: ['resizeContainer']
            }], data: [{
                type: Input
            }], height: [{
                type: Input
            }], showEditToggle: [{
                type: Input
            }], stringArrayOnly: [{
                type: Input
            }] } });

const MIN_HEIGHT = 100;
const INITIAL_HEIGHT = 200;
class MarkdownEditorComponent extends BaseEditorComponent {
    constructor(textService, controlContainer) {
        super(textService, 'ui-management-markdown-editor', controlContainer);
        this.textService = textService;
        /**
        * Height of editor - requires a fixed height for the editor to measure & size-to, minimum 100
        **/
        this.height = INITIAL_HEIGHT;
        /**
        * Display editor as read-only initially, but allow edit on button click
        **/
        this.showEditToggle = false;
        this.editorOptions = {
            automaticLayout: true,
            folding: true,
            language: 'markdown',
            readOnly: false,
            scrollBeyondLastLine: false,
        };
        this.readOnly = false;
        this.readOnlyValue = '';
        this.heightStyles = {};
        this.initialHeight = '';
        this.minHeight = MIN_HEIGHT + 'px';
        this.setInitialHeight(INITIAL_HEIGHT);
    }
    ngOnChanges(changes) {
        this.setReadonlyValue(this.value);
        this.locked = this.locked || !this.controlName;
        const newReadOnlyValue = this.showEditToggle || this.locked;
        // Do not set height here, as it will be set in ngAfterViewInit
        this.setReadonlyFlag(newReadOnlyValue, false);
    }
    ngAfterViewInit() {
        if (this.readOnly && !this.readOnlyValue) {
            this.readOnlyValue = this.value;
            this.setReadonlyValue(this.value);
        }
        // The default height is set once by the constructor.
        // Wait for content to load, then set the height from the input.
        // Note: since we are letting the user resize content, not going to respect the height input
        // via ngOnChanges.
        this.setInitialHeight(this.height);
    }
    setInitialHeight(height) {
        const heightInPx = (!height || height < MIN_HEIGHT ? MIN_HEIGHT : height) + 'px';
        if (heightInPx === this.initialHeight) {
            return;
        }
        // Used by the scrollbox
        this.initialHeight = heightInPx;
        // Used by the editor
        this.heightStyles = {
            height: this.initialHeight,
            minHeight: this.minHeight
        };
    }
    edit() {
        this.setReadonlyFlag(false, true);
    }
    setReadonlyFlag(newValue, setHeight) {
        const readOnlyStateChanged = newValue !== this.readOnly;
        if (readOnlyStateChanged) {
            this.readOnly = newValue;
            this.editorOptions.readOnly = newValue;
            // Grab the current height of the container, and use it as the initial height.
            // This will keep the two modes in sync with one another (scrollbox vs editor).
            if (setHeight && this.resizeContainer?.nativeElement) {
                const actualHeight = this.resizeContainer.nativeElement.clientHeight;
                this.setInitialHeight(actualHeight);
            }
        }
    }
    setReadonlyValue(incomingValue) {
        const parsedValue = marked.parse(incomingValue || '');
        this.readOnlyValue = parsedValue;
    }
    onValueChange(value) {
        this.setReadonlyValue(value);
    }
    getValidators() {
        // The base class returns an empty array, but using this as a placeholder for a comment.
        // The reality is that markdown isn't something that can be validated easily, since any
        // text is valid markdown. Previewing is the best way to validate markdown.
        return [];
    }
    getDefaultText() {
        return {
            editButtonLabel: 'Edit'
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: MarkdownEditorComponent, deps: [{ token: i1.TextService }, { token: i2.ControlContainer, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.17", type: MarkdownEditorComponent, isStandalone: false, selector: "ui-management-markdown-editor", inputs: { height: "height", showEditToggle: "showEditToggle" }, viewQueries: [{ propertyName: "resizeContainer", first: true, predicate: ["resizeContainer"], descendants: true }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div class=\"label-container\"\n  [class.justify-content-between]=\"showEditToggle && !locked && !hideLabel\"\n  [class.justify-content-end]=\"showEditToggle && !locked && hideLabel\">\n  <label *ngIf=\"!hideLabel\" uiCoreReplayUnmask [for]=\"fieldId\" [id]=\"labelId\">\n    {{ label }}\n    <ui-forms-label-tooltips\n        [label]=\"label\"\n        [locked]=\"locked\"\n        [lockedMessage]=\"lockedMessage\"\n        [tooltip]=\"tooltip\"\n        [tooltipPlacement]=\"tooltipPlacement\"\n        [e2e]=\"e2ePrefix\"\n    ></ui-forms-label-tooltips>\n  </label>\n  <div *ngIf=\"showEditToggle && !locked\">\n    <ui-core-button (click)=\"edit()\" [message]=\"text.editButtonLabel\" icon=\"edit\" [class.invisible]=\"!readOnly\" buttonClass=\"py-0\"></ui-core-button>\n  </div>\n</div>\n\n<div [class.mt-1]=\"(showEditToggle && !locked) || (label && !hideLabel)\" #resizeContainer>\n    <ui-core-scrollbox *ngIf=\"readOnly\" [content]=\"readOnlyValue\" [locked]=\"locked\"\n        [height]=\"initialHeight\" [minHeight]=\"minHeight\">\n    </ui-core-scrollbox>\n    <div *ngIf=\"!readOnly\" class=\"markdown-wrapper-resize\" [ngStyle]=\"heightStyles\">\n        <div class=\"h-100 container-form\" >\n            <ngx-monaco-editor [formControlName]=\"controlName\" [options]=\"editorOptions\" class=\"h-100\"></ngx-monaco-editor>\n        </div>\n    </div>\n</div>\n\n<ui-forms-field-validation *ngIf=\"controlName && !readOnly && !locked\"\n  [ariaInputName]=\"label\"\n  [errorMessage]=\"customErrorMessage || errorMessage\"\n  [infoMessage]=\"infoMessage\"\n  [successMessage]=\"successMessage\"\n  [warningMessage]=\"warningMessage\"\n  [fieldId]=\"fieldId\"\n  [locked]=\"locked\">\n</ui-forms-field-validation>\n", styles: [".markdown-wrapper-resize{overflow:auto;resize:vertical}.container-form{padding:12px 0}\n"], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i3.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "component", type: i4$2.EditorComponent, selector: "ngx-monaco-editor", inputs: ["options", "model"] }, { kind: "directive", type: i2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i1.ButtonComponent, selector: "ui-core-button", inputs: ["themeGroup", "theme", "message", "icon", "iconPosition", "disabled", "disabledMessage", "showSpinner", "buttonClass", "width", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "ariaLabel", "isFormValid", "e2e", "buttonId"] }, { kind: "component", type: i1.ScrollboxComponent, selector: "ui-core-scrollbox", inputs: ["content", "emitScroll", "message", "ariaLabel", "codeView", "locked", "e2e", "height", "minHeight"], outputs: ["scrolled"] }, { kind: "directive", type: i1.ReplayUnmaskDirective, selector: "[uiCoreReplayUnmask]" }, { kind: "component", type: i5.FieldValidationComponent, selector: "ui-forms-field-validation", inputs: ["fieldId", "locked", "errorMessage", "infoMessage", "successMessage", "warningMessage", "ariaInputName", "criteria", "criteriaDescription"] }, { kind: "component", type: i5.LabelTooltipsComponent, selector: "ui-forms-label-tooltips", inputs: ["label", "locked", "lockedMessage", "tooltip", "tooltipPlacement", "e2e", "tooltipClass"] }], viewProviders: [
            {
                provide: ControlContainer,
                useExisting: FormGroupDirective
            }
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: MarkdownEditorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ui-management-markdown-editor', viewProviders: [
                        {
                            provide: ControlContainer,
                            useExisting: FormGroupDirective
                        }
                    ], standalone: false, template: "<div class=\"label-container\"\n  [class.justify-content-between]=\"showEditToggle && !locked && !hideLabel\"\n  [class.justify-content-end]=\"showEditToggle && !locked && hideLabel\">\n  <label *ngIf=\"!hideLabel\" uiCoreReplayUnmask [for]=\"fieldId\" [id]=\"labelId\">\n    {{ label }}\n    <ui-forms-label-tooltips\n        [label]=\"label\"\n        [locked]=\"locked\"\n        [lockedMessage]=\"lockedMessage\"\n        [tooltip]=\"tooltip\"\n        [tooltipPlacement]=\"tooltipPlacement\"\n        [e2e]=\"e2ePrefix\"\n    ></ui-forms-label-tooltips>\n  </label>\n  <div *ngIf=\"showEditToggle && !locked\">\n    <ui-core-button (click)=\"edit()\" [message]=\"text.editButtonLabel\" icon=\"edit\" [class.invisible]=\"!readOnly\" buttonClass=\"py-0\"></ui-core-button>\n  </div>\n</div>\n\n<div [class.mt-1]=\"(showEditToggle && !locked) || (label && !hideLabel)\" #resizeContainer>\n    <ui-core-scrollbox *ngIf=\"readOnly\" [content]=\"readOnlyValue\" [locked]=\"locked\"\n        [height]=\"initialHeight\" [minHeight]=\"minHeight\">\n    </ui-core-scrollbox>\n    <div *ngIf=\"!readOnly\" class=\"markdown-wrapper-resize\" [ngStyle]=\"heightStyles\">\n        <div class=\"h-100 container-form\" >\n            <ngx-monaco-editor [formControlName]=\"controlName\" [options]=\"editorOptions\" class=\"h-100\"></ngx-monaco-editor>\n        </div>\n    </div>\n</div>\n\n<ui-forms-field-validation *ngIf=\"controlName && !readOnly && !locked\"\n  [ariaInputName]=\"label\"\n  [errorMessage]=\"customErrorMessage || errorMessage\"\n  [infoMessage]=\"infoMessage\"\n  [successMessage]=\"successMessage\"\n  [warningMessage]=\"warningMessage\"\n  [fieldId]=\"fieldId\"\n  [locked]=\"locked\">\n</ui-forms-field-validation>\n", styles: [".markdown-wrapper-resize{overflow:auto;resize:vertical}.container-form{padding:12px 0}\n"] }]
        }], ctorParameters: () => [{ type: i1.TextService }, { type: i2.ControlContainer, decorators: [{
                    type: Optional
                }] }], propDecorators: { resizeContainer: [{
                type: ViewChild,
                args: ['resizeContainer']
            }], height: [{
                type: Input
            }], showEditToggle: [{
                type: Input
            }] } });

class PanelListComponent {
    constructor() {
        /**
        * Header at the top of the list.
        **/
        this.header = '';
        /**
        * Optional. When provided, an icon button will be rendered in the top right corner of the card.
        **/
        this.headerIcon = '';
        /**
        * Required if headerIcon is provided. The label for the header icon button.
        **/
        this.headerIconLabel = '';
        /**
        * Subheader at the top of the list.
        **/
        this.subheader = '';
        /**
        * Each item shown in the panel.
        **/
        this.items = [];
        /**
        * Emits when the header icon is clicked.
        **/
        this.onHeaderIconClick = new EventEmitter();
        // TODO
        this.e2ePrefix = '';
    }
    headerIconClicked() {
        this.onHeaderIconClick.emit();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: PanelListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.17", type: PanelListComponent, isStandalone: false, selector: "ui-management-panel-list", inputs: { header: "header", headerIcon: "headerIcon", headerIconLabel: "headerIconLabel", subheader: "subheader", items: "items", itemTemplate: "itemTemplate" }, outputs: { onHeaderIconClick: "onHeaderIconClick" }, ngImport: i0, template: "<div class=\"container-bordered p-0 mb-5\" *ngIf=\"items.length > 0\">\n    <div *ngIf=\"header\" class=\"bg-gray-100 border-radius-top p-5\">\n        <div class=\"d-flex align-items-center justify-content-between\">\n            <h2 class=\"text-semibold m-0\">{{ header }}</h2>\n            <ui-core-icon-button *ngIf=\"headerIcon && headerIconLabel\"\n                [message]=\"headerIconLabel\"\n                [icon]=\"headerIcon\"\n                size=\"md\"\n                [e2e]=\"e2ePrefix + 'header-icon'\"\n                (click)=\"headerIconClicked()\"\n            ></ui-core-icon-button>\n        </div>\n        <div *ngIf=\"subheader\" class=\"mt-1\">{{ subheader }}</div>\n    </div>\n    <div class=\"panel-list\">\n        <ng-container *ngFor=\"let item of items; let i=index; let isLast=last\">\n            <div [attr.data-e2e]=\"'panel-list-item-' + i\" class=\"m-5\">\n                <ng-container [ngTemplateOutlet]=\"itemTemplate\" [ngTemplateOutletContext]=\"{item: item, index: i}\">\n                </ng-container>\n            </div>\n            <hr *ngIf=\"!isLast\" class=\"my-0 mx-5\"/>\n        </ng-container>\n    </div>\n</div>", dependencies: [{ kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i3.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: i1.IconButtonComponent, selector: "ui-core-icon-button", inputs: ["message", "icon", "size", "disabled", "buttonClass", "ariaPressed", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "e2e", "theme", "usesGlassHoverState", "buttonId"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: PanelListComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-management-panel-list', template: "<div class=\"container-bordered p-0 mb-5\" *ngIf=\"items.length > 0\">\n    <div *ngIf=\"header\" class=\"bg-gray-100 border-radius-top p-5\">\n        <div class=\"d-flex align-items-center justify-content-between\">\n            <h2 class=\"text-semibold m-0\">{{ header }}</h2>\n            <ui-core-icon-button *ngIf=\"headerIcon && headerIconLabel\"\n                [message]=\"headerIconLabel\"\n                [icon]=\"headerIcon\"\n                size=\"md\"\n                [e2e]=\"e2ePrefix + 'header-icon'\"\n                (click)=\"headerIconClicked()\"\n            ></ui-core-icon-button>\n        </div>\n        <div *ngIf=\"subheader\" class=\"mt-1\">{{ subheader }}</div>\n    </div>\n    <div class=\"panel-list\">\n        <ng-container *ngFor=\"let item of items; let i=index; let isLast=last\">\n            <div [attr.data-e2e]=\"'panel-list-item-' + i\" class=\"m-5\">\n                <ng-container [ngTemplateOutlet]=\"itemTemplate\" [ngTemplateOutletContext]=\"{item: item, index: i}\">\n                </ng-container>\n            </div>\n            <hr *ngIf=\"!isLast\" class=\"my-0 mx-5\"/>\n        </ng-container>\n    </div>\n</div>" }]
        }], propDecorators: { header: [{
                type: Input
            }], headerIcon: [{
                type: Input
            }], headerIconLabel: [{
                type: Input
            }], subheader: [{
                type: Input
            }], items: [{
                type: Input
            }], itemTemplate: [{
                type: Input
            }], onHeaderIconClick: [{
                type: Output
            }] } });

class PanelListItem {
    constructor(data) {
        this.data = data;
        this.id = '';
    }
    static fromObject(data) {
        if (data.data) {
            const item = new PanelListItem(data.data);
            item.id = data.id || '';
            return item;
        }
        return null;
    }
}

class SearchBarComponent extends BaseTextComponent {
    constructor(textService) {
        super(textService, 'ui-management-search-bar');
        /**
        * Set the value externally.
        **/
        this.value = '';
        /**
        * The maximum amount of character input allowed.
        **/
        this.maxLength = DEFAULT_MAX_LENGTH;
        /**
        * Custom placeholder text that appears when no value is entered.
        * Default placeholder text is "Search"
        **/
        this.placeholder = this.text.placeholder;
        /**
        * Set to true to automatically focus the search input after the component is initialized. Defaults to false.
        **/
        this.autoFocus = false;
        /**
        * Customizable text for Search button
        **/
        this.searchButtonText = this.text.searchButtonText;
        /**
        * Customizable label for the searchByText
        **/
        this.searchByLabel = this.text.searchByLabel;
        /**
        * Customizable text to display next to the "Search By:" label
        **/
        this.searchByText = '';
        /**
        * Set to true to set the loading state (if true, component is readonly & shows a spinner)
        **/
        this.loading = false;
        /**
        * Customizable input id
        **/
        this.inputId = HtmlUtils.generateRandomId();
        /**
        * Emits when the search button is clicked
        **/
        this.onSearch = new EventEmitter();
    }
    search() {
        if (this.value) {
            this.onSearch.emit(this.value);
        }
    }
    getDefaultText() {
        return {
            placeholder: 'Search',
            searchByLabel: 'Search by:',
            searchButtonText: 'Search'
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: SearchBarComponent, deps: [{ token: i1.TextService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.17", type: SearchBarComponent, isStandalone: false, selector: "ui-management-search-bar", inputs: { value: "value", maxLength: "maxLength", placeholder: "placeholder", autoFocus: "autoFocus", searchButtonText: "searchButtonText", searchByLabel: "searchByLabel", searchByText: "searchByText", loading: "loading", inputId: "inputId" }, outputs: { onSearch: "onSearch" }, usesInheritance: true, ngImport: i0, template: "<label *ngIf=\"searchByText\" class=\"search-label text-caption form-px\" [for]=\"inputId\">\n  <span class=\"text-strong\">{{ searchByLabel }}</span>\n  {{ searchByText }}\n</label>\n<div class=\"d-flex\">\n  <div class=\"d-flex flex-grow-1\">\n    <ui-forms-search-input\n      [autoFocus]=\"autoFocus\"\n      class=\"w-100\"\n      [class.form-locked]=\"loading\"\n      [inputId]=\"inputId\"\n      [isSearchBar]=\"true\"\n      [locked]=\"loading\"\n      [maxLength]=\"maxLength\"\n      [placeholder]=\"placeholder\"\n      size=\"lg\"\n      [value]=\"value\"\n      (change)=\"value = $event\"\n      (keyup.enter)=\"search()\" />\n  </div>\n  <div>\n    <ui-core-button\n      [message]=\"searchButtonText\"\n      icon=\"search\"\n      theme=\"primary\"\n      buttonClass=\"border-left-flat pl-5 h-100\"\n      [disabled]=\"loading\"\n      [showSpinner]=\"true\"\n      (click)=\"search()\" />\n  </div>\n</div>\n", dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i1.ButtonComponent, selector: "ui-core-button", inputs: ["themeGroup", "theme", "message", "icon", "iconPosition", "disabled", "disabledMessage", "showSpinner", "buttonClass", "width", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "ariaLabel", "isFormValid", "e2e", "buttonId"] }, { kind: "component", type: i5.SearchInputComponent, selector: "ui-forms-search-input", inputs: ["value", "maxLength", "placeholder", "size", "autoFocus", "locked", "inputId", "clearButtonId", "isSearchBar"], outputs: ["inputHasFocus"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: SearchBarComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-management-search-bar', template: "<label *ngIf=\"searchByText\" class=\"search-label text-caption form-px\" [for]=\"inputId\">\n  <span class=\"text-strong\">{{ searchByLabel }}</span>\n  {{ searchByText }}\n</label>\n<div class=\"d-flex\">\n  <div class=\"d-flex flex-grow-1\">\n    <ui-forms-search-input\n      [autoFocus]=\"autoFocus\"\n      class=\"w-100\"\n      [class.form-locked]=\"loading\"\n      [inputId]=\"inputId\"\n      [isSearchBar]=\"true\"\n      [locked]=\"loading\"\n      [maxLength]=\"maxLength\"\n      [placeholder]=\"placeholder\"\n      size=\"lg\"\n      [value]=\"value\"\n      (change)=\"value = $event\"\n      (keyup.enter)=\"search()\" />\n  </div>\n  <div>\n    <ui-core-button\n      [message]=\"searchButtonText\"\n      icon=\"search\"\n      theme=\"primary\"\n      buttonClass=\"border-left-flat pl-5 h-100\"\n      [disabled]=\"loading\"\n      [showSpinner]=\"true\"\n      (click)=\"search()\" />\n  </div>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i1.TextService }], propDecorators: { value: [{
                type: Input
            }], maxLength: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], autoFocus: [{
                type: Input
            }], searchButtonText: [{
                type: Input
            }], searchByLabel: [{
                type: Input
            }], searchByText: [{
                type: Input
            }], loading: [{
                type: Input
            }], inputId: [{
                type: Input
            }], onSearch: [{
                type: Output
            }] } });

class TargetConditionGroup {
}
var TargetGroupOperator;
(function (TargetGroupOperator) {
    TargetGroupOperator["AND"] = "AND";
    TargetGroupOperator["OR"] = "OR";
})(TargetGroupOperator || (TargetGroupOperator = {}));

class TargetingUtils {
    static toDropdownOptions(options) {
        const dropdownOptions = [];
        options.forEach(option => {
            const dOption = typeof option === 'string' ? [option, option] : [option.label, option.value];
            dropdownOptions.push(new DropdownOption(...dOption));
        });
        return dropdownOptions;
    }
}

class TargetCondition {
}
var ConditionOperator;
(function (ConditionOperator) {
    ConditionOperator["IS"] = "IS";
    ConditionOperator["IS_NOT"] = "IS_NOT";
    ConditionOperator["OVER"] = "OVER";
    ConditionOperator["UNDER"] = "UNDER";
    ConditionOperator["INCLUDES"] = "INCLUDES";
    ConditionOperator["DOES_NOT_INCLUDE"] = "DOES_NOT_INCLUDE";
})(ConditionOperator || (ConditionOperator = {}));

class TargetOperatorOption {
}

class TargetWorkflowOptions {
}
var ConditionValueType;
(function (ConditionValueType) {
    ConditionValueType["NONE"] = "none";
    ConditionValueType["NUMBER"] = "number";
    ConditionValueType["SELECT"] = "select";
    ConditionValueType["STRING"] = "string";
    ConditionValueType["DATE"] = "date";
    ConditionValueType["CURRENCY"] = "currency";
})(ConditionValueType || (ConditionValueType = {}));

class TargetResult {
    constructor(isValid, conditionGroup) {
        this.isValid = isValid;
        this.conditionGroup = conditionGroup;
    }
}

class TargetConditionComponent extends BaseTextComponent {
    constructor(textService, changeDetector, fb, ngZone, windowService) {
        super(textService, 'ui-management-target-condition');
        this.textService = textService;
        this.changeDetector = changeDetector;
        this.fb = fb;
        this.ngZone = ngZone;
        this.windowService = windowService;
        this.groupId = '';
        this.subjectDropdownOptions = [];
        this.targetingOptions = [];
        this.locked = false;
        this.onDeleteGroupCondition = new EventEmitter();
        this.onUpdateGroupCondition = new EventEmitter();
        this.isMobile = false;
        this.isMultiValueRule = false;
        this.operatorDropdownOptions = [];
        this.valueLabel = '';
        this.valueHelpText = '';
        this.valueDropdownOptions = [];
        this.ConditionValueType = ConditionValueType;
        this.multiValueOperators = [ConditionOperator.DOES_NOT_INCLUDE, ConditionOperator.INCLUDES];
        this.windowService.windowSize$.pipe(this.takeUntilDestroyed()).subscribe(windowSize => {
            this.isMobile = windowSize.isMobile;
        });
    }
    ngOnInit() {
        this.form = this.fb.group({
            subject: [this.condition.leftOperand, Validators.required],
            rule: [this.condition.operator, Validators.required],
        });
        this.form.get('subject').valueChanges.subscribe(subject => this.onSubjectChanged(subject));
        this.form.get('rule').valueChanges.subscribe(rule => this.onRuleChanged(rule));
        if (this.condition.leftOperand) {
            this.onSubjectChanged(this.condition.leftOperand);
        }
    }
    ngOnChanges(changes) {
        if (changes.condition && this.form?.get('subject')) {
            this.form.get('subject').setValue(this.condition.leftOperand);
        }
    }
    ngAfterViewInit() {
        // AfterViewInit run may be before CSS renders completely, resulting in spacing errors, this adds a delay cycle
        this.ngZone.runOutsideAngular(() => setTimeout(() => this.ngZone.run(() => this.setSpacing())));
    }
    isValid() {
        return this.form.valid;
    }
    validate() {
        if (!this.isValid()) {
            FormUtils.showFormValidation(this.form);
            return new TargetResult(false, this.condition);
        }
        return new TargetResult(true, this.condition);
    }
    setSpacing() {
        const elements = this.getFormSpacingElements();
        if (elements.length > 1) {
            SpacingUtils.setSpacingPerRow(elements);
        }
    }
    getFormSpacingElements() {
        const elements = [];
        if (!this.isMobile) {
            elements.push(this.subjectDropdown.nativeElement);
        }
        if (this.ruleDropdown?.nativeElement) {
            elements.push(this.ruleDropdown.nativeElement);
        }
        if (this.valueType !== ConditionValueType.NONE && this.valueInput?.nativeElement) {
            elements.push(this.valueInput.nativeElement);
        }
        elements.push(this.deleteDiv.nativeElement);
        return [...elements].map(element => ({
            element,
            ...FormSpacingUtils.getSpacingConfig(element)
        }));
    }
    onSubjectChanged(subject) {
        if (!subject) {
            return; // empty init
        }
        const updated = this.condition.leftOperand !== subject;
        this.condition.leftOperand = subject;
        this.operatorDropdownOptions = TargetingUtils.toDropdownOptions(this.getOperatorOptions());
        this.changeDetector.detectChanges();
        if (updated) {
            this.condition.operator = null;
            this.form.get('rule').setValue(null);
            this.condition.rightOperand = null;
            this.form.get('value')?.setValue(null);
            this.onConditionUpdated();
        }
        else if (this.condition.operator) {
            this.onRuleChanged(this.condition.operator);
        }
    }
    onRuleChanged(rule) {
        const updated = this.condition.operator !== rule;
        this.condition.operator = rule;
        this.setupValueField();
        if (updated) {
            this.onConditionUpdated();
        }
    }
    onValueChanged(value) {
        const strValue = (value || value === 0) && value.toString() || '';
        const updated = this.condition.rightOperand !== strValue;
        this.condition.rightOperand = strValue;
        if (updated) {
            this.onConditionUpdated();
        }
    }
    onDeleteCondition() {
        this.onDeleteGroupCondition.emit({ condition: this.condition, groupId: this.groupId });
    }
    onConditionUpdated() {
        this.onUpdateGroupCondition.emit({ condition: this.condition, groupId: this.groupId });
        this.setSpacing();
    }
    getTargetWorkflowOption(subject) {
        return this.targetingOptions.find(option => option.subject === subject);
    }
    getOperatorOptions() {
        if (!this.condition.leftOperand) {
            return [];
        }
        const operators = this.getTargetWorkflowOption(this.condition.leftOperand).operators;
        const operatorOptions = operators.map(op => {
            if (op instanceof TargetOperatorOption) {
                return op;
            }
            else {
                return {
                    label: op['label'] || this.text['operatorLabel' + op] || op,
                    value: op['value'] || op
                };
            }
        });
        return operatorOptions;
    }
    setupValueField() {
        if (!this.condition.leftOperand || !this.condition.operator) {
            this.valueLabel = '';
            this.valueHelpText = '';
            this.valueType = ConditionValueType.NONE;
            this.setSpacing();
            return;
        }
        const isMultiValueRule = this.multiValueOperators.includes(this.condition.operator);
        const workflowOption = this.getTargetWorkflowOption(this.condition.leftOperand);
        this.valueLabel = workflowOption.valueLabel || '';
        this.valueType = isMultiValueRule ? ConditionValueType.STRING : workflowOption.valueDropdownOptions ? ConditionValueType.SELECT : workflowOption.valueType;
        this.valueHelpText = isMultiValueRule ? this.text.multipleValuesHelpText : '';
        this.valueDropdownOptions = workflowOption.valueDropdownOptions;
        if (this.valueType !== ConditionValueType.NONE) {
            this.form.addControl('value', new FormControl(this.condition.rightOperand, Validators.required));
            this.form.get('value').valueChanges.subscribe(value => this.onValueChanged(value));
        }
        else {
            this.form.removeControl('value');
        }
        this.changeDetector.detectChanges();
        this.setSpacing();
    }
    getDefaultText() {
        return {
            conditionLabel: 'Condition',
            multipleValuesHelpText: 'Enter Values Separated by Commas',
            operatorLabelDOES_NOT_INCLUDE: 'Is Not One Of',
            operatorLabelINCLUDES: 'Is One Of',
            operatorLabelIS_NOT: 'Is Not',
            operatorLabelIS: 'Is',
            operatorLabelOVER: 'Over or Equal To',
            operatorLabelUNDER: 'Under',
            removeConditionButtonAria: 'Remove Condition',
            ruleLabel: 'Rule',
            conditionErrorMessage: 'Select a Condition',
            ruleErrorMessage: 'Select a Rule',
            valueErrorMessage: 'Enter a Value'
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TargetConditionComponent, deps: [{ token: i1.TextService }, { token: i0.ChangeDetectorRef }, { token: i2.UntypedFormBuilder }, { token: i0.NgZone }, { token: i1.WindowService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.17", type: TargetConditionComponent, isStandalone: false, selector: "ui-management-target-condition", inputs: { condition: "condition", groupId: "groupId", subjectDropdownOptions: "subjectDropdownOptions", targetingOptions: "targetingOptions", locked: "locked" }, outputs: { onDeleteGroupCondition: "onDeleteGroupCondition", onUpdateGroupCondition: "onUpdateGroupCondition" }, viewQueries: [{ propertyName: "subjectDropdown", first: true, predicate: ["subjectDropdown"], descendants: true, read: ElementRef }, { propertyName: "ruleDropdown", first: true, predicate: ["ruleDropdown"], descendants: true, read: ElementRef }, { propertyName: "valueInput", first: true, predicate: ["valueInput"], descendants: true, read: ElementRef }, { propertyName: "deleteDiv", first: true, predicate: ["deleteDiv"], descendants: true }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div class=\"row pt-2 py-half bg-brand\" [formGroup]=\"form\">\n  <div class=\"col-md\">\n    <ui-forms-dropdown\n      #subjectDropdown\n      formControlName=\"subject\"\n      class=\"form-control-validation-m-0\"\n      [label]=\"text.conditionLabel\"\n      [options]=\"subjectDropdownOptions\"\n      [locked]=\"locked\"\n      [errorMessage]=\"text.conditionErrorMessage\" />\n  </div>\n\n  <div class=\"col-md col-sm-5 pl-md-2 pl-4 pr-0 pr-md-2\">\n    <ui-forms-dropdown *ngIf=\"condition.leftOperand\"\n      #ruleDropdown\n      formControlName=\"rule\"\n      class=\"form-control-validation-m-0\"\n      [label]=\"text.ruleLabel\"\n      [options]=\"operatorDropdownOptions\"\n      [locked]=\"locked\"\n      [errorMessage]=\"text.ruleErrorMessage\" />\n  </div>\n\n  <div class=\"col-md col-sm-5 pr-sm-0\">\n    <ui-forms-dropdown *ngIf=\"valueType === ConditionValueType.SELECT\"\n      #valueInput\n      formControlName=\"value\"\n      class=\"form-control-validation-m-0\"\n      [label]=\"valueLabel\"\n      [options]=\"valueDropdownOptions\"\n      [locked]=\"locked\"\n      [errorMessage]=\"text.valueErrorMessage\" />\n    <ui-forms-number-input *ngIf=\"valueType === ConditionValueType.NUMBER\"\n      #valueInput\n      formControlName=\"value\"\n      class=\"form-control-validation-m-0\"\n      [label]=\"valueLabel\"\n      [locked]=\"locked\"\n      [errorMessage]=\"text.valueErrorMessage\" />\n    <ui-forms-text-input *ngIf=\"valueType === ConditionValueType.STRING\"\n      #valueInput\n      formControlName=\"value\"\n      class=\"form-control-validation-m-0\"\n      [label]=\"valueLabel\"\n      [tooltip]=\"valueHelpText\"\n      [locked]=\"locked\"\n      [errorMessage]=\"text.valueErrorMessage\" />\n    <ui-forms-datepicker *ngIf=\"valueType === ConditionValueType.DATE\"\n      #valueInput\n      formControlName=\"value\"\n      class=\"form-control-validation-m-0\"\n      [label]=\"valueLabel\"\n      [allowToday]=\"true\"\n      [locked]=\"locked\"\n      [errorMessage]=\"text.valueErrorMessage\" />\n    <ui-forms-amount-input *ngIf=\"valueType === ConditionValueType.CURRENCY\"\n      #valueInput\n      formControlName=\"value\"\n      class=\"form-control-validation-m-0\"\n      [label]=\"valueLabel\"\n      [tooltip]=\"valueHelpText\"\n      [locked]=\"locked\"\n      [errorMessage]=\"text.valueErrorMessage\" />\n  </div>\n\n  <div class=\"col-sm-2 col-md-1 pb-4\">\n    <div #deleteDiv class=\"d-flex form-content-centered justify-content-end\">\n      <ui-core-icon-button\n        [message]=\"text.removeConditionButtonAria\"\n        icon=\"delete\"\n        class=\"form-content-container\"\n        [disabled]=\"locked\"\n        (click)=\"onDeleteCondition()\" />\n    </div>\n  </div>\n</div>\n", dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i1.IconButtonComponent, selector: "ui-core-icon-button", inputs: ["message", "icon", "size", "disabled", "buttonClass", "ariaPressed", "ariaExpanded", "ariaControls", "ariaHasPopup", "ariaActiveDescendantId", "e2e", "theme", "usesGlassHoverState", "buttonId"] }, { kind: "component", type: i5.AmountInputComponent, selector: "ui-forms-amount-input", inputs: ["decimalPlaces", "min", "hideIcon", "allowEmptyField"] }, { kind: "component", type: i5.DatepickerComponent, selector: "ui-forms-datepicker", inputs: ["actionButtonIcon", "actionButtonLabel", "afterDateText", "allowToday", "daysAfter", "daysPrior", "disableAllExceptFirstDayOfMonth", "disableAllExceptLastDayOfMonth", "disableAllExceptFifteenthAndLastDay", "disabledDaysOfMonth", "disabledDaysText", "disableFutureDates", "disableHolidays", "disablePastDates", "disableWeekends", "hideCalendar", "holidays", "iconLeft", "markedDate", "markedDateText", "maxDate", "minDate", "mobileDoneButtonLabel", "placeholder", "priorDateText", "selectedDateText"], outputs: ["actionButtonClick"] }, { kind: "component", type: i5.DropdownComponent, selector: "ui-forms-dropdown", inputs: ["iconLeft", "showMenuOptionAsIconLeft", "options", "noOptionsMessage", "actions", "menuIconsOnRight", "allowEmojis"], outputs: ["onMenuSelection"] }, { kind: "component", type: i5.NumberInputComponent, selector: "ui-forms-number-input", inputs: ["min", "max", "dayOfMonthPicker", "disabledPickerDays", "markedDay", "markedDayLabel", "selectedDayLabel", "disabledDaysText", "decimalPlaces"] }, { kind: "component", type: i5.TextInputComponent, selector: "ui-forms-text-input", inputs: ["maxLength", "fieldType", "actionButtonIcon", "actionButtonMessage", "actionButtonDisabled", "actionButtonDisabledSpinner", "criteria", "criteriaDescription", "options", "typeaheadFactory", "autocomplete", "postalCodeCountryAlpha2", "postalCodeRequired", "customMasking"], outputs: ["onActionButtonClick", "onMenuSelection"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TargetConditionComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-management-target-condition', template: "<div class=\"row pt-2 py-half bg-brand\" [formGroup]=\"form\">\n  <div class=\"col-md\">\n    <ui-forms-dropdown\n      #subjectDropdown\n      formControlName=\"subject\"\n      class=\"form-control-validation-m-0\"\n      [label]=\"text.conditionLabel\"\n      [options]=\"subjectDropdownOptions\"\n      [locked]=\"locked\"\n      [errorMessage]=\"text.conditionErrorMessage\" />\n  </div>\n\n  <div class=\"col-md col-sm-5 pl-md-2 pl-4 pr-0 pr-md-2\">\n    <ui-forms-dropdown *ngIf=\"condition.leftOperand\"\n      #ruleDropdown\n      formControlName=\"rule\"\n      class=\"form-control-validation-m-0\"\n      [label]=\"text.ruleLabel\"\n      [options]=\"operatorDropdownOptions\"\n      [locked]=\"locked\"\n      [errorMessage]=\"text.ruleErrorMessage\" />\n  </div>\n\n  <div class=\"col-md col-sm-5 pr-sm-0\">\n    <ui-forms-dropdown *ngIf=\"valueType === ConditionValueType.SELECT\"\n      #valueInput\n      formControlName=\"value\"\n      class=\"form-control-validation-m-0\"\n      [label]=\"valueLabel\"\n      [options]=\"valueDropdownOptions\"\n      [locked]=\"locked\"\n      [errorMessage]=\"text.valueErrorMessage\" />\n    <ui-forms-number-input *ngIf=\"valueType === ConditionValueType.NUMBER\"\n      #valueInput\n      formControlName=\"value\"\n      class=\"form-control-validation-m-0\"\n      [label]=\"valueLabel\"\n      [locked]=\"locked\"\n      [errorMessage]=\"text.valueErrorMessage\" />\n    <ui-forms-text-input *ngIf=\"valueType === ConditionValueType.STRING\"\n      #valueInput\n      formControlName=\"value\"\n      class=\"form-control-validation-m-0\"\n      [label]=\"valueLabel\"\n      [tooltip]=\"valueHelpText\"\n      [locked]=\"locked\"\n      [errorMessage]=\"text.valueErrorMessage\" />\n    <ui-forms-datepicker *ngIf=\"valueType === ConditionValueType.DATE\"\n      #valueInput\n      formControlName=\"value\"\n      class=\"form-control-validation-m-0\"\n      [label]=\"valueLabel\"\n      [allowToday]=\"true\"\n      [locked]=\"locked\"\n      [errorMessage]=\"text.valueErrorMessage\" />\n    <ui-forms-amount-input *ngIf=\"valueType === ConditionValueType.CURRENCY\"\n      #valueInput\n      formControlName=\"value\"\n      class=\"form-control-validation-m-0\"\n      [label]=\"valueLabel\"\n      [tooltip]=\"valueHelpText\"\n      [locked]=\"locked\"\n      [errorMessage]=\"text.valueErrorMessage\" />\n  </div>\n\n  <div class=\"col-sm-2 col-md-1 pb-4\">\n    <div #deleteDiv class=\"d-flex form-content-centered justify-content-end\">\n      <ui-core-icon-button\n        [message]=\"text.removeConditionButtonAria\"\n        icon=\"delete\"\n        class=\"form-content-container\"\n        [disabled]=\"locked\"\n        (click)=\"onDeleteCondition()\" />\n    </div>\n  </div>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i1.TextService }, { type: i0.ChangeDetectorRef }, { type: i2.UntypedFormBuilder }, { type: i0.NgZone }, { type: i1.WindowService }], propDecorators: { subjectDropdown: [{
                type: ViewChild,
                args: ['subjectDropdown', { read: ElementRef }]
            }], ruleDropdown: [{
                type: ViewChild,
                args: ['ruleDropdown', { read: ElementRef }]
            }], valueInput: [{
                type: ViewChild,
                args: ['valueInput', { read: ElementRef }]
            }], deleteDiv: [{
                type: ViewChild,
                args: ['deleteDiv']
            }], condition: [{
                type: Input
            }], groupId: [{
                type: Input
            }], subjectDropdownOptions: [{
                type: Input
            }], targetingOptions: [{
                type: Input
            }], locked: [{
                type: Input
            }], onDeleteGroupCondition: [{
                type: Output
            }], onUpdateGroupCondition: [{
                type: Output
            }] } });

class TargetOperatorComponent {
    constructor() {
        this.disabled = false;
        this.locked = false;
        this.andLabel = 'AND';
        this.orLabel = 'OR';
        this.value = TargetGroupOperator.AND;
        this.onChange = new EventEmitter();
        this.controlId = '';
        this.andValue = TargetGroupOperator.AND;
        this.orValue = TargetGroupOperator.OR;
        this.controlId = HtmlUtils.generateRandomId();
    }
    changeValue(value) {
        this.onChange.emit(value);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TargetOperatorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.17", type: TargetOperatorComponent, isStandalone: false, selector: "ui-management-target-operator", inputs: { disabled: "disabled", locked: "locked", andLabel: "andLabel", orLabel: "orLabel", value: "value" }, outputs: { onChange: "onChange" }, ngImport: i0, template: `
        <div class="text-nowrap">
            <fieldset role="radiogroup" [attr.aria-disabled]="disabled || locked" [attr.aria-labelledby]="controlId + '-legend'">
                <legend class="sr-only" [id]="controlId + '-legend'">Group Operator</legend>
                <input
                    type="radio"
                    [checked]="value === andValue"
                    class="sr-only"
                    [class.locked]="locked && !disabled"
                    [disabled]="disabled || locked"
                    [id]="controlId + 'a'"
                    [name]="controlId"
                    [value]="andValue"
                    (change)="changeValue($event.target.value)"
                />
                <label [for]="controlId + 'a'">{{ andLabel }}</label>
                <input
                    type="radio"
                    [checked]="value === orValue"
                    class="sr-only"
                    [class.locked]="locked && !disabled"
                    [disabled]="disabled || locked"
                    [id]="controlId + 'o'"
                    [name]="controlId"
                    [value]="orValue"
                    (change)="changeValue($event.target.value)"
                />
                <label [for]="controlId + 'o'">{{ orLabel }}</label>
            </fieldset>
      </div>
    `, isInline: true, styles: ["label{background-color:var(--neutral-bg-color);border:1px solid var(--gray-600);border-radius:4px 0 0 4px;color:var(--gray-600);font-size:16px;font-weight:var(--font-weight-bold);line-height:1.5;margin:0;padding:1px 8px;position:relative;transition-property:color,background-color,border-color;transition-duration:var(--transition-duration);transition-timing-function:var(--transition-timing)}label~label{margin-left:-1px;border-radius:0 4px 4px 0}label:hover{border-color:var(--brand-primary);color:var(--brand-primary);position:relative;z-index:1;cursor:pointer}input:focus:not(:checked)+label{border-color:var(--brand-primary);color:var(--brand-primary);position:relative;z-index:1}input:checked+label,input:checked+label:hover{background-color:var(--brand-primary-dark);border-color:var(--brand-primary-dark);color:var(--neutral-color);cursor:default}input:checked.locked+label{background-color:var(--btn-disabled);border-color:var(--btn-disabled);color:var(--btn-disabled-text)}input:disabled+label{background-color:var(--neutral-bg-color);border-color:var(--gray-300);color:var(--gray-300)}input:disabled+label,input.locked+label{pointer-events:none}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TargetOperatorComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-management-target-operator', template: `
        <div class="text-nowrap">
            <fieldset role="radiogroup" [attr.aria-disabled]="disabled || locked" [attr.aria-labelledby]="controlId + '-legend'">
                <legend class="sr-only" [id]="controlId + '-legend'">Group Operator</legend>
                <input
                    type="radio"
                    [checked]="value === andValue"
                    class="sr-only"
                    [class.locked]="locked && !disabled"
                    [disabled]="disabled || locked"
                    [id]="controlId + 'a'"
                    [name]="controlId"
                    [value]="andValue"
                    (change)="changeValue($event.target.value)"
                />
                <label [for]="controlId + 'a'">{{ andLabel }}</label>
                <input
                    type="radio"
                    [checked]="value === orValue"
                    class="sr-only"
                    [class.locked]="locked && !disabled"
                    [disabled]="disabled || locked"
                    [id]="controlId + 'o'"
                    [name]="controlId"
                    [value]="orValue"
                    (change)="changeValue($event.target.value)"
                />
                <label [for]="controlId + 'o'">{{ orLabel }}</label>
            </fieldset>
      </div>
    `, styles: ["label{background-color:var(--neutral-bg-color);border:1px solid var(--gray-600);border-radius:4px 0 0 4px;color:var(--gray-600);font-size:16px;font-weight:var(--font-weight-bold);line-height:1.5;margin:0;padding:1px 8px;position:relative;transition-property:color,background-color,border-color;transition-duration:var(--transition-duration);transition-timing-function:var(--transition-timing)}label~label{margin-left:-1px;border-radius:0 4px 4px 0}label:hover{border-color:var(--brand-primary);color:var(--brand-primary);position:relative;z-index:1;cursor:pointer}input:focus:not(:checked)+label{border-color:var(--brand-primary);color:var(--brand-primary);position:relative;z-index:1}input:checked+label,input:checked+label:hover{background-color:var(--brand-primary-dark);border-color:var(--brand-primary-dark);color:var(--neutral-color);cursor:default}input:checked.locked+label{background-color:var(--btn-disabled);border-color:var(--btn-disabled);color:var(--btn-disabled-text)}input:disabled+label{background-color:var(--neutral-bg-color);border-color:var(--gray-300);color:var(--gray-300)}input:disabled+label,input.locked+label{pointer-events:none}\n"] }]
        }], ctorParameters: () => [], propDecorators: { disabled: [{
                type: Input
            }], locked: [{
                type: Input
            }], andLabel: [{
                type: Input
            }], orLabel: [{
                type: Input
            }], value: [{
                type: Input
            }], onChange: [{
                type: Output
            }] } });

class TargetRuleComponent {
    constructor() {
        /**
        * Boolean - true if this is the first rule of a child group
        **/
        this.isSubGroup = false;
        /**
        * Text to display for the current active operator
        **/
        this.operator = '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TargetRuleComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.17", type: TargetRuleComponent, isStandalone: false, selector: "ui-management-target-rule", inputs: { isFirst: "isFirst", isSubGroup: "isSubGroup", operator: "operator" }, ngImport: i0, template: `
        <div class="label-rule-wrapper" [class.nested]="isSubGroup">
          <div class="cell-1" [class.mt-2]="isFirst && !isSubGroup">
            <span *ngIf="operator && !isFirst" class="operator-label">{{ operator }}</span>
          </div>
        </div>
    `, isInline: true, styles: [".label-rule-wrapper{display:grid;height:100%;width:36px;border-left:2px solid var(--stroke-light);margin-left:15px;margin-top:-1px}.label-rule-wrapper .cell-1{height:3.65rem;border-bottom:2px solid var(--stroke-light)}.label-rule-wrapper .cell-1 .operator-label{position:relative;top:2.65rem;background-color:#fff;color:var(--gray-400);font-size:10px;font-weight:var(--font-weight-bold);margin-left:4px;padding:0 2px;text-transform:uppercase}@media (min-width: 767px){.label-rule-wrapper.nested{width:52px}}.label-rule-wrapper.nested .cell-1{height:2.3rem}.label-rule-wrapper.nested .cell-1 .operator-label{top:1.3rem}\n"], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TargetRuleComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-management-target-rule', template: `
        <div class="label-rule-wrapper" [class.nested]="isSubGroup">
          <div class="cell-1" [class.mt-2]="isFirst && !isSubGroup">
            <span *ngIf="operator && !isFirst" class="operator-label">{{ operator }}</span>
          </div>
        </div>
    `, styles: [".label-rule-wrapper{display:grid;height:100%;width:36px;border-left:2px solid var(--stroke-light);margin-left:15px;margin-top:-1px}.label-rule-wrapper .cell-1{height:3.65rem;border-bottom:2px solid var(--stroke-light)}.label-rule-wrapper .cell-1 .operator-label{position:relative;top:2.65rem;background-color:#fff;color:var(--gray-400);font-size:10px;font-weight:var(--font-weight-bold);margin-left:4px;padding:0 2px;text-transform:uppercase}@media (min-width: 767px){.label-rule-wrapper.nested{width:52px}}.label-rule-wrapper.nested .cell-1{height:2.3rem}.label-rule-wrapper.nested .cell-1 .operator-label{top:1.3rem}\n"] }]
        }], propDecorators: { isFirst: [{
                type: Input
            }], isSubGroup: [{
                type: Input
            }], operator: [{
                type: Input
            }] } });

class TargetingComponent extends BaseTextComponent {
    constructor(textService, changeDetector) {
        super(textService, 'ui-management-targeting');
        this.textService = textService;
        this.changeDetector = changeDetector;
        /**
        * Array of TargetWorkflowOptions to define available conditions & rules, text & options
        */
        this.targetingOptions = [];
        /**
        * Specifies whether or not the component should be read-only. Locked fields cannot be modified by the user.
        **/
        this.locked = false;
        /**
        * emits full conditionGroup object on any change
        **/
        this.onChange = new EventEmitter();
        /**
        * internal Inputs & Outputs
        **/
        // used to determine if component is inside a parent group
        this._isSubGroup = false;
        // used to pass options recursively
        this._subjectDropdownOptions = [];
        // used to emit updates to the parent group
        this.onDeleteGroup = new EventEmitter();
        this.onDeleteGroupCondition = new EventEmitter();
        this.onUpdateGroupCondition = new EventEmitter();
        this.id = '';
    }
    ngOnChanges(changes) {
        if (changes.conditionGroup && this.conditionGroup) {
            this.id = this.conditionGroup.id;
            if (this.conditionGroup.conditions?.length > 0) {
                if (this.groupOperator) {
                    this.groupOperator.value = this.conditionGroup.groupOperator;
                }
            }
        }
        if (changes.targetingOptions) {
            const subjectOptions = [];
            this.targetingOptions.forEach(option => {
                subjectOptions.push({ label: option.label, value: option.subject });
                if (option.valueOptions) {
                    option.valueDropdownOptions = TargetingUtils.toDropdownOptions(option.valueOptions);
                }
            });
            this._subjectDropdownOptions = TargetingUtils.toDropdownOptions(subjectOptions);
        }
    }
    ngAfterViewInit() {
        if (this.conditionGroup) {
            // trigger update to parent form to validate pre-filled data & allow submit
            this.updateGroupOperator(this.conditionGroup.groupOperator);
            if (!this._isSubGroup) { // run validate only on the top-level group
                this.validate();
                this.changeDetector.detectChanges();
            }
        }
    }
    validate() {
        let foundError = false;
        const conditions = [...this.targetConditions];
        if (this.targetSubgroups) {
            this.targetSubgroups.forEach(group => {
                conditions.push(...group.targetConditions);
            });
        }
        conditions.forEach(condition => {
            const result = condition.validate();
            if (!result.isValid) {
                foundError = true;
            }
        });
        return new TargetResult(!foundError, this.conditionGroup);
    }
    createConditionGroup() {
        const group = new TargetConditionGroup();
        group.id = UuidUtils.create();
        group.groupOperator = TargetGroupOperator.AND;
        group.conditions = [];
        this.conditionGroup = group;
        this.id = group.id;
        this.addCondition(group.id);
    }
    addCondition(groupId) {
        const group = this.getConditionGroup(groupId);
        group.conditions.push({
            id: UuidUtils.create(),
            operator: undefined,
            leftOperand: undefined,
            rightOperand: undefined
        });
        this.onChange.emit(this.conditionGroup);
    }
    addGroup() {
        const id = UuidUtils.create();
        this.conditionGroup.conditions.push({
            id,
            groupOperator: TargetGroupOperator.OR,
            conditions: []
        });
        this.addCondition(id);
    }
    deleteGroup(groupId) {
        if (this._isSubGroup) {
            this.onDeleteGroup.emit(groupId);
            return;
        }
        this.conditionGroup.conditions = this.conditionGroup.conditions.filter(condition => condition.id !== groupId);
        if (this.conditionGroup.conditions.length === 0) {
            this.conditionGroup = null;
        }
        this.onChange.emit(this.conditionGroup);
    }
    deleteGroupCondition(cData) {
        if (this._isSubGroup) {
            this.onDeleteGroupCondition.emit(cData);
            return;
        }
        let group = this.getConditionGroup(cData.condition.id, true);
        group.conditions = group.conditions.filter(condition => condition.id !== cData.condition.id);
        if (group.conditions.length === 0) {
            this.deleteGroup(group.id);
            return;
        }
        this.onChange.emit(this.conditionGroup);
    }
    updateGroupCondition(cData) {
        if (this._isSubGroup) {
            this.onUpdateGroupCondition.emit(cData);
            return;
        }
        let group = this.getConditionGroup(cData.condition.id, true);
        const index = group.conditions.findIndex(value => value.id === cData.condition.id);
        if (index >= 0) {
            group.conditions.splice(index, 1, cData.condition);
        }
        this.onChange.emit(this.conditionGroup);
    }
    updateGroupOperator(operator) {
        this.conditionGroup.groupOperator = operator;
        this.onChange.emit(this.conditionGroup);
    }
    getConditionGroup(id, getParent = false) {
        let group;
        if (this.conditionGroup.id === id) {
            group = this.conditionGroup;
        }
        this.conditionGroup.conditions.forEach(condition => {
            if (condition.id === id) {
                group = getParent ? this.conditionGroup : condition;
            }
            else {
                condition.conditions?.forEach(subCondition => {
                    if (subCondition.id === id) {
                        group = condition;
                    }
                });
            }
        });
        return group;
    }
    getDefaultText() {
        return {
            addConditionButtonLabel: 'Add Rule',
            addGroupButtonLabel: 'Add Group',
            deleteGroupButtonLabel: 'Delete Group',
            operatorAndLabel: 'AND',
            operatorOrLabel: 'OR'
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TargetingComponent, deps: [{ token: i1.TextService }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.17", type: TargetingComponent, isStandalone: false, selector: "ui-management-targeting", inputs: { targetingOptions: "targetingOptions", conditionGroup: "conditionGroup", locked: "locked", _isSubGroup: "_isSubGroup", _subjectDropdownOptions: "_subjectDropdownOptions" }, outputs: { onChange: "onChange", onDeleteGroup: "onDeleteGroup", onDeleteGroupCondition: "onDeleteGroupCondition", onUpdateGroupCondition: "onUpdateGroupCondition" }, viewQueries: [{ propertyName: "groupOperator", first: true, predicate: ["groupOperator"], descendants: true }, { propertyName: "targetConditions", predicate: TargetConditionComponent, descendants: true }, { propertyName: "targetSubgroups", predicate: ["targetSubgroup"], descendants: true }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div class=\"condition-group w-100 mt-3\">\n  <ng-container *ngIf=\"conditionGroup\">\n    <ui-management-target-operator *ngIf=\"conditionGroup.conditions?.length > 0\"\n      #groupOperator\n      [disabled]=\"conditionGroup.conditions.length <= 1\"\n      [andLabel]=\"text.operatorAndLabel\"\n      [orLabel]=\"text.operatorOrLabel\"\n      class=\"d-flex mt-half\"\n      [value]=\"conditionGroup.groupOperator\"\n      [locked]=\"locked\"\n      (onChange)=\"updateGroupOperator($event)\" />\n    <div *ngFor=\"let condition of conditionGroup.conditions; let first = first; let last = last\" class=\"conditions d-flex w-100\">\n      <ui-management-target-rule \n        [operator]=\"conditionGroup.conditions.length > 1 && conditionGroup.groupOperator\" \n        [isFirst]=\"first\" \n        [isSubGroup]=\"condition.conditions\">\n      </ui-management-target-rule>\n      <ui-management-target-condition *ngIf=\"!condition.conditions\"\n        [condition]=\"condition\"\n        [subjectDropdownOptions]=\"_subjectDropdownOptions\"\n        [targetingOptions]=\"targetingOptions\"\n        [groupId]=\"id\"\n        [locked]=\"locked\"\n        class=\"container ml-0 px-0 px-lg-2 mb-half\"\n        [class.pt-2]=\"first\"\n        [class.pb-2]=\"last\"\n        [class.mb-1]=\"last\"\n        (onDeleteGroupCondition)=\"deleteGroupCondition($event)\"\n        (onUpdateGroupCondition)=\"updateGroupCondition($event)\">\n      </ui-management-target-condition>\n      <ui-management-targeting *ngIf=\"condition.conditions\"\n        #targetSubgroup\n        [conditionGroup]=\"condition\"\n        [_isSubGroup]=\"true\"\n        [_subjectDropdownOptions]=\"_subjectDropdownOptions\"\n        [targetingOptions]=\"targetingOptions\"\n        [locked]=\"locked\"\n        class=\"d-flex w-100\"\n        (onDeleteGroup)=\"deleteGroup($event)\"\n        (onDeleteGroupCondition)=\"deleteGroupCondition($event)\"\n        (onUpdateGroupCondition)=\"updateGroupCondition($event)\"\n        (onChange)=\"onChange.emit(conditionGroup)\" />\n    </div>\n  </ng-container>\n  <ui-core-button-group\n    [primaryButtonText]=\"conditionGroup ? text.addConditionButtonLabel : null\"\n    (onPrimaryButtonClick)=\"addCondition(id)\"\n    [secondaryButtonText]=\"!conditionGroup ? text.addConditionButtonLabel : null\"\n    (onSecondaryButtonClick)=\"createConditionGroup()\"\n    [tertiaryButtonText]=\"!conditionGroup ? null : _isSubGroup ? text.deleteGroupButtonLabel : text.addGroupButtonLabel\"\n    [tertiaryButtonIcon]=\"_isSubGroup ? 'delete' : 'library_add'\"\n    (onTertiaryButtonClick)=\"_isSubGroup ? deleteGroup(id) : addGroup()\"\n    [disableButtons]=\"locked\"\n    [showPrimarySpinner]=\"false\"\n    [showSecondarySpinner]=\"false\"\n    [marginTop]=\"false\"\n    [marginBottom]=\"_isSubGroup\" />\n</div>\n", styles: [".condition-group{max-width:1200px}\n"], dependencies: [{ kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i1.ButtonGroupComponent, selector: "ui-core-button-group", inputs: ["disableButtons", "primaryButtonText", "primaryButtonDisabledText", "primaryButtonIcon", "primaryButtonIconPosition", "showPrimarySpinner", "primaryButtonUrl", "primaryButtonUrlParams", "primaryButtonUsesExternalUrlNewTab", "secondaryButtonText", "secondaryButtonIcon", "secondaryButtonIconPosition", "showSecondarySpinner", "secondaryButtonTheme", "secondaryButtonUrl", "secondaryButtonUrlParams", "secondaryButtonUsesExternalUrlNewTab", "tertiaryButtonText", "tertiaryButtonIcon", "tertiaryButtonIconPosition", "showTertiarySpinner", "tertiaryButtonTheme", "tertiaryButtonUrl", "tertiaryButtonUrlParams", "tertiaryButtonUsesExternalUrlNewTab", "isFormValid", "withinFormRenderer", "errorMessages", "e2e", "marginBottom", "marginTop", "stacked"], outputs: ["onPrimaryButtonClick", "onSecondaryButtonClick", "onTertiaryButtonClick"] }, { kind: "component", type: TargetConditionComponent, selector: "ui-management-target-condition", inputs: ["condition", "groupId", "subjectDropdownOptions", "targetingOptions", "locked"], outputs: ["onDeleteGroupCondition", "onUpdateGroupCondition"] }, { kind: "component", type: TargetingComponent, selector: "ui-management-targeting", inputs: ["targetingOptions", "conditionGroup", "locked", "_isSubGroup", "_subjectDropdownOptions"], outputs: ["onChange", "onDeleteGroup", "onDeleteGroupCondition", "onUpdateGroupCondition"] }, { kind: "component", type: TargetOperatorComponent, selector: "ui-management-target-operator", inputs: ["disabled", "locked", "andLabel", "orLabel", "value"], outputs: ["onChange"] }, { kind: "component", type: TargetRuleComponent, selector: "ui-management-target-rule", inputs: ["isFirst", "isSubGroup", "operator"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: TargetingComponent, decorators: [{
            type: Component,
            args: [{ standalone: false, selector: 'ui-management-targeting', template: "<div class=\"condition-group w-100 mt-3\">\n  <ng-container *ngIf=\"conditionGroup\">\n    <ui-management-target-operator *ngIf=\"conditionGroup.conditions?.length > 0\"\n      #groupOperator\n      [disabled]=\"conditionGroup.conditions.length <= 1\"\n      [andLabel]=\"text.operatorAndLabel\"\n      [orLabel]=\"text.operatorOrLabel\"\n      class=\"d-flex mt-half\"\n      [value]=\"conditionGroup.groupOperator\"\n      [locked]=\"locked\"\n      (onChange)=\"updateGroupOperator($event)\" />\n    <div *ngFor=\"let condition of conditionGroup.conditions; let first = first; let last = last\" class=\"conditions d-flex w-100\">\n      <ui-management-target-rule \n        [operator]=\"conditionGroup.conditions.length > 1 && conditionGroup.groupOperator\" \n        [isFirst]=\"first\" \n        [isSubGroup]=\"condition.conditions\">\n      </ui-management-target-rule>\n      <ui-management-target-condition *ngIf=\"!condition.conditions\"\n        [condition]=\"condition\"\n        [subjectDropdownOptions]=\"_subjectDropdownOptions\"\n        [targetingOptions]=\"targetingOptions\"\n        [groupId]=\"id\"\n        [locked]=\"locked\"\n        class=\"container ml-0 px-0 px-lg-2 mb-half\"\n        [class.pt-2]=\"first\"\n        [class.pb-2]=\"last\"\n        [class.mb-1]=\"last\"\n        (onDeleteGroupCondition)=\"deleteGroupCondition($event)\"\n        (onUpdateGroupCondition)=\"updateGroupCondition($event)\">\n      </ui-management-target-condition>\n      <ui-management-targeting *ngIf=\"condition.conditions\"\n        #targetSubgroup\n        [conditionGroup]=\"condition\"\n        [_isSubGroup]=\"true\"\n        [_subjectDropdownOptions]=\"_subjectDropdownOptions\"\n        [targetingOptions]=\"targetingOptions\"\n        [locked]=\"locked\"\n        class=\"d-flex w-100\"\n        (onDeleteGroup)=\"deleteGroup($event)\"\n        (onDeleteGroupCondition)=\"deleteGroupCondition($event)\"\n        (onUpdateGroupCondition)=\"updateGroupCondition($event)\"\n        (onChange)=\"onChange.emit(conditionGroup)\" />\n    </div>\n  </ng-container>\n  <ui-core-button-group\n    [primaryButtonText]=\"conditionGroup ? text.addConditionButtonLabel : null\"\n    (onPrimaryButtonClick)=\"addCondition(id)\"\n    [secondaryButtonText]=\"!conditionGroup ? text.addConditionButtonLabel : null\"\n    (onSecondaryButtonClick)=\"createConditionGroup()\"\n    [tertiaryButtonText]=\"!conditionGroup ? null : _isSubGroup ? text.deleteGroupButtonLabel : text.addGroupButtonLabel\"\n    [tertiaryButtonIcon]=\"_isSubGroup ? 'delete' : 'library_add'\"\n    (onTertiaryButtonClick)=\"_isSubGroup ? deleteGroup(id) : addGroup()\"\n    [disableButtons]=\"locked\"\n    [showPrimarySpinner]=\"false\"\n    [showSecondarySpinner]=\"false\"\n    [marginTop]=\"false\"\n    [marginBottom]=\"_isSubGroup\" />\n</div>\n", styles: [".condition-group{max-width:1200px}\n"] }]
        }], ctorParameters: () => [{ type: i1.TextService }, { type: i0.ChangeDetectorRef }], propDecorators: { groupOperator: [{
                type: ViewChild,
                args: ['groupOperator', { static: false }]
            }], targetConditions: [{
                type: ViewChildren,
                args: [TargetConditionComponent]
            }], targetSubgroups: [{
                type: ViewChildren,
                args: ['targetSubgroup']
            }], targetingOptions: [{
                type: Input
            }], conditionGroup: [{
                type: Input
            }], locked: [{
                type: Input
            }], onChange: [{
                type: Output
            }], _isSubGroup: [{
                type: Input
            }], _subjectDropdownOptions: [{
                type: Input
            }], onDeleteGroup: [{
                type: Output
            }], onDeleteGroupCondition: [{
                type: Output
            }], onUpdateGroupCondition: [{
                type: Output
            }] } });

class TargetGroupData {
}

class TargetOption {
}

class UiManagementModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: UiManagementModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.17", ngImport: i0, type: UiManagementModule, declarations: [DragAndDropListComponent,
            HeaderComponent,
            HtmlEditorComponent,
            JsonDiffComponent,
            JsonEditorComponent,
            MarkdownEditorComponent,
            PanelListComponent,
            SearchBarComponent,
            TargetConditionComponent,
            TargetingComponent,
            TargetOperatorComponent,
            TargetRuleComponent], imports: [CommonModule,
            DragDropModule,
            FormsModule, i4$2.MonacoEditorModule, NgbModule, i4.QuillModule, ReactiveFormsModule,
            UiCoreModule,
            UiFormsModule], exports: [DragAndDropListComponent,
            HeaderComponent,
            HtmlEditorComponent,
            JsonDiffComponent,
            JsonEditorComponent,
            MarkdownEditorComponent,
            PanelListComponent,
            SearchBarComponent,
            TargetingComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: UiManagementModule, imports: [CommonModule,
            DragDropModule,
            FormsModule,
            MonacoEditorModule.forRoot(),
            NgbModule,
            QuillModule.forRoot(),
            ReactiveFormsModule,
            UiCoreModule,
            UiFormsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.17", ngImport: i0, type: UiManagementModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        DragAndDropListComponent,
                        HeaderComponent,
                        HtmlEditorComponent,
                        JsonDiffComponent,
                        JsonEditorComponent,
                        MarkdownEditorComponent,
                        PanelListComponent,
                        SearchBarComponent,
                        TargetConditionComponent,
                        TargetingComponent,
                        TargetOperatorComponent,
                        TargetRuleComponent
                    ],
                    imports: [
                        CommonModule,
                        DragDropModule,
                        FormsModule,
                        MonacoEditorModule.forRoot(),
                        NgbModule,
                        QuillModule.forRoot(),
                        ReactiveFormsModule,
                        UiCoreModule,
                        UiFormsModule
                    ],
                    exports: [
                        DragAndDropListComponent,
                        HeaderComponent,
                        HtmlEditorComponent,
                        JsonDiffComponent,
                        JsonEditorComponent,
                        MarkdownEditorComponent,
                        PanelListComponent,
                        SearchBarComponent,
                        TargetingComponent
                    ]
                }]
        }] });

/*
 * Public API Surface of ui-management
 */
// Components

/**
 * Generated bundle index. Do not edit.
 */

export { ConditionOperator, ConditionValueType, DragAndDropListComponent, DragAndDropListItem, DragAndDropListResult, HeaderComponent, HtmlEditorAction, HtmlEditorComponent, JsonDiffComponent, JsonEditorComponent, MarkdownEditorComponent, PanelListComponent, PanelListItem, SearchBarComponent, TargetCondition, TargetConditionGroup, TargetGroupData, TargetGroupOperator, TargetOperatorOption, TargetOption, TargetResult, TargetWorkflowOptions, TargetingComponent, UiManagementModule };
//# sourceMappingURL=a3-digital-ui-management.mjs.map
